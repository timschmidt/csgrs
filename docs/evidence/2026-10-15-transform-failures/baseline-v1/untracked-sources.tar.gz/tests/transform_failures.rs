//! Transform failure is not a successfully constructed (possibly empty) model.
use csgrs::{
    Real, TriangleMesh,
    adapter::{AdapterError, RawTriangleMesh},
    errors::ValidationError,
    solid::{self, SolidExt},
};
use hyperlattice::{Matrix4, Point3};
use hypermesh::{MeshContext, Plane, Triangle};
use std::error::Error;

// Lets the same assertions reproduce the old infallible API and qualify its migration.
trait CheckedTransform {
    fn checked(self) -> Result<TriangleMesh, ValidationError>;
}

impl CheckedTransform for TriangleMesh {
    fn checked(self) -> Result<TriangleMesh, ValidationError> {
        Ok(self)
    }
}

impl CheckedTransform for Result<TriangleMesh, ValidationError> {
    fn checked(self) -> Result<TriangleMesh, ValidationError> {
        self
    }
}

fn malformed() -> TriangleMesh {
    TriangleMesh::new(vec![Point3::origin()], vec![Triangle::new(0, 1, 0)])
}

fn reciprocal_x() -> Matrix4 {
    // (x, y, z) -> (1/x, y/x, z/x). Invertible, but undefined on x = 0.
    Matrix4::from_row_major([0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0].map(Real::from))
}

#[test]
fn singular_transform_is_a_failure_even_for_empty_input() {
    let singular = Matrix4::affine_nonuniform_scale([Real::zero(), Real::one(), Real::one()]);
    for mesh in [solid::empty(), solid::cube(Real::one()).unwrap()] {
        assert!(solid::transform(&mesh, &singular).checked().is_err());
        assert!(mesh.transformed(&singular).checked().is_err());
        assert!(
            solid::scale(&mesh, Real::zero(), Real::one(), Real::one())
                .checked()
                .is_err()
        );
    }
}

#[test]
fn invalid_plane_does_not_become_empty_geometry() {
    let invalid =
        Plane::from_coefficients(Real::zero(), Real::zero(), Real::zero(), Real::one());
    assert!(
        solid::mirror(&solid::cube(Real::one()).unwrap(), &invalid)
            .checked()
            .is_err()
    );
}

#[test]
fn native_transforms_reject_invalid_indices() {
    let mesh = malformed();
    let context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
    assert!(mesh.try_transformed(&context, &Matrix4::identity()).is_err());
    assert!(
        mesh.try_rotated_xyz_degrees(&context, Real::zero(), Real::zero(), Real::zero())
            .is_err()
    );
}

#[test]
fn modeling_transforms_reject_invalid_indices() {
    let mesh = malformed();
    assert!(
        mesh.translated(Real::one(), Real::zero(), Real::zero())
            .checked()
            .is_err()
    );
    assert!(
        solid::rotate(&mesh, Real::zero(), Real::zero(), Real::zero())
            .checked()
            .is_err()
    );
}

#[test]
fn projective_triangle_cannot_cross_infinity_between_finite_vertices() {
    let mesh = TriangleMesh::new(
        vec![
            Point3::new((-1).into(), 0.into(), 0.into()),
            Point3::new(1.into(), 0.into(), 0.into()),
            Point3::new(1.into(), 1.into(), 0.into()),
        ],
        vec![Triangle::new(0, 1, 2)],
    );
    let context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
    // Its edge contains x = 0, although every supplied vertex has nonzero x.
    assert!(mesh.try_transformed(&context, &reciprocal_x()).is_err());
    assert!(solid::transform(&mesh, &reciprocal_x()).checked().is_err());
}

#[test]
fn adapter_preserves_the_native_validation_payload() {
    let cube = RawTriangleMesh::cube(Real::one()).unwrap();
    let error = cube
        .scale(Real::zero(), Real::one(), Real::one())
        .unwrap_err();
    assert!(matches!(
        error,
        AdapterError::Construction(ValidationError::InvalidArguments)
    ));
    assert!(
        error
            .source()
            .unwrap()
            .downcast_ref::<ValidationError>()
            .is_some()
    );
}
