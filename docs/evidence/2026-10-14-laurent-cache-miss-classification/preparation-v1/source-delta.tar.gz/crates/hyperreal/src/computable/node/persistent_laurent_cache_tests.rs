use super::*;

fn raw(approximation: Approximation) -> Computable {
    Computable {
        internal: Arc::new(Node::new(
            approximation,
            BoundCache::Invalid,
            ExactSignCache::Unknown,
        )),
        signal: None,
    }
}

fn rational(polynomial: PiLaurentPolynomial) -> Option<Rational> {
    match polynomial.terms.as_slice() {
        [] => Some(Rational::zero()),
        [(0, coefficient)] if coefficient.radicals.is_empty() && coefficient.atoms.is_empty() => {
            Some(coefficient.rational.clone())
        }
        _ => None,
    }
}

fn retained_query(
    value: &Computable,
    depth: usize,
    work: usize,
) -> (Option<PiLaurentPolynomial>, usize, bool) {
    let mut remaining = work;
    let mut reused = false;
    let result =
        value.pi_laurent_polynomial_retained::<true>(depth, &mut remaining, &mut None, &mut reused);
    (result, remaining, reused)
}

#[test]
fn warm_proof_is_available_with_no_new_work() {
    let value = raw(Approximation::Add(
        Computable::rational(Rational::new(3)),
        Computable::rational(Rational::new(5)),
    ));
    let clone = value.clone();
    let owners = Arc::strong_count(&value.internal);
    assert!(value.pi_laurent_polynomial(0).is_none());
    assert!(retained_query(&value, 0, 0).0.is_none());
    assert!(value.internal.cache.pi_laurent_polynomial().is_none());
    assert_eq!(
        retained_query(&value, 8, 512).0.and_then(rational),
        Some(Rational::new(8))
    );
    let (proof, remaining, reused) = retained_query(&clone, 0, 0);
    assert!(reused);
    assert_eq!(remaining, 0);
    assert_eq!(proof.and_then(rational), Some(Rational::new(8)));
    assert_eq!(clone.bounded_laurent_rational(0), Some(Rational::new(8)));
    assert_eq!(Arc::strong_count(&value.internal), owners);
    assert!(value.cached().is_none());
}

#[test]
fn opaque_coefficients_are_not_retained_and_nodes_are_reclaimed() {
    let atom = raw(Approximation::AtanRational(
        Rational::fraction(3, 4).unwrap(),
    ));
    let value = raw(Approximation::Add(atom.clone(), Computable::pi()));
    let clone = value.clone();
    let atom_weak = Arc::downgrade(&atom.internal);
    let value_weak = Arc::downgrade(&value.internal);
    let owners = Arc::strong_count(&atom.internal);
    let polynomial = retained_query(&value, 64, 512).0.unwrap();
    assert!(ClosedPiLaurentPolynomial::from_polynomial(&polynomial).is_none());
    assert!(value.internal.cache.pi_laurent_polynomial().is_none());
    drop(polynomial);
    assert_eq!(Arc::strong_count(&atom.internal), owners);
    drop(value);
    drop(clone);
    drop(atom);
    assert!(value_weak.upgrade().is_none());
    assert!(atom_weak.upgrade().is_none());
}

#[test]
fn expansion_at_a_term_limit_retries_the_original_proof() {
    let mut power = Computable::one();
    let mut sum = Computable::zero();
    for _ in 0..8 {
        sum = raw(Approximation::Add(sum, power.clone()));
        power = raw(Approximation::Multiply(power, Computable::pi()));
    }
    // ((x + y) - x) - y is zero. At depth four the cold recognizer can
    // cancel opaque x/y atoms. Warming x/y expands nine distinct pi powers,
    // exceeding the unchanged eight-term limit before cancellation.
    let expression = raw(Approximation::Add(
        raw(Approximation::Add(
            raw(Approximation::Add(sum.clone(), power.clone())),
            raw(Approximation::Negate(sum.clone())),
        )),
        raw(Approximation::Negate(power.clone())),
    ));
    assert_eq!(
        expression.pi_laurent_polynomial(4).and_then(rational),
        Some(Rational::zero())
    );
    assert!(retained_query(&sum, 64, 512).0.is_some());
    assert!(retained_query(&power, 64, 512).0.is_some());
    let (expanded, _, reused) = retained_query(&expression, 4, 512);
    assert!(reused);
    assert!(expanded.and_then(rational).is_none());
    assert_eq!(
        expression.bounded_laurent_rational(4),
        Some(Rational::zero())
    );
    assert!(expression.cached().is_none());
}

#[test]
fn successful_cold_rational_facts_survive_warming_and_cloning() {
    for width in [1, 2, 7, 8, 9, 127, 255, 256, 257, 511, 512, 513] {
        for depth in [0, 1, 2, 4, 8, 48, 64] {
            let mut nodes = (0..width)
                .map(|index| {
                    raw(Approximation::Ratio(
                        Rational::fraction(index + 1, 4099).unwrap(),
                    ))
                })
                .collect::<Vec<_>>();
            while nodes.len() > 1 {
                let mut next = Vec::new();
                let mut values = nodes.into_iter();
                while let Some(left) = values.next() {
                    next.push(match values.next() {
                        Some(right) => raw(Approximation::Add(left, right)),
                        None => left,
                    });
                }
                nodes = next;
            }
            let value = nodes.pop().unwrap();
            let clone = value.clone();
            let cold = value.pi_laurent_polynomial(depth).and_then(rational);
            let expected = Rational::fraction(width * (width + 1), 2 * 4099).unwrap();
            for query in [&value, &clone, &value] {
                let actual = query.bounded_laurent_rational(depth);
                if let Some(cold) = &cold {
                    assert_eq!(actual.as_ref(), Some(cold), "width={width}, depth={depth}");
                }
                if let Some(actual) = actual {
                    assert_eq!(actual, expected, "width={width}, depth={depth}");
                }
                let _ = retained_query(query, 64, 512);
            }
            assert!(value.cached().is_none());
        }
    }
}

#[test]
fn concurrent_publication_keeps_approximations_and_releases_the_graph() {
    let value = raw(Approximation::Add(
        Computable::rational(Rational::new(3)),
        Computable::sqrt_rational(Rational::new(13)),
    ));
    let weak = Arc::downgrade(&value.internal);
    std::thread::scope(|scope| {
        for index in 0..8 {
            let clone = value.clone();
            scope.spawn(move || {
                for _ in 0..8 {
                    assert_eq!(
                        clone.exact_quadratic_surd_parts(),
                        Some((Rational::new(3), Rational::one(), Some(Rational::new(13))))
                    );
                    let _ = clone.approx(if index % 2 == 0 { -32 } else { -64 });
                }
            });
        }
    });
    assert_eq!(value.cached().unwrap().0, -64);
    assert!(value.internal.cache.pi_laurent_polynomial().is_some());
    assert_eq!(
        value.exact_quadratic_surd_parts(),
        Some((Rational::new(3), Rational::one(), Some(Rational::new(13))))
    );
    drop(value);
    assert!(weak.upgrade().is_none());
}

#[test]
fn integer_leaf_values_survive_word_boundaries_warming_and_cloning() {
    let mut integers = [-65_i64, -64, -2, -1, 0, 1, 2, 64, 65]
        .into_iter()
        .map(BigInt::from)
        .collect::<Vec<_>>();
    for bits in [7_usize, 63, 64, 127, 255, 1024] {
        for offset in [-1_i32, 0, 1] {
            let magnitude = (BigInt::one() << bits) + offset;
            integers.push(magnitude.clone());
            integers.push(-magnitude);
        }
    }
    for integer in integers {
        let value = raw(Approximation::Int(integer.clone()));
        let clone = value.clone();
        for query in [&value, &clone, &value] {
            let exact = query.exact_rational().unwrap();
            // Compare the independent integer payload, including values
            // immediately outside signed conversion and canonical-table bounds.
            assert_eq!(exact.to_big_integer().as_ref(), Some(&integer));
            assert_eq!(query.bounded_laurent_rational(2).unwrap(), exact);
        }
        assert!(value.cached().is_none());
        let weak = Arc::downgrade(&value.internal);
        drop(clone);
        drop(value);
        assert!(weak.upgrade().is_none());
    }
}

#[test]
fn diagnostic_cache_counters_observe_publication_and_zero_work_replay() {
    use crate::construction_cache_trace::{Event, with_recording};
    let value = raw(Approximation::Add(
        Computable::rational(Rational::new(3)),
        Computable::rational(Rational::new(5)),
    ));
    let clone = value.clone();
    let (first, cold) = with_recording(|| retained_query(&value, 8, 512));
    assert_eq!(first.0.and_then(rational), Some(Rational::new(8)));
    assert!(!first.2);
    assert!(cold[Event::RetainedLookup as usize] > 0);
    assert_eq!(cold[Event::RetainedHit as usize], 0);
    assert_eq!(cold[Event::ClosedCopySuccess as usize], 1);
    assert_eq!(cold[Event::StorePublished as usize], 1);
    assert_eq!(cold[Event::EvaluationCellAllocated as usize], 1);
    assert_eq!(cold[Event::EvaluationCellPublished as usize], 1);
    assert_eq!(cold[Event::EvaluationCellRaceLost as usize], 0);
    assert_eq!(
        cold[Event::EvaluationCellRequestedBytes as usize],
        std::mem::size_of::<std::sync::RwLock<CachedEvaluation>>() as u64
    );
    let (warm, replay) = with_recording(|| retained_query(&clone, 0, 0));
    assert_eq!(warm.0.and_then(rational), Some(Rational::new(8)));
    assert_eq!(warm.1, 0);
    assert!(warm.2);
    assert_eq!(replay[Event::RetainedLookup as usize], 1);
    assert_eq!(replay[Event::RetainedHit as usize], 1);
    assert_eq!(replay[Event::RetainedTermsCopied as usize], 1);
    assert_eq!(replay[Event::RetainedRadicalsCopied as usize], 0);
    assert_eq!(replay[Event::StoreAttempt as usize], 0);
    assert_eq!(replay[Event::EvaluationCellAllocated as usize], 0);
    assert_eq!(replay[Event::NormalizerWorkVisit as usize], 0);
    assert_eq!(replay[Event::NormalizerBudgetDecline as usize], 0);
}

#[test]
fn diagnostic_lookup_classes_observe_actual_cache_states() {
    use crate::construction_cache_trace::{
        Event, LOOKUP_KIND_NAMES, lookup_counts, with_recording,
    };

    fn expect_classes(expected: &[(&str, [u64; 3])]) {
        let mut counts = [[0; 3]; LOOKUP_KIND_NAMES.len()];
        for (name, outcomes) in expected {
            let index = LOOKUP_KIND_NAMES
                .iter()
                .position(|kind| kind == name)
                .unwrap();
            counts[index] = *outcomes;
        }
        assert_eq!(lookup_counts(), counts);
    }

    let leaf = raw(Approximation::Ratio(Rational::new(7)));
    let (direct, counts) = with_recording(|| leaf.internal.cache.pi_laurent_polynomial());
    assert!(direct.is_none());
    assert_eq!(counts[Event::RetainedLookup as usize], 1);
    expect_classes(&[("Unclassified", [1, 0, 0])]);

    let (empty, counts) = with_recording(|| retained_query(&leaf, 0, 0));
    assert!(empty.0.is_none());
    assert_eq!(counts[Event::RetainedLookup as usize], 1);
    assert_eq!(counts[Event::NormalizerBudgetDecline as usize], 1);
    expect_classes(&[("Ratio", [1, 0, 0])]);

    leaf.internal.cache.store(-32, leaf.approx(-32));
    let cached = leaf.cached();
    assert!(cached.is_some());
    let (initialized, counts) = with_recording(|| retained_query(&leaf, 0, 0));
    assert!(initialized.0.is_none());
    assert_eq!(counts[Event::RetainedLookup as usize], 1);
    assert_eq!(counts[Event::NormalizerBudgetDecline as usize], 1);
    assert_eq!(leaf.cached(), cached);
    expect_classes(&[("Ratio", [0, 1, 0])]);

    let value = raw(Approximation::Add(
        raw(Approximation::Ratio(Rational::new(3))),
        raw(Approximation::Ratio(Rational::new(5))),
    ));
    let clone = value.clone();
    let weak = Arc::downgrade(&value.internal);
    let (empty, counts) = with_recording(|| retained_query(&value, 0, 0));
    assert!(empty.0.is_none());
    assert_eq!(counts[Event::RetainedLookup as usize], 1);
    expect_classes(&[("Add", [1, 0, 0])]);

    value
        .internal
        .cache
        .store_quadratic_tower(&Tower::rational(Rational::new(8)));
    let (initialized, counts) = with_recording(|| retained_query(&value, 0, 0));
    assert!(initialized.0.is_none());
    assert_eq!(counts[Event::RetainedLookup as usize], 1);
    expect_classes(&[("Add", [0, 1, 0])]);

    let (proof, counts) = with_recording(|| retained_query(&value, 64, 512));
    assert_eq!(proof.0.and_then(rational), Some(Rational::new(8)));
    assert!(!proof.2);
    assert_eq!(counts[Event::RetainedLookup as usize], 3);
    assert_eq!(counts[Event::RetainedHit as usize], 0);
    assert_eq!(counts[Event::StorePublished as usize], 1);
    assert_eq!(counts[Event::EvaluationCellAllocated as usize], 0);
    expect_classes(&[("Add", [0, 1, 0]), ("Ratio", [2, 0, 0])]);

    drop(clone);
    assert_eq!(Arc::strong_count(&value.internal), 1);
    let (proof, counts) = with_recording(|| retained_query(&value, 0, 0));
    assert_eq!(proof.0.and_then(rational), Some(Rational::new(8)));
    assert_eq!(proof.1, 0);
    assert!(proof.2);
    assert_eq!(counts[Event::RetainedLookup as usize], 1);
    assert_eq!(counts[Event::RetainedHit as usize], 1);
    assert_eq!(counts[Event::NormalizerWorkVisit as usize], 0);
    assert_eq!(counts[Event::NormalizerBudgetDecline as usize], 0);
    expect_classes(&[("Add", [0, 0, 1])]);
    assert!(value.cached().is_none());
    assert_eq!(
        value
            .internal
            .cache
            .quadratic_tower()
            .unwrap()
            .even
            .rational,
        Rational::new(8)
    );
    drop(value);
    assert!(weak.upgrade().is_none());
}
