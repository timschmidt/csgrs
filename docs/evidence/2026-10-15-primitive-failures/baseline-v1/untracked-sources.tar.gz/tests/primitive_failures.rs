//! Failed construction must not enter a pipeline as successful empty geometry.
use csgrs::{Real, adapter::RawTriangleMesh};

fn unresolved_zero() -> Real {
    let sine = Real::e().sin();
    let cosine = Real::e().cos();
    &sine * &sine + &cosine * &cosine - Real::one()
}

#[test]
fn negative_dimensions_are_errors_through_the_public_adapter() {
    assert!(RawTriangleMesh::cube(-Real::one()).is_err());
    assert!(RawTriangleMesh::cuboid(Real::one(), -Real::one(), Real::one()).is_err());
    assert!(RawTriangleMesh::sphere(-Real::one(), 8, 4).is_err());
    assert!(RawTriangleMesh::cylinder(-Real::one(), Real::one(), 8).is_err());
}

#[test]
fn undecided_dimensions_are_errors_through_the_public_adapter() {
    assert!(RawTriangleMesh::cube(unresolved_zero()).is_err());
}

#[test]
fn invalid_resolution_is_an_error_even_for_zero_radius() {
    for radius in [Real::one(), Real::zero()] {
        assert!(RawTriangleMesh::sphere(radius.clone(), 2, 4).is_err());
        assert!(RawTriangleMesh::sphere(radius.clone(), 8, 1).is_err());
        assert!(RawTriangleMesh::cylinder(radius, Real::one(), 2).is_err());
    }
}

#[test]
fn capacity_overflow_is_an_error_through_the_public_adapter() {
    assert!(RawTriangleMesh::sphere(Real::one(), usize::MAX, 2).is_err());
    assert!(RawTriangleMesh::cylinder(Real::one(), Real::one(), usize::MAX).is_err());
}
