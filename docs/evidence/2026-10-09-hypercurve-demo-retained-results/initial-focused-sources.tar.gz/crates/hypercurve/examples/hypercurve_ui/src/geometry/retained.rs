//! Exact sources behind editable display projections.
//!
//! The snapshot is authoring data, not geometric equality. Any edit, including
//! a direct change through the public UI records, invalidates source reuse.
//! Serialization exports those finite authoring records; sources stay in memory.

use super::{CurvePath2, CurvePrimitive, CurveRegion2, Polyline, Shape, Vertex};

#[derive(Clone, Debug, PartialEq)]
pub(super) struct RetainedPath {
    source: Option<CurvePath2>,
    curves: Vec<CurvePrimitive>,
    vertices: Vec<Vertex>,
    closed: bool,
}

impl RetainedPath {
    pub(super) fn new(source: Option<CurvePath2>, display: &Polyline) -> Self {
        Self {
            source,
            curves: display.curve_data.clone(),
            vertices: display.vertex_data.clone(),
            closed: display.is_closed,
        }
    }

    pub(super) fn source_for(&self, display: &Polyline) -> Option<&Option<CurvePath2>> {
        (self.curves == display.curve_data
            && self.vertices == display.vertex_data
            && self.closed == display.is_closed)
            .then_some(&self.source)
    }
}

#[derive(Clone, Debug)]
pub(super) struct RetainedRegion {
    source: CurveRegion2,
    materials: Vec<Polyline>,
    holes: Vec<Polyline>,
}

impl RetainedRegion {
    pub(super) fn new(source: CurveRegion2, display: &Shape) -> Self {
        Self {
            source,
            materials: display.materials.clone(),
            holes: display.holes.clone(),
        }
    }

    pub(super) fn source_for(&self, display: &Shape) -> Option<&CurveRegion2> {
        (self.materials == display.materials && self.holes == display.holes).then_some(&self.source)
    }
}
