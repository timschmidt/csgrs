#![cfg(feature = "curve")]
//! Sampling fidelity is separate from a certified topology decision.
use csgrs::{GeometryCertainty, GeometryContext, Real, curve};
use hypercurve::CurveRegion2;

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn vertices(region: &CurveRegion2) -> Vec<[Real; 2]> {
    let profiles = region.boundary_profiles().unwrap();
    assert_eq!(profiles.len(), 1);
    let (material, holes) = profiles[0].linear_contours().unwrap().unwrap();
    assert!(holes.is_empty());
    material
        .segments()
        .iter()
        .map(|edge| [edge.start().x().clone(), edge.start().y().clone()])
        .collect()
}

#[test]
fn one_chord_per_corner_retains_all_straight_sides_and_exact_area() {
    let region = curve::rounded_rectangle(4.into(), 2.into(), q(1, 2), 1).unwrap();
    // A 4x2 rectangle minus four right triangles with legs 1/2.
    assert_eq!(region.filled_area().unwrap(), Some(q(15, 2)));
    let expected = [
        [Real::zero(), q(1, 2)],
        [q(1, 2), Real::zero()],
        [q(7, 2), Real::zero()],
        [4.into(), q(1, 2)],
        [4.into(), q(3, 2)],
        [q(7, 2), 2.into()],
        [q(1, 2), 2.into()],
        [Real::zero(), q(3, 2)],
    ];
    let actual = vertices(&region);
    assert_eq!(actual.len(), expected.len());
    assert!(expected.iter().all(|point| actual.contains(point)));
}

#[test]
fn clamped_capsules_keep_nonzero_straight_sides() {
    for (width, height) in [(4, 2), (2, 4)] {
        for radius in [1, 100] {
            let region =
                curve::rounded_rectangle(width.into(), height.into(), radius.into(), 1)
                    .unwrap();
            // The corner radius clamps to one: 8 - 4*(1/2) = 6.
            assert_eq!(region.filled_area().unwrap(), Some(6.into()));
            assert_eq!(vertices(&region).len(), 6);
        }
    }
}

#[test]
fn original_published_sampling_resolutions_retain_tangent_vertices() {
    for (label, width, height, requested_radius, radius, samples) in [
        ("benchmark", 12.into(), 8.into(), 2.into(), 2.into(), 8),
        ("README", q(24, 10), q(15, 10), q(28, 100), q(28, 100), 12),
        ("strict catalog", 2.into(), 1.into(), q(3, 4), q(1, 2), 4),
    ] {
        let result = curve::rounded_rectangle_with_context(
            width.clone(),
            height.clone(),
            requested_radius,
            samples,
            &GeometryContext::STRICT,
        )
        .unwrap();
        assert_eq!(result.certainty, GeometryCertainty::Certified);
        let actual = vertices(&result.value);
        for expected in [
            [Real::zero(), radius.clone()],
            [radius.clone(), Real::zero()],
            [&width - &radius, Real::zero()],
            [width.clone(), radius.clone()],
            [width.clone(), &height - &radius],
            [&width - &radius, height.clone()],
            [radius.clone(), height.clone()],
            [Real::zero(), &height - &radius],
        ] {
            assert!(
                actual.contains(&expected),
                "{label}: omitted tangent {expected:?}"
            );
        }
    }
}

#[test]
fn full_radius_and_sharp_corner_controls_remain_defined() {
    let diamond = curve::rounded_rectangle(2.into(), 2.into(), 1.into(), 1).unwrap();
    assert_eq!(diamond.filled_area().unwrap(), Some(2.into()));
    assert_eq!(vertices(&diamond).len(), 4);
    for (radius, samples) in [(0, 3), (1, 0)] {
        let sharp =
            curve::rounded_rectangle(4.into(), 2.into(), radius.into(), samples).unwrap();
        assert_eq!(sharp.filled_area().unwrap(), Some(8.into()));
        assert_eq!(vertices(&sharp).len(), 4);
    }
}
