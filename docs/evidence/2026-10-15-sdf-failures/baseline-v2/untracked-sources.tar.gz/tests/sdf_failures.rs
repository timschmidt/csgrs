#![cfg(feature = "sdf")]
//! An unresolved or invalid sampled field must not publish successful geometry.
use csgrs::{
    GeometryContext, Real, TriangleMesh,
    errors::{ValidationError, ValidationErrorKind},
    solid,
};
use hyperlattice::Point3;
use hypersdf::SdfExpr;

// Compatibility only for reproducing the finding before the Result migration.
trait FailureKind {
    fn failure_kind(&self) -> Option<ValidationErrorKind>;
}
impl FailureKind for TriangleMesh {
    fn failure_kind(&self) -> Option<ValidationErrorKind> {
        None
    }
}
impl FailureKind for (TriangleMesh, solid::SdfDiagnostics) {
    fn failure_kind(&self) -> Option<ValidationErrorKind> {
        None
    }
}
impl<T> FailureKind for Result<T, ValidationError> {
    fn failure_kind(&self) -> Option<ValidationErrorKind> {
        self.as_ref().err().map(ValidationError::kind)
    }
}

fn point(n: i32) -> Point3 {
    Point3::new(n.into(), n.into(), n.into())
}
fn unknown_zero() -> Real {
    let sine = Real::e().sin();
    let cosine = Real::e().cos();
    &sine * &sine + &cosine * &cosine - Real::one()
}

#[test]
fn closure_uncertainty_is_not_successful_empty_geometry() {
    let zero = unknown_zero();
    let field = |_: &Point3| zero.clone();
    assert_eq!(
        solid::sdf(field, (3, 3, 3), point(-1), point(1), 0.into()).failure_kind(),
        Some(ValidationErrorKind::Undecided)
    );
}

#[test]
fn diagnostic_uncertainty_is_not_nonfinite_empty_geometry() {
    let zero = unknown_zero();
    assert_eq!(
        solid::sdf_with_diagnostics(
            |_| zero.clone(),
            (3, 3, 3),
            point(-1),
            point(1),
            0.into()
        )
        .failure_kind(),
        Some(ValidationErrorKind::Undecided)
    );
}

#[test]
fn invalid_expression_domains_remain_invalid_input() {
    let expr = SdfExpr::constant((-1).into()).sqrt();
    assert_eq!(
        solid::sdf_expr(expr, (3, 3, 3), point(-1), point(1), 0.into()).failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}

#[test]
fn diagnostic_expression_domains_remain_invalid_input() {
    let expr = SdfExpr::sphere(
        hyperlimit::Point3::new(0.into(), 0.into(), 0.into()),
        (-1).into(),
    );
    assert_eq!(
        solid::sdf_expr_with_diagnostics(expr, (3, 3, 3), point(-1), point(1), 0.into())
            .failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}

#[test]
fn expression_branch_uncertainty_retains_its_category() {
    let a = Real::e().sin();
    let expr = SdfExpr::constant(a.clone()).union(SdfExpr::constant(a + unknown_zero()));
    assert_eq!(
        solid::sdf_expr_with_context(
            expr,
            (3, 3, 3),
            point(-1),
            point(1),
            0.into(),
            &GeometryContext::STRICT
        )
        .failure_kind(),
        Some(ValidationErrorKind::Undecided)
    );
}

#[test]
fn context_expression_domain_errors_are_distinct_from_uncertainty() {
    let expr = SdfExpr::constant((-1).into()).sqrt();
    assert_eq!(
        solid::sdf_expr_with_context(
            expr,
            (3, 3, 3),
            point(-1),
            point(1),
            0.into(),
            &GeometryContext::STRICT
        )
        .failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}

#[test]
fn overflow_is_resource_exhaustion_before_sampling() {
    let field =
        |_: &Point3| -> Real { panic!("capacity must be checked before invoking the field") };
    assert_eq!(
        solid::sdf(field, (usize::MAX, 2, 2), point(-1), point(1), 0.into()).failure_kind(),
        Some(ValidationErrorKind::ResourceExhausted)
    );
}

#[test]
fn undersized_resolution_is_rejected_instead_of_clamped() {
    assert_eq!(
        solid::sdf_with_context(
            |_| Real::one(),
            (1, 3, 3),
            point(-1),
            point(1),
            0.into(),
            &GeometryContext::STRICT
        )
        .failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}
