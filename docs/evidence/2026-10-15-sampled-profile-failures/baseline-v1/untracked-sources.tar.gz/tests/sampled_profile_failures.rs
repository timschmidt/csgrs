//! Sampled constructors must return failures before geometry reaches consumers.
#![cfg(feature = "curve")]
use csgrs::{GeometryContext, Real, curve, errors::ValidationError, solid};
use hypercurve::CurveRegion2;

// This acceptance fixture also compiles on the pre-migration revision. The
// old infallible carrier is deliberately treated as success, including empty.
trait Attempt {
    fn attempt(self) -> Result<CurveRegion2, ValidationError>;
}
impl Attempt for CurveRegion2 {
    fn attempt(self) -> Result<CurveRegion2, ValidationError> {
        Ok(self)
    }
}
impl Attempt for Result<CurveRegion2, ValidationError> {
    fn attempt(self) -> Result<CurveRegion2, ValidationError> {
        self
    }
}
fn r(x: f64) -> Real {
    Real::try_from(x).unwrap()
}
fn invalid(result: impl Attempt) {
    let error = result.attempt().expect_err("invalid input became geometry");
    assert_eq!(error.kind(), csgrs::errors::ValidationErrorKind::InvalidInput);
}
fn unresolved_zero() -> Real {
    let sine = Real::e().sin();
    let cosine = Real::e().cos();
    &sine * &sine + &cosine * &cosine - Real::one()
}

#[test]
fn arrow_rejects_nonpositive_dimensions() {
    invalid(curve::arrow((-1).into(), 1.into(), 1.into(), 2.into()));
}
#[test]
fn trapezoid_rejects_nonpositive_dimensions() {
    invalid(curve::trapezoid(1.into(), (-1).into(), 1.into(), 0.into()));
}
#[test]
fn star_rejects_invalid_resolution() {
    invalid(curve::star(2, 2.into(), 1.into()));
}
#[test]
fn teardrop_rejects_invalid_dimensions() {
    invalid(curve::teardrop((-1).into(), 2.into(), 4));
}
#[test]
fn egg_rejects_invalid_dimensions() {
    invalid(curve::egg(2.into(), (-1).into(), 4));
}
#[test]
fn squircle_rejects_invalid_resolution() {
    invalid(curve::squircle(2.into(), 2.into(), 2));
}
#[test]
fn sector_rejects_excessive_sweep() {
    invalid(curve::pie_slice(1.into(), 0.into(), 361.into(), 4));
}
#[test]
fn heart_rejects_invalid_resolution() {
    invalid(curve::heart(2.into(), 2.into(), 7));
}
#[test]
fn supershape_rejects_nonpositive_axes() {
    invalid(curve::supershape(
        0.into(),
        1.into(),
        4.into(),
        2.into(),
        2.into(),
        2.into(),
        8,
    ));
}
#[test]
fn scalar_domain_failure_does_not_become_empty_geometry() {
    let error =
        curve::supershape(1.into(), 1.into(), 4.into(), 0.into(), 2.into(), 2.into(), 8)
            .attempt()
            .expect_err("scalar domain failure became geometry");
    assert!(matches!(error, ValidationError::Scalar(_)));
}
#[test]
fn undecided_dimensions_do_not_become_empty_geometry() {
    let error = curve::arrow(unresolved_zero(), 1.into(), 1.into(), 2.into())
        .attempt()
        .expect_err("undecided input became geometry");
    assert!(matches!(error, ValidationError::PredicateUndecided { .. }));
}
#[test]
fn checked_count_overflows_do_not_become_empty_geometry() {
    for result in [
        curve::star(usize::MAX, 2.into(), 1.into()).attempt(),
        curve::teardrop(1.into(), 2.into(), usize::MAX).attempt(),
    ] {
        assert!(matches!(result, Err(ValidationError::CapacityOverflow)));
    }
}
#[test]
fn native_degenerate_sample_failure_does_not_become_geometry() {
    let error = curve::pie_slice(2.into(), 0.into(), 180.into(), 1)
        .attempt()
        .expect_err("degenerate sampling became geometry");
    assert!(matches!(
        error,
        ValidationError::Curve(_) | ValidationError::ExactCurve(_)
    ));
}
#[test]
fn extruded_teardrop_does_not_certify_a_failed_profile() {
    assert!(
        solid::teardrop_cylinder((-1).into(), 2.into(), 3.into(), 4, &GeometryContext::STRICT)
            .is_err()
    );
}
#[test]
fn equal_arrow_widths_preserve_the_shaft_and_head() {
    let region = curve::arrow(2.into(), 1.into(), 1.into(), 1.into())
        .attempt()
        .unwrap();
    assert_eq!(
        region.filled_area().unwrap(),
        Some((Real::from(5) / Real::from(2)).unwrap())
    );
}

fn complete_fixture(label: &str, result: impl Attempt) {
    let region = result.attempt().unwrap();
    assert!(!region.is_empty(), "{label} did not complete");
    let profiles = region.boundary_profiles().unwrap();
    assert_eq!(profiles.len(), 1, "{label}");
    let (material, holes) = profiles[0].linear_contours().unwrap().unwrap();
    assert!(holes.is_empty(), "{label}");
    assert!(!material.segments().is_empty(), "{label}");
    // Exact expression rows supplement independent semantic tests; byte equality
    // alone is not an oracle for the intended set. No display demotion is used.
    #[cfg(feature = "svg-io")]
    if let Ok(directory) = std::env::var("CSGRS_SAMPLED_PROFILE_ARTIFACTS") {
        let rows = material
            .segments()
            .iter()
            .map(|edge| {
                format!(
                    "[{},{}]",
                    edge.start().x().to_json(),
                    edge.start().y().to_json()
                )
            })
            .collect::<Vec<_>>();
        let directory = std::path::Path::new(&directory);
        std::fs::create_dir_all(directory).unwrap();
        std::fs::write(
            directory.join(format!("{label}.json")),
            format!("[{}]\n", rows.join(",\n")),
        )
        .unwrap();
    }
}
macro_rules! fixture {
    ($name:ident, $value:expr) => {
        #[test]
        fn $name() {
            complete_fixture(stringify!($name), $value);
        }
    };
}
fixture!(
    original_readme_arrow,
    curve::arrow(r(2.2), r(0.35), r(0.8), r(1.0))
);
fixture!(
    original_readme_trapezoid,
    curve::trapezoid(r(1.2), r(2.2), r(1.4), r(0.45))
);
fixture!(original_readme_star, curve::star(5, r(1.1), r(0.45)));
fixture!(original_readme_teardrop, curve::teardrop(r(1.5), r(2.3), 96));
fixture!(original_readme_egg, curve::egg(r(1.6), r(2.2), 96));
fixture!(original_readme_squircle, curve::squircle(r(2.0), r(1.6), 128));
fixture!(
    original_readme_sector,
    curve::pie_slice(r(1.1), r(-35.0), r(115.0), 64)
);
fixture!(original_readme_heart, curve::heart(r(2.0), r(1.8), 160));
fixture!(
    original_readme_supershape,
    curve::supershape(r(1.0), r(1.0), r(5.0), r(2.0), r(7.0), r(7.0), 160)
);
