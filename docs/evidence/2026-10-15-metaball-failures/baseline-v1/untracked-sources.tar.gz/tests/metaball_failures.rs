#![cfg(feature = "metaballs")]
//! Invalid metaballs and failed samples must not publish successful geometry.
use csgrs::{
    Real, TriangleMesh,
    errors::{ValidationError, ValidationErrorKind},
    solid::{self, MetaBall},
};
use hyperlattice::Point3;

// Compatibility for reproducing the old infallible modeling API.
trait FailureKind {
    fn failure_kind(&self) -> Option<ValidationErrorKind>;
}
impl FailureKind for TriangleMesh {
    fn failure_kind(&self) -> Option<ValidationErrorKind> {
        None
    }
}
impl FailureKind for (TriangleMesh, solid::MetaballDiagnostics) {
    fn failure_kind(&self) -> Option<ValidationErrorKind> {
        None
    }
}
impl<T> FailureKind for Result<T, ValidationError> {
    fn failure_kind(&self) -> Option<ValidationErrorKind> {
        self.as_ref().err().map(ValidationError::kind)
    }
}
trait InfluenceFailure {
    fn rejects_singularity(&self) -> bool;
}
impl InfluenceFailure for Option<Real> {
    fn rejects_singularity(&self) -> bool {
        false
    }
}
impl InfluenceFailure for Result<Real, hypersdf::SdfEvaluationError> {
    fn rejects_singularity(&self) -> bool {
        matches!(
            self,
            Err(hypersdf::SdfEvaluationError::Scalar {
                source: hyperreal::Problem::DivideByZero,
                ..
            })
        )
    }
}
trait IntoMesh {
    fn into_mesh(self) -> Result<TriangleMesh, ValidationError>;
}
impl IntoMesh for TriangleMesh {
    fn into_mesh(self) -> Result<TriangleMesh, ValidationError> {
        Ok(self)
    }
}
impl IntoMesh for Result<TriangleMesh, ValidationError> {
    fn into_mesh(self) -> Result<TriangleMesh, ValidationError> {
        self
    }
}
fn ball(radius: Real) -> MetaBall {
    MetaBall::new(Point3::origin(), radius)
}
fn unknown_zero() -> Real {
    let sine = Real::e().sin();
    let cosine = Real::e().cos();
    &sine * &sine + &cosine * &cosine - Real::one()
}

#[test]
fn zero_radius_is_invalid_input_instead_of_empty_geometry() {
    assert_eq!(
        solid::metaballs(&[ball(0.into())], (3, 3, 3), 1.into(), 0.into()).failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}
#[test]
fn negative_padding_is_invalid_input_instead_of_empty_geometry() {
    assert_eq!(
        solid::metaballs_with_diagnostics(&[ball(1.into())], (3, 3, 3), 1.into(), (-1).into())
            .failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}
#[test]
fn unresolved_radius_is_undecided_instead_of_invalid_or_empty() {
    assert_eq!(
        solid::metaballs(&[ball(unknown_zero())], (3, 3, 3), 1.into(), 0.into())
            .failure_kind(),
        Some(ValidationErrorKind::Undecided)
    );
}
#[test]
fn empty_input_does_not_hide_invalid_iso_value() {
    assert_eq!(
        solid::metaballs(&[], (3, 3, 3), 0.into(), 0.into()).failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}
#[test]
fn empty_input_does_not_hide_invalid_padding() {
    assert_eq!(
        solid::metaballs(&[], (3, 3, 3), 1.into(), (-1).into()).failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}
#[test]
fn resolution_is_validated_instead_of_silently_clamped() {
    assert_eq!(
        solid::metaballs(&[ball(1.into())], (1, 3, 3), 1.into(), 0.into()).failure_kind(),
        Some(ValidationErrorKind::InvalidInput)
    );
}
#[test]
fn grid_overflow_is_resource_exhaustion() {
    assert_eq!(
        solid::metaballs_with_diagnostics(
            &[ball(1.into())],
            (usize::MAX, 2, 2),
            1.into(),
            0.into()
        )
        .failure_kind(),
        Some(ValidationErrorKind::ResourceExhausted)
    );
}
#[test]
fn inverse_square_influence_does_not_discard_distant_contributions() {
    let value = ball(1.into())
        .influence(&Point3::new(100.into(), 0.into(), 0.into()))
        .expect("nonzero distance");
    assert_eq!(value, (Real::one() / Real::from(10000)).unwrap());
}
#[test]
fn singular_inverse_square_influence_is_not_a_finite_sentinel() {
    assert!(
        ball(1.into())
            .influence(&Point3::origin())
            .rejects_singularity()
    );
}
#[test]
fn normalized_level_field_has_independently_known_exact_sampled_vertices() {
    // Declared migration: sample F=(iso-I)/(1+I), continuously extended to -1 at poles.
    // For one unit ball, core half-extent a=101/100 and resolution 3,
    // an axis edge crosses at (a²+1)/(2a); averaging its three crossings
    // gives each coordinate magnitude 20201/60600. No f32 construction is involved.
    let mesh = solid::metaballs(&[ball(1.into())], (3, 3, 3), 1.into(), 0.into())
        .into_mesh()
        .unwrap();
    let coordinate = (Real::from(20201) / Real::from(60600)).unwrap();
    assert!(!mesh.triangles.is_empty());
    assert!(mesh.positions.iter().all(|p| {
        [&p.x, &p.y, &p.z]
            .into_iter()
            .all(|v| v == &coordinate || v == &(-&coordinate))
    }));
}
