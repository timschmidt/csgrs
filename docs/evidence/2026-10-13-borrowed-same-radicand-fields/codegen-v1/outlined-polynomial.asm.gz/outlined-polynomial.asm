
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/outlined-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000cf770 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply>:
   cf770:	55                   	push   %rbp
   cf771:	41 57                	push   %r15
   cf773:	41 56                	push   %r14
   cf775:	41 55                	push   %r13
   cf777:	41 54                	push   %r12
   cf779:	53                   	push   %rbx
   cf77a:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
   cf781:	49 89 fe             	mov    %rdi,%r14
   cf784:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
   cf78b:	00 00 
   cf78d:	48 c7 44 24 48 08 00 	movq   $0x8,0x48(%rsp)
   cf794:	00 00 
   cf796:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   cf79d:	00 00 
   cf79f:	48 8b 42 08          	mov    0x8(%rdx),%rax
   cf7a3:	48 89 04 24          	mov    %rax,(%rsp)
   cf7a7:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   cf7ac:	4c 8b 62 10          	mov    0x10(%rdx),%r12
   cf7b0:	49 83 fc 01          	cmp    $0x1,%r12
   cf7b4:	0f 85 b8 01 00 00    	jne    cf972 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x202>
   cf7ba:	48 8b 06             	mov    (%rsi),%rax
   cf7bd:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   cf7c1:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
   cf7c5:	49 89 cd             	mov    %rcx,%r13
   cf7c8:	49 c1 e5 06          	shl    $0x6,%r13
   cf7cc:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   cf7d0:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cf7d5:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf7da:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   cf7df:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   cf7e4:	48 85 c9             	test   %rcx,%rcx
   cf7e7:	0f 84 64 01 00 00    	je     cf951 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x1e1>
   cf7ed:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   cf7f2:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   cf7f7:	48 8b 04 24          	mov    (%rsp),%rax
   cf7fb:	48 83 c0 08          	add    $0x8,%rax
   cf7ff:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cf804:	4c 8d bc 24 98 00 00 	lea    0x98(%rsp),%r15
   cf80b:	00 
   cf80c:	48 83 c3 40          	add    $0x40,%rbx
   cf810:	48 8d ac 24 00 01 00 	lea    0x100(%rsp),%rbp
   cf817:	00 
   cf818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   cf81f:	00 
   cf820:	48 8b 43 c8          	mov    -0x38(%rbx),%rax
   cf824:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   cf828:	0f 84 19 01 00 00    	je     cf947 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x1d7>
   cf82e:	44 0f b7 73 c0       	movzwl -0x40(%rbx),%r14d
   cf833:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   cf83a:	00 
   cf83b:	0f 10 43 d0          	movups -0x30(%rbx),%xmm0
   cf83f:	0f 10 4b e0          	movups -0x20(%rbx),%xmm1
   cf843:	0f 10 53 f0          	movups -0x10(%rbx),%xmm2
   cf847:	41 0f 11 57 20       	movups %xmm2,0x20(%r15)
   cf84c:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
   cf851:	41 0f 11 07          	movups %xmm0,(%r15)
   cf855:	48 8b 04 24          	mov    (%rsp),%rax
   cf859:	66 44 03 30          	add    (%rax),%r14w
   cf85d:	0f 80 7b 06 00 00    	jo     cfede <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x76e>
   cf863:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   cf86a:	00 
   cf86b:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   cf872:	00 
   cf873:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   cf87a:	00 
   cf87b:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   cf882:	00 
   cf883:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
   cf88a:	00 
   cf88b:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
   cf892:	00 
   cf893:	0f 29 8c 24 20 01 00 	movaps %xmm1,0x120(%rsp)
   cf89a:	00 
   cf89b:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
   cf8a2:	00 
   cf8a3:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   cf8aa:	00 
   cf8ab:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
   cf8b2:	00 
   cf8b3:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cf8ba:	00 
   cf8bb:	48 89 ee             	mov    %rbp,%rsi
   cf8be:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   cf8c3:	e8 88 de ff ff       	call   cd750 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cf8c8:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cf8cf:	00 ff 
   cf8d1:	0f 84 08 05 00 00    	je     cfddf <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66f>
   cf8d7:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cf8de:	00 
   cf8df:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   cf8e6:	00 
   cf8e7:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cf8ee:	00 
   cf8ef:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cf8f6:	00 
   cf8f7:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cf8fe:	00 
   cf8ff:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   cf906:	00 
   cf907:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   cf90e:	00 
   cf90f:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   cf916:	00 
   cf917:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cf91c:	44 89 f6             	mov    %r14d,%esi
   cf91f:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
   cf926:	00 
   cf927:	e8 b4 f2 ff ff       	call   cebe0 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cf92c:	84 c0                	test   %al,%al
   cf92e:	0f 84 ab 04 00 00    	je     cfddf <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66f>
   cf934:	48 83 c3 40          	add    $0x40,%rbx
   cf938:	49 83 c5 c0          	add    $0xffffffffffffffc0,%r13
   cf93c:	0f 85 de fe ff ff    	jne    cf820 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0xb0>
   cf942:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   cf947:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf94c:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cf951:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf956:	e8 45 e1 03 00       	call   10daa0 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf95b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   cf960:	49 89 46 10          	mov    %rax,0x10(%r14)
   cf964:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   cf969:	41 0f 11 06          	movups %xmm0,(%r14)
   cf96d:	e9 03 05 00 00       	jmp    cfe75 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x705>
   cf972:	48 8b 0e             	mov    (%rsi),%rcx
   cf975:	48 8b 46 08          	mov    0x8(%rsi),%rax
   cf979:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   cf97d:	48 89 d6             	mov    %rdx,%rsi
   cf980:	48 c1 e6 06          	shl    $0x6,%rsi
   cf984:	48 01 c6             	add    %rax,%rsi
   cf987:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   cf98c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf991:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   cf996:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
   cf99d:	00 
   cf99e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   cf9a3:	48 85 d2             	test   %rdx,%rdx
   cf9a6:	0f 84 d1 03 00 00    	je     cfd7d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x60d>
   cf9ac:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   cf9b3:	00 
   cf9b4:	4c 89 e1             	mov    %r12,%rcx
   cf9b7:	48 c1 e1 06          	shl    $0x6,%rcx
   cf9bb:	48 03 0c 24          	add    (%rsp),%rcx
   cf9bf:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   cf9c4:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   cf9c9:	48 8d 50 40          	lea    0x40(%rax),%rdx
   cf9cd:	48 8b 48 08          	mov    0x8(%rax),%rcx
   cf9d1:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   cf9d5:	0f 84 9d 03 00 00    	je     cfd78 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x608>
   cf9db:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   cf9e0:	0f b7 10             	movzwl (%rax),%edx
   cf9e3:	66 89 54 24 38       	mov    %dx,0x38(%rsp)
   cf9e8:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   cf9ef:	00 
   cf9f0:	0f 10 40 10          	movups 0x10(%rax),%xmm0
   cf9f4:	0f 10 48 20          	movups 0x20(%rax),%xmm1
   cf9f8:	0f 10 50 30          	movups 0x30(%rax),%xmm2
   cf9fc:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
   cfa00:	0f 11 4e 10          	movups %xmm1,0x10(%rsi)
   cfa04:	0f 11 06             	movups %xmm0,(%rsi)
   cfa07:	4d 85 e4             	test   %r12,%r12
   cfa0a:	0f 84 30 03 00 00    	je     cfd40 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x5d0>
   cfa10:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   cfa17:	00 
   cfa18:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   cfa1f:	00 
   cfa20:	48 89 dd             	mov    %rbx,%rbp
   cfa23:	48 c1 e5 04          	shl    $0x4,%rbp
   cfa27:	48 89 d8             	mov    %rbx,%rax
   cfa2a:	48 c1 e8 3c          	shr    $0x3c,%rax
   cfa2e:	0f 94 c0             	sete   %al
   cfa31:	48 b9 f9 ff ff ff ff 	movabs $0x7ffffffffffffff9,%rcx
   cfa38:	ff ff 7f 
   cfa3b:	48 39 cd             	cmp    %rcx,%rbp
   cfa3e:	0f 92 c1             	setb   %cl
   cfa41:	84 c8                	test   %cl,%al
   cfa43:	0f 84 72 03 00 00    	je     cfdbb <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x64b>
   cfa49:	48 85 ed             	test   %rbp,%rbp
   cfa4c:	0f 84 ab 01 00 00    	je     cfbfd <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x48d>
   cfa52:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   cfa59:	00 
   cfa5a:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
   cfa61:	00 
   cfa62:	4c 8b 3c 24          	mov    (%rsp),%r15
   cfa66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cfa6d:	00 00 00 
   cfa70:	45 0f b7 2f          	movzwl (%r15),%r13d
   cfa74:	66 44 03 6c 24 38    	add    0x38(%rsp),%r13w
   cfa7a:	0f 80 7c 03 00 00    	jo     cfdfc <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfa80:	f0 49 ff 06          	lock incq (%r14)
   cfa84:	0f 8e 53 03 00 00    	jle    cfddd <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfa8a:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cfa8f:	ff 15 d3 f9 09 00    	call   *0x9f9d3(%rip)        # 16f468 <_DYNAMIC+0x338>
   cfa95:	be 08 00 00 00       	mov    $0x8,%esi
   cfa9a:	48 89 ef             	mov    %rbp,%rdi
   cfa9d:	ff 15 cd f9 09 00    	call   *0x9f9cd(%rip)        # 16f470 <_DYNAMIC+0x340>
   cfaa3:	48 85 c0             	test   %rax,%rax
   cfaa6:	0f 84 55 04 00 00    	je     cff01 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x791>
   cfaac:	48 85 db             	test   %rbx,%rbx
   cfaaf:	74 48                	je     cfaf9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x389>
   cfab1:	31 c9                	xor    %ecx,%ecx
   cfab3:	48 89 da             	mov    %rbx,%rdx
   cfab6:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
   cfabd:	00 
   cfabe:	66 90                	xchg   %ax,%ax
   cfac0:	48 39 cd             	cmp    %rcx,%rbp
   cfac3:	74 34                	je     cfaf9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x389>
   cfac5:	48 8b 3e             	mov    (%rsi),%rdi
   cfac8:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   cfacc:	f0 48 ff 07          	lock incq (%rdi)
   cfad0:	0f 8e 07 03 00 00    	jle    cfddd <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfad6:	f0 49 ff 00          	lock incq (%r8)
   cfada:	0f 8e fd 02 00 00    	jle    cfddd <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfae0:	48 ff ca             	dec    %rdx
   cfae3:	48 83 c6 10          	add    $0x10,%rsi
   cfae7:	48 89 3c 08          	mov    %rdi,(%rax,%rcx,1)
   cfaeb:	4c 89 44 08 08       	mov    %r8,0x8(%rax,%rcx,1)
   cfaf0:	48 83 c1 10          	add    $0x10,%rcx
   cfaf4:	48 85 d2             	test   %rdx,%rdx
   cfaf7:	75 c7                	jne    cfac0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x350>
   cfaf9:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   cfafe:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   cfb03:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
   cfb0a:	00 
   cfb0b:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
   cfb12:	00 
   cfb13:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   cfb1a:	00 
   cfb1b:	e8 70 32 04 00       	call   112d90 <<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::clone::Clone>::clone>
   cfb20:	49 8d 57 08          	lea    0x8(%r15),%rdx
   cfb24:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   cfb2b:	00 
   cfb2c:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cfb31:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
   cfb38:	00 
   cfb39:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cfb40:	00 
   cfb41:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   cfb48:	00 
   cfb49:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   cfb50:	00 
   cfb51:	48 8d 8c 24 18 01 00 	lea    0x118(%rsp),%rcx
   cfb58:	00 
   cfb59:	48 89 41 10          	mov    %rax,0x10(%rcx)
   cfb5d:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   cfb64:	00 
   cfb65:	0f 11 01             	movups %xmm0,(%rcx)
   cfb68:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cfb6f:	00 
   cfb70:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   cfb77:	00 
   cfb78:	e8 d3 db ff ff       	call   cd750 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cfb7d:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cfb84:	00 ff 
   cfb86:	0f 84 70 02 00 00    	je     cfdfc <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfb8c:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cfb93:	00 
   cfb94:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   cfb9b:	00 
   cfb9c:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cfba3:	00 
   cfba4:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cfbab:	00 
   cfbac:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cfbb3:	00 
   cfbb4:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
   cfbbb:	00 
   cfbbc:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
   cfbc3:	00 
   cfbc4:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   cfbcb:	00 
   cfbcc:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cfbd1:	44 89 ee             	mov    %r13d,%esi
   cfbd4:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
   cfbdb:	00 
   cfbdc:	e8 ff ef ff ff       	call   cebe0 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cfbe1:	84 c0                	test   %al,%al
   cfbe3:	0f 84 13 02 00 00    	je     cfdfc <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfbe9:	49 83 c7 40          	add    $0x40,%r15
   cfbed:	4c 3b 7c 24 60       	cmp    0x60(%rsp),%r15
   cfbf2:	0f 85 78 fe ff ff    	jne    cfa70 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x300>
   cfbf8:	e9 43 01 00 00       	jmp    cfd40 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x5d0>
   cfbfd:	4c 8b 2c 24          	mov    (%rsp),%r13
   cfc01:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cfc08:	0f 1f 84 00 00 00 00 
   cfc0f:	00 
   cfc10:	41 0f b7 5d 00       	movzwl 0x0(%r13),%ebx
   cfc15:	66 03 5c 24 38       	add    0x38(%rsp),%bx
   cfc1a:	0f 80 dc 01 00 00    	jo     cfdfc <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfc20:	f0 49 ff 06          	lock incq (%r14)
   cfc24:	0f 8e b3 01 00 00    	jle    cfddd <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfc2a:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cfc2f:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
   cfc36:	00 00 
   cfc38:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
   cfc3f:	00 00 
   cfc41:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   cfc48:	00 00 00 00 00 
   cfc4d:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
   cfc54:	00 
   cfc55:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   cfc5c:	00 
   cfc5d:	e8 2e 31 04 00       	call   112d90 <<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::clone::Clone>::clone>
   cfc62:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   cfc69:	00 
   cfc6a:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cfc6f:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
   cfc76:	00 
   cfc77:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cfc7e:	00 
   cfc7f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   cfc86:	00 
   cfc87:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   cfc8e:	00 
   cfc8f:	48 8d 8c 24 18 01 00 	lea    0x118(%rsp),%rcx
   cfc96:	00 
   cfc97:	48 89 41 10          	mov    %rax,0x10(%rcx)
   cfc9b:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   cfca2:	00 
   cfca3:	0f 11 01             	movups %xmm0,(%rcx)
   cfca6:	49 83 c5 08          	add    $0x8,%r13
   cfcaa:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cfcb1:	00 
   cfcb2:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   cfcb9:	00 
   cfcba:	4c 89 ea             	mov    %r13,%rdx
   cfcbd:	e8 8e da ff ff       	call   cd750 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cfcc2:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cfcc9:	00 ff 
   cfccb:	0f 84 2b 01 00 00    	je     cfdfc <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfcd1:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cfcd8:	00 
   cfcd9:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   cfce0:	00 
   cfce1:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cfce8:	00 
   cfce9:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cfcf0:	00 
   cfcf1:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cfcf8:	00 
   cfcf9:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
   cfd00:	00 
   cfd01:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
   cfd08:	00 
   cfd09:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   cfd10:	00 
   cfd11:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cfd16:	89 de                	mov    %ebx,%esi
   cfd18:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
   cfd1f:	00 
   cfd20:	e8 bb ee ff ff       	call   cebe0 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cfd25:	84 c0                	test   %al,%al
   cfd27:	0f 84 cf 00 00 00    	je     cfdfc <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfd2d:	49 83 c5 38          	add    $0x38,%r13
   cfd31:	4c 3b 6c 24 60       	cmp    0x60(%rsp),%r13
   cfd36:	0f 85 d4 fe ff ff    	jne    cfc10 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x4a0>
   cfd3c:	0f 1f 40 00          	nopl   0x0(%rax)
   cfd40:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cfd47:	00 
   cfd48:	e8 a3 10 fe ff       	call   b0df0 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cfd4d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cfd52:	48 89 c8             	mov    %rcx,%rax
   cfd55:	48 3b 8c 24 88 00 00 	cmp    0x88(%rsp),%rcx
   cfd5c:	00 
   cfd5d:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cfd62:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   cfd69:	00 
   cfd6a:	0f 85 59 fc ff ff    	jne    cf9c9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x259>
   cfd70:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   cfd77:	00 
   cfd78:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   cfd7d:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfd82:	e8 19 dd 03 00       	call   10daa0 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfd87:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   cfd8c:	49 89 46 10          	mov    %rax,0x10(%r14)
   cfd90:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   cfd95:	41 0f 11 06          	movups %xmm0,(%r14)
   cfd99:	49 ff c4             	inc    %r12
   cfd9c:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfda0:	49 83 fc 01          	cmp    $0x1,%r12
   cfda4:	0f 84 ed 00 00 00    	je     cfe97 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x727>
   cfdaa:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cfdae:	49 ff cc             	dec    %r12
   cfdb1:	e8 5a 1d 04 00       	call   111b10 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfdb6:	48 89 df             	mov    %rbx,%rdi
   cfdb9:	eb e5                	jmp    cfda0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x630>
   cfdbb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfdc0:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfdc5:	48 8b 04 24          	mov    (%rsp),%rax
   cfdc9:	0f b7 4c 24 38       	movzwl 0x38(%rsp),%ecx
   cfdce:	66 03 08             	add    (%rax),%cx
   cfdd1:	70 33                	jo     cfe06 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x696>
   cfdd3:	f0 49 ff 06          	lock incq (%r14)
   cfdd7:	0f 8f ec 00 00 00    	jg     cfec9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x759>
   cfddd:	0f 0b                	ud2
   cfddf:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cfde4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cfde9:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cfdf0:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfdf5:	e8 a6 dc 03 00       	call   10daa0 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfdfa:	eb 2d                	jmp    cfe29 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6b9>
   cfdfc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfe01:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfe06:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cfe0b:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cfe12:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cfe19:	00 
   cfe1a:	e8 d1 0f fe ff       	call   b0df0 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cfe1f:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfe24:	e8 77 dc 03 00       	call   10daa0 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfe29:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cfe2e:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
   cfe33:	49 ff c6             	inc    %r14
   cfe36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cfe3d:	00 00 00 
   cfe40:	49 83 fe 01          	cmp    $0x1,%r14
   cfe44:	74 11                	je     cfe57 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6e7>
   cfe46:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cfe4a:	49 ff ce             	dec    %r14
   cfe4d:	e8 be 1c 04 00       	call   111b10 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfe52:	48 89 df             	mov    %rbx,%rdi
   cfe55:	eb e9                	jmp    cfe40 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6d0>
   cfe57:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   cfe5c:	48 85 f6             	test   %rsi,%rsi
   cfe5f:	74 14                	je     cfe75 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x705>
   cfe61:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cfe66:	48 c1 e6 06          	shl    $0x6,%rsi
   cfe6a:	ba 08 00 00 00       	mov    $0x8,%edx
   cfe6f:	ff 15 7b f5 09 00    	call   *0x9f57b(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cfe75:	49 ff c4             	inc    %r12
   cfe78:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfe7c:	0f 1f 40 00          	nopl   0x0(%rax)
   cfe80:	49 83 fc 01          	cmp    $0x1,%r12
   cfe84:	74 11                	je     cfe97 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x727>
   cfe86:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cfe8a:	49 ff cc             	dec    %r12
   cfe8d:	e8 7e 1c 04 00       	call   111b10 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfe92:	48 89 df             	mov    %rbx,%rdi
   cfe95:	eb e9                	jmp    cfe80 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x710>
   cfe97:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   cfe9c:	48 8b 30             	mov    (%rax),%rsi
   cfe9f:	48 85 f6             	test   %rsi,%rsi
   cfea2:	74 13                	je     cfeb7 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x747>
   cfea4:	48 c1 e6 06          	shl    $0x6,%rsi
   cfea8:	ba 08 00 00 00       	mov    $0x8,%edx
   cfead:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfeb1:	ff 15 39 f5 09 00    	call   *0x9f539(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cfeb7:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
   cfebe:	5b                   	pop    %rbx
   cfebf:	41 5c                	pop    %r12
   cfec1:	41 5d                	pop    %r13
   cfec3:	41 5e                	pop    %r14
   cfec5:	41 5f                	pop    %r15
   cfec7:	5d                   	pop    %rbp
   cfec8:	c3                   	ret
   cfec9:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cfece:	31 ff                	xor    %edi,%edi
   cfed0:	48 89 ee             	mov    %rbp,%rsi
   cfed3:	ff 15 87 f5 09 00    	call   *0x9f587(%rip)        # 16f460 <_DYNAMIC+0x330>
   cfed9:	e9 ff fe ff ff       	jmp    cfddd <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfede:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cfee3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cfee8:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cfeef:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cfef6:	00 
   cfef7:	e8 f4 0e fe ff       	call   b0df0 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cfefc:	e9 ef fe ff ff       	jmp    cfdf0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x680>
   cff01:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cff06:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cff0b:	bf 08 00 00 00       	mov    $0x8,%edi
   cff10:	eb be                	jmp    cfed0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x760>
   cff12:	49 89 c7             	mov    %rax,%r15
   cff15:	eb 5c                	jmp    cff73 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x803>
   cff17:	49 89 c7             	mov    %rax,%r15
   cff1a:	e9 56 01 00 00       	jmp    d0075 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x905>
   cff1f:	49 89 c7             	mov    %rax,%r15
   cff22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cff27:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cff2c:	e9 44 01 00 00       	jmp    d0075 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x905>
   cff31:	eb 08                	jmp    cff3b <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x7cb>
   cff33:	49 89 c7             	mov    %rax,%r15
   cff36:	e9 44 01 00 00       	jmp    d007f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x90f>
   cff3b:	49 89 c7             	mov    %rax,%r15
   cff3e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cff43:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cff48:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cff4d:	e8 6e fb fd ff       	call   afac0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   cff52:	e9 00 01 00 00       	jmp    d0057 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8e7>
   cff57:	eb 00                	jmp    cff59 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x7e9>
   cff59:	49 89 c7             	mov    %rax,%r15
   cff5c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cff61:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cff66:	e9 fd 00 00 00       	jmp    d0068 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8f8>
   cff6b:	49 89 c7             	mov    %rax,%r15
   cff6e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cff73:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cff78:	e8 23 db 03 00       	call   10daa0 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cff7d:	e9 fd 00 00 00       	jmp    d007f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x90f>
   cff82:	49 89 c7             	mov    %rax,%r15
   cff85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   cff8c:	00 00 00 00 
   cff90:	49 ff cc             	dec    %r12
   cff93:	0f 84 8d 00 00 00    	je     d0026 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8b6>
   cff99:	4c 8d 73 40          	lea    0x40(%rbx),%r14
   cff9d:	48 89 df             	mov    %rbx,%rdi
   cffa0:	e8 6b 1b 04 00       	call   111b10 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cffa5:	4c 89 f3             	mov    %r14,%rbx
   cffa8:	eb e6                	jmp    cff90 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x820>
   cffaa:	ff 15 28 f4 09 00    	call   *0x9f428(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   cffb0:	49 89 c7             	mov    %rax,%r15
   cffb3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cffba:	84 00 00 00 00 00 
   cffc0:	49 ff ce             	dec    %r14
   cffc3:	74 11                	je     cffd6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x866>
   cffc5:	4c 8d 63 40          	lea    0x40(%rbx),%r12
   cffc9:	48 89 df             	mov    %rbx,%rdi
   cffcc:	e8 3f 1b 04 00       	call   111b10 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cffd1:	4c 89 e3             	mov    %r12,%rbx
   cffd4:	eb ea                	jmp    cffc0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x850>
   cffd6:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   cffdb:	48 85 f6             	test   %rsi,%rsi
   cffde:	0f 84 a5 00 00 00    	je     d0089 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x919>
   cffe4:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cffe9:	48 c1 e6 06          	shl    $0x6,%rsi
   cffed:	ba 08 00 00 00       	mov    $0x8,%edx
   cfff2:	ff 15 f8 f3 09 00    	call   *0x9f3f8(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cfff8:	e9 8c 00 00 00       	jmp    d0089 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x919>
   cfffd:	ff 15 d5 f3 09 00    	call   *0x9f3d5(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   d0003:	49 89 c7             	mov    %rax,%r15
   d0006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   d000d:	00 00 00 
   d0010:	49 ff cc             	dec    %r12
   d0013:	74 11                	je     d0026 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8b6>
   d0015:	4c 8d 73 40          	lea    0x40(%rbx),%r14
   d0019:	48 89 df             	mov    %rbx,%rdi
   d001c:	e8 ef 1a 04 00       	call   111b10 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   d0021:	4c 89 f3             	mov    %r14,%rbx
   d0024:	eb ea                	jmp    d0010 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8a0>
   d0026:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   d002b:	48 8b 30             	mov    (%rax),%rsi
   d002e:	48 85 f6             	test   %rsi,%rsi
   d0031:	74 60                	je     d0093 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x923>
   d0033:	48 c1 e6 06          	shl    $0x6,%rsi
   d0037:	ba 08 00 00 00       	mov    $0x8,%edx
   d003c:	48 8b 3c 24          	mov    (%rsp),%rdi
   d0040:	ff 15 aa f3 09 00    	call   *0x9f3aa(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   d0046:	4c 89 ff             	mov    %r15,%rdi
   d0049:	e8 22 90 09 00       	call   169070 <_Unwind_Resume@plt>
   d004e:	ff 15 84 f3 09 00    	call   *0x9f384(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   d0054:	49 89 c7             	mov    %rax,%r15
   d0057:	f0 49 ff 0e          	lock decq (%r14)
   d005b:	75 0b                	jne    d0068 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8f8>
   d005d:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   d0062:	ff 15 68 f3 09 00    	call   *0x9f368(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   d0068:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   d006f:	00 
   d0070:	e8 7b 0d fe ff       	call   b0df0 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   d0075:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   d007a:	e8 21 da 03 00       	call   10daa0 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   d007f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   d0084:	e8 07 fb fd ff       	call   afb90 <core::ptr::drop_glue::<alloc::vec::Vec<(i16, hyperreal::computable::node::RadicalCoefficient)>>>
   d0089:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   d008e:	e8 fd fa fd ff       	call   afb90 <core::ptr::drop_glue::<alloc::vec::Vec<(i16, hyperreal::computable::node::RadicalCoefficient)>>>
   d0093:	4c 89 ff             	mov    %r15,%rdi
   d0096:	e8 d5 8f 09 00       	call   169070 <_Unwind_Resume@plt>
   d009b:	ff 15 37 f3 09 00    	call   *0x9f337(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   d00a1:	ff 15 31 f3 09 00    	call   *0x9f331(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
