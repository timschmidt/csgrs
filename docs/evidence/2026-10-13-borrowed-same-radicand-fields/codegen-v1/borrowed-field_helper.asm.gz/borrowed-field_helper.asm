
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/borrowed-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000ccd40 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields>:
   ccd40:	55                   	push   %rbp
   ccd41:	41 57                	push   %r15
   ccd43:	41 56                	push   %r14
   ccd45:	41 55                	push   %r13
   ccd47:	41 54                	push   %r12
   ccd49:	53                   	push   %rbx
   ccd4a:	48 83 ec 68          	sub    $0x68,%rsp
   ccd4e:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
   ccd53:	49 89 cc             	mov    %rcx,%r12
   ccd56:	49 89 d6             	mov    %rdx,%r14
   ccd59:	48 89 f3             	mov    %rsi,%rbx
   ccd5c:	49 89 fd             	mov    %rdi,%r13
   ccd5f:	48 89 d6             	mov    %rdx,%rsi
   ccd62:	e8 f9 49 fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   ccd67:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   ccd6c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   ccd71:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
   ccd75:	48 89 ef             	mov    %rbp,%rdi
   ccd78:	4c 89 f6             	mov    %r14,%rsi
   ccd7b:	e8 e0 49 fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   ccd80:	49 89 c7             	mov    %rax,%r15
   ccd83:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   ccd88:	4d 8d 74 24 08       	lea    0x8(%r12),%r14
   ccd8d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   ccd92:	41 b4 01             	mov    $0x1,%r12b
   ccd95:	4c 89 f7             	mov    %r14,%rdi
   ccd98:	4c 89 ee             	mov    %r13,%rsi
   ccd9b:	e8 c0 49 fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   ccda0:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   ccda5:	48 89 c6             	mov    %rax,%rsi
   ccda8:	4c 89 f8             	mov    %r15,%rax
   ccdab:	45 0f b6 7f 64       	movzbl 0x64(%r15),%r15d
   ccdb0:	41 80 ff 01          	cmp    $0x1,%r15b
   ccdb4:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   ccdb9:	75 18                	jne    ccdd3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x93>
   ccdbb:	f0 48 ff 08          	lock decq (%rax)
   ccdbf:	75 3d                	jne    ccdfe <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0xbe>
   ccdc1:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ccdc6:	ff 15 54 24 0a 00    	call   *0xa2454(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ccdcc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   ccdd1:	eb 2b                	jmp    ccdfe <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0xbe>
   ccdd3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   ccdd8:	80 7e 64 01          	cmpb   $0x1,0x64(%rsi)
   ccddc:	75 08                	jne    ccde6 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0xa6>
   ccdde:	b0 01                	mov    $0x1,%al
   ccde0:	89 44 24 14          	mov    %eax,0x14(%rsp)
   ccde4:	eb 2a                	jmp    cce10 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0xd0>
   ccde6:	45 31 e4             	xor    %r12d,%r12d
   ccde9:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   ccdf0:	00 
   ccdf1:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   ccdf6:	e8 35 30 fc ff       	call   8fe30 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Add>::add>
   ccdfb:	48 89 c6             	mov    %rax,%rsi
   ccdfe:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
   cce03:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
   cce08:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   cce0f:	00 
   cce10:	41 b4 01             	mov    $0x1,%r12b
   cce13:	48 89 ef             	mov    %rbp,%rdi
   cce16:	4c 89 f6             	mov    %r14,%rsi
   cce19:	e8 42 49 fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cce1e:	49 89 c6             	mov    %rax,%r14
   cce21:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   cce26:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   cce2b:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
   cce30:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   cce35:	48 89 de             	mov    %rbx,%rsi
   cce38:	e8 23 49 fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cce3d:	49 89 c4             	mov    %rax,%r12
   cce40:	f0 49 ff 0e          	lock decq (%r14)
   cce44:	75 0b                	jne    cce51 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x111>
   cce46:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   cce4b:	ff 15 cf 23 0a 00    	call   *0xa23cf(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cce51:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   cce56:	4c 89 e6             	mov    %r12,%rsi
   cce59:	e8 d2 2f fc ff       	call   8fe30 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Add>::add>
   cce5e:	49 89 c6             	mov    %rax,%r14
   cce61:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   cce66:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cce6b:	80 78 64 01          	cmpb   $0x1,0x64(%rax)
   cce6f:	75 3f                	jne    cceb0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x170>
   cce71:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   cce76:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   cce7b:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
   cce80:	74 14                	je     cce96 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x156>
   cce82:	f0 48 ff 08          	lock decq (%rax)
   cce86:	75 0e                	jne    cce96 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x156>
   cce88:	45 31 e4             	xor    %r12d,%r12d
   cce8b:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cce90:	ff 15 8a 23 0a 00    	call   *0xa238a(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cce96:	f0 49 ff 0f          	lock decq (%r15)
   cce9a:	0f 85 00 01 00 00    	jne    ccfa0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x260>
   ccea0:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ccea5:	ff 15 75 23 0a 00    	call   *0xa2375(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cceab:	e9 f0 00 00 00       	jmp    ccfa0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x260>
   cceb0:	41 80 ff 01          	cmp    $0x1,%r15b
   cceb4:	75 27                	jne    ccedd <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x19d>
   cceb6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ccebb:	4c 8b 38             	mov    (%rax),%r15
   ccebe:	f0 49 ff 07          	lock incq (%r15)
   ccec2:	0f 8e ea 00 00 00    	jle    ccfb2 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x272>
   ccec8:	48 8b 03             	mov    (%rbx),%rax
   ccecb:	f0 48 ff 08          	lock decq (%rax)
   ccecf:	75 09                	jne    cceda <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x19a>
   cced1:	48 89 df             	mov    %rbx,%rdi
   cced4:	ff 15 46 23 0a 00    	call   *0xa2346(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cceda:	4c 89 3b             	mov    %r15,(%rbx)
   ccedd:	49 8b 45 00          	mov    0x0(%r13),%rax
   ccee1:	f0 48 ff 08          	lock decq (%rax)
   ccee5:	75 09                	jne    ccef0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x1b0>
   ccee7:	4c 89 ef             	mov    %r13,%rdi
   cceea:	ff 15 30 23 0a 00    	call   *0xa2330(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ccef0:	4d 89 75 00          	mov    %r14,0x0(%r13)
   ccef4:	48 8b 45 00          	mov    0x0(%rbp),%rax
   ccef8:	f0 48 ff 08          	lock decq (%rax)
   ccefc:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
   ccf01:	75 09                	jne    ccf0c <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x1cc>
   ccf03:	48 89 ef             	mov    %rbp,%rdi
   ccf06:	ff 15 14 23 0a 00    	call   *0xa2314(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ccf0c:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
   ccf10:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   ccf15:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
   ccf1a:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   ccf1f:	49 ff c7             	inc    %r15
   ccf22:	48 89 df             	mov    %rbx,%rdi
   ccf25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   ccf2c:	00 00 00 00 
   ccf30:	49 83 ff 01          	cmp    $0x1,%r15
   ccf34:	74 11                	je     ccf47 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x207>
   ccf36:	4c 8d 77 18          	lea    0x18(%rdi),%r14
   ccf3a:	49 ff cf             	dec    %r15
   ccf3d:	e8 1e 48 04 00       	call   111760 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   ccf42:	4c 89 f7             	mov    %r14,%rdi
   ccf45:	eb e9                	jmp    ccf30 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x1f0>
   ccf47:	49 8b 04 24          	mov    (%r12),%rax
   ccf4b:	48 85 c0             	test   %rax,%rax
   ccf4e:	74 16                	je     ccf66 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x226>
   ccf50:	48 c1 e0 03          	shl    $0x3,%rax
   ccf54:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   ccf58:	ba 08 00 00 00       	mov    $0x8,%edx
   ccf5d:	48 89 df             	mov    %rbx,%rdi
   ccf60:	ff 15 da 22 0a 00    	call   *0xa22da(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   ccf66:	49 c7 04 24 00 00 00 	movq   $0x0,(%r12)
   ccf6d:	00 
   ccf6e:	49 c7 44 24 08 08 00 	movq   $0x8,0x8(%r12)
   ccf75:	00 00 
   ccf77:	49 c7 44 24 10 00 00 	movq   $0x0,0x10(%r12)
   ccf7e:	00 00 
   ccf80:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   ccf85:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   ccf8a:	74 11                	je     ccf9d <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x25d>
   ccf8c:	f0 48 ff 08          	lock decq (%rax)
   ccf90:	75 0b                	jne    ccf9d <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x25d>
   ccf92:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   ccf97:	ff 15 83 22 0a 00    	call   *0xa2283(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ccf9d:	45 31 f6             	xor    %r14d,%r14d
   ccfa0:	4c 89 f0             	mov    %r14,%rax
   ccfa3:	48 83 c4 68          	add    $0x68,%rsp
   ccfa7:	5b                   	pop    %rbx
   ccfa8:	41 5c                	pop    %r12
   ccfaa:	41 5d                	pop    %r13
   ccfac:	41 5e                	pop    %r14
   ccfae:	41 5f                	pop    %r15
   ccfb0:	5d                   	pop    %rbp
   ccfb1:	c3                   	ret
   ccfb2:	0f 0b                	ud2
   ccfb4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   ccfb9:	4c 89 3b             	mov    %r15,(%rbx)
   ccfbc:	f0 49 ff 0e          	lock decq (%r14)
   ccfc0:	41 b4 01             	mov    $0x1,%r12b
   ccfc3:	0f 85 1f 01 00 00    	jne    cd0e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3a8>
   ccfc9:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   ccfce:	ff 15 4c 22 0a 00    	call   *0xa224c(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ccfd4:	e9 0f 01 00 00       	jmp    cd0e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3a8>
   ccfd9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   ccfde:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
   ccfe2:	e9 fe 00 00 00       	jmp    cd0e5 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3a5>
   ccfe7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   ccfec:	4d 89 75 00          	mov    %r14,0x0(%r13)
   ccff0:	eb 22                	jmp    cd014 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x2d4>
   ccff2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   ccff7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   ccffc:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   cd001:	b3 01                	mov    $0x1,%bl
   cd003:	e9 0e 01 00 00       	jmp    cd116 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3d6>
   cd008:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd00d:	eb 23                	jmp    cd032 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x2f2>
   cd00f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd014:	41 b4 01             	mov    $0x1,%r12b
   cd017:	e9 cc 00 00 00       	jmp    cd0e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3a8>
   cd01c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd021:	f0 49 ff 0e          	lock decq (%r14)
   cd025:	75 0b                	jne    cd032 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x2f2>
   cd027:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   cd02c:	ff 15 ee 21 0a 00    	call   *0xa21ee(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd032:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   cd037:	f0 48 ff 08          	lock decq (%rax)
   cd03b:	41 b4 01             	mov    $0x1,%r12b
   cd03e:	0f 85 a4 00 00 00    	jne    cd0e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3a8>
   cd044:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cd049:	ff 15 d1 21 0a 00    	call   *0xa21d1(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd04f:	e9 94 00 00 00       	jmp    cd0e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3a8>
   cd054:	ff 15 ce 21 0a 00    	call   *0xa21ce(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cd05a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd05f:	e9 cc 00 00 00       	jmp    cd130 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3f0>
   cd064:	44 89 e3             	mov    %r12d,%ebx
   cd067:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd06c:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   cd071:	e9 a0 00 00 00       	jmp    cd116 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3d6>
   cd076:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd07b:	b3 01                	mov    $0x1,%bl
   cd07d:	eb 6b                	jmp    cd0ea <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3aa>
   cd07f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   cd084:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   cd08b:	00 00 00 00 00 
   cd090:	49 ff cf             	dec    %r15
   cd093:	74 11                	je     cd0a6 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x366>
   cd095:	4d 8d 66 18          	lea    0x18(%r14),%r12
   cd099:	4c 89 f7             	mov    %r14,%rdi
   cd09c:	e8 bf 46 04 00       	call   111760 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   cd0a1:	4d 89 e6             	mov    %r12,%r14
   cd0a4:	eb ea                	jmp    cd090 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x350>
   cd0a6:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   cd0ab:	48 8b 00             	mov    (%rax),%rax
   cd0ae:	48 85 c0             	test   %rax,%rax
   cd0b1:	74 16                	je     cd0c9 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x389>
   cd0b3:	48 c1 e0 03          	shl    $0x3,%rax
   cd0b7:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   cd0bb:	ba 08 00 00 00       	mov    $0x8,%edx
   cd0c0:	48 89 df             	mov    %rbx,%rdi
   cd0c3:	ff 15 77 21 0a 00    	call   *0xa2177(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cd0c9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   cd0ce:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   cd0d5:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
   cd0dc:	00 
   cd0dd:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
   cd0e4:	00 
   cd0e5:	45 31 e4             	xor    %r12d,%r12d
   cd0e8:	31 db                	xor    %ebx,%ebx
   cd0ea:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   cd0ef:	74 16                	je     cd107 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3c7>
   cd0f1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   cd0f6:	f0 48 ff 08          	lock decq (%rax)
   cd0fa:	75 0b                	jne    cd107 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3c7>
   cd0fc:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cd101:	ff 15 19 21 0a 00    	call   *0xa2119(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd107:	45 84 e4             	test   %r12b,%r12b
   cd10a:	74 20                	je     cd12c <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3ec>
   cd10c:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cd111:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   cd116:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   cd11b:	f0 48 ff 08          	lock decq (%rax)
   cd11f:	75 0b                	jne    cd12c <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x3ec>
   cd121:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cd126:	ff 15 f4 20 0a 00    	call   *0xa20f4(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd12c:	84 db                	test   %bl,%bl
   cd12e:	74 16                	je     cd146 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x406>
   cd130:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   cd135:	f0 48 ff 08          	lock decq (%rax)
   cd139:	75 0b                	jne    cd146 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields+0x406>
   cd13b:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   cd140:	ff 15 da 20 0a 00    	call   *0xa20da(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd146:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   cd14b:	e8 d0 bd 09 00       	call   168f20 <_Unwind_Resume@plt>
   cd150:	ff 15 d2 20 0a 00    	call   *0xa20d2(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cd156:	ff 15 cc 20 0a 00    	call   *0xa20cc(%rip)        # 16f228 <_DYNAMIC+0x2a8>
