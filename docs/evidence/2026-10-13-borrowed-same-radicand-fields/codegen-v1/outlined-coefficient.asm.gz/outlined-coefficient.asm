
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/outlined-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000cd750 <<hyperreal::computable::node::RadicalCoefficient>::multiply>:
   cd750:	55                   	push   %rbp
   cd751:	41 57                	push   %r15
   cd753:	41 56                	push   %r14
   cd755:	41 55                	push   %r13
   cd757:	41 54                	push   %r12
   cd759:	53                   	push   %rbx
   cd75a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   cd761:	49 89 d5             	mov    %rdx,%r13
   cd764:	48 8d 5e 18          	lea    0x18(%rsi),%rbx
   cd768:	48 89 34 24          	mov    %rsi,(%rsp)
   cd76c:	48 83 7e 28 00       	cmpq   $0x0,0x28(%rsi)
   cd771:	74 30                	je     cd7a3 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x53>
   cd773:	49 83 7d 10 00       	cmpq   $0x0,0x10(%r13)
   cd778:	75 41                	jne    cd7bb <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6b>
   cd77a:	49 83 7d 28 00       	cmpq   $0x0,0x28(%r13)
   cd77f:	75 3a                	jne    cd7bb <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6b>
   cd781:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   cd786:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cd78b:	4d 8d 65 08          	lea    0x8(%r13),%r12
   cd78f:	b0 01                	mov    $0x1,%al
   cd791:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   cd795:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   cd79c:	00 00 
   cd79e:	e9 af 01 00 00       	jmp    cd952 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x202>
   cd7a3:	49 8b 45 28          	mov    0x28(%r13),%rax
   cd7a7:	48 85 c0             	test   %rax,%rax
   cd7aa:	74 37                	je     cd7e3 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x93>
   cd7ac:	48 8b 0c 24          	mov    (%rsp),%rcx
   cd7b0:	48 83 79 10 00       	cmpq   $0x0,0x10(%rcx)
   cd7b5:	0f 84 b4 00 00 00    	je     cd86f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x11f>
   cd7bb:	48 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%rdi)
   cd7c2:	4c 8b 34 24          	mov    (%rsp),%r14
   cd7c6:	49 8b 46 30          	mov    0x30(%r14),%rax
   cd7ca:	f0 48 ff 08          	lock decq (%rax)
   cd7ce:	0f 85 10 03 00 00    	jne    cdae4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x394>
   cd7d4:	49 8d 7e 30          	lea    0x30(%r14),%rdi
   cd7d8:	ff 15 f2 1b 0a 00    	call   *0xa1bf2(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd7de:	e9 01 03 00 00       	jmp    cdae4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x394>
   cd7e3:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   cd7e8:	49 8b 4d 10          	mov    0x10(%r13),%rcx
   cd7ec:	48 8b 14 24          	mov    (%rsp),%rdx
   cd7f0:	48 8b 42 10          	mov    0x10(%rdx),%rax
   cd7f4:	48 83 f0 01          	xor    $0x1,%rax
   cd7f8:	4d 8d 65 08          	lea    0x8(%r13),%r12
   cd7fc:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   cd801:	48 83 f1 01          	xor    $0x1,%rcx
   cd805:	48 09 c1             	or     %rax,%rcx
   cd808:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cd80d:	0f 85 39 01 00 00    	jne    cd94c <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1fc>
   cd813:	4c 8b 7a 08          	mov    0x8(%rdx),%r15
   cd817:	49 8b 34 24          	mov    (%r12),%rsi
   cd81b:	40 b5 01             	mov    $0x1,%bpl
   cd81e:	4c 89 ff             	mov    %r15,%rdi
   cd821:	ff 15 51 1b 0a 00    	call   *0xa1b51(%rip)        # 16f378 <_DYNAMIC+0x248>
   cd827:	b9 01 00 00 00       	mov    $0x1,%ecx
   cd82c:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   cd831:	84 c0                	test   %al,%al
   cd833:	0f 84 13 01 00 00    	je     cd94c <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1fc>
   cd839:	49 8b 1f             	mov    (%r15),%rbx
   cd83c:	eb 0b                	jmp    cd849 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xf9>
   cd83e:	66 90                	xchg   %ax,%ax
   cd840:	4c 89 fb             	mov    %r15,%rbx
   cd843:	49 89 df             	mov    %rbx,%r15
   cd846:	48 8b 1b             	mov    (%rbx),%rbx
   cd849:	8b 43 60             	mov    0x60(%rbx),%eax
   cd84c:	84 c0                	test   %al,%al
   cd84e:	79 50                	jns    cd8a0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x150>
   cd850:	8b 43 60             	mov    0x60(%rbx),%eax
   cd853:	84 c0                	test   %al,%al
   cd855:	79 e9                	jns    cd840 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xf0>
   cd857:	8b 43 50             	mov    0x50(%rbx),%eax
   cd85a:	48 83 c3 40          	add    $0x40,%rbx
   cd85e:	85 c0                	test   %eax,%eax
   cd860:	74 e1                	je     cd843 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xf3>
   cd862:	48 89 df             	mov    %rbx,%rdi
   cd865:	4c 89 fe             	mov    %r15,%rsi
   cd868:	e8 2c 06 04 00       	call   10de99 <<std::sync::once_lock::OnceLock<hyperreal::rational::arithmetic::CachedRationalProduct>>::initialize::<<std::sync::once_lock::OnceLock<hyperreal::rational::arithmetic::CachedRationalProduct>>::get_or_init<<hyperreal::rational::arithmetic::Rational>::canonicalized_ref::{closure#0}>::{closure#0}, !>>
   cd86d:	eb d4                	jmp    cd843 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xf3>
   cd86f:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   cd874:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cd879:	4d 8d 65 08          	lea    0x8(%r13),%r12
   cd87d:	49 8b 4d 10          	mov    0x10(%r13),%rcx
   cd881:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   cd886:	48 c1 e0 03          	shl    $0x3,%rax
   cd88a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   cd88e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cd893:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   cd89a:	00 
   cd89b:	e9 bb 00 00 00       	jmp    cd95b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x20b>
   cd8a0:	80 7b 64 02          	cmpb   $0x2,0x64(%rbx)
   cd8a4:	75 5f                	jne    cd905 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1b5>
   cd8a6:	4c 8b 35 0b 1b 0a 00 	mov    0xa1b0b(%rip),%r14        # 16f3b8 <_DYNAMIC+0x288>
   cd8ad:	41 8b 46 18          	mov    0x18(%r14),%eax
   cd8b1:	85 c0                	test   %eax,%eax
   cd8b3:	0f 85 39 06 00 00    	jne    cdef2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7a2>
   cd8b9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
   cd8bd:	49 3b 56 10          	cmp    0x10(%r14),%rdx
   cd8c1:	75 42                	jne    cd905 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1b5>
   cd8c3:	49 8b 76 08          	mov    0x8(%r14),%rsi
   cd8c7:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
   cd8cb:	48 c1 e2 03          	shl    $0x3,%rdx
   cd8cf:	ff 15 eb 1a 0a 00    	call   *0xa1aeb(%rip)        # 16f3c0 <bcmp@GLIBC_2.2.5>
   cd8d5:	85 c0                	test   %eax,%eax
   cd8d7:	75 2c                	jne    cd905 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1b5>
   cd8d9:	41 8b 46 18          	mov    0x18(%r14),%eax
   cd8dd:	85 c0                	test   %eax,%eax
   cd8df:	0f 85 48 06 00 00    	jne    cdf2d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7dd>
   cd8e5:	48 8b 53 38          	mov    0x38(%rbx),%rdx
   cd8e9:	49 3b 56 10          	cmp    0x10(%r14),%rdx
   cd8ed:	75 16                	jne    cd905 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1b5>
   cd8ef:	49 8b 76 08          	mov    0x8(%r14),%rsi
   cd8f3:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
   cd8f7:	48 c1 e2 03          	shl    $0x3,%rdx
   cd8fb:	ff 15 bf 1a 0a 00    	call   *0xa1abf(%rip)        # 16f3c0 <bcmp@GLIBC_2.2.5>
   cd901:	85 c0                	test   %eax,%eax
   cd903:	74 47                	je     cd94c <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1fc>
   cd905:	48 8b 0c 24          	mov    (%rsp),%rcx
   cd909:	48 8b 41 30          	mov    0x30(%rcx),%rax
   cd90d:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   cd914:	00 
   cd915:	0f 10 01             	movups (%rcx),%xmm0
   cd918:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   cd91c:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   cd920:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   cd927:	00 
   cd928:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   cd92f:	00 
   cd930:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   cd935:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   cd93a:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   cd93f:	4c 89 ea             	mov    %r13,%rdx
   cd942:	e8 89 f4 ff ff       	call   ccdd0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand>
   cd947:	e9 0e 02 00 00       	jmp    cdb5a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x40a>
   cd94c:	b0 01                	mov    $0x1,%al
   cd94e:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   cd952:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   cd959:	00 00 
   cd95b:	48 8b 04 24          	mov    (%rsp),%rax
   cd95f:	48 8d 78 30          	lea    0x30(%rax),%rdi
   cd963:	49 8d 75 30          	lea    0x30(%r13),%rsi
   cd967:	40 b5 01             	mov    $0x1,%bpl
   cd96a:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
   cd971:	00 
   cd972:	48 89 b4 24 d0 00 00 	mov    %rsi,0xd0(%rsp)
   cd979:	00 
   cd97a:	e8 71 3e fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cd97f:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
   cd986:	00 
   cd987:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   cd98e:	00 
   cd98f:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
   cd996:	00 00 
   cd998:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
   cd99f:	00 00 
   cd9a1:	0f 57 c0             	xorps  %xmm0,%xmm0
   cd9a4:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
   cd9ab:	00 
   cd9ac:	48 c7 84 24 90 00 00 	movq   $0x8,0x90(%rsp)
   cd9b3:	00 08 00 00 00 
   cd9b8:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
   cd9bf:	00 00 00 00 00 
   cd9c4:	48 8b 04 24          	mov    (%rsp),%rax
   cd9c8:	4c 8b 70 08          	mov    0x8(%rax),%r14
   cd9cc:	4c 8b 68 10          	mov    0x10(%rax),%r13
   cd9d0:	49 c1 e5 04          	shl    $0x4,%r13
   cd9d4:	48 8d 5c 24 70       	lea    0x70(%rsp),%rbx
   cd9d9:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
   cd9e0:	00 
   cd9e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cd9e8:	0f 1f 84 00 00 00 00 
   cd9ef:	00 
   cd9f0:	4d 85 ed             	test   %r13,%r13
   cd9f3:	74 42                	je     cda37 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x2e7>
   cd9f5:	49 8b 06             	mov    (%r14),%rax
   cd9f8:	f0 48 ff 00          	lock incq (%rax)
   cd9fc:	0f 8e 29 05 00 00    	jle    cdf2b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7db>
   cda02:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   cda06:	4d 8b 3e             	mov    (%r14),%r15
   cda09:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   cda0e:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   cda15:	00 
   cda16:	e8 d5 3d fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cda1b:	48 89 df             	mov    %rbx,%rdi
   cda1e:	4c 89 fe             	mov    %r15,%rsi
   cda21:	48 89 c2             	mov    %rax,%rdx
   cda24:	e8 c7 ee ff ff       	call   cc8f0 <<hyperreal::computable::node::RadicalCoefficient>::insert_radical>
   cda29:	49 83 c6 10          	add    $0x10,%r14
   cda2d:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
   cda31:	84 c0                	test   %al,%al
   cda33:	75 bb                	jne    cd9f0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x2a0>
   cda35:	eb 70                	jmp    cdaa7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x357>
   cda37:	4d 8b 24 24          	mov    (%r12),%r12
   cda3b:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
   cda40:	49 c1 e6 04          	shl    $0x4,%r14
   cda44:	48 8d 5c 24 70       	lea    0x70(%rsp),%rbx
   cda49:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
   cda50:	00 
   cda51:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
   cda58:	00 
   cda59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   cda60:	4d 85 f6             	test   %r14,%r14
   cda63:	0f 84 03 01 00 00    	je     cdb6c <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x41c>
   cda69:	49 8b 04 24          	mov    (%r12),%rax
   cda6d:	f0 48 ff 00          	lock incq (%rax)
   cda71:	0f 8e b4 04 00 00    	jle    cdf2b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7db>
   cda77:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
   cda7c:	4d 8b 3c 24          	mov    (%r12),%r15
   cda80:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   cda85:	48 89 ee             	mov    %rbp,%rsi
   cda88:	e8 63 3d fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cda8d:	48 89 df             	mov    %rbx,%rdi
   cda90:	4c 89 fe             	mov    %r15,%rsi
   cda93:	48 89 c2             	mov    %rax,%rdx
   cda96:	e8 55 ee ff ff       	call   cc8f0 <<hyperreal::computable::node::RadicalCoefficient>::insert_radical>
   cda9b:	49 83 c4 10          	add    $0x10,%r12
   cda9f:	49 83 c6 f0          	add    $0xfffffffffffffff0,%r14
   cdaa3:	84 c0                	test   %al,%al
   cdaa5:	75 b9                	jne    cda60 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x310>
   cdaa7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cdaac:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cdab3:	40 b5 01             	mov    $0x1,%bpl
   cdab6:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cdabb:	e8 30 33 fe ff       	call   b0df0 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cdac0:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   cdac7:	00 
   cdac8:	48 8b 07             	mov    (%rdi),%rax
   cdacb:	f0 48 ff 08          	lock decq (%rax)
   cdacf:	75 06                	jne    cdad7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x387>
   cdad1:	ff 15 f9 18 0a 00    	call   *0xa18f9(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdad7:	40 84 ed             	test   %bpl,%bpl
   cdada:	4c 8b 34 24          	mov    (%rsp),%r14
   cdade:	49 8d 5e 18          	lea    0x18(%r14),%rbx
   cdae2:	74 23                	je     cdb07 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3b7>
   cdae4:	4c 89 f7             	mov    %r14,%rdi
   cdae7:	e8 34 59 04 00       	call   113420 <<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdaec:	49 8b 36             	mov    (%r14),%rsi
   cdaef:	48 85 f6             	test   %rsi,%rsi
   cdaf2:	74 13                	je     cdb07 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3b7>
   cdaf4:	49 8b 7e 08          	mov    0x8(%r14),%rdi
   cdaf8:	48 c1 e6 04          	shl    $0x4,%rsi
   cdafc:	ba 08 00 00 00       	mov    $0x8,%edx
   cdb01:	ff 15 e9 18 0a 00    	call   *0xa18e9(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cdb07:	49 8b 7e 20          	mov    0x20(%r14),%rdi
   cdb0b:	4d 8b 76 28          	mov    0x28(%r14),%r14
   cdb0f:	49 ff c6             	inc    %r14
   cdb12:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cdb19:	1f 84 00 00 00 00 00 
   cdb20:	49 83 fe 01          	cmp    $0x1,%r14
   cdb24:	74 11                	je     cdb37 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3e7>
   cdb26:	4c 8d 7f 18          	lea    0x18(%rdi),%r15
   cdb2a:	49 ff ce             	dec    %r14
   cdb2d:	e8 7e 3d 04 00       	call   1118b0 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   cdb32:	4c 89 ff             	mov    %r15,%rdi
   cdb35:	eb e9                	jmp    cdb20 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3d0>
   cdb37:	48 8b 03             	mov    (%rbx),%rax
   cdb3a:	48 85 c0             	test   %rax,%rax
   cdb3d:	74 1b                	je     cdb5a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x40a>
   cdb3f:	48 8b 0c 24          	mov    (%rsp),%rcx
   cdb43:	48 8b 79 20          	mov    0x20(%rcx),%rdi
   cdb47:	48 c1 e0 03          	shl    $0x3,%rax
   cdb4b:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   cdb4f:	ba 08 00 00 00       	mov    $0x8,%edx
   cdb54:	ff 15 96 18 0a 00    	call   *0xa1896(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cdb5a:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   cdb61:	5b                   	pop    %rbx
   cdb62:	41 5c                	pop    %r12
   cdb64:	41 5d                	pop    %r13
   cdb66:	41 5e                	pop    %r14
   cdb68:	41 5f                	pop    %r15
   cdb6a:	5d                   	pop    %rbp
   cdb6b:	c3                   	ret
   cdb6c:	48 8b 0c 24          	mov    (%rsp),%rcx
   cdb70:	48 8b 01             	mov    (%rcx),%rax
   cdb73:	48 8b 59 08          	mov    0x8(%rcx),%rbx
   cdb77:	48 8b 49 10          	mov    0x10(%rcx),%rcx
   cdb7b:	48 89 ca             	mov    %rcx,%rdx
   cdb7e:	48 c1 e2 04          	shl    $0x4,%rdx
   cdb82:	48 01 da             	add    %rbx,%rdx
   cdb85:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   cdb8a:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   cdb8f:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cdb94:	48 89 94 24 d8 00 00 	mov    %rdx,0xd8(%rsp)
   cdb9b:	00 
   cdb9c:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   cdba1:	48 85 c9             	test   %rcx,%rcx
   cdba4:	0f 84 b9 01 00 00    	je     cdd63 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x613>
   cdbaa:	4c 8d ac 24 c8 00 00 	lea    0xc8(%rsp),%r13
   cdbb1:	00 
   cdbb2:	eb 0e                	jmp    cdbc2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x472>
   cdbb4:	48 3b 9c 24 d8 00 00 	cmp    0xd8(%rsp),%rbx
   cdbbb:	00 
   cdbbc:	0f 84 a1 01 00 00    	je     cdd63 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x613>
   cdbc2:	48 8d 4b 10          	lea    0x10(%rbx),%rcx
   cdbc6:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
   cdbcd:	00 
   cdbce:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   cdbd3:	48 8b 0b             	mov    (%rbx),%rcx
   cdbd6:	48 8b 43 08          	mov    0x8(%rbx),%rax
   cdbda:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
   cdbe1:	00 
   cdbe2:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
   cdbe9:	00 
   cdbea:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   cdbf1:	00 
   cdbf2:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   cdbf7:	4c 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%r14
   cdbfe:	00 
   cdbff:	48 8b ac 24 f0 00 00 	mov    0xf0(%rsp),%rbp
   cdc06:	00 
   cdc07:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
   cdc0d:	75 5e                	jne    cdc6d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x51d>
   cdc0f:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   cdc16:	00 
   cdc17:	f0 48 ff 08          	lock decq (%rax)
   cdc1b:	75 0b                	jne    cdc28 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x4d8>
   cdc1d:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cdc22:	ff 15 a8 17 0a 00    	call   *0xa17a8(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdc28:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   cdc2f:	00 
   cdc30:	f0 48 ff 08          	lock decq (%rax)
   cdc34:	48 8b 9c 24 f8 00 00 	mov    0xf8(%rsp),%rbx
   cdc3b:	00 
   cdc3c:	0f 85 72 ff ff ff    	jne    cdbb4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x464>
   cdc42:	4c 89 ef             	mov    %r13,%rdi
   cdc45:	ff 15 85 17 0a 00    	call   *0xa1785(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdc4b:	e9 64 ff ff ff       	jmp    cdbb4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x464>
   cdc50:	4c 89 ff             	mov    %r15,%rdi
   cdc53:	48 89 de             	mov    %rbx,%rsi
   cdc56:	e8 65 22 fc ff       	call   8fec0 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Add>::add>
   cdc5b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   cdc62:	00 
   cdc63:	48 83 c5 10          	add    $0x10,%rbp
   cdc67:	49 83 c6 f0          	add    $0xfffffffffffffff0,%r14
   cdc6b:	74 a2                	je     cdc0f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x4bf>
   cdc6d:	48 8d 75 08          	lea    0x8(%rbp),%rsi
   cdc71:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cdc76:	e8 75 3b fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdc7b:	49 89 c4             	mov    %rax,%r12
   cdc7e:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   cdc85:	00 
   cdc86:	4c 89 ef             	mov    %r13,%rdi
   cdc89:	48 89 ee             	mov    %rbp,%rsi
   cdc8c:	ff 15 e6 16 0a 00    	call   *0xa16e6(%rip)        # 16f378 <_DYNAMIC+0x248>
   cdc92:	84 c0                	test   %al,%al
   cdc94:	74 3a                	je     cdcd0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x580>
   cdc96:	4c 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%r15
   cdc9d:	00 
   cdc9e:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   cdca3:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
   cdca8:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cdcad:	4c 89 ee             	mov    %r13,%rsi
   cdcb0:	e8 3b 3b fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdcb5:	48 89 c3             	mov    %rax,%rbx
   cdcb8:	f0 49 ff 0c 24       	lock decq (%r12)
   cdcbd:	75 91                	jne    cdc50 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x500>
   cdcbf:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cdcc4:	ff 15 06 17 0a 00    	call   *0xa1706(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdcca:	eb 84                	jmp    cdc50 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x500>
   cdccc:	0f 1f 40 00          	nopl   0x0(%rax)
   cdcd0:	4c 89 ef             	mov    %r13,%rdi
   cdcd3:	48 89 ee             	mov    %rbp,%rsi
   cdcd6:	e8 15 3b fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdcdb:	48 89 c7             	mov    %rax,%rdi
   cdcde:	e8 dd 56 fa ff       	call   733c0 <<hyperreal::rational::arithmetic::Rational>::extract_square_reduced_retained>
   cdce3:	49 89 d7             	mov    %rdx,%r15
   cdce6:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   cdceb:	4c 89 e7             	mov    %r12,%rdi
   cdcee:	48 89 c6             	mov    %rax,%rsi
   cdcf1:	e8 7a 46 fc ff       	call   92370 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdcf6:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cdcfb:	4c 89 fe             	mov    %r15,%rsi
   cdcfe:	48 89 c2             	mov    %rax,%rdx
   cdd01:	e8 ea eb ff ff       	call   cc8f0 <<hyperreal::computable::node::RadicalCoefficient>::insert_radical>
   cdd06:	84 c0                	test   %al,%al
   cdd08:	0f 85 55 ff ff ff    	jne    cdc63 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x513>
   cdd0e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cdd13:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cdd1a:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   cdd21:	00 
   cdd22:	f0 48 ff 08          	lock decq (%rax)
   cdd26:	75 0b                	jne    cdd33 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x5e3>
   cdd28:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cdd2d:	ff 15 9d 16 0a 00    	call   *0xa169d(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdd33:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   cdd3a:	00 
   cdd3b:	f0 48 ff 08          	lock decq (%rax)
   cdd3f:	75 0e                	jne    cdd4f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x5ff>
   cdd41:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cdd48:	00 
   cdd49:	ff 15 81 16 0a 00    	call   *0xa1681(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdd4f:	41 b7 01             	mov    $0x1,%r15b
   cdd52:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdd57:	e8 54 fc 03 00       	call   10d9b0 <<alloc::vec::into_iter::IntoIter<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdd5c:	31 ed                	xor    %ebp,%ebp
   cdd5e:	e9 53 fd ff ff       	jmp    cdab6 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x366>
   cdd63:	41 b7 01             	mov    $0x1,%r15b
   cdd66:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdd6b:	e8 40 fc 03 00       	call   10d9b0 <<alloc::vec::into_iter::IntoIter<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdd70:	48 8b 0c 24          	mov    (%rsp),%rcx
   cdd74:	48 8b 41 18          	mov    0x18(%rcx),%rax
   cdd78:	4c 8b 71 20          	mov    0x20(%rcx),%r14
   cdd7c:	48 8b 49 28          	mov    0x28(%rcx),%rcx
   cdd80:	48 8d 14 cd 00 00 00 	lea    0x0(,%rcx,8),%rdx
   cdd87:	00 
   cdd88:	4c 8d 24 52          	lea    (%rdx,%rdx,2),%r12
   cdd8c:	4b 8d 14 26          	lea    (%r14,%r12,1),%rdx
   cdd90:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   cdd95:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   cdd9a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cdd9f:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   cdda4:	48 85 c9             	test   %rcx,%rcx
   cdda7:	74 6f                	je     cde18 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6c8>
   cdda9:	49 83 c6 18          	add    $0x18,%r14
   cddad:	0f 1f 00             	nopl   (%rax)
   cddb0:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   cddb5:	4d 8b 7e e8          	mov    -0x18(%r14),%r15
   cddb9:	4d 85 ff             	test   %r15,%r15
   cddbc:	74 5a                	je     cde18 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6c8>
   cddbe:	4d 8b 6e f0          	mov    -0x10(%r14),%r13
   cddc2:	49 8b 5e f8          	mov    -0x8(%r14),%rbx
   cddc6:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
   cddcb:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
   cddd0:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   cddd5:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   cddda:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   cdde1:	00 
   cdde2:	e8 09 3a fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdde7:	48 89 c5             	mov    %rax,%rbp
   cddea:	f0 48 ff 0b          	lock decq (%rbx)
   cddee:	75 0b                	jne    cddfb <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6ab>
   cddf0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   cddf5:	ff 15 d5 15 0a 00    	call   *0xa15d5(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cddfb:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cde00:	4c 89 fe             	mov    %r15,%rsi
   cde03:	4c 89 ea             	mov    %r13,%rdx
   cde06:	48 89 e9             	mov    %rbp,%rcx
   cde09:	e8 92 e7 ff ff       	call   cc5a0 <<hyperreal::computable::node::RadicalCoefficient>::insert_atom>
   cde0e:	49 83 c6 18          	add    $0x18,%r14
   cde12:	49 83 c4 e8          	add    $0xffffffffffffffe8,%r12
   cde16:	75 98                	jne    cddb0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x660>
   cde18:	45 31 ff             	xor    %r15d,%r15d
   cde1b:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cde20:	e8 bb fa 03 00       	call   10d8e0 <<alloc::vec::into_iter::IntoIter<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cde25:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   cde2a:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cde2f:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
   cde36:	00 
   cde37:	75 6e                	jne    cdea7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x757>
   cde39:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   cde40:	00 
   cde41:	48 8b 58 20          	mov    0x20(%rax),%rbx
   cde45:	48 01 5c 24 20       	add    %rbx,0x20(%rsp)
   cde4a:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
   cde4f:	90                   	nop
   cde50:	4c 8b 23             	mov    (%rbx),%r12
   cde53:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
   cde57:	f0 49 ff 04 24       	lock incq (%r12)
   cde5c:	0f 8e c9 00 00 00    	jle    cdf2b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7db>
   cde62:	4d 85 ed             	test   %r13,%r13
   cde65:	74 0b                	je     cde72 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x722>
   cde67:	f0 49 ff 45 00       	lock incq 0x0(%r13)
   cde6c:	0f 8e b9 00 00 00    	jle    cdf2b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7db>
   cde72:	48 83 c3 10          	add    $0x10,%rbx
   cde76:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   cde7b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
   cde80:	48 89 df             	mov    %rbx,%rdi
   cde83:	48 89 ee             	mov    %rbp,%rsi
   cde86:	e8 65 39 fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cde8b:	4c 89 ff             	mov    %r15,%rdi
   cde8e:	4c 89 e6             	mov    %r12,%rsi
   cde91:	4c 89 ea             	mov    %r13,%rdx
   cde94:	48 89 c1             	mov    %rax,%rcx
   cde97:	e8 04 e7 ff ff       	call   cc5a0 <<hyperreal::computable::node::RadicalCoefficient>::insert_atom>
   cde9c:	48 83 c3 08          	add    $0x8,%rbx
   cdea0:	48 3b 5c 24 20       	cmp    0x20(%rsp),%rbx
   cdea5:	75 a9                	jne    cde50 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x700>
   cdea7:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   cdeae:	00 
   cdeaf:	49 89 46 30          	mov    %rax,0x30(%r14)
   cdeb3:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cdeb8:	0f 10 8c 24 80 00 00 	movups 0x80(%rsp),%xmm1
   cdebf:	00 
   cdec0:	0f 10 94 24 90 00 00 	movups 0x90(%rsp),%xmm2
   cdec7:	00 
   cdec8:	41 0f 11 56 20       	movups %xmm2,0x20(%r14)
   cdecd:	41 0f 11 4e 10       	movups %xmm1,0x10(%r14)
   cded2:	41 0f 11 06          	movups %xmm0,(%r14)
   cded6:	48 8b 45 00          	mov    0x0(%rbp),%rax
   cdeda:	f0 48 ff 08          	lock decq (%rax)
   cdede:	0f 85 76 fc ff ff    	jne    cdb5a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x40a>
   cdee4:	48 89 ef             	mov    %rbp,%rdi
   cdee7:	ff 15 e3 14 0a 00    	call   *0xa14e3(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdeed:	e9 68 fc ff ff       	jmp    cdb5a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x40a>
   cdef2:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   cdef7:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   cdefc:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   cdf01:	40 b5 01             	mov    $0x1,%bpl
   cdf04:	49 8d 7e 18          	lea    0x18(%r14),%rdi
   cdf08:	48 8d 0d 81 d1 09 00 	lea    0x9d181(%rip),%rcx        # 16b090 <anon.afeede234644f26776946e76b404b106.3.llvm.3222190057612512104+0x28>
   cdf0f:	4c 8d 05 3a d1 09 00 	lea    0x9d13a(%rip),%r8        # 16b050 <anon.afeede234644f26776946e76b404b106.2.llvm.3222190057612512104>
   cdf16:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   cdf1b:	be 01 00 00 00       	mov    $0x1,%esi
   cdf20:	ff 15 4a 14 0a 00    	call   *0xa144a(%rip)        # 16f370 <_DYNAMIC+0x240>
   cdf26:	e9 8e f9 ff ff       	jmp    cd8b9 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x169>
   cdf2b:	0f 0b                	ud2
   cdf2d:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   cdf32:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   cdf37:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   cdf3c:	40 b5 01             	mov    $0x1,%bpl
   cdf3f:	49 8d 7e 18          	lea    0x18(%r14),%rdi
   cdf43:	48 8d 0d 46 d1 09 00 	lea    0x9d146(%rip),%rcx        # 16b090 <anon.afeede234644f26776946e76b404b106.3.llvm.3222190057612512104+0x28>
   cdf4a:	4c 8d 05 ff d0 09 00 	lea    0x9d0ff(%rip),%r8        # 16b050 <anon.afeede234644f26776946e76b404b106.2.llvm.3222190057612512104>
   cdf51:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   cdf56:	be 01 00 00 00       	mov    $0x1,%esi
   cdf5b:	ff 15 0f 14 0a 00    	call   *0xa140f(%rip)        # 16f370 <_DYNAMIC+0x240>
   cdf61:	e9 7f f9 ff ff       	jmp    cd8e5 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x195>
   cdf66:	49 89 c5             	mov    %rax,%r13
   cdf69:	40 b5 01             	mov    $0x1,%bpl
   cdf6c:	e9 a5 00 00 00       	jmp    ce016 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8c6>
   cdf71:	eb 02                	jmp    cdf75 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x825>
   cdf73:	eb 0b                	jmp    cdf80 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x830>
   cdf75:	49 89 c5             	mov    %rax,%r13
   cdf78:	41 b6 01             	mov    $0x1,%r14b
   cdf7b:	e9 f3 01 00 00       	jmp    ce173 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa23>
   cdf80:	49 89 c5             	mov    %rax,%r13
   cdf83:	41 b6 01             	mov    $0x1,%r14b
   cdf86:	e9 cc 01 00 00       	jmp    ce157 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa07>
   cdf8b:	49 89 c5             	mov    %rax,%r13
   cdf8e:	31 ed                	xor    %ebp,%ebp
   cdf90:	e9 70 01 00 00       	jmp    ce105 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b5>
   cdf95:	49 89 c5             	mov    %rax,%r13
   cdf98:	40 84 ed             	test   %bpl,%bpl
   cdf9b:	75 4f                	jne    cdfec <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x89c>
   cdf9d:	e9 a8 00 00 00       	jmp    ce04a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8fa>
   cdfa2:	49 89 c5             	mov    %rax,%r13
   cdfa5:	eb 19                	jmp    cdfc0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x870>
   cdfa7:	49 89 c5             	mov    %rax,%r13
   cdfaa:	eb 1e                	jmp    cdfca <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x87a>
   cdfac:	49 89 c5             	mov    %rax,%r13
   cdfaf:	f0 48 ff 0b          	lock decq (%rbx)
   cdfb3:	75 0b                	jne    cdfc0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x870>
   cdfb5:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   cdfba:	ff 15 10 14 0a 00    	call   *0xa1410(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cdfc0:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cdfc5:	e8 86 29 fe ff       	call   b0950 <core::ptr::drop_glue::<hyperreal::computable::node::Computable>>
   cdfca:	31 ed                	xor    %ebp,%ebp
   cdfcc:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdfd1:	e8 0a f9 03 00       	call   10d8e0 <<alloc::vec::into_iter::IntoIter<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdfd6:	45 31 ff             	xor    %r15d,%r15d
   cdfd9:	e9 27 01 00 00       	jmp    ce105 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b5>
   cdfde:	ff 15 f4 13 0a 00    	call   *0xa13f4(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   cdfe4:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cdfe9:	49 89 c5             	mov    %rax,%r13
   cdfec:	48 8b 3c 24          	mov    (%rsp),%rdi
   cdff0:	e8 cb 1a fe ff       	call   afac0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   cdff5:	eb 53                	jmp    ce04a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8fa>
   cdff7:	49 89 c5             	mov    %rax,%r13
   cdffa:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdfff:	e8 4c 29 fe ff       	call   b0950 <core::ptr::drop_glue::<hyperreal::computable::node::Computable>>
   ce004:	eb 03                	jmp    ce009 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8b9>
   ce006:	49 89 c5             	mov    %rax,%r13
   ce009:	31 ed                	xor    %ebp,%ebp
   ce00b:	45 31 ff             	xor    %r15d,%r15d
   ce00e:	e9 f2 00 00 00       	jmp    ce105 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b5>
   ce013:	49 89 c5             	mov    %rax,%r13
   ce016:	41 b7 01             	mov    $0x1,%r15b
   ce019:	e9 84 01 00 00       	jmp    ce1a2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa52>
   ce01e:	49 89 c5             	mov    %rax,%r13
   ce021:	eb 70                	jmp    ce093 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x943>
   ce023:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   ce028:	49 89 c5             	mov    %rax,%r13
   ce02b:	49 8b 36             	mov    (%r14),%rsi
   ce02e:	48 85 f6             	test   %rsi,%rsi
   ce031:	74 17                	je     ce04a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8fa>
   ce033:	48 8b 04 24          	mov    (%rsp),%rax
   ce037:	48 8b 78 08          	mov    0x8(%rax),%rdi
   ce03b:	48 c1 e6 04          	shl    $0x4,%rsi
   ce03f:	ba 08 00 00 00       	mov    $0x8,%edx
   ce044:	ff 15 a6 13 0a 00    	call   *0xa13a6(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   ce04a:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   ce04f:	e8 9c 19 fe ff       	call   af9f0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   ce054:	e9 b6 01 00 00       	jmp    ce20f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xabf>
   ce059:	49 89 c5             	mov    %rax,%r13
   ce05c:	f0 49 ff 0f          	lock decq (%r15)
   ce060:	41 b6 01             	mov    $0x1,%r14b
   ce063:	0f 85 d5 00 00 00    	jne    ce13e <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9ee>
   ce069:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   ce06e:	ff 15 5c 13 0a 00    	call   *0xa135c(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce074:	e9 c5 00 00 00       	jmp    ce13e <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9ee>
   ce079:	49 89 c5             	mov    %rax,%r13
   ce07c:	eb 26                	jmp    ce0a4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x954>
   ce07e:	49 89 c5             	mov    %rax,%r13
   ce081:	f0 49 ff 0c 24       	lock decq (%r12)
   ce086:	75 0b                	jne    ce093 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x943>
   ce088:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   ce08d:	ff 15 3d 13 0a 00    	call   *0xa133d(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce093:	f0 49 ff 0f          	lock decq (%r15)
   ce097:	75 0b                	jne    ce0a4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x954>
   ce099:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   ce09e:	ff 15 2c 13 0a 00    	call   *0xa132c(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce0a4:	45 31 f6             	xor    %r14d,%r14d
   ce0a7:	e9 92 00 00 00       	jmp    ce13e <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9ee>
   ce0ac:	ff 15 26 13 0a 00    	call   *0xa1326(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   ce0b2:	eb 21                	jmp    ce0d5 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x985>
   ce0b4:	49 89 c5             	mov    %rax,%r13
   ce0b7:	f0 49 ff 0f          	lock decq (%r15)
   ce0bb:	40 b5 01             	mov    $0x1,%bpl
   ce0be:	75 42                	jne    ce102 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b2>
   ce0c0:	40 b5 01             	mov    $0x1,%bpl
   ce0c3:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ce0c8:	ff 15 02 13 0a 00    	call   *0xa1302(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce0ce:	41 b7 01             	mov    $0x1,%r15b
   ce0d1:	eb 32                	jmp    ce105 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b5>
   ce0d3:	eb 27                	jmp    ce0fc <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9ac>
   ce0d5:	49 89 c5             	mov    %rax,%r13
   ce0d8:	41 b6 01             	mov    $0x1,%r14b
   ce0db:	eb 61                	jmp    ce13e <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9ee>
   ce0dd:	49 89 c5             	mov    %rax,%r13
   ce0e0:	f0 49 ff 0f          	lock decq (%r15)
   ce0e4:	40 b5 01             	mov    $0x1,%bpl
   ce0e7:	75 19                	jne    ce102 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b2>
   ce0e9:	40 b5 01             	mov    $0x1,%bpl
   ce0ec:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ce0f1:	ff 15 d9 12 0a 00    	call   *0xa12d9(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce0f7:	41 b7 01             	mov    $0x1,%r15b
   ce0fa:	eb 09                	jmp    ce105 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b5>
   ce0fc:	49 89 c5             	mov    %rax,%r13
   ce0ff:	40 b5 01             	mov    $0x1,%bpl
   ce102:	41 b7 01             	mov    $0x1,%r15b
   ce105:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   ce10c:	00 
   ce10d:	f0 48 ff 08          	lock decq (%rax)
   ce111:	75 78                	jne    ce18b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa3b>
   ce113:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   ce11a:	00 
   ce11b:	ff 15 af 12 0a 00    	call   *0xa12af(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce121:	eb 68                	jmp    ce18b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa3b>
   ce123:	49 89 c5             	mov    %rax,%r13
   ce126:	f0 49 ff 0c 24       	lock decq (%r12)
   ce12b:	41 b6 01             	mov    $0x1,%r14b
   ce12e:	75 0e                	jne    ce13e <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9ee>
   ce130:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
   ce137:	00 
   ce138:	ff 15 92 12 0a 00    	call   *0xa1292(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce13e:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   ce145:	00 
   ce146:	f0 48 ff 08          	lock decq (%rax)
   ce14a:	75 0b                	jne    ce157 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa07>
   ce14c:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   ce151:	ff 15 79 12 0a 00    	call   *0xa1279(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce157:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   ce15e:	00 
   ce15f:	f0 48 ff 08          	lock decq (%rax)
   ce163:	75 0e                	jne    ce173 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa23>
   ce165:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   ce16c:	00 
   ce16d:	ff 15 5d 12 0a 00    	call   *0xa125d(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce173:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ce178:	e8 33 f8 03 00       	call   10d9b0 <<alloc::vec::into_iter::IntoIter<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   ce17d:	41 b7 01             	mov    $0x1,%r15b
   ce180:	31 ed                	xor    %ebp,%ebp
   ce182:	45 84 f6             	test   %r14b,%r14b
   ce185:	0f 85 7a ff ff ff    	jne    ce105 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b5>
   ce18b:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   ce190:	e8 2b 19 fe ff       	call   afac0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   ce195:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
   ce19c:	00 
   ce19d:	e8 4e 18 fe ff       	call   af9f0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   ce1a2:	48 8b 04 24          	mov    (%rsp),%rax
   ce1a6:	48 8b 40 30          	mov    0x30(%rax),%rax
   ce1aa:	f0 48 ff 08          	lock decq (%rax)
   ce1ae:	75 0e                	jne    ce1be <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa6e>
   ce1b0:	48 8b 04 24          	mov    (%rsp),%rax
   ce1b4:	48 8d 78 30          	lea    0x30(%rax),%rdi
   ce1b8:	ff 15 12 12 0a 00    	call   *0xa1212(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ce1be:	40 84 ed             	test   %bpl,%bpl
   ce1c1:	74 09                	je     ce1cc <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa7c>
   ce1c3:	48 8b 3c 24          	mov    (%rsp),%rdi
   ce1c7:	e8 f4 18 fe ff       	call   afac0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   ce1cc:	45 84 ff             	test   %r15b,%r15b
   ce1cf:	74 3e                	je     ce20f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xabf>
   ce1d1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   ce1d6:	e8 15 18 fe ff       	call   af9f0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   ce1db:	eb 32                	jmp    ce20f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xabf>
   ce1dd:	ff 15 f5 11 0a 00    	call   *0xa11f5(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   ce1e3:	49 89 dc             	mov    %rbx,%r12
   ce1e6:	49 89 c5             	mov    %rax,%r13
   ce1e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   ce1f0:	49 ff ce             	dec    %r14
   ce1f3:	74 11                	je     ce206 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xab6>
   ce1f5:	49 8d 5f 18          	lea    0x18(%r15),%rbx
   ce1f9:	4c 89 ff             	mov    %r15,%rdi
   ce1fc:	e8 af 36 04 00       	call   1118b0 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   ce201:	49 89 df             	mov    %rbx,%r15
   ce204:	eb ea                	jmp    ce1f0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaa0>
   ce206:	49 8b 04 24          	mov    (%r12),%rax
   ce20a:	48 85 c0             	test   %rax,%rax
   ce20d:	75 08                	jne    ce217 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xac7>
   ce20f:	4c 89 ef             	mov    %r13,%rdi
   ce212:	e8 59 ae 09 00       	call   169070 <_Unwind_Resume@plt>
   ce217:	48 8b 0c 24          	mov    (%rsp),%rcx
   ce21b:	48 8b 79 20          	mov    0x20(%rcx),%rdi
   ce21f:	48 c1 e0 03          	shl    $0x3,%rax
   ce223:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   ce227:	ba 08 00 00 00       	mov    $0x8,%edx
   ce22c:	ff 15 be 11 0a 00    	call   *0xa11be(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   ce232:	4c 89 ef             	mov    %r13,%rdi
   ce235:	e8 36 ae 09 00       	call   169070 <_Unwind_Resume@plt>
   ce23a:	ff 15 98 11 0a 00    	call   *0xa1198(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
