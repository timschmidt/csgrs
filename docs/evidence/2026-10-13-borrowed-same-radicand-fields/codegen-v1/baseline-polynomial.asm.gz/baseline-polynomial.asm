
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/baseline-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000cef20 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply>:
   cef20:	55                   	push   %rbp
   cef21:	41 57                	push   %r15
   cef23:	41 56                	push   %r14
   cef25:	41 55                	push   %r13
   cef27:	41 54                	push   %r12
   cef29:	53                   	push   %rbx
   cef2a:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
   cef31:	49 89 fe             	mov    %rdi,%r14
   cef34:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
   cef3b:	00 00 
   cef3d:	48 c7 44 24 48 08 00 	movq   $0x8,0x48(%rsp)
   cef44:	00 00 
   cef46:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   cef4d:	00 00 
   cef4f:	48 8b 42 08          	mov    0x8(%rdx),%rax
   cef53:	48 89 04 24          	mov    %rax,(%rsp)
   cef57:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   cef5c:	4c 8b 62 10          	mov    0x10(%rdx),%r12
   cef60:	49 83 fc 01          	cmp    $0x1,%r12
   cef64:	0f 85 b8 01 00 00    	jne    cf122 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x202>
   cef6a:	48 8b 06             	mov    (%rsi),%rax
   cef6d:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   cef71:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
   cef75:	49 89 cd             	mov    %rcx,%r13
   cef78:	49 c1 e5 06          	shl    $0x6,%r13
   cef7c:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   cef80:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cef85:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cef8a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   cef8f:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   cef94:	48 85 c9             	test   %rcx,%rcx
   cef97:	0f 84 64 01 00 00    	je     cf101 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x1e1>
   cef9d:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   cefa2:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   cefa7:	48 8b 04 24          	mov    (%rsp),%rax
   cefab:	48 83 c0 08          	add    $0x8,%rax
   cefaf:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cefb4:	4c 8d bc 24 98 00 00 	lea    0x98(%rsp),%r15
   cefbb:	00 
   cefbc:	48 83 c3 40          	add    $0x40,%rbx
   cefc0:	48 8d ac 24 00 01 00 	lea    0x100(%rsp),%rbp
   cefc7:	00 
   cefc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   cefcf:	00 
   cefd0:	48 8b 43 c8          	mov    -0x38(%rbx),%rax
   cefd4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   cefd8:	0f 84 19 01 00 00    	je     cf0f7 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x1d7>
   cefde:	44 0f b7 73 c0       	movzwl -0x40(%rbx),%r14d
   cefe3:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   cefea:	00 
   cefeb:	0f 10 43 d0          	movups -0x30(%rbx),%xmm0
   cefef:	0f 10 4b e0          	movups -0x20(%rbx),%xmm1
   ceff3:	0f 10 53 f0          	movups -0x10(%rbx),%xmm2
   ceff7:	41 0f 11 57 20       	movups %xmm2,0x20(%r15)
   ceffc:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
   cf001:	41 0f 11 07          	movups %xmm0,(%r15)
   cf005:	48 8b 04 24          	mov    (%rsp),%rax
   cf009:	66 44 03 30          	add    (%rax),%r14w
   cf00d:	0f 80 7b 06 00 00    	jo     cf68e <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x76e>
   cf013:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   cf01a:	00 
   cf01b:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   cf022:	00 
   cf023:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   cf02a:	00 
   cf02b:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   cf032:	00 
   cf033:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
   cf03a:	00 
   cf03b:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
   cf042:	00 
   cf043:	0f 29 8c 24 20 01 00 	movaps %xmm1,0x120(%rsp)
   cf04a:	00 
   cf04b:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
   cf052:	00 
   cf053:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   cf05a:	00 
   cf05b:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
   cf062:	00 
   cf063:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cf06a:	00 
   cf06b:	48 89 ee             	mov    %rbp,%rsi
   cf06e:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   cf073:	e8 c8 df ff ff       	call   cd040 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cf078:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cf07f:	00 ff 
   cf081:	0f 84 08 05 00 00    	je     cf58f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66f>
   cf087:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cf08e:	00 
   cf08f:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   cf096:	00 
   cf097:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cf09e:	00 
   cf09f:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cf0a6:	00 
   cf0a7:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cf0ae:	00 
   cf0af:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   cf0b6:	00 
   cf0b7:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   cf0be:	00 
   cf0bf:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   cf0c6:	00 
   cf0c7:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cf0cc:	44 89 f6             	mov    %r14d,%esi
   cf0cf:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
   cf0d6:	00 
   cf0d7:	e8 b4 f2 ff ff       	call   ce390 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cf0dc:	84 c0                	test   %al,%al
   cf0de:	0f 84 ab 04 00 00    	je     cf58f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66f>
   cf0e4:	48 83 c3 40          	add    $0x40,%rbx
   cf0e8:	49 83 c5 c0          	add    $0xffffffffffffffc0,%r13
   cf0ec:	0f 85 de fe ff ff    	jne    cefd0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0xb0>
   cf0f2:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   cf0f7:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf0fc:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cf101:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf106:	e8 45 e1 03 00       	call   10d250 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf10b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   cf110:	49 89 46 10          	mov    %rax,0x10(%r14)
   cf114:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   cf119:	41 0f 11 06          	movups %xmm0,(%r14)
   cf11d:	e9 03 05 00 00       	jmp    cf625 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x705>
   cf122:	48 8b 0e             	mov    (%rsi),%rcx
   cf125:	48 8b 46 08          	mov    0x8(%rsi),%rax
   cf129:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   cf12d:	48 89 d6             	mov    %rdx,%rsi
   cf130:	48 c1 e6 06          	shl    $0x6,%rsi
   cf134:	48 01 c6             	add    %rax,%rsi
   cf137:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   cf13c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf141:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   cf146:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
   cf14d:	00 
   cf14e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   cf153:	48 85 d2             	test   %rdx,%rdx
   cf156:	0f 84 d1 03 00 00    	je     cf52d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x60d>
   cf15c:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   cf163:	00 
   cf164:	4c 89 e1             	mov    %r12,%rcx
   cf167:	48 c1 e1 06          	shl    $0x6,%rcx
   cf16b:	48 03 0c 24          	add    (%rsp),%rcx
   cf16f:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   cf174:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   cf179:	48 8d 50 40          	lea    0x40(%rax),%rdx
   cf17d:	48 8b 48 08          	mov    0x8(%rax),%rcx
   cf181:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   cf185:	0f 84 9d 03 00 00    	je     cf528 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x608>
   cf18b:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   cf190:	0f b7 10             	movzwl (%rax),%edx
   cf193:	66 89 54 24 38       	mov    %dx,0x38(%rsp)
   cf198:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   cf19f:	00 
   cf1a0:	0f 10 40 10          	movups 0x10(%rax),%xmm0
   cf1a4:	0f 10 48 20          	movups 0x20(%rax),%xmm1
   cf1a8:	0f 10 50 30          	movups 0x30(%rax),%xmm2
   cf1ac:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
   cf1b0:	0f 11 4e 10          	movups %xmm1,0x10(%rsi)
   cf1b4:	0f 11 06             	movups %xmm0,(%rsi)
   cf1b7:	4d 85 e4             	test   %r12,%r12
   cf1ba:	0f 84 30 03 00 00    	je     cf4f0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x5d0>
   cf1c0:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   cf1c7:	00 
   cf1c8:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   cf1cf:	00 
   cf1d0:	48 89 dd             	mov    %rbx,%rbp
   cf1d3:	48 c1 e5 04          	shl    $0x4,%rbp
   cf1d7:	48 89 d8             	mov    %rbx,%rax
   cf1da:	48 c1 e8 3c          	shr    $0x3c,%rax
   cf1de:	0f 94 c0             	sete   %al
   cf1e1:	48 b9 f9 ff ff ff ff 	movabs $0x7ffffffffffffff9,%rcx
   cf1e8:	ff ff 7f 
   cf1eb:	48 39 cd             	cmp    %rcx,%rbp
   cf1ee:	0f 92 c1             	setb   %cl
   cf1f1:	84 c8                	test   %cl,%al
   cf1f3:	0f 84 72 03 00 00    	je     cf56b <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x64b>
   cf1f9:	48 85 ed             	test   %rbp,%rbp
   cf1fc:	0f 84 ab 01 00 00    	je     cf3ad <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x48d>
   cf202:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   cf209:	00 
   cf20a:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
   cf211:	00 
   cf212:	4c 8b 3c 24          	mov    (%rsp),%r15
   cf216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cf21d:	00 00 00 
   cf220:	45 0f b7 2f          	movzwl (%r15),%r13d
   cf224:	66 44 03 6c 24 38    	add    0x38(%rsp),%r13w
   cf22a:	0f 80 7c 03 00 00    	jo     cf5ac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf230:	f0 49 ff 06          	lock incq (%r14)
   cf234:	0f 8e 53 03 00 00    	jle    cf58d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf23a:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cf23f:	ff 15 73 f9 09 00    	call   *0x9f973(%rip)        # 16ebb8 <_DYNAMIC+0x338>
   cf245:	be 08 00 00 00       	mov    $0x8,%esi
   cf24a:	48 89 ef             	mov    %rbp,%rdi
   cf24d:	ff 15 6d f9 09 00    	call   *0x9f96d(%rip)        # 16ebc0 <_DYNAMIC+0x340>
   cf253:	48 85 c0             	test   %rax,%rax
   cf256:	0f 84 55 04 00 00    	je     cf6b1 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x791>
   cf25c:	48 85 db             	test   %rbx,%rbx
   cf25f:	74 48                	je     cf2a9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x389>
   cf261:	31 c9                	xor    %ecx,%ecx
   cf263:	48 89 da             	mov    %rbx,%rdx
   cf266:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
   cf26d:	00 
   cf26e:	66 90                	xchg   %ax,%ax
   cf270:	48 39 cd             	cmp    %rcx,%rbp
   cf273:	74 34                	je     cf2a9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x389>
   cf275:	48 8b 3e             	mov    (%rsi),%rdi
   cf278:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   cf27c:	f0 48 ff 07          	lock incq (%rdi)
   cf280:	0f 8e 07 03 00 00    	jle    cf58d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf286:	f0 49 ff 00          	lock incq (%r8)
   cf28a:	0f 8e fd 02 00 00    	jle    cf58d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf290:	48 ff ca             	dec    %rdx
   cf293:	48 83 c6 10          	add    $0x10,%rsi
   cf297:	48 89 3c 08          	mov    %rdi,(%rax,%rcx,1)
   cf29b:	4c 89 44 08 08       	mov    %r8,0x8(%rax,%rcx,1)
   cf2a0:	48 83 c1 10          	add    $0x10,%rcx
   cf2a4:	48 85 d2             	test   %rdx,%rdx
   cf2a7:	75 c7                	jne    cf270 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x350>
   cf2a9:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   cf2ae:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   cf2b3:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
   cf2ba:	00 
   cf2bb:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
   cf2c2:	00 
   cf2c3:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   cf2ca:	00 
   cf2cb:	e8 70 32 04 00       	call   112540 <<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::clone::Clone>::clone>
   cf2d0:	49 8d 57 08          	lea    0x8(%r15),%rdx
   cf2d4:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   cf2db:	00 
   cf2dc:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cf2e1:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
   cf2e8:	00 
   cf2e9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cf2f0:	00 
   cf2f1:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   cf2f8:	00 
   cf2f9:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   cf300:	00 
   cf301:	48 8d 8c 24 18 01 00 	lea    0x118(%rsp),%rcx
   cf308:	00 
   cf309:	48 89 41 10          	mov    %rax,0x10(%rcx)
   cf30d:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   cf314:	00 
   cf315:	0f 11 01             	movups %xmm0,(%rcx)
   cf318:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cf31f:	00 
   cf320:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   cf327:	00 
   cf328:	e8 13 dd ff ff       	call   cd040 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cf32d:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cf334:	00 ff 
   cf336:	0f 84 70 02 00 00    	je     cf5ac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf33c:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cf343:	00 
   cf344:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   cf34b:	00 
   cf34c:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cf353:	00 
   cf354:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cf35b:	00 
   cf35c:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cf363:	00 
   cf364:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
   cf36b:	00 
   cf36c:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
   cf373:	00 
   cf374:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   cf37b:	00 
   cf37c:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cf381:	44 89 ee             	mov    %r13d,%esi
   cf384:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
   cf38b:	00 
   cf38c:	e8 ff ef ff ff       	call   ce390 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cf391:	84 c0                	test   %al,%al
   cf393:	0f 84 13 02 00 00    	je     cf5ac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf399:	49 83 c7 40          	add    $0x40,%r15
   cf39d:	4c 3b 7c 24 60       	cmp    0x60(%rsp),%r15
   cf3a2:	0f 85 78 fe ff ff    	jne    cf220 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x300>
   cf3a8:	e9 43 01 00 00       	jmp    cf4f0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x5d0>
   cf3ad:	4c 8b 2c 24          	mov    (%rsp),%r13
   cf3b1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cf3b8:	0f 1f 84 00 00 00 00 
   cf3bf:	00 
   cf3c0:	41 0f b7 5d 00       	movzwl 0x0(%r13),%ebx
   cf3c5:	66 03 5c 24 38       	add    0x38(%rsp),%bx
   cf3ca:	0f 80 dc 01 00 00    	jo     cf5ac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf3d0:	f0 49 ff 06          	lock incq (%r14)
   cf3d4:	0f 8e b3 01 00 00    	jle    cf58d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf3da:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cf3df:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
   cf3e6:	00 00 
   cf3e8:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
   cf3ef:	00 00 
   cf3f1:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   cf3f8:	00 00 00 00 00 
   cf3fd:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
   cf404:	00 
   cf405:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   cf40c:	00 
   cf40d:	e8 2e 31 04 00       	call   112540 <<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::clone::Clone>::clone>
   cf412:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   cf419:	00 
   cf41a:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cf41f:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
   cf426:	00 
   cf427:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cf42e:	00 
   cf42f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   cf436:	00 
   cf437:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   cf43e:	00 
   cf43f:	48 8d 8c 24 18 01 00 	lea    0x118(%rsp),%rcx
   cf446:	00 
   cf447:	48 89 41 10          	mov    %rax,0x10(%rcx)
   cf44b:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   cf452:	00 
   cf453:	0f 11 01             	movups %xmm0,(%rcx)
   cf456:	49 83 c5 08          	add    $0x8,%r13
   cf45a:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cf461:	00 
   cf462:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   cf469:	00 
   cf46a:	4c 89 ea             	mov    %r13,%rdx
   cf46d:	e8 ce db ff ff       	call   cd040 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cf472:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cf479:	00 ff 
   cf47b:	0f 84 2b 01 00 00    	je     cf5ac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf481:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cf488:	00 
   cf489:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   cf490:	00 
   cf491:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cf498:	00 
   cf499:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cf4a0:	00 
   cf4a1:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cf4a8:	00 
   cf4a9:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
   cf4b0:	00 
   cf4b1:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
   cf4b8:	00 
   cf4b9:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   cf4c0:	00 
   cf4c1:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cf4c6:	89 de                	mov    %ebx,%esi
   cf4c8:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
   cf4cf:	00 
   cf4d0:	e8 bb ee ff ff       	call   ce390 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cf4d5:	84 c0                	test   %al,%al
   cf4d7:	0f 84 cf 00 00 00    	je     cf5ac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf4dd:	49 83 c5 38          	add    $0x38,%r13
   cf4e1:	4c 3b 6c 24 60       	cmp    0x60(%rsp),%r13
   cf4e6:	0f 85 d4 fe ff ff    	jne    cf3c0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x4a0>
   cf4ec:	0f 1f 40 00          	nopl   0x0(%rax)
   cf4f0:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cf4f7:	00 
   cf4f8:	e8 93 17 fe ff       	call   b0c90 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cf4fd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cf502:	48 89 c8             	mov    %rcx,%rax
   cf505:	48 3b 8c 24 88 00 00 	cmp    0x88(%rsp),%rcx
   cf50c:	00 
   cf50d:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cf512:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   cf519:	00 
   cf51a:	0f 85 59 fc ff ff    	jne    cf179 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x259>
   cf520:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   cf527:	00 
   cf528:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   cf52d:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf532:	e8 19 dd 03 00       	call   10d250 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf537:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   cf53c:	49 89 46 10          	mov    %rax,0x10(%r14)
   cf540:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   cf545:	41 0f 11 06          	movups %xmm0,(%r14)
   cf549:	49 ff c4             	inc    %r12
   cf54c:	48 8b 3c 24          	mov    (%rsp),%rdi
   cf550:	49 83 fc 01          	cmp    $0x1,%r12
   cf554:	0f 84 ed 00 00 00    	je     cf647 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x727>
   cf55a:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cf55e:	49 ff cc             	dec    %r12
   cf561:	e8 5a 1d 04 00       	call   1112c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cf566:	48 89 df             	mov    %rbx,%rdi
   cf569:	eb e5                	jmp    cf550 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x630>
   cf56b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cf570:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf575:	48 8b 04 24          	mov    (%rsp),%rax
   cf579:	0f b7 4c 24 38       	movzwl 0x38(%rsp),%ecx
   cf57e:	66 03 08             	add    (%rax),%cx
   cf581:	70 33                	jo     cf5b6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x696>
   cf583:	f0 49 ff 06          	lock incq (%r14)
   cf587:	0f 8f ec 00 00 00    	jg     cf679 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x759>
   cf58d:	0f 0b                	ud2
   cf58f:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf594:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cf599:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cf5a0:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf5a5:	e8 a6 dc 03 00       	call   10d250 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf5aa:	eb 2d                	jmp    cf5d9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6b9>
   cf5ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cf5b1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf5b6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cf5bb:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cf5c2:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cf5c9:	00 
   cf5ca:	e8 c1 16 fe ff       	call   b0c90 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cf5cf:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf5d4:	e8 77 dc 03 00       	call   10d250 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf5d9:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cf5de:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
   cf5e3:	49 ff c6             	inc    %r14
   cf5e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cf5ed:	00 00 00 
   cf5f0:	49 83 fe 01          	cmp    $0x1,%r14
   cf5f4:	74 11                	je     cf607 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6e7>
   cf5f6:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cf5fa:	49 ff ce             	dec    %r14
   cf5fd:	e8 be 1c 04 00       	call   1112c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cf602:	48 89 df             	mov    %rbx,%rdi
   cf605:	eb e9                	jmp    cf5f0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6d0>
   cf607:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   cf60c:	48 85 f6             	test   %rsi,%rsi
   cf60f:	74 14                	je     cf625 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x705>
   cf611:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cf616:	48 c1 e6 06          	shl    $0x6,%rsi
   cf61a:	ba 08 00 00 00       	mov    $0x8,%edx
   cf61f:	ff 15 1b f5 09 00    	call   *0x9f51b(%rip)        # 16eb40 <_DYNAMIC+0x2c0>
   cf625:	49 ff c4             	inc    %r12
   cf628:	48 8b 3c 24          	mov    (%rsp),%rdi
   cf62c:	0f 1f 40 00          	nopl   0x0(%rax)
   cf630:	49 83 fc 01          	cmp    $0x1,%r12
   cf634:	74 11                	je     cf647 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x727>
   cf636:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cf63a:	49 ff cc             	dec    %r12
   cf63d:	e8 7e 1c 04 00       	call   1112c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cf642:	48 89 df             	mov    %rbx,%rdi
   cf645:	eb e9                	jmp    cf630 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x710>
   cf647:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   cf64c:	48 8b 30             	mov    (%rax),%rsi
   cf64f:	48 85 f6             	test   %rsi,%rsi
   cf652:	74 13                	je     cf667 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x747>
   cf654:	48 c1 e6 06          	shl    $0x6,%rsi
   cf658:	ba 08 00 00 00       	mov    $0x8,%edx
   cf65d:	48 8b 3c 24          	mov    (%rsp),%rdi
   cf661:	ff 15 d9 f4 09 00    	call   *0x9f4d9(%rip)        # 16eb40 <_DYNAMIC+0x2c0>
   cf667:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
   cf66e:	5b                   	pop    %rbx
   cf66f:	41 5c                	pop    %r12
   cf671:	41 5d                	pop    %r13
   cf673:	41 5e                	pop    %r14
   cf675:	41 5f                	pop    %r15
   cf677:	5d                   	pop    %rbp
   cf678:	c3                   	ret
   cf679:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cf67e:	31 ff                	xor    %edi,%edi
   cf680:	48 89 ee             	mov    %rbp,%rsi
   cf683:	ff 15 27 f5 09 00    	call   *0x9f527(%rip)        # 16ebb0 <_DYNAMIC+0x330>
   cf689:	e9 ff fe ff ff       	jmp    cf58d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf68e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf693:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cf698:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cf69f:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cf6a6:	00 
   cf6a7:	e8 e4 15 fe ff       	call   b0c90 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cf6ac:	e9 ef fe ff ff       	jmp    cf5a0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x680>
   cf6b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cf6b6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf6bb:	bf 08 00 00 00       	mov    $0x8,%edi
   cf6c0:	eb be                	jmp    cf680 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x760>
   cf6c2:	49 89 c7             	mov    %rax,%r15
   cf6c5:	eb 5c                	jmp    cf723 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x803>
   cf6c7:	49 89 c7             	mov    %rax,%r15
   cf6ca:	e9 56 01 00 00       	jmp    cf825 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x905>
   cf6cf:	49 89 c7             	mov    %rax,%r15
   cf6d2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cf6d7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf6dc:	e9 44 01 00 00       	jmp    cf825 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x905>
   cf6e1:	eb 08                	jmp    cf6eb <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x7cb>
   cf6e3:	49 89 c7             	mov    %rax,%r15
   cf6e6:	e9 44 01 00 00       	jmp    cf82f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x90f>
   cf6eb:	49 89 c7             	mov    %rax,%r15
   cf6ee:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cf6f3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf6f8:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cf6fd:	e8 5e 02 fe ff       	call   af960 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   cf702:	e9 00 01 00 00       	jmp    cf807 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8e7>
   cf707:	eb 00                	jmp    cf709 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x7e9>
   cf709:	49 89 c7             	mov    %rax,%r15
   cf70c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cf711:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf716:	e9 fd 00 00 00       	jmp    cf818 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8f8>
   cf71b:	49 89 c7             	mov    %rax,%r15
   cf71e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf723:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf728:	e8 23 db 03 00       	call   10d250 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf72d:	e9 fd 00 00 00       	jmp    cf82f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x90f>
   cf732:	49 89 c7             	mov    %rax,%r15
   cf735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   cf73c:	00 00 00 00 
   cf740:	49 ff cc             	dec    %r12
   cf743:	0f 84 8d 00 00 00    	je     cf7d6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8b6>
   cf749:	4c 8d 73 40          	lea    0x40(%rbx),%r14
   cf74d:	48 89 df             	mov    %rbx,%rdi
   cf750:	e8 6b 1b 04 00       	call   1112c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cf755:	4c 89 f3             	mov    %r14,%rbx
   cf758:	eb e6                	jmp    cf740 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x820>
   cf75a:	ff 15 c8 f3 09 00    	call   *0x9f3c8(%rip)        # 16eb28 <_DYNAMIC+0x2a8>
   cf760:	49 89 c7             	mov    %rax,%r15
   cf763:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cf76a:	84 00 00 00 00 00 
   cf770:	49 ff ce             	dec    %r14
   cf773:	74 11                	je     cf786 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x866>
   cf775:	4c 8d 63 40          	lea    0x40(%rbx),%r12
   cf779:	48 89 df             	mov    %rbx,%rdi
   cf77c:	e8 3f 1b 04 00       	call   1112c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cf781:	4c 89 e3             	mov    %r12,%rbx
   cf784:	eb ea                	jmp    cf770 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x850>
   cf786:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   cf78b:	48 85 f6             	test   %rsi,%rsi
   cf78e:	0f 84 a5 00 00 00    	je     cf839 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x919>
   cf794:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cf799:	48 c1 e6 06          	shl    $0x6,%rsi
   cf79d:	ba 08 00 00 00       	mov    $0x8,%edx
   cf7a2:	ff 15 98 f3 09 00    	call   *0x9f398(%rip)        # 16eb40 <_DYNAMIC+0x2c0>
   cf7a8:	e9 8c 00 00 00       	jmp    cf839 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x919>
   cf7ad:	ff 15 75 f3 09 00    	call   *0x9f375(%rip)        # 16eb28 <_DYNAMIC+0x2a8>
   cf7b3:	49 89 c7             	mov    %rax,%r15
   cf7b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cf7bd:	00 00 00 
   cf7c0:	49 ff cc             	dec    %r12
   cf7c3:	74 11                	je     cf7d6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8b6>
   cf7c5:	4c 8d 73 40          	lea    0x40(%rbx),%r14
   cf7c9:	48 89 df             	mov    %rbx,%rdi
   cf7cc:	e8 ef 1a 04 00       	call   1112c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cf7d1:	4c 89 f3             	mov    %r14,%rbx
   cf7d4:	eb ea                	jmp    cf7c0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8a0>
   cf7d6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   cf7db:	48 8b 30             	mov    (%rax),%rsi
   cf7de:	48 85 f6             	test   %rsi,%rsi
   cf7e1:	74 60                	je     cf843 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x923>
   cf7e3:	48 c1 e6 06          	shl    $0x6,%rsi
   cf7e7:	ba 08 00 00 00       	mov    $0x8,%edx
   cf7ec:	48 8b 3c 24          	mov    (%rsp),%rdi
   cf7f0:	ff 15 4a f3 09 00    	call   *0x9f34a(%rip)        # 16eb40 <_DYNAMIC+0x2c0>
   cf7f6:	4c 89 ff             	mov    %r15,%rdi
   cf7f9:	e8 22 90 09 00       	call   168820 <_Unwind_Resume@plt>
   cf7fe:	ff 15 24 f3 09 00    	call   *0x9f324(%rip)        # 16eb28 <_DYNAMIC+0x2a8>
   cf804:	49 89 c7             	mov    %rax,%r15
   cf807:	f0 49 ff 0e          	lock decq (%r14)
   cf80b:	75 0b                	jne    cf818 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8f8>
   cf80d:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cf812:	ff 15 08 f3 09 00    	call   *0x9f308(%rip)        # 16eb20 <_DYNAMIC+0x2a0>
   cf818:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cf81f:	00 
   cf820:	e8 6b 14 fe ff       	call   b0c90 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cf825:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf82a:	e8 21 da 03 00       	call   10d250 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf82f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cf834:	e8 f7 01 fe ff       	call   afa30 <core::ptr::drop_glue::<alloc::vec::Vec<(i16, hyperreal::computable::node::RadicalCoefficient)>>>
   cf839:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   cf83e:	e8 ed 01 fe ff       	call   afa30 <core::ptr::drop_glue::<alloc::vec::Vec<(i16, hyperreal::computable::node::RadicalCoefficient)>>>
   cf843:	4c 89 ff             	mov    %r15,%rdi
   cf846:	e8 d5 8f 09 00       	call   168820 <_Unwind_Resume@plt>
   cf84b:	ff 15 d7 f2 09 00    	call   *0x9f2d7(%rip)        # 16eb28 <_DYNAMIC+0x2a8>
   cf851:	ff 15 d1 f2 09 00    	call   *0x9f2d1(%rip)        # 16eb28 <_DYNAMIC+0x2a8>
