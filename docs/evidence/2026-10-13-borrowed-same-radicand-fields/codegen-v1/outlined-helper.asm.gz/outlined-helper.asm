
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/outlined-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000ccdd0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand>:
   ccdd0:	55                   	push   %rbp
   ccdd1:	41 57                	push   %r15
   ccdd3:	41 56                	push   %r14
   ccdd5:	41 55                	push   %r13
   ccdd7:	41 54                	push   %r12
   ccdd9:	53                   	push   %rbx
   ccdda:	48 83 ec 68          	sub    $0x68,%rsp
   ccdde:	48 83 7e 10 00       	cmpq   $0x0,0x10(%rsi)
   ccde3:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   ccde8:	0f 84 07 03 00 00    	je     cd0f5 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x325>
   ccdee:	49 89 d7             	mov    %rdx,%r15
   ccdf1:	48 83 7a 10 00       	cmpq   $0x0,0x10(%rdx)
   ccdf6:	0f 84 02 03 00 00    	je     cd0fe <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x32e>
   ccdfc:	49 89 fd             	mov    %rdi,%r13
   ccdff:	4c 8b 76 08          	mov    0x8(%rsi),%r14
   cce03:	4d 8b 67 08          	mov    0x8(%r15),%r12
   cce07:	48 8d 7e 30          	lea    0x30(%rsi),%rdi
   cce0b:	49 83 c7 30          	add    $0x30,%r15
   cce0f:	4c 89 fe             	mov    %r15,%rsi
   cce12:	e8 d9 49 fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cce17:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   cce1b:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cce20:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   cce25:	4c 89 fe             	mov    %r15,%rsi
   cce28:	e8 c3 49 fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cce2d:	49 89 c7             	mov    %rax,%r15
   cce30:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
   cce35:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
   cce3a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   cce3f:	41 b4 01             	mov    $0x1,%r12b
   cce42:	40 b5 01             	mov    $0x1,%bpl
   cce45:	48 89 fb             	mov    %rdi,%rbx
   cce48:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cce4d:	48 8d 70 30          	lea    0x30(%rax),%rsi
   cce51:	e8 9a 49 fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cce56:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   cce5b:	48 89 c6             	mov    %rax,%rsi
   cce5e:	4c 89 f8             	mov    %r15,%rax
   cce61:	45 0f b6 7f 64       	movzbl 0x64(%r15),%r15d
   cce66:	41 80 ff 01          	cmp    $0x1,%r15b
   cce6a:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
   cce6f:	75 1b                	jne    cce8c <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0xbc>
   cce71:	f0 48 ff 08          	lock decq (%rax)
   cce75:	48 89 f0             	mov    %rsi,%rax
   cce78:	75 39                	jne    cceb3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0xe3>
   cce7a:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   cce7f:	ff 15 4b 25 0a 00    	call   *0xa254b(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cce85:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cce8a:	eb 27                	jmp    cceb3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0xe3>
   cce8c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   cce91:	80 7e 64 01          	cmpb   $0x1,0x64(%rsi)
   cce95:	75 08                	jne    cce9f <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0xcf>
   cce97:	b0 01                	mov    $0x1,%al
   cce99:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   cce9d:	eb 26                	jmp    ccec5 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0xf5>
   cce9f:	31 ed                	xor    %ebp,%ebp
   ccea1:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   ccea8:	00 
   ccea9:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   cceae:	e8 0d 30 fc ff       	call   8fec0 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Add>::add>
   cceb3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   cceb8:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   ccebd:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   ccec4:	00 
   ccec5:	40 b5 01             	mov    $0x1,%bpl
   ccec8:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   ccecc:	48 89 de             	mov    %rbx,%rsi
   ccecf:	e8 1c 49 fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cced4:	49 89 c4             	mov    %rax,%r12
   cced7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   ccedc:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   ccee1:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   ccee6:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cceeb:	4c 89 f6             	mov    %r14,%rsi
   cceee:	e8 fd 48 fc ff       	call   917f0 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   ccef3:	49 89 c6             	mov    %rax,%r14
   ccef6:	f0 49 ff 0c 24       	lock decq (%r12)
   ccefb:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
   ccf00:	48 8d 6b 30          	lea    0x30(%rbx),%rbp
   ccf04:	75 0b                	jne    ccf11 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x141>
   ccf06:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ccf0b:	ff 15 bf 24 0a 00    	call   *0xa24bf(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ccf11:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   ccf16:	4c 89 f6             	mov    %r14,%rsi
   ccf19:	e8 a2 2f fc ff       	call   8fec0 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Add>::add>
   ccf1e:	49 89 c6             	mov    %rax,%r14
   ccf21:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   ccf26:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   ccf2b:	80 78 64 01          	cmpb   $0x1,0x64(%rax)
   ccf2f:	75 74                	jne    ccfa5 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x1d5>
   ccf31:	4d 89 75 30          	mov    %r14,0x30(%r13)
   ccf35:	49 c7 45 00 00 00 00 	movq   $0x0,0x0(%r13)
   ccf3c:	00 
   ccf3d:	49 c7 45 08 08 00 00 	movq   $0x8,0x8(%r13)
   ccf44:	00 
   ccf45:	0f 57 c0             	xorps  %xmm0,%xmm0
   ccf48:	41 0f 11 45 10       	movups %xmm0,0x10(%r13)
   ccf4d:	49 c7 45 20 08 00 00 	movq   $0x8,0x20(%r13)
   ccf54:	00 
   ccf55:	49 c7 45 28 00 00 00 	movq   $0x0,0x28(%r13)
   ccf5c:	00 
   ccf5d:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   ccf62:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   ccf67:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   ccf6c:	74 17                	je     ccf85 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x1b5>
   ccf6e:	f0 48 ff 08          	lock decq (%rax)
   ccf72:	75 11                	jne    ccf85 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x1b5>
   ccf74:	40 b5 01             	mov    $0x1,%bpl
   ccf77:	45 31 e4             	xor    %r12d,%r12d
   ccf7a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   ccf7f:	ff 15 4b 24 0a 00    	call   *0xa244b(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ccf85:	f0 49 ff 0f          	lock decq (%r15)
   ccf89:	75 0b                	jne    ccf96 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x1c6>
   ccf8b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   ccf90:	ff 15 3a 24 0a 00    	call   *0xa243a(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ccf96:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   ccf9b:	e8 50 3e fe ff       	call   b0df0 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   ccfa0:	e9 41 01 00 00       	jmp    cd0e6 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x316>
   ccfa5:	41 80 ff 01          	cmp    $0x1,%r15b
   ccfa9:	75 40                	jne    ccfeb <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x21b>
   ccfab:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   ccfb0:	48 8b 01             	mov    (%rcx),%rax
   ccfb3:	f0 48 ff 00          	lock incq (%rax)
   ccfb7:	0f 8e 78 01 00 00    	jle    cd135 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x365>
   ccfbd:	4c 8b 39             	mov    (%rcx),%r15
   ccfc0:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   ccfc5:	48 83 7b 10 00       	cmpq   $0x0,0x10(%rbx)
   ccfca:	0f 84 54 01 00 00    	je     cd124 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x354>
   ccfd0:	4c 8b 63 08          	mov    0x8(%rbx),%r12
   ccfd4:	49 8b 04 24          	mov    (%r12),%rax
   ccfd8:	f0 48 ff 08          	lock decq (%rax)
   ccfdc:	75 09                	jne    ccfe7 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x217>
   ccfde:	4c 89 e7             	mov    %r12,%rdi
   ccfe1:	ff 15 e9 23 0a 00    	call   *0xa23e9(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   ccfe7:	4d 89 3c 24          	mov    %r15,(%r12)
   ccfeb:	48 8b 45 00          	mov    0x0(%rbp),%rax
   ccfef:	f0 48 ff 08          	lock decq (%rax)
   ccff3:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   ccff8:	75 09                	jne    cd003 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x233>
   ccffa:	48 89 ef             	mov    %rbp,%rdi
   ccffd:	ff 15 cd 23 0a 00    	call   *0xa23cd(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd003:	4c 89 73 30          	mov    %r14,0x30(%rbx)
   cd007:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   cd00c:	48 83 7b 10 00       	cmpq   $0x0,0x10(%rbx)
   cd011:	0f 84 fa 00 00 00    	je     cd111 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x341>
   cd017:	4c 8b 73 08          	mov    0x8(%rbx),%r14
   cd01b:	49 8b 46 08          	mov    0x8(%r14),%rax
   cd01f:	49 83 c6 08          	add    $0x8,%r14
   cd023:	f0 48 ff 08          	lock decq (%rax)
   cd027:	75 09                	jne    cd032 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x262>
   cd029:	4c 89 f7             	mov    %r14,%rdi
   cd02c:	ff 15 9e 23 0a 00    	call   *0xa239e(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd032:	4d 89 3e             	mov    %r15,(%r14)
   cd035:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   cd039:	4c 8b 7b 28          	mov    0x28(%rbx),%r15
   cd03d:	49 ff c7             	inc    %r15
   cd040:	49 83 ff 01          	cmp    $0x1,%r15
   cd044:	74 11                	je     cd057 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x287>
   cd046:	4c 8d 77 18          	lea    0x18(%rdi),%r14
   cd04a:	49 ff cf             	dec    %r15
   cd04d:	e8 5e 48 04 00       	call   1118b0 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   cd052:	4c 89 f7             	mov    %r14,%rdi
   cd055:	eb e9                	jmp    cd040 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x270>
   cd057:	48 8b 43 18          	mov    0x18(%rbx),%rax
   cd05b:	48 85 c0             	test   %rax,%rax
   cd05e:	74 17                	je     cd077 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x2a7>
   cd060:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   cd064:	48 c1 e0 03          	shl    $0x3,%rax
   cd068:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   cd06c:	ba 08 00 00 00       	mov    $0x8,%edx
   cd071:	ff 15 79 23 0a 00    	call   *0xa2379(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cd077:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
   cd07e:	00 
   cd07f:	48 c7 43 20 08 00 00 	movq   $0x8,0x20(%rbx)
   cd086:	00 
   cd087:	48 c7 43 28 00 00 00 	movq   $0x0,0x28(%rbx)
   cd08e:	00 
   cd08f:	48 8b 43 30          	mov    0x30(%rbx),%rax
   cd093:	49 89 45 30          	mov    %rax,0x30(%r13)
   cd097:	0f 10 03             	movups (%rbx),%xmm0
   cd09a:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
   cd09f:	48 8b 43 20          	mov    0x20(%rbx),%rax
   cd0a3:	49 89 45 20          	mov    %rax,0x20(%r13)
   cd0a7:	48 8b 43 28          	mov    0x28(%rbx),%rax
   cd0ab:	49 89 45 28          	mov    %rax,0x28(%r13)
   cd0af:	48 8b 43 10          	mov    0x10(%rbx),%rax
   cd0b3:	49 89 45 10          	mov    %rax,0x10(%r13)
   cd0b7:	48 8b 43 18          	mov    0x18(%rbx),%rax
   cd0bb:	49 89 45 18          	mov    %rax,0x18(%r13)
   cd0bf:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   cd0c4:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   cd0c9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cd0ce:	74 16                	je     cd0e6 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x316>
   cd0d0:	f0 48 ff 08          	lock decq (%rax)
   cd0d4:	75 10                	jne    cd0e6 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x316>
   cd0d6:	45 31 e4             	xor    %r12d,%r12d
   cd0d9:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cd0de:	31 ed                	xor    %ebp,%ebp
   cd0e0:	ff 15 ea 22 0a 00    	call   *0xa22ea(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd0e6:	48 83 c4 68          	add    $0x68,%rsp
   cd0ea:	5b                   	pop    %rbx
   cd0eb:	41 5c                	pop    %r12
   cd0ed:	41 5d                	pop    %r13
   cd0ef:	41 5e                	pop    %r14
   cd0f1:	41 5f                	pop    %r15
   cd0f3:	5d                   	pop    %rbp
   cd0f4:	c3                   	ret
   cd0f5:	48 8d 15 64 e6 09 00 	lea    0x9e664(%rip),%rdx        # 16b760 <anon.afeede234644f26776946e76b404b106.261.llvm.3222190057612512104+0x128>
   cd0fc:	eb 07                	jmp    cd105 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x335>
   cd0fe:	48 8d 15 73 e6 09 00 	lea    0x9e673(%rip),%rdx        # 16b778 <anon.afeede234644f26776946e76b404b106.261.llvm.3222190057612512104+0x140>
   cd105:	31 ff                	xor    %edi,%edi
   cd107:	31 f6                	xor    %esi,%esi
   cd109:	ff 15 a1 27 0a 00    	call   *0xa27a1(%rip)        # 16f8b0 <_DYNAMIC+0x780>
   cd10f:	eb 24                	jmp    cd135 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x365>
   cd111:	48 8d 15 90 e6 09 00 	lea    0x9e690(%rip),%rdx        # 16b7a8 <anon.afeede234644f26776946e76b404b106.261.llvm.3222190057612512104+0x170>
   cd118:	31 ff                	xor    %edi,%edi
   cd11a:	31 f6                	xor    %esi,%esi
   cd11c:	ff 15 8e 27 0a 00    	call   *0xa278e(%rip)        # 16f8b0 <_DYNAMIC+0x780>
   cd122:	eb 11                	jmp    cd135 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x365>
   cd124:	48 8d 15 65 e6 09 00 	lea    0x9e665(%rip),%rdx        # 16b790 <anon.afeede234644f26776946e76b404b106.261.llvm.3222190057612512104+0x158>
   cd12b:	31 ff                	xor    %edi,%edi
   cd12d:	31 f6                	xor    %esi,%esi
   cd12f:	ff 15 7b 27 0a 00    	call   *0xa277b(%rip)        # 16f8b0 <_DYNAMIC+0x780>
   cd135:	0f 0b                	ud2
   cd137:	49 89 c5             	mov    %rax,%r13
   cd13a:	4d 89 3c 24          	mov    %r15,(%r12)
   cd13e:	eb 2b                	jmp    cd16b <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x39b>
   cd140:	49 89 c5             	mov    %rax,%r13
   cd143:	4d 89 3e             	mov    %r15,(%r14)
   cd146:	e9 72 01 00 00       	jmp    cd2bd <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4ed>
   cd14b:	49 89 c5             	mov    %rax,%r13
   cd14e:	4c 89 75 00          	mov    %r14,0x0(%rbp)
   cd152:	e9 87 00 00 00       	jmp    cd1de <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x40e>
   cd157:	49 89 c5             	mov    %rax,%r13
   cd15a:	f0 49 ff 0f          	lock decq (%r15)
   cd15e:	75 0b                	jne    cd16b <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x39b>
   cd160:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cd165:	ff 15 65 22 0a 00    	call   *0xa2265(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd16b:	f0 49 ff 0e          	lock decq (%r14)
   cd16f:	41 b7 01             	mov    $0x1,%r15b
   cd172:	0f 85 9f 00 00 00    	jne    cd217 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x447>
   cd178:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cd17d:	ff 15 4d 22 0a 00    	call   *0xa224d(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd183:	e9 8f 00 00 00       	jmp    cd217 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x447>
   cd188:	e9 be 00 00 00       	jmp    cd24b <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x47b>
   cd18d:	49 89 c5             	mov    %rax,%r13
   cd190:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cd195:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   cd19a:	40 b5 01             	mov    $0x1,%bpl
   cd19d:	41 b4 01             	mov    $0x1,%r12b
   cd1a0:	e9 4d 01 00 00       	jmp    cd2f2 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x522>
   cd1a5:	49 89 c5             	mov    %rax,%r13
   cd1a8:	45 31 ff             	xor    %r15d,%r15d
   cd1ab:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   cd1b0:	f0 48 ff 08          	lock decq (%rax)
   cd1b4:	41 bc 00 00 00 00    	mov    $0x0,%r12d
   cd1ba:	0f 85 03 01 00 00    	jne    cd2c3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4f3>
   cd1c0:	45 31 e4             	xor    %r12d,%r12d
   cd1c3:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cd1c8:	ff 15 02 22 0a 00    	call   *0xa2202(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd1ce:	45 31 ff             	xor    %r15d,%r15d
   cd1d1:	e9 ed 00 00 00       	jmp    cd2c3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4f3>
   cd1d6:	49 89 c5             	mov    %rax,%r13
   cd1d9:	eb 23                	jmp    cd1fe <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x42e>
   cd1db:	49 89 c5             	mov    %rax,%r13
   cd1de:	41 b7 01             	mov    $0x1,%r15b
   cd1e1:	45 31 e4             	xor    %r12d,%r12d
   cd1e4:	e9 da 00 00 00       	jmp    cd2c3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4f3>
   cd1e9:	49 89 c5             	mov    %rax,%r13
   cd1ec:	f0 49 ff 0c 24       	lock decq (%r12)
   cd1f1:	75 0b                	jne    cd1fe <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x42e>
   cd1f3:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cd1f8:	ff 15 d2 21 0a 00    	call   *0xa21d2(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd1fe:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   cd203:	f0 48 ff 08          	lock decq (%rax)
   cd207:	41 b7 01             	mov    $0x1,%r15b
   cd20a:	75 0b                	jne    cd217 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x447>
   cd20c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cd211:	ff 15 b9 21 0a 00    	call   *0xa21b9(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd217:	45 31 e4             	xor    %r12d,%r12d
   cd21a:	e9 a4 00 00 00       	jmp    cd2c3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4f3>
   cd21f:	ff 15 b3 21 0a 00    	call   *0xa21b3(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   cd225:	49 89 c5             	mov    %rax,%r13
   cd228:	40 b5 01             	mov    $0x1,%bpl
   cd22b:	e9 dd 00 00 00       	jmp    cd30d <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x53d>
   cd230:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   cd235:	49 89 c5             	mov    %rax,%r13
   cd238:	41 89 ef             	mov    %ebp,%r15d
   cd23b:	e9 a3 00 00 00       	jmp    cd2e3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x513>
   cd240:	41 89 ef             	mov    %ebp,%r15d
   cd243:	49 89 c5             	mov    %rax,%r13
   cd246:	41 b4 01             	mov    $0x1,%r12b
   cd249:	eb 78                	jmp    cd2c3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4f3>
   cd24b:	49 89 c5             	mov    %rax,%r13
   cd24e:	e9 d5 00 00 00       	jmp    cd328 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x558>
   cd253:	49 89 c5             	mov    %rax,%r13
   cd256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cd25d:	00 00 00 
   cd260:	49 ff cf             	dec    %r15
   cd263:	74 11                	je     cd276 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4a6>
   cd265:	4d 8d 66 18          	lea    0x18(%r14),%r12
   cd269:	4c 89 f7             	mov    %r14,%rdi
   cd26c:	e8 3f 46 04 00       	call   1118b0 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   cd271:	4d 89 e6             	mov    %r12,%r14
   cd274:	eb ea                	jmp    cd260 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x490>
   cd276:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cd27b:	48 8b 40 18          	mov    0x18(%rax),%rax
   cd27f:	48 85 c0             	test   %rax,%rax
   cd282:	74 1c                	je     cd2a0 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x4d0>
   cd284:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   cd289:	48 8b 79 20          	mov    0x20(%rcx),%rdi
   cd28d:	48 c1 e0 03          	shl    $0x3,%rax
   cd291:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   cd295:	ba 08 00 00 00       	mov    $0x8,%edx
   cd29a:	ff 15 50 21 0a 00    	call   *0xa2150(%rip)        # 16f3f0 <_DYNAMIC+0x2c0>
   cd2a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cd2a5:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
   cd2ac:	00 
   cd2ad:	48 c7 40 20 08 00 00 	movq   $0x8,0x20(%rax)
   cd2b4:	00 
   cd2b5:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
   cd2bc:	00 
   cd2bd:	45 31 e4             	xor    %r12d,%r12d
   cd2c0:	45 31 ff             	xor    %r15d,%r15d
   cd2c3:	40 b5 01             	mov    $0x1,%bpl
   cd2c6:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   cd2cb:	74 16                	je     cd2e3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x513>
   cd2cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cd2d2:	f0 48 ff 08          	lock decq (%rax)
   cd2d6:	75 0b                	jne    cd2e3 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x513>
   cd2d8:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cd2dd:	ff 15 ed 20 0a 00    	call   *0xa20ed(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd2e3:	45 84 ff             	test   %r15b,%r15b
   cd2e6:	74 20                	je     cd308 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x538>
   cd2e8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   cd2ed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cd2f2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   cd2f7:	f0 48 ff 08          	lock decq (%rax)
   cd2fb:	75 0b                	jne    cd308 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x538>
   cd2fd:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   cd302:	ff 15 c8 20 0a 00    	call   *0xa20c8(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd308:	45 84 e4             	test   %r12b,%r12b
   cd30b:	74 16                	je     cd323 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x553>
   cd30d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   cd312:	f0 48 ff 08          	lock decq (%rax)
   cd316:	75 0b                	jne    cd323 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x553>
   cd318:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   cd31d:	ff 15 ad 20 0a 00    	call   *0xa20ad(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd323:	40 84 ed             	test   %bpl,%bpl
   cd326:	74 36                	je     cd35e <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x58e>
   cd328:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cd32d:	48 8b 40 30          	mov    0x30(%rax),%rax
   cd331:	f0 48 ff 08          	lock decq (%rax)
   cd335:	75 0f                	jne    cd346 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand+0x576>
   cd337:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cd33c:	48 8d 78 30          	lea    0x30(%rax),%rdi
   cd340:	ff 15 8a 20 0a 00    	call   *0xa208a(%rip)        # 16f3d0 <_DYNAMIC+0x2a0>
   cd346:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   cd34b:	e8 70 27 fe ff       	call   afac0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   cd350:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   cd355:	48 83 c7 18          	add    $0x18,%rdi
   cd359:	e8 92 26 fe ff       	call   af9f0 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   cd35e:	4c 89 ef             	mov    %r13,%rdi
   cd361:	e8 0a bd 09 00       	call   169070 <_Unwind_Resume@plt>
   cd366:	ff 15 6c 20 0a 00    	call   *0xa206c(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
   cd36c:	ff 15 66 20 0a 00    	call   *0xa2066(%rip)        # 16f3d8 <_DYNAMIC+0x2a8>
