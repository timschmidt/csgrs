
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/borrowed-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000cd530 <<hyperreal::computable::node::RadicalCoefficient>::multiply>:
   cd530:	55                   	push   %rbp
   cd531:	41 57                	push   %r15
   cd533:	41 56                	push   %r14
   cd535:	41 55                	push   %r13
   cd537:	41 54                	push   %r12
   cd539:	53                   	push   %rbx
   cd53a:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
   cd541:	49 89 d4             	mov    %rdx,%r12
   cd544:	48 8d 5e 18          	lea    0x18(%rsi),%rbx
   cd548:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
   cd54d:	48 83 7e 28 00       	cmpq   $0x0,0x28(%rsi)
   cd552:	74 35                	je     cd589 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x59>
   cd554:	49 83 7c 24 10 00    	cmpq   $0x0,0x10(%r12)
   cd55a:	75 47                	jne    cd5a3 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x73>
   cd55c:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
   cd562:	75 3f                	jne    cd5a3 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x73>
   cd564:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   cd569:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cd56e:	49 8b 44 24 08       	mov    0x8(%r12),%rax
   cd573:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   cd578:	41 b5 01             	mov    $0x1,%r13b
   cd57b:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   cd582:	00 00 
   cd584:	e9 c9 01 00 00       	jmp    cd752 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x222>
   cd589:	49 8b 44 24 28       	mov    0x28(%r12),%rax
   cd58e:	48 85 c0             	test   %rax,%rax
   cd591:	74 39                	je     cd5cc <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9c>
   cd593:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cd598:	48 83 79 10 00       	cmpq   $0x0,0x10(%rcx)
   cd59d:	0f 84 7c 01 00 00    	je     cd71f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x1ef>
   cd5a3:	48 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%rdi)
   cd5aa:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   cd5af:	49 8b 46 30          	mov    0x30(%r14),%rax
   cd5b3:	f0 48 ff 08          	lock decq (%rax)
   cd5b7:	0f 85 2b 03 00 00    	jne    cd8e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3b8>
   cd5bd:	49 8d 7e 30          	lea    0x30(%r14),%rdi
   cd5c1:	ff 15 59 1c 0a 00    	call   *0xa1c59(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd5c7:	e9 1c 03 00 00       	jmp    cd8e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3b8>
   cd5cc:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   cd5d1:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cd5d6:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
   cd5db:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
   cd5e0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   cd5e5:	48 8b 42 10          	mov    0x10(%rdx),%rax
   cd5e9:	48 83 f0 01          	xor    $0x1,%rax
   cd5ed:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   cd5f2:	48 83 f1 01          	xor    $0x1,%rcx
   cd5f6:	48 09 c1             	or     %rax,%rcx
   cd5f9:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
   cd5fe:	0f 85 4b 01 00 00    	jne    cd74f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x21f>
   cd604:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
   cd608:	40 b5 01             	mov    $0x1,%bpl
   cd60b:	48 89 df             	mov    %rbx,%rdi
   cd60e:	ff 15 b4 1b 0a 00    	call   *0xa1bb4(%rip)        # 16f1c8 <_DYNAMIC+0x248>
   cd614:	41 b5 01             	mov    $0x1,%r13b
   cd617:	b9 01 00 00 00       	mov    $0x1,%ecx
   cd61c:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   cd621:	84 c0                	test   %al,%al
   cd623:	0f 84 29 01 00 00    	je     cd752 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x222>
   cd629:	4c 8b 3b             	mov    (%rbx),%r15
   cd62c:	41 8b 47 60          	mov    0x60(%r15),%eax
   cd630:	84 c0                	test   %al,%al
   cd632:	0f 88 dd 06 00 00    	js     cdd15 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7e5>
   cd638:	41 80 7f 64 02       	cmpb   $0x2,0x64(%r15)
   cd63d:	75 63                	jne    cd6a2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x172>
   cd63f:	4c 8b 35 c2 1b 0a 00 	mov    0xa1bc2(%rip),%r14        # 16f208 <_DYNAMIC+0x288>
   cd646:	41 8b 46 18          	mov    0x18(%r14),%eax
   cd64a:	85 c0                	test   %eax,%eax
   cd64c:	0f 85 2e 07 00 00    	jne    cdd80 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x850>
   cd652:	49 8b 57 20          	mov    0x20(%r15),%rdx
   cd656:	49 3b 56 10          	cmp    0x10(%r14),%rdx
   cd65a:	75 46                	jne    cd6a2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x172>
   cd65c:	49 8b 76 08          	mov    0x8(%r14),%rsi
   cd660:	49 8b 7f 18          	mov    0x18(%r15),%rdi
   cd664:	48 c1 e2 03          	shl    $0x3,%rdx
   cd668:	ff 15 a2 1b 0a 00    	call   *0xa1ba2(%rip)        # 16f210 <bcmp@GLIBC_2.2.5>
   cd66e:	85 c0                	test   %eax,%eax
   cd670:	75 30                	jne    cd6a2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x172>
   cd672:	41 8b 46 18          	mov    0x18(%r14),%eax
   cd676:	85 c0                	test   %eax,%eax
   cd678:	0f 85 43 07 00 00    	jne    cddc1 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x891>
   cd67e:	49 8b 57 38          	mov    0x38(%r15),%rdx
   cd682:	49 3b 56 10          	cmp    0x10(%r14),%rdx
   cd686:	75 1a                	jne    cd6a2 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x172>
   cd688:	49 8b 76 08          	mov    0x8(%r14),%rsi
   cd68c:	49 8b 7f 30          	mov    0x30(%r15),%rdi
   cd690:	48 c1 e2 03          	shl    $0x3,%rdx
   cd694:	ff 15 76 1b 0a 00    	call   *0xa1b76(%rip)        # 16f210 <bcmp@GLIBC_2.2.5>
   cd69a:	85 c0                	test   %eax,%eax
   cd69c:	0f 84 b0 00 00 00    	je     cd752 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x222>
   cd6a2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cd6a7:	48 8d 78 30          	lea    0x30(%rax),%rdi
   cd6ab:	49 83 c4 30          	add    $0x30,%r12
   cd6af:	40 b5 01             	mov    $0x1,%bpl
   cd6b2:	48 89 de             	mov    %rbx,%rsi
   cd6b5:	4c 89 e2             	mov    %r12,%rdx
   cd6b8:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   cd6bd:	4c 8d 40 18          	lea    0x18(%rax),%r8
   cd6c1:	e8 7a f6 ff ff       	call   ccd40 <<hyperreal::computable::node::RadicalCoefficient>::multiply_same_radicand_fields>
   cd6c6:	48 85 c0             	test   %rax,%rax
   cd6c9:	0f 84 84 06 00 00    	je     cdd53 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x823>
   cd6cf:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   cd6d4:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
   cd6db:	48 c7 41 08 08 00 00 	movq   $0x8,0x8(%rcx)
   cd6e2:	00 
   cd6e3:	0f 57 c0             	xorps  %xmm0,%xmm0
   cd6e6:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
   cd6ea:	48 c7 41 20 08 00 00 	movq   $0x8,0x20(%rcx)
   cd6f1:	00 
   cd6f2:	48 c7 41 28 00 00 00 	movq   $0x0,0x28(%rcx)
   cd6f9:	00 
   cd6fa:	48 89 41 30          	mov    %rax,0x30(%rcx)
   cd6fe:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cd703:	48 8d 58 18          	lea    0x18(%rax),%rbx
   cd707:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   cd70c:	49 8b 46 30          	mov    0x30(%r14),%rax
   cd710:	f0 48 ff 08          	lock decq (%rax)
   cd714:	0f 84 a3 fe ff ff    	je     cd5bd <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8d>
   cd71a:	e9 c9 01 00 00       	jmp    cd8e8 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3b8>
   cd71f:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   cd724:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cd729:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
   cd72e:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   cd733:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
   cd738:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   cd73d:	48 c1 e0 03          	shl    $0x3,%rax
   cd741:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   cd745:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cd74a:	45 31 ed             	xor    %r13d,%r13d
   cd74d:	eb 0c                	jmp    cd75b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x22b>
   cd74f:	41 b5 01             	mov    $0x1,%r13b
   cd752:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   cd759:	00 00 
   cd75b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cd760:	48 8d 78 30          	lea    0x30(%rax),%rdi
   cd764:	49 8d 74 24 30       	lea    0x30(%r12),%rsi
   cd769:	40 b5 01             	mov    $0x1,%bpl
   cd76c:	48 89 bc 24 88 00 00 	mov    %rdi,0x88(%rsp)
   cd773:	00 
   cd774:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   cd77b:	00 
   cd77c:	e8 df 3f fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cd781:	4c 89 a4 24 e8 00 00 	mov    %r12,0xe8(%rsp)
   cd788:	00 
   cd789:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   cd790:	00 
   cd791:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
   cd798:	00 00 00 00 00 
   cd79d:	48 c7 84 24 a8 00 00 	movq   $0x8,0xa8(%rsp)
   cd7a4:	00 08 00 00 00 
   cd7a9:	0f 57 c0             	xorps  %xmm0,%xmm0
   cd7ac:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
   cd7b3:	00 
   cd7b4:	48 c7 84 24 c0 00 00 	movq   $0x8,0xc0(%rsp)
   cd7bb:	00 08 00 00 00 
   cd7c0:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
   cd7c7:	00 00 00 00 00 
   cd7cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cd7d1:	4c 8b 70 08          	mov    0x8(%rax),%r14
   cd7d5:	4c 8b 60 10          	mov    0x10(%rax),%r12
   cd7d9:	49 c1 e4 04          	shl    $0x4,%r12
   cd7dd:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
   cd7e4:	00 
   cd7e5:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
   cd7ec:	00 
   cd7ed:	0f 1f 00             	nopl   (%rax)
   cd7f0:	4d 85 e4             	test   %r12,%r12
   cd7f3:	74 42                	je     cd837 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x307>
   cd7f5:	49 8b 06             	mov    (%r14),%rax
   cd7f8:	f0 48 ff 00          	lock incq (%rax)
   cd7fc:	0f 8e bd 05 00 00    	jle    cddbf <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x88f>
   cd802:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   cd806:	4d 8b 3e             	mov    (%r14),%r15
   cd809:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   cd80e:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
   cd815:	00 
   cd816:	e8 45 3f fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cd81b:	48 89 df             	mov    %rbx,%rdi
   cd81e:	4c 89 fe             	mov    %r15,%rsi
   cd821:	48 89 c2             	mov    %rax,%rdx
   cd824:	e8 37 f0 ff ff       	call   cc860 <<hyperreal::computable::node::RadicalCoefficient>::insert_radical>
   cd829:	49 83 c6 10          	add    $0x10,%r14
   cd82d:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
   cd831:	84 c0                	test   %al,%al
   cd833:	75 bb                	jne    cd7f0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x2c0>
   cd835:	eb 70                	jmp    cd8a7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x377>
   cd837:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
   cd83c:	49 c1 e6 04          	shl    $0x4,%r14
   cd840:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
   cd847:	00 
   cd848:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
   cd84f:	00 
   cd850:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
   cd855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   cd85c:	00 00 00 00 
   cd860:	4d 85 f6             	test   %r14,%r14
   cd863:	0f 84 04 01 00 00    	je     cd96d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x43d>
   cd869:	49 8b 04 24          	mov    (%r12),%rax
   cd86d:	f0 48 ff 00          	lock incq (%rax)
   cd871:	0f 8e 48 05 00 00    	jle    cddbf <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x88f>
   cd877:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
   cd87c:	4d 8b 3c 24          	mov    (%r12),%r15
   cd880:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   cd885:	48 89 ee             	mov    %rbp,%rsi
   cd888:	e8 d3 3e fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cd88d:	48 89 df             	mov    %rbx,%rdi
   cd890:	4c 89 fe             	mov    %r15,%rsi
   cd893:	48 89 c2             	mov    %rax,%rdx
   cd896:	e8 c5 ef ff ff       	call   cc860 <<hyperreal::computable::node::RadicalCoefficient>::insert_radical>
   cd89b:	49 83 c4 10          	add    $0x10,%r12
   cd89f:	49 83 c6 f0          	add    $0xfffffffffffffff0,%r14
   cd8a3:	84 c0                	test   %al,%al
   cd8a5:	75 b9                	jne    cd860 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x330>
   cd8a7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cd8ac:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cd8b3:	40 b5 01             	mov    $0x1,%bpl
   cd8b6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   cd8bd:	00 
   cd8be:	e8 9d 34 fe ff       	call   b0d60 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cd8c3:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
   cd8ca:	00 
   cd8cb:	48 8b 07             	mov    (%rdi),%rax
   cd8ce:	f0 48 ff 08          	lock decq (%rax)
   cd8d2:	75 06                	jne    cd8da <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3aa>
   cd8d4:	ff 15 46 19 0a 00    	call   *0xa1946(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cd8da:	40 84 ed             	test   %bpl,%bpl
   cd8dd:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   cd8e2:	49 8d 5e 18          	lea    0x18(%r14),%rbx
   cd8e6:	74 23                	je     cd90b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3db>
   cd8e8:	4c 89 f7             	mov    %r14,%rdi
   cd8eb:	e8 e0 59 04 00       	call   1132d0 <<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cd8f0:	49 8b 36             	mov    (%r14),%rsi
   cd8f3:	48 85 f6             	test   %rsi,%rsi
   cd8f6:	74 13                	je     cd90b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3db>
   cd8f8:	49 8b 7e 08          	mov    0x8(%r14),%rdi
   cd8fc:	48 c1 e6 04          	shl    $0x4,%rsi
   cd900:	ba 08 00 00 00       	mov    $0x8,%edx
   cd905:	ff 15 35 19 0a 00    	call   *0xa1935(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cd90b:	49 8b 7e 20          	mov    0x20(%r14),%rdi
   cd90f:	4d 8b 76 28          	mov    0x28(%r14),%r14
   cd913:	49 ff c6             	inc    %r14
   cd916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cd91d:	00 00 00 
   cd920:	49 83 fe 01          	cmp    $0x1,%r14
   cd924:	74 11                	je     cd937 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x407>
   cd926:	4c 8d 7f 18          	lea    0x18(%rdi),%r15
   cd92a:	49 ff ce             	dec    %r14
   cd92d:	e8 2e 3e 04 00       	call   111760 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   cd932:	4c 89 ff             	mov    %r15,%rdi
   cd935:	eb e9                	jmp    cd920 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x3f0>
   cd937:	48 8b 03             	mov    (%rbx),%rax
   cd93a:	48 85 c0             	test   %rax,%rax
   cd93d:	74 1c                	je     cd95b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x42b>
   cd93f:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cd944:	48 8b 79 20          	mov    0x20(%rcx),%rdi
   cd948:	48 c1 e0 03          	shl    $0x3,%rax
   cd94c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   cd950:	ba 08 00 00 00       	mov    $0x8,%edx
   cd955:	ff 15 e5 18 0a 00    	call   *0xa18e5(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cd95b:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
   cd962:	5b                   	pop    %rbx
   cd963:	41 5c                	pop    %r12
   cd965:	41 5d                	pop    %r13
   cd967:	41 5e                	pop    %r14
   cd969:	41 5f                	pop    %r15
   cd96b:	5d                   	pop    %rbp
   cd96c:	c3                   	ret
   cd96d:	44 89 ac 24 9c 00 00 	mov    %r13d,0x9c(%rsp)
   cd974:	00 
   cd975:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cd97a:	48 8b 01             	mov    (%rcx),%rax
   cd97d:	48 8b 59 08          	mov    0x8(%rcx),%rbx
   cd981:	48 8b 49 10          	mov    0x10(%rcx),%rcx
   cd985:	48 89 ca             	mov    %rcx,%rdx
   cd988:	48 c1 e2 04          	shl    $0x4,%rdx
   cd98c:	48 01 da             	add    %rbx,%rdx
   cd98f:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   cd994:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   cd999:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cd99e:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
   cd9a5:	00 
   cd9a6:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   cd9ab:	48 85 c9             	test   %rcx,%rcx
   cd9ae:	0f 84 bf 01 00 00    	je     cdb73 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x643>
   cd9b4:	4c 8d ac 24 90 00 00 	lea    0x90(%rsp),%r13
   cd9bb:	00 
   cd9bc:	eb 0e                	jmp    cd9cc <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x49c>
   cd9be:	48 3b 9c 24 e0 00 00 	cmp    0xe0(%rsp),%rbx
   cd9c5:	00 
   cd9c6:	0f 84 a7 01 00 00    	je     cdb73 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x643>
   cd9cc:	48 8d 4b 10          	lea    0x10(%rbx),%rcx
   cd9d0:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
   cd9d7:	00 
   cd9d8:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   cd9dd:	48 8b 0b             	mov    (%rbx),%rcx
   cd9e0:	48 8b 43 08          	mov    0x8(%rbx),%rax
   cd9e4:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   cd9e9:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   cd9f0:	00 
   cd9f1:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   cd9f8:	00 
   cd9f9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   cd9fe:	4c 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%r14
   cda05:	00 
   cda06:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
   cda0b:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
   cda11:	75 6a                	jne    cda7d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x54d>
   cda13:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cda1a:	00 
   cda1b:	f0 48 ff 08          	lock decq (%rax)
   cda1f:	75 0b                	jne    cda2c <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x4fc>
   cda21:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cda26:	ff 15 f4 17 0a 00    	call   *0xa17f4(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cda2c:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   cda31:	f0 48 ff 08          	lock decq (%rax)
   cda35:	48 8b 9c 24 f8 00 00 	mov    0xf8(%rsp),%rbx
   cda3c:	00 
   cda3d:	0f 85 7b ff ff ff    	jne    cd9be <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x48e>
   cda43:	4c 89 ef             	mov    %r13,%rdi
   cda46:	ff 15 d4 17 0a 00    	call   *0xa17d4(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cda4c:	e9 6d ff ff ff       	jmp    cd9be <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x48e>
   cda51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cda58:	0f 1f 84 00 00 00 00 
   cda5f:	00 
   cda60:	4c 89 ff             	mov    %r15,%rdi
   cda63:	48 89 de             	mov    %rbx,%rsi
   cda66:	e8 c5 23 fc ff       	call   8fe30 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Add>::add>
   cda6b:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   cda72:	00 
   cda73:	48 83 c5 10          	add    $0x10,%rbp
   cda77:	49 83 c6 f0          	add    $0xfffffffffffffff0,%r14
   cda7b:	74 96                	je     cda13 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x4e3>
   cda7d:	48 8d 75 08          	lea    0x8(%rbp),%rsi
   cda81:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cda86:	e8 d5 3c fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cda8b:	49 89 c4             	mov    %rax,%r12
   cda8e:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   cda95:	00 
   cda96:	4c 89 ef             	mov    %r13,%rdi
   cda99:	48 89 ee             	mov    %rbp,%rsi
   cda9c:	ff 15 26 17 0a 00    	call   *0xa1726(%rip)        # 16f1c8 <_DYNAMIC+0x248>
   cdaa2:	84 c0                	test   %al,%al
   cdaa4:	74 3a                	je     cdae0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x5b0>
   cdaa6:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
   cdaad:	00 
   cdaae:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
   cdab3:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
   cdab8:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cdabd:	4c 89 ee             	mov    %r13,%rsi
   cdac0:	e8 9b 3c fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdac5:	48 89 c3             	mov    %rax,%rbx
   cdac8:	f0 49 ff 0c 24       	lock decq (%r12)
   cdacd:	75 91                	jne    cda60 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x530>
   cdacf:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cdad4:	ff 15 46 17 0a 00    	call   *0xa1746(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdada:	eb 84                	jmp    cda60 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x530>
   cdadc:	0f 1f 40 00          	nopl   0x0(%rax)
   cdae0:	4c 89 ef             	mov    %r13,%rdi
   cdae3:	48 89 ee             	mov    %rbp,%rsi
   cdae6:	e8 75 3c fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdaeb:	48 89 c7             	mov    %rax,%rdi
   cdaee:	e8 3d 58 fa ff       	call   73330 <<hyperreal::rational::arithmetic::Rational>::extract_square_reduced_retained>
   cdaf3:	49 89 d7             	mov    %rdx,%r15
   cdaf6:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   cdafb:	4c 89 e7             	mov    %r12,%rdi
   cdafe:	48 89 c6             	mov    %rax,%rsi
   cdb01:	e8 da 47 fc ff       	call   922e0 <<hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdb06:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   cdb0d:	00 
   cdb0e:	4c 89 fe             	mov    %r15,%rsi
   cdb11:	48 89 c2             	mov    %rax,%rdx
   cdb14:	e8 47 ed ff ff       	call   cc860 <<hyperreal::computable::node::RadicalCoefficient>::insert_radical>
   cdb19:	84 c0                	test   %al,%al
   cdb1b:	0f 85 52 ff ff ff    	jne    cda73 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x543>
   cdb21:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cdb26:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cdb2d:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cdb34:	00 
   cdb35:	f0 48 ff 08          	lock decq (%rax)
   cdb39:	75 0b                	jne    cdb46 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x616>
   cdb3b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cdb40:	ff 15 da 16 0a 00    	call   *0xa16da(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdb46:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   cdb4b:	f0 48 ff 08          	lock decq (%rax)
   cdb4f:	75 0e                	jne    cdb5f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x62f>
   cdb51:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cdb58:	00 
   cdb59:	ff 15 c1 16 0a 00    	call   *0xa16c1(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdb5f:	41 b7 01             	mov    $0x1,%r15b
   cdb62:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdb67:	e8 f4 fc 03 00       	call   10d860 <<alloc::vec::into_iter::IntoIter<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdb6c:	31 ed                	xor    %ebp,%ebp
   cdb6e:	e9 43 fd ff ff       	jmp    cd8b6 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x386>
   cdb73:	41 b7 01             	mov    $0x1,%r15b
   cdb76:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdb7b:	e8 e0 fc 03 00       	call   10d860 <<alloc::vec::into_iter::IntoIter<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdb80:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cdb85:	48 8b 41 18          	mov    0x18(%rcx),%rax
   cdb89:	4c 8b 71 20          	mov    0x20(%rcx),%r14
   cdb8d:	48 8b 49 28          	mov    0x28(%rcx),%rcx
   cdb91:	48 8d 14 cd 00 00 00 	lea    0x0(,%rcx,8),%rdx
   cdb98:	00 
   cdb99:	4c 8d 24 52          	lea    (%rdx,%rdx,2),%r12
   cdb9d:	4b 8d 14 26          	lea    (%r14,%r12,1),%rdx
   cdba1:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   cdba6:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   cdbab:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cdbb0:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
   cdbb5:	48 85 c9             	test   %rcx,%rcx
   cdbb8:	74 71                	je     cdc2b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6fb>
   cdbba:	49 83 c6 18          	add    $0x18,%r14
   cdbbe:	66 90                	xchg   %ax,%ax
   cdbc0:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   cdbc5:	4d 8b 7e e8          	mov    -0x18(%r14),%r15
   cdbc9:	4d 85 ff             	test   %r15,%r15
   cdbcc:	74 5d                	je     cdc2b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6fb>
   cdbce:	4d 8b 6e f0          	mov    -0x10(%r14),%r13
   cdbd2:	49 8b 5e f8          	mov    -0x8(%r14),%rbx
   cdbd6:	4c 89 7c 24 68       	mov    %r15,0x68(%rsp)
   cdbdb:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   cdbe0:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   cdbe5:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cdbea:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
   cdbf1:	00 
   cdbf2:	e8 69 3b fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdbf7:	48 89 c5             	mov    %rax,%rbp
   cdbfa:	f0 48 ff 0b          	lock decq (%rbx)
   cdbfe:	75 0b                	jne    cdc0b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x6db>
   cdc00:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cdc05:	ff 15 15 16 0a 00    	call   *0xa1615(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdc0b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   cdc12:	00 
   cdc13:	4c 89 fe             	mov    %r15,%rsi
   cdc16:	4c 89 ea             	mov    %r13,%rdx
   cdc19:	48 89 e9             	mov    %rbp,%rcx
   cdc1c:	e8 ef e8 ff ff       	call   cc510 <<hyperreal::computable::node::RadicalCoefficient>::insert_atom>
   cdc21:	49 83 c6 18          	add    $0x18,%r14
   cdc25:	49 83 c4 e8          	add    $0xffffffffffffffe8,%r12
   cdc29:	75 95                	jne    cdbc0 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x690>
   cdc2b:	45 31 ff             	xor    %r15d,%r15d
   cdc2e:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdc33:	e8 58 fb 03 00       	call   10d790 <<alloc::vec::into_iter::IntoIter<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cdc38:	80 bc 24 9c 00 00 00 	cmpb   $0x0,0x9c(%rsp)
   cdc3f:	00 
   cdc40:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cdc45:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   cdc4c:	00 
   cdc4d:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
   cdc54:	00 
   cdc55:	75 70                	jne    cdcc7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x797>
   cdc57:	48 8b 58 20          	mov    0x20(%rax),%rbx
   cdc5b:	48 01 5c 24 20       	add    %rbx,0x20(%rsp)
   cdc60:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
   cdc67:	00 
   cdc68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   cdc6f:	00 
   cdc70:	4c 8b 23             	mov    (%rbx),%r12
   cdc73:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
   cdc77:	f0 49 ff 04 24       	lock incq (%r12)
   cdc7c:	0f 8e 3d 01 00 00    	jle    cddbf <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x88f>
   cdc82:	4d 85 ed             	test   %r13,%r13
   cdc85:	74 0b                	je     cdc92 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x762>
   cdc87:	f0 49 ff 45 00       	lock incq 0x0(%r13)
   cdc8c:	0f 8e 2d 01 00 00    	jle    cddbf <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x88f>
   cdc92:	48 83 c3 10          	add    $0x10,%rbx
   cdc96:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   cdc9b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
   cdca0:	48 89 df             	mov    %rbx,%rdi
   cdca3:	48 89 ee             	mov    %rbp,%rsi
   cdca6:	e8 b5 3a fc ff       	call   91760 <<&hyperreal::rational::arithmetic::Rational as core::ops::arith::Mul>::mul>
   cdcab:	4c 89 ff             	mov    %r15,%rdi
   cdcae:	4c 89 e6             	mov    %r12,%rsi
   cdcb1:	4c 89 ea             	mov    %r13,%rdx
   cdcb4:	48 89 c1             	mov    %rax,%rcx
   cdcb7:	e8 54 e8 ff ff       	call   cc510 <<hyperreal::computable::node::RadicalCoefficient>::insert_atom>
   cdcbc:	48 83 c3 08          	add    $0x8,%rbx
   cdcc0:	48 3b 5c 24 20       	cmp    0x20(%rsp),%rbx
   cdcc5:	75 a9                	jne    cdc70 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x740>
   cdcc7:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   cdcce:	00 
   cdccf:	49 89 46 30          	mov    %rax,0x30(%r14)
   cdcd3:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
   cdcda:	00 
   cdcdb:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
   cdce2:	00 
   cdce3:	0f 10 94 24 c0 00 00 	movups 0xc0(%rsp),%xmm2
   cdcea:	00 
   cdceb:	41 0f 11 56 20       	movups %xmm2,0x20(%r14)
   cdcf0:	41 0f 11 4e 10       	movups %xmm1,0x10(%r14)
   cdcf5:	41 0f 11 06          	movups %xmm0,(%r14)
   cdcf9:	48 8b 45 00          	mov    0x0(%rbp),%rax
   cdcfd:	f0 48 ff 08          	lock decq (%rax)
   cdd01:	0f 85 54 fc ff ff    	jne    cd95b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x42b>
   cdd07:	48 89 ef             	mov    %rbp,%rdi
   cdd0a:	ff 15 10 15 0a 00    	call   *0xa1510(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdd10:	e9 46 fc ff ff       	jmp    cd95b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x42b>
   cdd15:	48 89 de             	mov    %rbx,%rsi
   cdd18:	eb 1b                	jmp    cdd35 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x805>
   cdd1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   cdd20:	49 89 f7             	mov    %rsi,%r15
   cdd23:	4c 89 fe             	mov    %r15,%rsi
   cdd26:	4d 8b 3f             	mov    (%r15),%r15
   cdd29:	41 8b 47 60          	mov    0x60(%r15),%eax
   cdd2d:	84 c0                	test   %al,%al
   cdd2f:	0f 89 03 f9 ff ff    	jns    cd638 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x108>
   cdd35:	41 8b 47 60          	mov    0x60(%r15),%eax
   cdd39:	84 c0                	test   %al,%al
   cdd3b:	79 e3                	jns    cdd20 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7f0>
   cdd3d:	41 8b 47 50          	mov    0x50(%r15),%eax
   cdd41:	49 83 c7 40          	add    $0x40,%r15
   cdd45:	85 c0                	test   %eax,%eax
   cdd47:	74 da                	je     cdd23 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7f3>
   cdd49:	4c 89 ff             	mov    %r15,%rdi
   cdd4c:	e8 f8 ff 03 00       	call   10dd49 <<std::sync::once_lock::OnceLock<hyperreal::rational::arithmetic::CachedRationalProduct>>::initialize::<<std::sync::once_lock::OnceLock<hyperreal::rational::arithmetic::CachedRationalProduct>>::get_or_init<<hyperreal::rational::arithmetic::Rational>::canonicalized_ref::{closure#0}>::{closure#0}, !>>
   cdd51:	eb d0                	jmp    cdd23 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x7f3>
   cdd53:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cdd58:	48 8b 41 30          	mov    0x30(%rcx),%rax
   cdd5c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   cdd61:	48 89 42 30          	mov    %rax,0x30(%rdx)
   cdd65:	0f 10 01             	movups (%rcx),%xmm0
   cdd68:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   cdd6c:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   cdd70:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
   cdd74:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
   cdd78:	0f 11 02             	movups %xmm0,(%rdx)
   cdd7b:	e9 db fb ff ff       	jmp    cd95b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x42b>
   cdd80:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   cdd85:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   cdd8a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   cdd91:	00 
   cdd92:	40 b5 01             	mov    $0x1,%bpl
   cdd95:	49 8d 7e 18          	lea    0x18(%r14),%rdi
   cdd99:	48 8d 0d a0 d1 09 00 	lea    0x9d1a0(%rip),%rcx        # 16af40 <anon.afeede234644f26776946e76b404b106.3.llvm.3890322146277128485+0x28>
   cdda0:	4c 8d 05 59 d1 09 00 	lea    0x9d159(%rip),%r8        # 16af00 <anon.afeede234644f26776946e76b404b106.2.llvm.3890322146277128485>
   cdda7:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
   cddae:	00 
   cddaf:	be 01 00 00 00       	mov    $0x1,%esi
   cddb4:	ff 15 06 14 0a 00    	call   *0xa1406(%rip)        # 16f1c0 <_DYNAMIC+0x240>
   cddba:	e9 93 f8 ff ff       	jmp    cd652 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x122>
   cddbf:	0f 0b                	ud2
   cddc1:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   cddc6:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   cddcb:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   cddd2:	00 
   cddd3:	40 b5 01             	mov    $0x1,%bpl
   cddd6:	49 8d 7e 18          	lea    0x18(%r14),%rdi
   cddda:	48 8d 0d 5f d1 09 00 	lea    0x9d15f(%rip),%rcx        # 16af40 <anon.afeede234644f26776946e76b404b106.3.llvm.3890322146277128485+0x28>
   cdde1:	4c 8d 05 18 d1 09 00 	lea    0x9d118(%rip),%r8        # 16af00 <anon.afeede234644f26776946e76b404b106.2.llvm.3890322146277128485>
   cdde8:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
   cddef:	00 
   cddf0:	be 01 00 00 00       	mov    $0x1,%esi
   cddf5:	ff 15 c5 13 0a 00    	call   *0xa13c5(%rip)        # 16f1c0 <_DYNAMIC+0x240>
   cddfb:	e9 7e f8 ff ff       	jmp    cd67e <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x14e>
   cde00:	49 89 c5             	mov    %rax,%r13
   cde03:	41 b7 01             	mov    $0x1,%r15b
   cde06:	40 b5 01             	mov    $0x1,%bpl
   cde09:	e9 2f 02 00 00       	jmp    ce03d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb0d>
   cde0e:	eb 02                	jmp    cde12 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8e2>
   cde10:	eb 0b                	jmp    cde1d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x8ed>
   cde12:	49 89 c5             	mov    %rax,%r13
   cde15:	41 b6 01             	mov    $0x1,%r14b
   cde18:	e9 f2 01 00 00       	jmp    ce00f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xadf>
   cde1d:	49 89 c5             	mov    %rax,%r13
   cde20:	41 b6 01             	mov    $0x1,%r14b
   cde23:	e9 ce 01 00 00       	jmp    cdff6 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xac6>
   cde28:	49 89 c5             	mov    %rax,%r13
   cde2b:	31 ed                	xor    %ebp,%ebp
   cde2d:	e9 72 01 00 00       	jmp    cdfa4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa74>
   cde32:	49 89 c5             	mov    %rax,%r13
   cde35:	40 84 ed             	test   %bpl,%bpl
   cde38:	75 4f                	jne    cde89 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x959>
   cde3a:	e9 aa 00 00 00       	jmp    cdee9 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b9>
   cde3f:	49 89 c5             	mov    %rax,%r13
   cde42:	eb 19                	jmp    cde5d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x92d>
   cde44:	49 89 c5             	mov    %rax,%r13
   cde47:	eb 1e                	jmp    cde67 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x937>
   cde49:	49 89 c5             	mov    %rax,%r13
   cde4c:	f0 48 ff 0b          	lock decq (%rbx)
   cde50:	75 0b                	jne    cde5d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x92d>
   cde52:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cde57:	ff 15 c3 13 0a 00    	call   *0xa13c3(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cde5d:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cde62:	e8 59 2a fe ff       	call   b08c0 <core::ptr::drop_glue::<hyperreal::computable::node::Computable>>
   cde67:	31 ed                	xor    %ebp,%ebp
   cde69:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cde6e:	e8 1d f9 03 00       	call   10d790 <<alloc::vec::into_iter::IntoIter<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   cde73:	45 31 ff             	xor    %r15d,%r15d
   cde76:	e9 29 01 00 00       	jmp    cdfa4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa74>
   cde7b:	ff 15 a7 13 0a 00    	call   *0xa13a7(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cde81:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cde86:	49 89 c5             	mov    %rax,%r13
   cde89:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   cde8e:	e8 9d 1b fe ff       	call   afa30 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   cde93:	eb 54                	jmp    cdee9 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b9>
   cde95:	49 89 c5             	mov    %rax,%r13
   cde98:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cde9d:	e8 1e 2a fe ff       	call   b08c0 <core::ptr::drop_glue::<hyperreal::computable::node::Computable>>
   cdea2:	eb 03                	jmp    cdea7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x977>
   cdea4:	49 89 c5             	mov    %rax,%r13
   cdea7:	31 ed                	xor    %ebp,%ebp
   cdea9:	45 31 ff             	xor    %r15d,%r15d
   cdeac:	e9 f3 00 00 00       	jmp    cdfa4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa74>
   cdeb1:	49 89 c5             	mov    %rax,%r13
   cdeb4:	41 b7 01             	mov    $0x1,%r15b
   cdeb7:	e9 81 01 00 00       	jmp    ce03d <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb0d>
   cdebc:	49 89 c5             	mov    %rax,%r13
   cdebf:	eb 71                	jmp    cdf32 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa02>
   cdec1:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cdec6:	49 89 c5             	mov    %rax,%r13
   cdec9:	49 8b 36             	mov    (%r14),%rsi
   cdecc:	48 85 f6             	test   %rsi,%rsi
   cdecf:	74 18                	je     cdee9 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0x9b9>
   cded1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cded6:	48 8b 78 08          	mov    0x8(%rax),%rdi
   cdeda:	48 c1 e6 04          	shl    $0x4,%rsi
   cdede:	ba 08 00 00 00       	mov    $0x8,%edx
   cdee3:	ff 15 57 13 0a 00    	call   *0xa1357(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cdee9:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   cdeee:	e8 6d 1a fe ff       	call   af960 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   cdef3:	e9 b7 01 00 00       	jmp    ce0af <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb7f>
   cdef8:	49 89 c5             	mov    %rax,%r13
   cdefb:	f0 49 ff 0f          	lock decq (%r15)
   cdeff:	41 b6 01             	mov    $0x1,%r14b
   cdf02:	0f 85 d5 00 00 00    	jne    cdfdd <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaad>
   cdf08:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cdf0d:	ff 15 0d 13 0a 00    	call   *0xa130d(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdf13:	e9 c5 00 00 00       	jmp    cdfdd <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaad>
   cdf18:	49 89 c5             	mov    %rax,%r13
   cdf1b:	eb 26                	jmp    cdf43 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa13>
   cdf1d:	49 89 c5             	mov    %rax,%r13
   cdf20:	f0 49 ff 0c 24       	lock decq (%r12)
   cdf25:	75 0b                	jne    cdf32 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa02>
   cdf27:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cdf2c:	ff 15 ee 12 0a 00    	call   *0xa12ee(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdf32:	f0 49 ff 0f          	lock decq (%r15)
   cdf36:	75 0b                	jne    cdf43 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa13>
   cdf38:	48 8d 7c 24 58       	lea    0x58(%rsp),%rdi
   cdf3d:	ff 15 dd 12 0a 00    	call   *0xa12dd(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdf43:	45 31 f6             	xor    %r14d,%r14d
   cdf46:	e9 92 00 00 00       	jmp    cdfdd <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaad>
   cdf4b:	ff 15 d7 12 0a 00    	call   *0xa12d7(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cdf51:	eb 21                	jmp    cdf74 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa44>
   cdf53:	49 89 c5             	mov    %rax,%r13
   cdf56:	f0 49 ff 0f          	lock decq (%r15)
   cdf5a:	40 b5 01             	mov    $0x1,%bpl
   cdf5d:	75 42                	jne    cdfa1 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa71>
   cdf5f:	40 b5 01             	mov    $0x1,%bpl
   cdf62:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdf67:	ff 15 b3 12 0a 00    	call   *0xa12b3(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdf6d:	41 b7 01             	mov    $0x1,%r15b
   cdf70:	eb 32                	jmp    cdfa4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa74>
   cdf72:	eb 27                	jmp    cdf9b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa6b>
   cdf74:	49 89 c5             	mov    %rax,%r13
   cdf77:	41 b6 01             	mov    $0x1,%r14b
   cdf7a:	eb 61                	jmp    cdfdd <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaad>
   cdf7c:	49 89 c5             	mov    %rax,%r13
   cdf7f:	f0 49 ff 0f          	lock decq (%r15)
   cdf83:	40 b5 01             	mov    $0x1,%bpl
   cdf86:	75 19                	jne    cdfa1 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa71>
   cdf88:	40 b5 01             	mov    $0x1,%bpl
   cdf8b:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   cdf90:	ff 15 8a 12 0a 00    	call   *0xa128a(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdf96:	41 b7 01             	mov    $0x1,%r15b
   cdf99:	eb 09                	jmp    cdfa4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa74>
   cdf9b:	49 89 c5             	mov    %rax,%r13
   cdf9e:	40 b5 01             	mov    $0x1,%bpl
   cdfa1:	41 b7 01             	mov    $0x1,%r15b
   cdfa4:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   cdfab:	00 
   cdfac:	f0 48 ff 08          	lock decq (%rax)
   cdfb0:	75 71                	jne    ce023 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaf3>
   cdfb2:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
   cdfb9:	00 
   cdfba:	ff 15 60 12 0a 00    	call   *0xa1260(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdfc0:	eb 61                	jmp    ce023 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaf3>
   cdfc2:	49 89 c5             	mov    %rax,%r13
   cdfc5:	f0 49 ff 0c 24       	lock decq (%r12)
   cdfca:	41 b6 01             	mov    $0x1,%r14b
   cdfcd:	75 0e                	jne    cdfdd <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xaad>
   cdfcf:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
   cdfd6:	00 
   cdfd7:	ff 15 43 12 0a 00    	call   *0xa1243(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdfdd:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cdfe4:	00 
   cdfe5:	f0 48 ff 08          	lock decq (%rax)
   cdfe9:	75 0b                	jne    cdff6 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xac6>
   cdfeb:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   cdff0:	ff 15 2a 12 0a 00    	call   *0xa122a(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cdff6:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   cdffb:	f0 48 ff 08          	lock decq (%rax)
   cdfff:	75 0e                	jne    ce00f <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xadf>
   ce001:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   ce008:	00 
   ce009:	ff 15 11 12 0a 00    	call   *0xa1211(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ce00f:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   ce014:	e8 47 f8 03 00       	call   10d860 <<alloc::vec::into_iter::IntoIter<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)> as core::ops::drop::Drop>::drop>
   ce019:	41 b7 01             	mov    $0x1,%r15b
   ce01c:	31 ed                	xor    %ebp,%ebp
   ce01e:	45 84 f6             	test   %r14b,%r14b
   ce021:	75 81                	jne    cdfa4 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xa74>
   ce023:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   ce02a:	00 
   ce02b:	e8 00 1a fe ff       	call   afa30 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   ce030:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   ce037:	00 
   ce038:	e8 23 19 fe ff       	call   af960 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   ce03d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ce042:	48 8b 40 30          	mov    0x30(%rax),%rax
   ce046:	f0 48 ff 08          	lock decq (%rax)
   ce04a:	75 0f                	jne    ce05b <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb2b>
   ce04c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   ce051:	48 8d 78 30          	lea    0x30(%rax),%rdi
   ce055:	ff 15 c5 11 0a 00    	call   *0xa11c5(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   ce05b:	40 84 ed             	test   %bpl,%bpl
   ce05e:	74 0a                	je     ce06a <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb3a>
   ce060:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   ce065:	e8 c6 19 fe ff       	call   afa30 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   ce06a:	45 84 ff             	test   %r15b,%r15b
   ce06d:	74 40                	je     ce0af <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb7f>
   ce06f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   ce074:	e8 e7 18 fe ff       	call   af960 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>>
   ce079:	eb 34                	jmp    ce0af <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb7f>
   ce07b:	ff 15 a7 11 0a 00    	call   *0xa11a7(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   ce081:	49 89 dc             	mov    %rbx,%r12
   ce084:	49 89 c5             	mov    %rax,%r13
   ce087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   ce08e:	00 00 
   ce090:	49 ff ce             	dec    %r14
   ce093:	74 11                	je     ce0a6 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb76>
   ce095:	49 8d 5f 18          	lea    0x18(%r15),%rbx
   ce099:	4c 89 ff             	mov    %r15,%rdi
   ce09c:	e8 bf 36 04 00       	call   111760 <core::ptr::drop_glue::<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)>>
   ce0a1:	49 89 df             	mov    %rbx,%r15
   ce0a4:	eb ea                	jmp    ce090 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb60>
   ce0a6:	49 8b 04 24          	mov    (%r12),%rax
   ce0aa:	48 85 c0             	test   %rax,%rax
   ce0ad:	75 08                	jne    ce0b7 <<hyperreal::computable::node::RadicalCoefficient>::multiply+0xb87>
   ce0af:	4c 89 ef             	mov    %r13,%rdi
   ce0b2:	e8 69 ae 09 00       	call   168f20 <_Unwind_Resume@plt>
   ce0b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   ce0bc:	48 8b 79 20          	mov    0x20(%rcx),%rdi
   ce0c0:	48 c1 e0 03          	shl    $0x3,%rax
   ce0c4:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   ce0c8:	ba 08 00 00 00       	mov    $0x8,%edx
   ce0cd:	ff 15 6d 11 0a 00    	call   *0xa116d(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   ce0d3:	4c 89 ef             	mov    %r13,%rdi
   ce0d6:	e8 45 ae 09 00       	call   168f20 <_Unwind_Resume@plt>
   ce0db:	ff 15 47 11 0a 00    	call   *0xa1147(%rip)        # 16f228 <_DYNAMIC+0x2a8>
