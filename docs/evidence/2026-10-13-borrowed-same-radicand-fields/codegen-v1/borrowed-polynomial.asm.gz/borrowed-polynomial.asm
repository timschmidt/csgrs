
/home/tim/Documents/GitHub/workspace/csgrs/target/borrowed-same-radicand-fields/cost-v1-binaries/borrowed-quadratic-time:     file format elf64-x86-64


Disassembly of section .text:

00000000000cf620 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply>:
   cf620:	55                   	push   %rbp
   cf621:	41 57                	push   %r15
   cf623:	41 56                	push   %r14
   cf625:	41 55                	push   %r13
   cf627:	41 54                	push   %r12
   cf629:	53                   	push   %rbx
   cf62a:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
   cf631:	49 89 fe             	mov    %rdi,%r14
   cf634:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
   cf63b:	00 00 
   cf63d:	48 c7 44 24 48 08 00 	movq   $0x8,0x48(%rsp)
   cf644:	00 00 
   cf646:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   cf64d:	00 00 
   cf64f:	48 8b 42 08          	mov    0x8(%rdx),%rax
   cf653:	48 89 04 24          	mov    %rax,(%rsp)
   cf657:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   cf65c:	4c 8b 62 10          	mov    0x10(%rdx),%r12
   cf660:	49 83 fc 01          	cmp    $0x1,%r12
   cf664:	0f 85 b8 01 00 00    	jne    cf822 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x202>
   cf66a:	48 8b 06             	mov    (%rsi),%rax
   cf66d:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   cf671:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
   cf675:	49 89 cd             	mov    %rcx,%r13
   cf678:	49 c1 e5 06          	shl    $0x6,%r13
   cf67c:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
   cf680:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   cf685:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf68a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   cf68f:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   cf694:	48 85 c9             	test   %rcx,%rcx
   cf697:	0f 84 64 01 00 00    	je     cf801 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x1e1>
   cf69d:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   cf6a2:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   cf6a7:	48 8b 04 24          	mov    (%rsp),%rax
   cf6ab:	48 83 c0 08          	add    $0x8,%rax
   cf6af:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   cf6b4:	4c 8d bc 24 98 00 00 	lea    0x98(%rsp),%r15
   cf6bb:	00 
   cf6bc:	48 83 c3 40          	add    $0x40,%rbx
   cf6c0:	48 8d ac 24 00 01 00 	lea    0x100(%rsp),%rbp
   cf6c7:	00 
   cf6c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   cf6cf:	00 
   cf6d0:	48 8b 43 c8          	mov    -0x38(%rbx),%rax
   cf6d4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   cf6d8:	0f 84 19 01 00 00    	je     cf7f7 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x1d7>
   cf6de:	44 0f b7 73 c0       	movzwl -0x40(%rbx),%r14d
   cf6e3:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   cf6ea:	00 
   cf6eb:	0f 10 43 d0          	movups -0x30(%rbx),%xmm0
   cf6ef:	0f 10 4b e0          	movups -0x20(%rbx),%xmm1
   cf6f3:	0f 10 53 f0          	movups -0x10(%rbx),%xmm2
   cf6f7:	41 0f 11 57 20       	movups %xmm2,0x20(%r15)
   cf6fc:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
   cf701:	41 0f 11 07          	movups %xmm0,(%r15)
   cf705:	48 8b 04 24          	mov    (%rsp),%rax
   cf709:	66 44 03 30          	add    (%rax),%r14w
   cf70d:	0f 80 7b 06 00 00    	jo     cfd8e <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x76e>
   cf713:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   cf71a:	00 
   cf71b:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   cf722:	00 
   cf723:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   cf72a:	00 
   cf72b:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   cf732:	00 
   cf733:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
   cf73a:	00 
   cf73b:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
   cf742:	00 
   cf743:	0f 29 8c 24 20 01 00 	movaps %xmm1,0x120(%rsp)
   cf74a:	00 
   cf74b:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
   cf752:	00 
   cf753:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   cf75a:	00 
   cf75b:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
   cf762:	00 
   cf763:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cf76a:	00 
   cf76b:	48 89 ee             	mov    %rbp,%rsi
   cf76e:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   cf773:	e8 b8 dd ff ff       	call   cd530 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cf778:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cf77f:	00 ff 
   cf781:	0f 84 08 05 00 00    	je     cfc8f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66f>
   cf787:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cf78e:	00 
   cf78f:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   cf796:	00 
   cf797:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cf79e:	00 
   cf79f:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cf7a6:	00 
   cf7a7:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cf7ae:	00 
   cf7af:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   cf7b6:	00 
   cf7b7:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   cf7be:	00 
   cf7bf:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   cf7c6:	00 
   cf7c7:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cf7cc:	44 89 f6             	mov    %r14d,%esi
   cf7cf:	48 8d 94 24 a0 01 00 	lea    0x1a0(%rsp),%rdx
   cf7d6:	00 
   cf7d7:	e8 b4 f2 ff ff       	call   cea90 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cf7dc:	84 c0                	test   %al,%al
   cf7de:	0f 84 ab 04 00 00    	je     cfc8f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66f>
   cf7e4:	48 83 c3 40          	add    $0x40,%rbx
   cf7e8:	49 83 c5 c0          	add    $0xffffffffffffffc0,%r13
   cf7ec:	0f 85 de fe ff ff    	jne    cf6d0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0xb0>
   cf7f2:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   cf7f7:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cf7fc:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cf801:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cf806:	e8 45 e1 03 00       	call   10d950 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cf80b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   cf810:	49 89 46 10          	mov    %rax,0x10(%r14)
   cf814:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   cf819:	41 0f 11 06          	movups %xmm0,(%r14)
   cf81d:	e9 03 05 00 00       	jmp    cfd25 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x705>
   cf822:	48 8b 0e             	mov    (%rsi),%rcx
   cf825:	48 8b 46 08          	mov    0x8(%rsi),%rax
   cf829:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   cf82d:	48 89 d6             	mov    %rdx,%rsi
   cf830:	48 c1 e6 06          	shl    $0x6,%rsi
   cf834:	48 01 c6             	add    %rax,%rsi
   cf837:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   cf83c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cf841:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   cf846:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
   cf84d:	00 
   cf84e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   cf853:	48 85 d2             	test   %rdx,%rdx
   cf856:	0f 84 d1 03 00 00    	je     cfc2d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x60d>
   cf85c:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   cf863:	00 
   cf864:	4c 89 e1             	mov    %r12,%rcx
   cf867:	48 c1 e1 06          	shl    $0x6,%rcx
   cf86b:	48 03 0c 24          	add    (%rsp),%rcx
   cf86f:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   cf874:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   cf879:	48 8d 50 40          	lea    0x40(%rax),%rdx
   cf87d:	48 8b 48 08          	mov    0x8(%rax),%rcx
   cf881:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   cf885:	0f 84 9d 03 00 00    	je     cfc28 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x608>
   cf88b:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   cf890:	0f b7 10             	movzwl (%rax),%edx
   cf893:	66 89 54 24 38       	mov    %dx,0x38(%rsp)
   cf898:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   cf89f:	00 
   cf8a0:	0f 10 40 10          	movups 0x10(%rax),%xmm0
   cf8a4:	0f 10 48 20          	movups 0x20(%rax),%xmm1
   cf8a8:	0f 10 50 30          	movups 0x30(%rax),%xmm2
   cf8ac:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
   cf8b0:	0f 11 4e 10          	movups %xmm1,0x10(%rsi)
   cf8b4:	0f 11 06             	movups %xmm0,(%rsi)
   cf8b7:	4d 85 e4             	test   %r12,%r12
   cf8ba:	0f 84 30 03 00 00    	je     cfbf0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x5d0>
   cf8c0:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   cf8c7:	00 
   cf8c8:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   cf8cf:	00 
   cf8d0:	48 89 dd             	mov    %rbx,%rbp
   cf8d3:	48 c1 e5 04          	shl    $0x4,%rbp
   cf8d7:	48 89 d8             	mov    %rbx,%rax
   cf8da:	48 c1 e8 3c          	shr    $0x3c,%rax
   cf8de:	0f 94 c0             	sete   %al
   cf8e1:	48 b9 f9 ff ff ff ff 	movabs $0x7ffffffffffffff9,%rcx
   cf8e8:	ff ff 7f 
   cf8eb:	48 39 cd             	cmp    %rcx,%rbp
   cf8ee:	0f 92 c1             	setb   %cl
   cf8f1:	84 c8                	test   %cl,%al
   cf8f3:	0f 84 72 03 00 00    	je     cfc6b <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x64b>
   cf8f9:	48 85 ed             	test   %rbp,%rbp
   cf8fc:	0f 84 ab 01 00 00    	je     cfaad <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x48d>
   cf902:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
   cf909:	00 
   cf90a:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
   cf911:	00 
   cf912:	4c 8b 3c 24          	mov    (%rsp),%r15
   cf916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cf91d:	00 00 00 
   cf920:	45 0f b7 2f          	movzwl (%r15),%r13d
   cf924:	66 44 03 6c 24 38    	add    0x38(%rsp),%r13w
   cf92a:	0f 80 7c 03 00 00    	jo     cfcac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cf930:	f0 49 ff 06          	lock incq (%r14)
   cf934:	0f 8e 53 03 00 00    	jle    cfc8d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf93a:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cf93f:	ff 15 73 f9 09 00    	call   *0x9f973(%rip)        # 16f2b8 <_DYNAMIC+0x338>
   cf945:	be 08 00 00 00       	mov    $0x8,%esi
   cf94a:	48 89 ef             	mov    %rbp,%rdi
   cf94d:	ff 15 6d f9 09 00    	call   *0x9f96d(%rip)        # 16f2c0 <_DYNAMIC+0x340>
   cf953:	48 85 c0             	test   %rax,%rax
   cf956:	0f 84 55 04 00 00    	je     cfdb1 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x791>
   cf95c:	48 85 db             	test   %rbx,%rbx
   cf95f:	74 48                	je     cf9a9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x389>
   cf961:	31 c9                	xor    %ecx,%ecx
   cf963:	48 89 da             	mov    %rbx,%rdx
   cf966:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
   cf96d:	00 
   cf96e:	66 90                	xchg   %ax,%ax
   cf970:	48 39 cd             	cmp    %rcx,%rbp
   cf973:	74 34                	je     cf9a9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x389>
   cf975:	48 8b 3e             	mov    (%rsi),%rdi
   cf978:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   cf97c:	f0 48 ff 07          	lock incq (%rdi)
   cf980:	0f 8e 07 03 00 00    	jle    cfc8d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf986:	f0 49 ff 00          	lock incq (%r8)
   cf98a:	0f 8e fd 02 00 00    	jle    cfc8d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cf990:	48 ff ca             	dec    %rdx
   cf993:	48 83 c6 10          	add    $0x10,%rsi
   cf997:	48 89 3c 08          	mov    %rdi,(%rax,%rcx,1)
   cf99b:	4c 89 44 08 08       	mov    %r8,0x8(%rax,%rcx,1)
   cf9a0:	48 83 c1 10          	add    $0x10,%rcx
   cf9a4:	48 85 d2             	test   %rdx,%rdx
   cf9a7:	75 c7                	jne    cf970 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x350>
   cf9a9:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   cf9ae:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   cf9b3:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
   cf9ba:	00 
   cf9bb:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
   cf9c2:	00 
   cf9c3:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   cf9ca:	00 
   cf9cb:	e8 70 32 04 00       	call   112c40 <<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::clone::Clone>::clone>
   cf9d0:	49 8d 57 08          	lea    0x8(%r15),%rdx
   cf9d4:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   cf9db:	00 
   cf9dc:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cf9e1:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
   cf9e8:	00 
   cf9e9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cf9f0:	00 
   cf9f1:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   cf9f8:	00 
   cf9f9:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   cfa00:	00 
   cfa01:	48 8d 8c 24 18 01 00 	lea    0x118(%rsp),%rcx
   cfa08:	00 
   cfa09:	48 89 41 10          	mov    %rax,0x10(%rcx)
   cfa0d:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   cfa14:	00 
   cfa15:	0f 11 01             	movups %xmm0,(%rcx)
   cfa18:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cfa1f:	00 
   cfa20:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   cfa27:	00 
   cfa28:	e8 03 db ff ff       	call   cd530 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cfa2d:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cfa34:	00 ff 
   cfa36:	0f 84 70 02 00 00    	je     cfcac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfa3c:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cfa43:	00 
   cfa44:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   cfa4b:	00 
   cfa4c:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cfa53:	00 
   cfa54:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cfa5b:	00 
   cfa5c:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cfa63:	00 
   cfa64:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
   cfa6b:	00 
   cfa6c:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
   cfa73:	00 
   cfa74:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   cfa7b:	00 
   cfa7c:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cfa81:	44 89 ee             	mov    %r13d,%esi
   cfa84:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
   cfa8b:	00 
   cfa8c:	e8 ff ef ff ff       	call   cea90 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cfa91:	84 c0                	test   %al,%al
   cfa93:	0f 84 13 02 00 00    	je     cfcac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfa99:	49 83 c7 40          	add    $0x40,%r15
   cfa9d:	4c 3b 7c 24 60       	cmp    0x60(%rsp),%r15
   cfaa2:	0f 85 78 fe ff ff    	jne    cf920 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x300>
   cfaa8:	e9 43 01 00 00       	jmp    cfbf0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x5d0>
   cfaad:	4c 8b 2c 24          	mov    (%rsp),%r13
   cfab1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cfab8:	0f 1f 84 00 00 00 00 
   cfabf:	00 
   cfac0:	41 0f b7 5d 00       	movzwl 0x0(%r13),%ebx
   cfac5:	66 03 5c 24 38       	add    0x38(%rsp),%bx
   cfaca:	0f 80 dc 01 00 00    	jo     cfcac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfad0:	f0 49 ff 06          	lock incq (%r14)
   cfad4:	0f 8e b3 01 00 00    	jle    cfc8d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfada:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cfadf:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
   cfae6:	00 00 
   cfae8:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
   cfaef:	00 00 
   cfaf1:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   cfaf8:	00 00 00 00 00 
   cfafd:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
   cfb04:	00 
   cfb05:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   cfb0c:	00 
   cfb0d:	e8 2e 31 04 00       	call   112c40 <<alloc::vec::Vec<(hyperreal::computable::node::Computable, hyperreal::rational::arithmetic::Rational)> as core::clone::Clone>::clone>
   cfb12:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   cfb19:	00 
   cfb1a:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
   cfb1f:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
   cfb26:	00 
   cfb27:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   cfb2e:	00 
   cfb2f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   cfb36:	00 
   cfb37:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   cfb3e:	00 
   cfb3f:	48 8d 8c 24 18 01 00 	lea    0x118(%rsp),%rcx
   cfb46:	00 
   cfb47:	48 89 41 10          	mov    %rax,0x10(%rcx)
   cfb4b:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   cfb52:	00 
   cfb53:	0f 11 01             	movups %xmm0,(%rcx)
   cfb56:	49 83 c5 08          	add    $0x8,%r13
   cfb5a:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
   cfb61:	00 
   cfb62:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   cfb69:	00 
   cfb6a:	4c 89 ea             	mov    %r13,%rdx
   cfb6d:	e8 be d9 ff ff       	call   cd530 <<hyperreal::computable::node::RadicalCoefficient>::multiply>
   cfb72:	48 83 bc 24 c8 00 00 	cmpq   $0xffffffffffffffff,0xc8(%rsp)
   cfb79:	00 ff 
   cfb7b:	0f 84 2b 01 00 00    	je     cfcac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfb81:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   cfb88:	00 
   cfb89:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   cfb90:	00 
   cfb91:	0f 10 84 24 c8 00 00 	movups 0xc8(%rsp),%xmm0
   cfb98:	00 
   cfb99:	0f 10 8c 24 d8 00 00 	movups 0xd8(%rsp),%xmm1
   cfba0:	00 
   cfba1:	0f 10 94 24 e8 00 00 	movups 0xe8(%rsp),%xmm2
   cfba8:	00 
   cfba9:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
   cfbb0:	00 
   cfbb1:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
   cfbb8:	00 
   cfbb9:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   cfbc0:	00 
   cfbc1:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cfbc6:	89 de                	mov    %ebx,%esi
   cfbc8:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
   cfbcf:	00 
   cfbd0:	e8 bb ee ff ff       	call   cea90 <<hyperreal::computable::node::PiLaurentPolynomial>::insert>
   cfbd5:	84 c0                	test   %al,%al
   cfbd7:	0f 84 cf 00 00 00    	je     cfcac <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x68c>
   cfbdd:	49 83 c5 38          	add    $0x38,%r13
   cfbe1:	4c 3b 6c 24 60       	cmp    0x60(%rsp),%r13
   cfbe6:	0f 85 d4 fe ff ff    	jne    cfac0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x4a0>
   cfbec:	0f 1f 40 00          	nopl   0x0(%rax)
   cfbf0:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cfbf7:	00 
   cfbf8:	e8 63 11 fe ff       	call   b0d60 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cfbfd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   cfc02:	48 89 c8             	mov    %rcx,%rax
   cfc05:	48 3b 8c 24 88 00 00 	cmp    0x88(%rsp),%rcx
   cfc0c:	00 
   cfc0d:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   cfc12:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
   cfc19:	00 
   cfc1a:	0f 85 59 fc ff ff    	jne    cf879 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x259>
   cfc20:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   cfc27:	00 
   cfc28:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   cfc2d:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfc32:	e8 19 dd 03 00       	call   10d950 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfc37:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   cfc3c:	49 89 46 10          	mov    %rax,0x10(%r14)
   cfc40:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
   cfc45:	41 0f 11 06          	movups %xmm0,(%r14)
   cfc49:	49 ff c4             	inc    %r12
   cfc4c:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfc50:	49 83 fc 01          	cmp    $0x1,%r12
   cfc54:	0f 84 ed 00 00 00    	je     cfd47 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x727>
   cfc5a:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cfc5e:	49 ff cc             	dec    %r12
   cfc61:	e8 5a 1d 04 00       	call   1119c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfc66:	48 89 df             	mov    %rbx,%rdi
   cfc69:	eb e5                	jmp    cfc50 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x630>
   cfc6b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfc70:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfc75:	48 8b 04 24          	mov    (%rsp),%rax
   cfc79:	0f b7 4c 24 38       	movzwl 0x38(%rsp),%ecx
   cfc7e:	66 03 08             	add    (%rax),%cx
   cfc81:	70 33                	jo     cfcb6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x696>
   cfc83:	f0 49 ff 06          	lock incq (%r14)
   cfc87:	0f 8f ec 00 00 00    	jg     cfd79 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x759>
   cfc8d:	0f 0b                	ud2
   cfc8f:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cfc94:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cfc99:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cfca0:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfca5:	e8 a6 dc 03 00       	call   10d950 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfcaa:	eb 2d                	jmp    cfcd9 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6b9>
   cfcac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfcb1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfcb6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cfcbb:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cfcc2:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cfcc9:	00 
   cfcca:	e8 91 10 fe ff       	call   b0d60 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cfccf:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfcd4:	e8 77 dc 03 00       	call   10d950 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfcd9:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cfcde:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
   cfce3:	49 ff c6             	inc    %r14
   cfce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cfced:	00 00 00 
   cfcf0:	49 83 fe 01          	cmp    $0x1,%r14
   cfcf4:	74 11                	je     cfd07 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6e7>
   cfcf6:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cfcfa:	49 ff ce             	dec    %r14
   cfcfd:	e8 be 1c 04 00       	call   1119c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfd02:	48 89 df             	mov    %rbx,%rdi
   cfd05:	eb e9                	jmp    cfcf0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x6d0>
   cfd07:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   cfd0c:	48 85 f6             	test   %rsi,%rsi
   cfd0f:	74 14                	je     cfd25 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x705>
   cfd11:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cfd16:	48 c1 e6 06          	shl    $0x6,%rsi
   cfd1a:	ba 08 00 00 00       	mov    $0x8,%edx
   cfd1f:	ff 15 1b f5 09 00    	call   *0x9f51b(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cfd25:	49 ff c4             	inc    %r12
   cfd28:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfd2c:	0f 1f 40 00          	nopl   0x0(%rax)
   cfd30:	49 83 fc 01          	cmp    $0x1,%r12
   cfd34:	74 11                	je     cfd47 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x727>
   cfd36:	48 8d 5f 40          	lea    0x40(%rdi),%rbx
   cfd3a:	49 ff cc             	dec    %r12
   cfd3d:	e8 7e 1c 04 00       	call   1119c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfd42:	48 89 df             	mov    %rbx,%rdi
   cfd45:	eb e9                	jmp    cfd30 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x710>
   cfd47:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   cfd4c:	48 8b 30             	mov    (%rax),%rsi
   cfd4f:	48 85 f6             	test   %rsi,%rsi
   cfd52:	74 13                	je     cfd67 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x747>
   cfd54:	48 c1 e6 06          	shl    $0x6,%rsi
   cfd58:	ba 08 00 00 00       	mov    $0x8,%edx
   cfd5d:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfd61:	ff 15 d9 f4 09 00    	call   *0x9f4d9(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cfd67:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
   cfd6e:	5b                   	pop    %rbx
   cfd6f:	41 5c                	pop    %r12
   cfd71:	41 5d                	pop    %r13
   cfd73:	41 5e                	pop    %r14
   cfd75:	41 5f                	pop    %r15
   cfd77:	5d                   	pop    %rbp
   cfd78:	c3                   	ret
   cfd79:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
   cfd7e:	31 ff                	xor    %edi,%edi
   cfd80:	48 89 ee             	mov    %rbp,%rsi
   cfd83:	ff 15 27 f5 09 00    	call   *0x9f527(%rip)        # 16f2b0 <_DYNAMIC+0x330>
   cfd89:	e9 ff fe ff ff       	jmp    cfc8d <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x66d>
   cfd8e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cfd93:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   cfd98:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   cfd9f:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cfda6:	00 
   cfda7:	e8 b4 0f fe ff       	call   b0d60 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cfdac:	e9 ef fe ff ff       	jmp    cfca0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x680>
   cfdb1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfdb6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfdbb:	bf 08 00 00 00       	mov    $0x8,%edi
   cfdc0:	eb be                	jmp    cfd80 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x760>
   cfdc2:	49 89 c7             	mov    %rax,%r15
   cfdc5:	eb 5c                	jmp    cfe23 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x803>
   cfdc7:	49 89 c7             	mov    %rax,%r15
   cfdca:	e9 56 01 00 00       	jmp    cff25 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x905>
   cfdcf:	49 89 c7             	mov    %rax,%r15
   cfdd2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfdd7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfddc:	e9 44 01 00 00       	jmp    cff25 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x905>
   cfde1:	eb 08                	jmp    cfdeb <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x7cb>
   cfde3:	49 89 c7             	mov    %rax,%r15
   cfde6:	e9 44 01 00 00       	jmp    cff2f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x90f>
   cfdeb:	49 89 c7             	mov    %rax,%r15
   cfdee:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfdf3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfdf8:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   cfdfd:	e8 2e fc fd ff       	call   afa30 <core::ptr::drop_glue::<alloc::vec::Vec<(hyperreal::rational::arithmetic::Rational, hyperreal::rational::arithmetic::Rational)>>>
   cfe02:	e9 00 01 00 00       	jmp    cff07 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8e7>
   cfe07:	eb 00                	jmp    cfe09 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x7e9>
   cfe09:	49 89 c7             	mov    %rax,%r15
   cfe0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   cfe11:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   cfe16:	e9 fd 00 00 00       	jmp    cff18 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8f8>
   cfe1b:	49 89 c7             	mov    %rax,%r15
   cfe1e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   cfe23:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cfe28:	e8 23 db 03 00       	call   10d950 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cfe2d:	e9 fd 00 00 00       	jmp    cff2f <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x90f>
   cfe32:	49 89 c7             	mov    %rax,%r15
   cfe35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   cfe3c:	00 00 00 00 
   cfe40:	49 ff cc             	dec    %r12
   cfe43:	0f 84 8d 00 00 00    	je     cfed6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8b6>
   cfe49:	4c 8d 73 40          	lea    0x40(%rbx),%r14
   cfe4d:	48 89 df             	mov    %rbx,%rdi
   cfe50:	e8 6b 1b 04 00       	call   1119c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfe55:	4c 89 f3             	mov    %r14,%rbx
   cfe58:	eb e6                	jmp    cfe40 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x820>
   cfe5a:	ff 15 c8 f3 09 00    	call   *0x9f3c8(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cfe60:	49 89 c7             	mov    %rax,%r15
   cfe63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   cfe6a:	84 00 00 00 00 00 
   cfe70:	49 ff ce             	dec    %r14
   cfe73:	74 11                	je     cfe86 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x866>
   cfe75:	4c 8d 63 40          	lea    0x40(%rbx),%r12
   cfe79:	48 89 df             	mov    %rbx,%rdi
   cfe7c:	e8 3f 1b 04 00       	call   1119c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfe81:	4c 89 e3             	mov    %r12,%rbx
   cfe84:	eb ea                	jmp    cfe70 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x850>
   cfe86:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   cfe8b:	48 85 f6             	test   %rsi,%rsi
   cfe8e:	0f 84 a5 00 00 00    	je     cff39 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x919>
   cfe94:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   cfe99:	48 c1 e6 06          	shl    $0x6,%rsi
   cfe9d:	ba 08 00 00 00       	mov    $0x8,%edx
   cfea2:	ff 15 98 f3 09 00    	call   *0x9f398(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cfea8:	e9 8c 00 00 00       	jmp    cff39 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x919>
   cfead:	ff 15 75 f3 09 00    	call   *0x9f375(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cfeb3:	49 89 c7             	mov    %rax,%r15
   cfeb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   cfebd:	00 00 00 
   cfec0:	49 ff cc             	dec    %r12
   cfec3:	74 11                	je     cfed6 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8b6>
   cfec5:	4c 8d 73 40          	lea    0x40(%rbx),%r14
   cfec9:	48 89 df             	mov    %rbx,%rdi
   cfecc:	e8 ef 1a 04 00       	call   1119c0 <core::ptr::drop_glue::<(i16, hyperreal::computable::node::RadicalCoefficient)>>
   cfed1:	4c 89 f3             	mov    %r14,%rbx
   cfed4:	eb ea                	jmp    cfec0 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8a0>
   cfed6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   cfedb:	48 8b 30             	mov    (%rax),%rsi
   cfede:	48 85 f6             	test   %rsi,%rsi
   cfee1:	74 60                	je     cff43 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x923>
   cfee3:	48 c1 e6 06          	shl    $0x6,%rsi
   cfee7:	ba 08 00 00 00       	mov    $0x8,%edx
   cfeec:	48 8b 3c 24          	mov    (%rsp),%rdi
   cfef0:	ff 15 4a f3 09 00    	call   *0x9f34a(%rip)        # 16f240 <_DYNAMIC+0x2c0>
   cfef6:	4c 89 ff             	mov    %r15,%rdi
   cfef9:	e8 22 90 09 00       	call   168f20 <_Unwind_Resume@plt>
   cfefe:	ff 15 24 f3 09 00    	call   *0x9f324(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cff04:	49 89 c7             	mov    %rax,%r15
   cff07:	f0 49 ff 0e          	lock decq (%r14)
   cff0b:	75 0b                	jne    cff18 <<hyperreal::computable::node::PiLaurentPolynomial>::multiply+0x8f8>
   cff0d:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   cff12:	ff 15 08 f3 09 00    	call   *0x9f308(%rip)        # 16f220 <_DYNAMIC+0x2a0>
   cff18:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   cff1f:	00 
   cff20:	e8 3b 0e fe ff       	call   b0d60 <core::ptr::drop_glue::<hyperreal::computable::node::RadicalCoefficient>>
   cff25:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   cff2a:	e8 21 da 03 00       	call   10d950 <<alloc::vec::into_iter::IntoIter<(i16, hyperreal::computable::node::RadicalCoefficient)> as core::ops::drop::Drop>::drop>
   cff2f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   cff34:	e8 c7 fb fd ff       	call   afb00 <core::ptr::drop_glue::<alloc::vec::Vec<(i16, hyperreal::computable::node::RadicalCoefficient)>>>
   cff39:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   cff3e:	e8 bd fb fd ff       	call   afb00 <core::ptr::drop_glue::<alloc::vec::Vec<(i16, hyperreal::computable::node::RadicalCoefficient)>>>
   cff43:	4c 89 ff             	mov    %r15,%rdi
   cff46:	e8 d5 8f 09 00       	call   168f20 <_Unwind_Resume@plt>
   cff4b:	ff 15 d7 f2 09 00    	call   *0x9f2d7(%rip)        # 16f228 <_DYNAMIC+0x2a8>
   cff51:	ff 15 d1 f2 09 00    	call   *0x9f2d1(%rip)        # 16f228 <_DYNAMIC+0x2a8>
