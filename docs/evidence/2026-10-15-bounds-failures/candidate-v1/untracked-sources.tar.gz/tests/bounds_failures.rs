//! Bounds preserve absence and uncertainty through the modeling boundary.
use csgrs::{
    Real, TriangleMesh,
    adapter::RawTriangleMesh,
    errors::{ValidationError, ValidationErrorKind},
    solid,
};
use hyperlattice::Point3;
use hypermesh::Triangle;

fn uncertain_points() -> TriangleMesh {
    let sine = Real::e().sin();
    let cosine = Real::e().cos();
    let zero = &sine * &sine + &cosine * &cosine - Real::one();
    TriangleMesh::new(
        vec![
            Point3::new(sine.clone(), 0.into(), sine.clone()),
            Point3::new(&sine + &zero, 1.into(), sine + zero),
        ],
        Vec::new(),
    )
}

#[test]
fn empty_bounds_are_absent_rather_than_a_point_at_the_origin() {
    let mesh = solid::empty();
    assert!(solid::try_bounding_box(&mesh).unwrap().is_none());
    assert!(solid::bounding_box(&mesh).unwrap().is_none());
}

#[test]
fn undecided_bounds_do_not_become_an_origin_box_or_empty_model() {
    let mesh = uncertain_points();
    assert!(solid::bounding_box(&mesh).is_err());
    assert!(solid::center(&mesh).is_err());
    assert!(solid::float(&mesh).is_err());
}

#[test]
fn bounds_reject_malformed_indices() {
    let mesh = TriangleMesh::new(vec![Point3::origin()], vec![Triangle::new(0, 1, 0)]);
    assert!(
        mesh.exact_bounds(&csgrs::GeometryContext::STRICT.mesh_context())
            .is_err()
    );
    assert!(solid::try_bounding_box(&mesh).is_err());
}

#[test]
fn cached_position_bounds_do_not_validate_mutated_indices() {
    let mut mesh = solid::cube(Real::one()).unwrap();
    solid::try_bounding_box(&mesh).unwrap();
    std::sync::Arc::make_mut(&mut mesh.triangles)[0].v0 = mesh.positions.len();
    assert!(solid::try_bounding_box(&mesh).is_err());
}

#[test]
fn undecided_bounds_retain_their_category_through_the_adapter() {
    let mesh = RawTriangleMesh::from_native(uncertain_points());
    let error = mesh.bounding_box().unwrap_err();
    let csgrs::adapter::AdapterError::Construction(error) = error else {
        panic!("native failure was flattened")
    };
    assert_eq!(error.kind(), ValidationErrorKind::Undecided);
}

#[cfg(feature = "curve")]
#[test]
fn empty_curve_bounds_are_absent() {
    let curve = hypercurve::CurveRegion2::empty();
    assert!(csgrs::curve::try_bounding_box(&curve).unwrap().is_none());
    assert!(csgrs::curve::bounding_box(&curve).unwrap().is_none());
}

#[cfg(feature = "sdf")]
#[test]
fn tpms_consumers_preserve_bounds_and_capacity_failures() {
    assert!(solid::gyroid(&uncertain_points(), 4, 1.into(), 0.into()).is_err());
    let mesh = solid::cube(Real::one()).unwrap();
    assert!(solid::gyroid(&mesh, usize::MAX, 1.into(), 0.into()).is_err());
}

#[cfg(feature = "sdf")]
#[test]
fn tpms_invalid_parameters_are_not_successful_empty_models() {
    for mesh in [solid::empty(), solid::cube(Real::one()).unwrap()] {
        assert!(solid::gyroid(&mesh, 4, 0.into(), 0.into()).is_err());
        assert!(solid::schwarz_p_solid(&mesh, 4, 1.into(), 0.into(), (-1).into()).is_err());
        assert!(solid::schwarz_d(&mesh, 1, 1.into(), 0.into()).is_err());
    }
}
