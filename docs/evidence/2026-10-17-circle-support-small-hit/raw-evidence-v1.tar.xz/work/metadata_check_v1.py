"""Type-check the real prepared source under a bounded metadata-only contract."""
import gzip
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import time
from pathlib import Path

W = Path(__file__).resolve().parent
ROOT = W.parents[2]
R = Path('/run/user/1000/csgrs-circle-support-small-hit-metadata-v1')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def available():
    fs = os.statvfs(R)
    memory = next(line for line in Path('/proc/meminfo').read_text().splitlines()
                  if line.startswith('MemAvailable:'))
    return {'runtime_free_bytes': fs.f_bavail * fs.f_frsize,
            'host_available_memory_bytes': int(memory.split()[1]) * 1024}


def violation(value):
    for key, minimum in [('runtime_free_bytes', 256 * 1024**2),
                         ('host_available_memory_bytes', 2 * 1024**3)]:
        if value[key] < minimum:
            return key + '-reserve'
    return None


def run(name, command, cwd):
    initial = available()
    assert violation(initial) is None
    scratch = R / (name + '-scratch')
    scratch.mkdir()
    env = os.environ.copy()
    for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER']:
        env.pop(key, None)
    env.update({'TMPDIR': str(scratch), 'PYTHONDONTWRITEBYTECODE': '1'})

    def limits():
        resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    start = time.monotonic()
    observed, reason = [{'elapsed_seconds': 0, **initial}], None
    print('START ' + name, flush=True)
    with (R / (name + '.stdout')).open('wb') as out, (R / (name + '.stderr')).open('wb') as err:
        process = subprocess.Popen(['/usr/bin/time', '-v', '-o', str(R / (name + '.resources')), *command],
            cwd=cwd, env=env, stdout=out, stderr=err, preexec_fn=limits, start_new_session=True)
        dump(R / (name + '.process.json'), {'pid': process.pid, 'started_unix': time.time()})
        while process.poll() is None:
            try:
                process.wait(timeout=5)
                continue
            except subprocess.TimeoutExpired:
                pass
            elapsed = time.monotonic() - start
            state = available()
            observed.append({'elapsed_seconds': elapsed, **state})
            reason = violation(state)
            if elapsed > 1800:
                reason = 'external-timeout'
            if reason:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                break
        code = process.wait()
    row = {'name': name, 'command': command, 'exit_code': code,
        'elapsed_seconds': time.monotonic() - start, 'external_stop_reason': reason,
        'resource_observations': observed,
        **{suffix + '_sha256': sha(R / (name + '.' + suffix)) for suffix in ['stdout', 'stderr', 'resources']}}
    dump(R / (name + '.result.json'), row)
    print(json.dumps({key: row[key] for key in ['name', 'exit_code', 'elapsed_seconds', 'external_stop_reason']}), flush=True)
    return row


assert not R.exists()
assert shutil.disk_usage(ROOT).free >= 512 * 1024**2
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '324e30bd212a544a7b115944d060cd8c19a13d82'
subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--cached', '--quiet'], cwd=ROOT, check=True)
prepared = read(W / 'preparation-v2.json')
assert not prepared['compiled'] and prepared['format_exit_code'] == 0
assert sha(prepared['candidate_source']) == prepared['candidate_sha256']
old = Path('/run/user/1000/csgrs-circle-support-lazy-index-v1/build-v1')
prior, previous = read(old / 'protocol.json'), read(old / 'result.json')
assert previous['complete'] and previous['output_closed'] and not previous['command_failures']
assert subprocess.check_output(['rustc', '-vV'], text=True) == prior['rustc']
assert all(sha(path) == digest for path, digest in prior['read_only_dependencies_sha256'].items())
source = prior['sources']['candidate']
copied_bytes = sum((Path(source['path']) / path).stat().st_size for path in source['sha256'])
assert copied_bytes <= 32 * 1024**2
assert shutil.disk_usage(R.parent).free - copied_bytes >= 256 * 1024**2
with gzip.open(old / 'main-input-hashes.json.gz', 'rt') as stream:
    prior_main = json.load(stream)
main = {path: sha(ROOT / path) for path in prior_main}
assert {path for path in main if main[path] != prior_main[path]} == {'docs/properties-status.json'}
R.mkdir(mode=0o700)
snapshot = R / 'candidate-source'
snapshot.mkdir()
for path, digest in source['sha256'].items():
    original = Path(source['path']) / path
    assert sha(original) == digest
    dest = snapshot / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, dest)
relative = 'crates/hypercurve/src/curve_intersection.rs'
(snapshot / relative).write_bytes(Path(prepared['candidate_source']).read_bytes())
source_pins = {str(path.relative_to(snapshot)): sha(path) for path in snapshot.rglob('*') if path.is_file()}
changed = sorted(path for path in source_pins if source_pins[path] != source['sha256'][path])
assert changed == [relative]
inputs = {str(path): sha(path) for path in [Path(__file__), W / 'contract-v1.md',
    W / 'metadata-contract-v1.md', W / 'preparation-v2.json', Path(prepared['candidate_source']),
    old / 'protocol.json', old / 'result.json']}
with gzip.open(R / 'main-input-hashes.json.gz', 'wt') as stream:
    json.dump(main, stream, sort_keys=True)
dump(R / 'protocol.json', {'base_commit': prepared['main_parent_commit'], 'input_sha256': inputs,
    'source': {'path': str(snapshot), 'sha256': source_pins},
    'read_only_dependencies_sha256': prior['read_only_dependencies_sha256'],
    'externs': prior['externs'], 'rustc': prior['rustc'], 'features': prior['features'],
    'source_copy_bytes': copied_bytes, 'source_copy_limit_bytes': 32 * 1024**2,
    'metadata_only': True, 'executable_built': False, 'tests_executed': False,
    'new_resource_contract': str(W / 'metadata-contract-v1.md'),
    'full_build_storage_still_pending': True})
command = ['rustc', '--crate-name', 'hypercurve', '--edition=2024', '--test',
    'crates/hypercurve/src/lib.rs', '--emit=metadata', '-C', 'opt-level=3',
    '-C', 'codegen-units=16', '-C', 'embed-bitcode=no', '-D', 'warnings',
    '-L', 'dependency=' + str(Path(prior['externs']['hyperreal']).parent),
    '-o', str(R / 'candidate.rmeta')]
for name, path in prior['externs'].items():
    command += ['--extern', name + '=' + path]
commands = [run('typecheck', command, snapshot)]
dump(R / 'commands.json', commands)
if commands[-1]['exit_code'] == 0:
    lint = command.copy()
    lint[0] = 'clippy-driver'
    lint[lint.index('-o') + 1] = str(R / 'clippy.rmeta')
    commands.append(run('clippy', lint, snapshot))
    dump(R / 'commands.json', commands)
assert all(sha(path) == digest for path, digest in (inputs | prior['read_only_dependencies_sha256']).items())
assert all(sha(snapshot / path) == digest for path, digest in source_pins.items())
assert all(sha(Path(source['path']) / path) == digest for path, digest in source['sha256'].items())
assert all(sha(ROOT / path) == digest for path, digest in main.items())
failures = [row['name'] for row in commands if row['exit_code'] != 0]
dump(R / 'result.json', {'complete': True, 'output_closed': True, 'command_failures': failures,
    'compiler_and_lint_passed': len(commands) == 2 and not failures,
    'metadata_only': True, 'executable_built': False, 'semantic_tests_executed': 0,
    'performance_evidence_collected': False, 'sources_and_dependencies_unchanged': True,
    'main_sources_unchanged': True, 'source_changes_applied': False,
    'cache_admitted': False, 'full_plan_complete': False})
raise SystemExit(0 if len(commands) == 2 and not failures else 101)
