"""Build one new diagnostic executable and reuse the verified E44 baseline."""
import gzip
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, resources, run, sha, violation

base = '324e30bd212a544a7b115944d060cd8c19a13d82'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == base
subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--cached', '--quiet'], cwd=ROOT, check=True)
old = Path('/run/user/1000/csgrs-circle-support-lazy-index-v1/build-v1')
metadata = Path('/run/user/1000/csgrs-circle-support-small-hit-metadata-v1')
prior, previous = read(old / 'protocol.json'), read(old / 'result.json')
qualified, prepared = read(metadata / 'result.json'), read(metadata / 'protocol.json')
assert previous['complete'] and previous['output_closed'] and not previous['command_failures']
assert qualified['complete'] and qualified['output_closed'] and qualified['compiler_and_lint_passed']
assert subprocess.check_output(['rustc', '-vV'], text=True) == prior['rustc']
assert all(sha(path) == digest for path, digest in prior['read_only_dependencies_sha256'].items())
for source in prior['sources'].values():
    assert all(sha(Path(source['path']) / path) == digest for path, digest in source['sha256'].items())
with gzip.open(metadata / 'main-input-hashes.json.gz', 'rt') as stream:
    main = json.load(stream)
assert all(sha(ROOT / path) == digest for path, digest in main.items())
RUNTIME.mkdir(mode=0o700, exist_ok=False)
assert violation(resources()) is None
repro = RUNTIME / 'reproduction-v1'
repro.mkdir()
dump(repro / 'protocol.json', {'base_commit': base,
    'input_sha256': {str(path): sha(path) for path in [Path(__file__), W / 'runner_v1.py',
        W / 'executable-contract-v1.md', old / 'protocol.json', old / 'result.json']},
    'binaries': previous['binaries'], 'source_equivalent_current_main': True,
    'scope': 'Fresh observations before compiling the direct-hit candidate; the E44 grouped comparison remains retained.'})
rows = []
for label, binary in previous['binaries'].items():
    assert sha(binary['path']) == binary['sha256']
    row = run(repro, label, [binary['path'],
        'curve_intersection::circle_support_coefficient_probe::shared_coefficient_lookup_cost',
        '--exact', '--ignored', '--nocapture', '--test-threads=1'], repro,
        {'CIRCLE_SHARED_BITS': '64', 'CIRCLE_SHARED_REPEATS': '20000'})
    rows.append(row)
    assert row['exit_code'] == 0
    assert 'CIRCLE_SHARED_CERTAINTY Certified' in (repro / (label + '.stdout')).read_text()
dump(repro / 'commands.json', rows)
dump(repro / 'result.json', {'complete': True, 'output_closed': True, 'command_failures': []})

output = RUNTIME / 'build-v1'
output.mkdir()
source = output / 'candidate-source'
source.mkdir()
for path, digest in prepared['source']['sha256'].items():
    original = Path(prepared['source']['path']) / path
    assert sha(original) == digest
    dest = source / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, dest)
relative = 'crates/hypercurve/src/curve_intersection.rs'
path = source / relative
canonical = path.read_text()
text = canonical
for module in ['circle_support_cost_probe', 'circle_support_coefficient_probe', 'circle_support_small_batch_probe']:
    hook = f'\n#[cfg(test)]\n#[path = "{module}.rs"]\nmod {module};\n'
    assert hook not in text
    text += hook
path.write_text(text)
commands = [run(output, 'format', ['rustfmt', '--check', '--edition', '2024',
    '--config-path', str(ROOT / 'crates/.rustfmt.toml'), '--config', 'skip_children=true', str(path)], source)]
assert commands[-1]['exit_code'] == 0
source_pins = {str(path.relative_to(source)): sha(path) for path in source.rglob('*') if path.is_file()}
sources = {'baseline': prior['sources']['baseline'], 'candidate': {'path': str(source), 'sha256': source_pins}}
for relative in ['crates/hypercurve/src/circle_support_cache_tests.rs',
                 'crates/hypercurve/src/circle_support_small_batch_probe.rs',
                 'crates/hypercurve/src/circle_support_cost_probe.rs',
                 'crates/hypercurve/src/circle_support_coefficient_probe.rs']:
    assert sha(source / relative) == sha(Path(sources['baseline']['path']) / relative)
inputs = {str(path): sha(path) for path in [Path(__file__), W / 'runner_v1.py', W / 'contract-v1.md',
    W / 'metadata-contract-v1.md', W / 'executable-contract-v1.md', metadata / 'protocol.json',
    metadata / 'result.json', old / 'protocol.json', old / 'result.json', ROOT / 'crates/.rustfmt.toml',
    repro / 'result.json', Path(shutil.which('quota'))]}
shutil.copy2(metadata / 'main-input-hashes.json.gz', output / 'main-input-hashes.json.gz')
dump(output / 'protocol.json', {'base_commit': base, 'input_sha256': inputs, 'sources': sources,
    'read_only_dependencies_sha256': prior['read_only_dependencies_sha256'], 'externs': prior['externs'],
    'rustc': prior['rustc'], 'hardware': prior['hardware'], 'features': prior['features'],
    'baseline_reused_read_only': True, 'same_tests_and_diagnostics': True,
    'full_build_storage_still_pending': True, 'completed_cargo_targets_reopened': False,
    'resource_contract': str(W / 'executable-contract-v1.md'), 'initial_resources': resources()})
binary = output / 'candidate-tests'
command = ['rustc', '--crate-name', 'hypercurve', '--edition=2024', '--test',
    'crates/hypercurve/src/lib.rs', '-C', 'opt-level=3', '-C', 'codegen-units=16',
    '-C', 'embed-bitcode=no', '-D', 'warnings',
    '-L', 'dependency=' + str(Path(prior['externs']['hyperreal']).parent), '-o', str(binary)]
for name, path in prior['externs'].items():
    command += ['--extern', name + '=' + path]
commands.append(run(output, 'candidate', command, source))
dump(output / 'commands.json', commands)
binaries = {'baseline': previous['binaries']['baseline']}
if commands[-1]['exit_code'] == 0:
    binaries['candidate'] = {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size}
    for label, executable in binaries.items():
        commands.append(run(output, label + '-contracts', [executable['path'],
            'curve_intersection::circle_support_cache_tests::', '--nocapture', '--test-threads=1'], source))
    lint = command.copy()
    lint[0] = 'clippy-driver'
    lint[lint.index('-o') + 1] = str(output / 'candidate.rmeta')
    lint.append('--emit=metadata')
    commands.append(run(output, 'candidate-clippy', lint, source))
    dump(output / 'commands.json', commands)
assert all(sha(path) == digest for path, digest in (inputs | prior['read_only_dependencies_sha256']).items())
assert all(sha(Path(value['path']) / path) == digest for value in sources.values() for path, digest in value['sha256'].items())
assert all(sha(ROOT / path) == digest for path, digest in main.items())
failures = [row['name'] for row in commands if row['exit_code'] != 0]
dump(output / 'result.json', {'complete': True, 'output_closed': True, 'binaries': binaries,
    'command_failures': failures, 'main_sources_unchanged': True,
    'frozen_sources_and_dependencies_unchanged': True, 'baseline_reused_read_only': True,
    'cache_admitted': False, 'full_plan_complete': False})
raise SystemExit(0 if len(binaries) == 2 and not failures else 101)
