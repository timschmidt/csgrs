"""Record the failed cost gate without qualifying unexecuted checks."""
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, sha

metadata = Path('/run/user/1000/csgrs-circle-support-small-hit-metadata-v1')
small = read(RUNTIME / 'cost-matched-v1/result.json')
summary = read(RUNTIME / 'cost-matched-v1/summary.json')
assert small['process_samples'] == 140 and small['phase_observations'] == 280
assert not small['command_failures'] and small['all_completed_observations_certified']
assert len(small['decisive_rejection_cases']) == 1
failure = small['decisive_rejection_cases'][0]
assert failure['count'] == 33 and failure['phase'] == 'cold'
assert failure['candidate_over_baseline'] > 1.10
assert failure['positive_paired_differences'] == 7 and failure['candidate_min_exceeds_baseline_max']
assert not (RUNTIME / 'support-cost-preflight-v1').exists()
for label in ['baseline', 'candidate']:
    text = (RUNTIME / 'build-v1' / (label + '-contracts.stdout')).read_text()
    assert 'test result: ok. 9 passed; 0 failed;' in text
assert read(metadata / 'result.json')['compiler_and_lint_passed']
proposal = read(RUNTIME / 'proposal-v1/result.json')
assert proposal['proposal_sha256']['crates/hypercurve/src/curve_intersection.rs'] == read(W / 'preparation-v2.json')['candidate_sha256']
assert not (W / 'progress-v1.md').exists()
rows = []
for n in [1, 4, 8, 9, 16, 31, 32, 33, 64, 128]:
    cold = next(v for v in summary if v['count'] == n and v['phase'] == 'cold')
    warm = next(v for v in summary if v['count'] == n and v['phase'] == 'warm')
    rows.append('| ' + str(n) + ' | ' + ' | '.join(format(v, '.9f') for v in [
        cold['baseline_median_seconds'], cold['candidate_median_seconds'],
        warm['baseline_median_seconds'], warm['candidate_median_seconds']]) + ' |')
(W / 'progress-v1.md').write_text('''# Direct small-cache-hit return: rejected at index activation

**Reject this proposal as written.** The new small-hit early return passes its
focused semantic checks but fails the predeclared repeated cold-batch cost gate.
The main implementation is unchanged. The earlier 35-file native integration
remains rejected; its independently admitted fixes remain intact. E44 remains
an unadmitted historical proposal with its own measurements, not a retained
fallback. Neither evaluation establishes general exact KiCad stroke fidelity.

The owner is Hypercurve's operation-local circular-support relation cache,
under P4, P10, P19, P20 and P36. The candidate preserves E44's exact keys,
ordered matching priority, original retained witnesses, symbolic and very-large
coefficient fallback, single-policy batch lifetime and 32-entry activation
threshold. It moves small retained hits before index bookkeeping, with one scan
on a small miss. The candidate was isolated throughout; review the complete
proposal patches and the incremental patch against E44 in the evidence archive.

A read-only replay of the E44 baseline and candidate completed on the current
production revision before executable qualification. Those two short shared-hit
observations are diagnostic reproduction, not a new matched performance claim.
The new candidate passed metadata type checking and strict direct Clippy, then
compiled successfully with the same optimized flags, toolchain, dependencies,
features, tests and diagnostic modules as the hash-verified E44 baseline.
The baseline executable was reused read-only with its source and build proof.
Both binaries passed all nine focused cache contracts. The candidate diagnostic
test harness also passed strict direct Clippy. These are not Cargo-matrix or
full-library passes for this revision.

All 20 preflight processes and all **140 matched processes / 280 timed phases**
completed. Every phase contains at least 65,536 queries; cold uses a fresh
batch cache including its creation and destruction, while warm uses one prepared
cache. Each query validates independently derived 3-4-5 intersections and both
circle equations, with complete ordered rows and a strict Certified receipt.
Input construction, reference preparation, printing and process startup stay
outside the phase timers and inside process observations. Cold here means the
batch cache, not a reset of every scalar or process cache. The ten original
sizes and all seven paired repetitions are preserved, with deterministic case
shuffling and alternating variant order.

Median seconds per complete repeated phase:

| Pairs per batch | Baseline cold | Candidate cold | Baseline warm | Candidate warm |
| ---: | ---: | ---: | ---: | ---: |
''' + '\n'.join(rows) + '''

At 33 pairs the cold median rises from 0.215810937 s to 0.238608847 s:
**10.5638344% slower**. All seven paired differences are positive, and the
candidate minimum (0.234221130 s) exceeds the baseline maximum (0.219813662 s).
This satisfies every part of the predeclared rejection criterion. Favorable
large-batch results and all small differences remain in the raw evidence;
none cancels the stable supported-workload regression. The source initializes
the index from retained relations on the first eligible lookup at length 32.
That is an implementation observation, not a measured allocation attribution.

The subsequent support-matrix preflight invocation was refused by its existing
assertion because the small-batch result contains a decisive rejection. The
script exited 1 before creating an output directory or launching a benchmark.
Its tool-reported assertion is recorded in the decision; no raw redirected
process log exists for that invocation. Do not count this as a completed support
case or silently bypass the guard. The prepared support, allocation, full-library,
all-feature and grouped-comparison helpers remain unexecuted, except for that
refused support preflight. No new allocation or package-size claim is made.
The required downstream, native/report, binding and release gates remain open;
continuing them cannot retain this already rejected revision.

Preparation first selected the repository-root rustfmt style because the draft
lived under target/. That check failed and its outputs remain preserved. The
byte-identical candidate passed with the owning crate's explicit rustfmt config;
no source edit or validation weakening was used to obtain that pass.

Storage was part of the declared execution contract. Metadata checks used a
fresh runtime directory; executable checks used a fresh /dev/shm directory with
an explicit user-quota guard. Each compiler/test command retained a 1,800-second
wall and 8 GiB address-space limit, at least 2 GiB host available memory and
256 MiB runtime/quota reserve, with a separately declared 512 MiB repository
reserve for small controls/evidence. These are new experiment contracts, not
retroactive changes to prior native CPU/wall gates. No closed Cargo target was
reopened. The requested directory on Disk A is still absent: OS ownership and
password-required sudo blocked creation. There was no automatic-review denial.
A writable larger volume remains needed for fresh full downstream validation.

Only current_work changes in the execution ledger. Every new physical file
path is independently hashed, including metadata and executable roots; the
compressed Git archive is verified byte-for-byte against its originals.
The inherited 27,093 missing paths remain disclosed. This is not a successful
whole-history preservation audit or completion of the properties plan.

A successor must address index activation cost with the original sizes, exact
witnesses and full-scale workloads intact. Deferring construction until its
cost can be amortized is an untested hypothesis, not an admitted optimization.
''')
inputs = [Path(__file__), W / 'progress-v1.md', W / 'preparation-v2.json',
          W / 'contract-v1.md', W / 'metadata-contract-v1.md',
          W / 'executable-contract-v1.md', W / 'library-contract-v1.md',
          W / 'shared-aggregate-contract-v1.md']
for root, names in [(RUNTIME, ['reproduction-v1', 'build-v1', 'cost-preflight-v1', 'cost-matched-v1', 'proposal-v1']),
                    (metadata, [''])]:
    for name in names:
        for item in ['protocol.json', 'commands.json', 'result.json']:
            p = root / name / item
            if p.exists(): inputs.append(p)
inputs += [RUNTIME / 'cost-matched-v1/summary.json', W / 'format.stdout', W / 'format.stderr',
           W / 'format-v2.stdout', W / 'format-v2.stderr']
folder = Path('/mnt/Disk A/csgrs-properties-validation-2026-10-17')
dump(W / 'decision-v1.json', {
    'complete': True, 'main_parent_commit': '324e30bd212a544a7b115944d060cd8c19a13d82',
    'status': 'rejected: direct small-hit return retains a decisive cold index-activation regression at 33 pairs',
    'retention_decision': 'rejected', 'cache_index_admitted': False, 'source_changes_applied': False,
    'implementation_sha256': {}, 'proposal_sha256': proposal['proposal_sha256'],
    'input_sha256': {str(p): sha(p) for p in inputs},
    'metadata_typecheck_and_strict_clippy_passed': True,
    'candidate_executable_build_passed': True, 'baseline_executable_reused_read_only': True,
    'focused_contract_tests_per_variant': 9, 'candidate_diagnostic_strict_clippy_passed': True,
    'preflight_processes': 20, 'matched_processes': 140, 'matched_phases': 280,
    'all_measured_results_certified_and_exact_rows_preserved': True,
    'decisive_rejection_cases': small['decisive_rejection_cases'],
    'support_preflight_refused': {
        'command': ['python3', 'target/properties/circle-support-small-hit/support_measure_v1.py', 'preflight'],
        'exit_code': 1, 'error': 'AssertionError', 'line': 23,
        'reason': 'Existing precondition requires no decisive small-batch rejection.',
        'output_directory_created': False, 'benchmark_processes_launched': 0,
        'raw_redirected_log_available': False, 'observation_source': 'exec_command tool result'},
    'prepared_but_unexecuted_after_rejection': ['support matrix', 'heap observations', 'full no-feature library',
        'all-feature library', 'grouped shared-support comparison'],
    'storage_request': {'path': str(folder), 'exists': folder.exists(), 'writable': os.access(folder, os.W_OK),
        'creation_blocker': 'Administrator-owned parent; sudo requires a password; no automatic-review denial.'},
    'native_disposition_preserved': True, 'pending_native_paths_remaining': 0,
    'full_archived_integration_admitted': False, 'native_runtime_admitted': False,
    'full_plan_complete': False,
    'next': ['Keep the failed cold activation case and original matrix; investigate amortized index construction in a fresh isolated experiment.',
             'Preserve typed failures, empty composition, ordinary strict completion and full original native workload gates.',
             'Use a writable larger volume for fresh affected downstream, native/report, binding and distribution checks.']})
print(json.dumps({'retention_decision': 'rejected', 'ratio': failure['candidate_over_baseline'],
                  'matched_processes': 140, 'focused_tests_per_variant': 9}))
