use super::*;

const RADICALS: [(i64, i64); 8] = [
    (2, -3),
    (3, 5),
    (5, 7),
    (7, -11),
    (11, 13),
    (13, -17),
    (17, 19),
    (19, -23),
];
const ATOMS: [i64; 4] = [-5, 11, 17, -19];

fn raw(approximation: Approximation) -> Computable {
    Computable {
        internal: Arc::new(Node::new(
            approximation,
            BoundCache::Invalid,
            ExactSignCache::Unknown,
        )),
        signal: None,
    }
}

fn atom(index: usize) -> Computable {
    raw(Approximation::AtanRational(
        Rational::fraction(index as i64 + 1, 37).unwrap(),
    ))
}

fn coefficient(shape: usize) -> RadicalCoefficient {
    RadicalCoefficient {
        rational: Rational::new(21),
        radicals: if shape & 1 != 0 {
            RADICALS
                .into_iter()
                .map(|(d, b)| (Rational::new(d), Rational::new(b)))
                .collect()
        } else {
            Vec::new()
        },
        atoms: if shape & 2 != 0 {
            ATOMS
                .into_iter()
                .enumerate()
                .map(|(index, b)| (atom(index), Rational::new(b)))
                .collect()
        } else {
            Vec::new()
        },
    }
}

#[test]
fn rational_scaling_preserves_exact_components_in_both_directions() {
    for shape in 0..4 {
        for (numerator, denominator) in [(0, 1), (1, 1), (-1, 1), (3, 7), (-17, 13)] {
            for reverse in [false, true] {
                let value = coefficient(shape);
                let scale = RadicalCoefficient::rational(
                    Rational::fraction(numerator, denominator).unwrap(),
                );
                let result = if reverse {
                    scale.multiply(&value)
                } else {
                    value.multiply(&scale)
                }
                .unwrap();
                assert_eq!(
                    result.rational,
                    Rational::fraction(21 * numerator, denominator).unwrap()
                );
                let expected_radicals = if numerator != 0 && shape & 1 != 0 {
                    RADICALS
                        .into_iter()
                        .map(|(d, b)| {
                            (
                                Rational::new(d),
                                Rational::fraction(b * numerator, denominator).unwrap(),
                            )
                        })
                        .collect()
                } else {
                    Vec::new()
                };
                assert_eq!(result.radicals, expected_radicals);
                if numerator == 0 || shape & 2 == 0 {
                    assert!(result.atoms.is_empty());
                } else {
                    assert_eq!(result.atoms.len(), ATOMS.len());
                    for (index, (actual_atom, actual_coefficient)) in
                        result.atoms.iter().enumerate()
                    {
                        assert!(Computable::internal_structural_eq(
                            actual_atom,
                            &atom(index)
                        ));
                        assert_eq!(
                            *actual_coefficient,
                            Rational::fraction(ATOMS[index] * numerator, denominator).unwrap()
                        );
                    }
                }
            }
        }
    }
}

#[test]
fn unsupported_symbolic_cross_products_keep_their_declines() {
    for left in 1..4 {
        for right in 1..4 {
            if left == 1 && right == 1 {
                continue;
            }
            assert!(coefficient(left).multiply(&coefficient(right)).is_none());
        }
    }
}

#[test]
fn opaque_owners_are_released_after_both_scaling_directions() {
    for reverse in [false, true] {
        let value = coefficient(3);
        let weak = value
            .atoms
            .iter()
            .map(|(atom, _)| Arc::downgrade(&atom.internal))
            .collect::<Vec<_>>();
        let scale = RadicalCoefficient::rational(Rational::fraction(-3, 7).unwrap());
        let result = if reverse {
            let result = scale.multiply(&value).unwrap();
            drop(value);
            result
        } else {
            value.multiply(&scale).unwrap()
        };
        assert!(weak.iter().all(|owner| owner.strong_count() == 1));
        drop(result);
        assert!(weak.iter().all(|owner| owner.upgrade().is_none()));
    }
}

#[test]
fn scaled_opaque_cancellation_keeps_cold_warm_and_cloned_quadratic_facts() {
    for reverse in [false, true] {
        let scale = Rational::fraction(-3, 7).unwrap();
        let multiply = |value: Computable| {
            let scalar = Computable::rational(scale.clone());
            if reverse {
                raw(Approximation::Multiply(scalar, value))
            } else {
                raw(Approximation::Multiply(value, scalar))
            }
        };
        let opaque = atom(0);
        let radical = Computable::sqrt_rational(Rational::new(13));
        let sum = raw(Approximation::Add(
            raw(Approximation::Add(Computable::pi(), radical)),
            opaque.clone(),
        ));
        let value = raw(Approximation::Add(
            raw(Approximation::Add(
                multiply(sum.clone()),
                raw(Approximation::Negate(multiply(Computable::pi()))),
            )),
            raw(Approximation::Negate(multiply(opaque))),
        ));
        let expected = Some((Rational::zero(), scale.clone(), Some(Rational::new(13))));
        assert_eq!(value.exact_quadratic_surd_parts(), expected);
        assert!(sum.exact_quadratic_surd_parts().is_none());
        let cloned = value.clone();
        for query in [&value, &cloned, &value] {
            assert_eq!(query.exact_quadratic_surd_parts(), expected);
            assert!(query.cached().is_none());
        }
    }
}
