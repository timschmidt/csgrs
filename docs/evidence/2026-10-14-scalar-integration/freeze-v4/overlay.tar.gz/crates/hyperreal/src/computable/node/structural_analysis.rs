#[derive(Clone, Copy)]
struct Binary64Interval {
    lower: f64,
    upper: f64,
}

#[derive(Clone)]
struct AlgebraicGenerator {
    root: Computable,
    degree: u32,
}

/// A bounded zero-separation certificate for `alpha = beta / gamma`.
///
/// `beta` and nonzero `gamma` are algebraic integers, and the two logarithms
/// bound the magnitudes of every conjugate of each. If `D` is the product
/// of the retained generator degrees and `alpha != 0`, the algebraic norm is a
/// nonzero integer, so
///
/// `|alpha| >= 2^-(denominator_log2 + (D - 1) * conjugate_log2)`.
///
/// Generator degrees deliberately overestimate the actual field degree. That
/// only weakens the bound; exact rational-root dependency checks may remove a
/// generator when membership in the existing field is proved.
#[derive(Clone)]
struct AlgebraicSeparation {
    // Keeping an algebraic-integer denominator avoids taking its integer norm
    // at each inverse. Both logarithms bound all conjugate magnitudes; gamma
    // need not be positive, but must be nonzero in the selected embedding.
    denominator_log2: u64,
    conjugate_log2: u64,
    generators: Vec<AlgebraicGenerator>,
}

impl AlgebraicSeparation {
    const MAX_GENERATORS: usize = 16;
    const MAX_FIELD_DEGREE: u64 = 1 << 20;
    const MAX_LOG2: u64 = 1 << 17;
    const MAX_DEPENDENCY_COMBINATIONS: u64 = 4_096;
    const MAX_DEPENDENCY_BITS: u64 = 4_096;

    fn ceil_log2(value: &BigUint) -> u64 {
        if value <= &BigUint::one() {
            0
        } else if value.trailing_zeros() == Some(value.bits() - 1) {
            value.bits() - 1
        } else {
            value.bits()
        }
    }

    #[cfg(test)]
    fn rational(value: &Rational) -> Option<Self> {
        Self::rational_with_work(value, crate::computable::budget::is_active())
    }

    fn rational_with_work(value: &Rational, metered: bool) -> Option<Self> {
        // At MAX_LOG2 + 1 bits, only an exact power of two remains admissible.
        let value = SymbolicWork { metered }.bounded_rational(value, Self::MAX_LOG2 + 1)??;
        let result = Self {
            denominator_log2: Self::ceil_log2(value.denominator()),
            conjugate_log2: Self::ceil_log2(value.numerator()),
            generators: Vec::new(),
        };
        result.within_limits().then_some(result)
    }

    fn integer(value: &BigInt, metered: bool) -> Option<Self> {
        if value.magnitude().bits() > Self::MAX_LOG2 + 1 {
            return None;
        }
        SymbolicWork { metered }.integer(value)?;
        let result = Self {
            denominator_log2: 0,
            conjugate_log2: Self::ceil_log2(value.magnitude()),
            generators: Vec::new(),
        };
        result.within_limits().then_some(result)
    }

    fn within_limits(&self) -> bool {
        self.denominator_log2 <= Self::MAX_LOG2
            && self.conjugate_log2 <= Self::MAX_LOG2
            && self.generators.len() <= Self::MAX_GENERATORS
            && self.field_degree().is_some()
    }

    fn field_degree(&self) -> Option<u64> {
        self.generators.iter().try_fold(1_u64, |degree, generator| {
            degree
                .checked_mul(u64::from(generator.degree))
                .filter(|degree| *degree <= Self::MAX_FIELD_DEGREE)
        })
    }

    fn dependency_radicand(
        root: &Computable,
        degree: u32,
        metered: bool,
    ) -> Option<Option<Rational>> {
        let child = match &root.internal.approximation {
            Approximation::Sqrt(child) if degree == 2 => child,
            Approximation::NthRoot(child, actual_degree) if *actual_degree == degree => child,
            Approximation::Constant(SharedConstant::Sqrt2) if degree == 2 => {
                return Some(Some(Rational::new(2)));
            }
            Approximation::Constant(SharedConstant::Sqrt3) if degree == 2 => {
                return Some(Some(Rational::new(3)));
            }
            _ => return Some(None),
        };
        // Inspect borrowed metadata before converting an integer or retaining
        // a rational. A declined local search differs from shared exhaustion.
        let supported = match &child.internal.approximation {
            Approximation::One => true,
            Approximation::Int(value) => {
                value.sign() == Sign::Plus && value.magnitude().bits() <= Self::MAX_DEPENDENCY_BITS
            }
            Approximation::Ratio(value) => {
                if value.sign() != Sign::Plus {
                    return Some(None);
                }
                // The preflight paid for canonicalization or the supported
                // read. Keep that canonical view for subsequent arithmetic.
                return Some(
                    SymbolicWork { metered }
                        .bounded_rational(value, Self::MAX_DEPENDENCY_BITS)?
                        .cloned(),
                );
            }
            _ => false,
        };
        if !supported {
            return Some(None);
        }
        SymbolicWork { metered }.rational_leaf(child)
    }

    fn charge_coefficient_work(left: &Rational, right: &Rational) -> Option<()> {
        // Charge before coefficient multiplication, division and exact root
        // extraction. Squared limb counts distinguish wide coefficients from
        // tiny ones; these cooperative units are not a CPU or allocation bound.
        // Cost estimation must not canonicalize its own operands.
        let (left_numerator, left_denominator) = left.stored_component_bits();
        let (right_numerator, right_denominator) = right.stored_component_bits();
        let bits = left_numerator
            .saturating_add(left_denominator)
            .saturating_add(right_numerator)
            .saturating_add(right_denominator);
        let words = bits.div_ceil(64).max(1);
        crate::computable::budget::charge(words.saturating_mul(words)).then_some(())
    }

    fn rational_root_depends_on_existing(&self, root: &Computable, degree: u32) -> Option<bool> {
        let metered = crate::computable::budget::is_active();
        if metered {
            charge_evaluation_work().then_some(())?;
        }
        let Some(candidate) = Self::dependency_radicand(root, degree, metered)? else {
            return Some(false);
        };

        let mut bases = Vec::new();
        for generator in &self.generators {
            if metered {
                charge_evaluation_work().then_some(())?;
            }
            let Some(radicand) = Self::dependency_radicand(&generator.root, degree, metered)?
            else {
                continue;
            };
            bases.push(radicand);
        }
        let combinations = bases.iter().try_fold(1_u64, |count, _| {
            count
                .checked_mul(u64::from(degree))
                .filter(|count| *count <= Self::MAX_DEPENDENCY_COMBINATIONS)
        });
        let Some(combinations) = combinations else {
            return Some(false);
        };

        // Positive rational nth roots generate a multiplicative extension.
        // If r / product(b_i^e_i) is an exact nth power for exponents modulo n,
        // root_n(r) already belongs to the field generated by root_n(b_i).
        for mut combination in 0..combinations {
            if metered {
                charge_evaluation_work().then_some(())?;
            }
            let mut product = Rational::one();
            for base in &bases {
                if metered {
                    charge_evaluation_work().then_some(())?;
                }
                let exponent = combination % u64::from(degree);
                combination /= u64::from(degree);
                for _ in 0..exponent {
                    if metered {
                        Self::charge_coefficient_work(&product, base)?;
                    }
                    product *= base;
                    if product.numerator().bits() > Self::MAX_DEPENDENCY_BITS
                        || product.denominator().bits() > Self::MAX_DEPENDENCY_BITS
                    {
                        return Some(false);
                    }
                }
            }
            if metered {
                Self::charge_coefficient_work(&candidate, &product)?;
            }
            let quotient = &candidate / &product;
            if metered {
                Self::charge_coefficient_work(&quotient, &Rational::one())?;
            }
            if quotient.perfect_nth_root(degree).is_some() {
                return Some(true);
            }
        }
        Some(false)
    }

    fn insert_generator(&mut self, root: Computable, degree: u32) -> Option<()> {
        let metered = crate::computable::budget::is_active();
        for generator in &self.generators {
            let same = if metered {
                Computable::budgeted_structural_eq(&generator.root, &root)?
            } else {
                Computable::internal_structural_eq(&generator.root, &root)
            };
            if same {
                return Some(());
            }
        }
        // A declined local search only withholds a dependency proof. Shared
        // exhaustion propagates separately, before appending any generator.
        if self.rational_root_depends_on_existing(&root, degree)? {
            return Some(());
        }
        self.generators.push(AlgebraicGenerator { root, degree });
        self.within_limits().then_some(())
    }

    fn merge_generators(&mut self, other: Self) -> Option<()> {
        let metered = crate::computable::budget::is_active();
        for generator in other.generators {
            if metered {
                charge_evaluation_work().then_some(())?;
            }
            self.insert_generator(generator.root, generator.degree)?;
        }
        Some(())
    }

    fn add(mut self, other: Self) -> Option<Self> {
        let conjugate_log2 = other
            .denominator_log2
            .checked_add(self.conjugate_log2)?
            .max(self.denominator_log2.checked_add(other.conjugate_log2)?)
            .checked_add(1)?;
        self.denominator_log2 = self.denominator_log2.checked_add(other.denominator_log2)?;
        self.conjugate_log2 = conjugate_log2;
        self.merge_generators(other)?;
        self.within_limits().then_some(self)
    }

    fn multiply(mut self, other: Self) -> Option<Self> {
        self.denominator_log2 = self.denominator_log2.checked_add(other.denominator_log2)?;
        self.conjugate_log2 = self.conjugate_log2.checked_add(other.conjugate_log2)?;
        self.merge_generators(other)?;
        self.within_limits().then_some(self)
    }

    fn square(mut self) -> Option<Self> {
        self.denominator_log2 = self.denominator_log2.checked_mul(2)?;
        self.conjugate_log2 = self.conjugate_log2.checked_mul(2)?;
        self.within_limits().then_some(self)
    }

    fn inverse(mut self) -> Option<Self> {
        // The parser admits an inverse only after proving its input nonzero,
        // so beta is a valid denominator for gamma / beta.
        std::mem::swap(&mut self.denominator_log2, &mut self.conjugate_log2);
        self.within_limits().then_some(self)
    }

    fn root(mut self, root: Computable, degree: u32) -> Option<Self> {
        // If alpha = beta/gamma, then gamma * root_n(alpha) is integral:
        // its nth power is beta * gamma^(n-1). This holds even when the
        // selected gamma is negative; no principal-root choice for this
        // integral numerator is needed by the conjugate-magnitude bound.
        let degree_u64 = u64::from(degree);
        let numerator = self
            .denominator_log2
            .checked_mul(degree_u64.checked_sub(1)?)?
            .checked_add(self.conjugate_log2)?;
        self.conjugate_log2 = numerator.checked_add(degree_u64.checked_sub(1)?)? / degree_u64;
        self.insert_generator(root, degree)?;
        self.within_limits().then_some(self)
    }

    fn offset(mut self, shift: Precision) -> Option<Self> {
        if shift >= 0 {
            self.conjugate_log2 = self
                .conjugate_log2
                .checked_add(u64::from(shift.unsigned_abs()))?;
        } else {
            self.denominator_log2 = self
                .denominator_log2
                .checked_add(u64::from(shift.unsigned_abs()))?;
        }
        self.within_limits().then_some(self)
    }

    fn separation_bits(&self) -> Option<u64> {
        self.denominator_log2.checked_add(
            self.field_degree()?
                .checked_sub(1)?
                .checked_mul(self.conjugate_log2)?,
        )
    }
}

impl Binary64Interval {
    fn new(lower: f64, upper: f64) -> Option<Self> {
        (lower.is_finite() && upper.is_finite() && lower <= upper).then_some(Self { lower, upper })
    }

    fn exact(value: f64) -> Option<Self> {
        Self::new(value, value)
    }

    fn power_of_two(exponent: Precision) -> f64 {
        // Construct the exact IEEE-754 value directly. This covers every
        // representable normal and subnormal power of two without relying on
        // a libm implementation or rounding mode.
        if exponent > 1_023 {
            f64::INFINITY
        } else if exponent >= -1_022 {
            f64::from_bits(u64::try_from(exponent + 1_023).unwrap() << 52)
        } else if exponent >= -1_074 {
            f64::from_bits(1_u64 << u32::try_from(exponent + 1_074).unwrap())
        } else {
            0.0
        }
    }

    fn from_rational(value: &Rational) -> Option<Self> {
        if value.sign() == Sign::NoSign {
            return Self::exact(0.0);
        }
        let numerator = num::ToPrimitive::to_u64(value.numerator())?;
        let denominator = num::ToPrimitive::to_u64(value.denominator())?;
        const MAX_EXACT_BINARY64_INTEGER: u64 = 1_u64 << 53;
        if numerator > MAX_EXACT_BINARY64_INTEGER || denominator > MAX_EXACT_BINARY64_INTEGER {
            return None;
        }
        // Both integer-to-binary64 conversions are exact. Division is the only
        // rounding operation, so one adjacent value on either side encloses
        // the exact rational without allocating big-integer scratch storage.
        let magnitude = numerator as f64 / denominator as f64;
        let lower = magnitude.next_down();
        let upper = magnitude.next_up();
        if value.sign() == Sign::Minus {
            Self::new(-upper, -lower)
        } else {
            Self::new(lower, upper)
        }
    }

    fn negate(self) -> Self {
        Self {
            lower: -self.upper,
            upper: -self.lower,
        }
    }

    fn add(self, other: Self) -> Option<Self> {
        // Basic binary64 operations are correctly rounded. Expand each result
        // by one representable value to turn the rounded endpoint operation
        // into an outward enclosure.
        Self::new(
            (self.lower + other.lower).next_down(),
            (self.upper + other.upper).next_up(),
        )
    }

    fn multiply(self, other: Self) -> Option<Self> {
        let products = [
            self.lower * other.lower,
            self.lower * other.upper,
            self.upper * other.lower,
            self.upper * other.upper,
        ];
        let lower = products.into_iter().fold(f64::INFINITY, f64::min);
        let upper = products.into_iter().fold(f64::NEG_INFINITY, f64::max);
        Self::new(lower.next_down(), upper.next_up())
    }

    fn inverse(self) -> Option<Self> {
        if self.lower <= 0.0 && self.upper >= 0.0 {
            return None;
        }
        Self::new((1.0 / self.upper).next_down(), (1.0 / self.lower).next_up())
    }

    fn square(self) -> Option<Self> {
        if self.lower <= 0.0 && self.upper >= 0.0 {
            let magnitude = self.lower.abs().max(self.upper.abs());
            let upper = (magnitude * magnitude).next_up();
            return Self::new(0.0, upper);
        }
        self.multiply(self)
    }
}

impl Computable {
    pub(crate) fn exp_rational(r: Rational) -> Self {
        if r.is_one() {
            // e^1 is hot enough to route to the shared e cache.
            Self::e_constant()
        } else {
            let rational = Self::rational(r);
            Self::exp(rational)
        }
    }

    fn shared_constant_kind(&self) -> Option<SharedConstant> {
        match &self.internal.approximation {
            Approximation::Constant(constant) => Some(*constant),
            _ => None,
        }
    }

    fn power_of_two_rational(shift: Precision) -> Option<Rational> {
        // Structural recognition may decline coefficient expansion while the
        // exact Offset graph and all previously published facts stay intact.
        // Share the evaluator's existing precision ceiling before allocating;
        // unsigned_abs also avoids negating i32::MIN.
        let magnitude = shift.unsigned_abs();
        if magnitude > Self::MAX_APPROXIMATION_BITS as u32 {
            return None;
        }
        Some(if shift >= 0 {
            Rational::from_bigint(BigInt::one() << magnitude as usize)
        } else {
            Rational::from_bigint_fraction(BigInt::one(), BigUint::one() << magnitude as usize)
                .expect("a power-of-two denominator is nonzero")
        })
    }

    fn algebraic_separation_bound_bits(&self) -> Option<u64> {
        const NODE_BUDGET: usize = 256;

        fn parse(
            node: &Computable,
            remaining: &mut usize,
            memo: &mut Vec<(usize, AlgebraicSeparation)>,
            metered: bool,
        ) -> Option<AlgebraicSeparation> {
            if metered {
                charge_evaluation_work().then_some(())?;
            }
            let key = Arc::as_ptr(&node.internal) as usize;
            if let Some((_, value)) = memo.iter().find(|(candidate, _)| *candidate == key) {
                return Some(value.clone());
            }
            *remaining = remaining.checked_sub(1)?;
            let result = match &node.internal.approximation {
                Approximation::One => {
                    AlgebraicSeparation::rational_with_work(&Rational::one(), metered)
                }
                Approximation::Int(value) => AlgebraicSeparation::integer(value, metered),
                Approximation::Ratio(value) => {
                    AlgebraicSeparation::rational_with_work(value, metered)
                }
                Approximation::Constant(SharedConstant::Sqrt2)
                | Approximation::Constant(SharedConstant::Sqrt3) => {
                    let radicand = match &node.internal.approximation {
                        Approximation::Constant(SharedConstant::Sqrt2) => 2,
                        Approximation::Constant(SharedConstant::Sqrt3) => 3,
                        _ => unreachable!(),
                    };
                    AlgebraicSeparation::rational_with_work(&Rational::new(radicand), metered)?
                        .root(node.clone(), 2)
                }
                Approximation::Negate(child) => parse(child, remaining, memo, metered),
                Approximation::Offset(child, shift) => {
                    parse(child, remaining, memo, metered)?.offset(*shift)
                }
                Approximation::Add(left, right) => parse(left, remaining, memo, metered)?
                    .add(parse(right, remaining, memo, metered)?),
                Approximation::Multiply(left, right) => parse(left, remaining, memo, metered)?
                    .multiply(parse(right, remaining, memo, metered)?),
                Approximation::Inverse(child) if child.zero_status() == ZeroKnowledge::NonZero => {
                    parse(child, remaining, memo, metered)?.inverse()
                }
                Approximation::Square(child) => parse(child, remaining, memo, metered)?.square(),
                Approximation::Sqrt(child) => {
                    parse(child, remaining, memo, metered)?.root(node.clone(), 2)
                }
                Approximation::NthRoot(child, degree) => {
                    parse(child, remaining, memo, metered)?.root(node.clone(), *degree)
                }
                Approximation::LinearCombination3(combination) => {
                    let mut sum =
                        AlgebraicSeparation::rational_with_work(&Rational::zero(), metered)?;
                    for (coefficient, value) in combination
                        .coefficients
                        .iter()
                        .zip(combination.values.iter())
                    {
                        sum = sum.add(parse(coefficient, remaining, memo, metered)?.multiply(
                            AlgebraicSeparation::rational_with_work(value, metered)?,
                        )?)?;
                    }
                    Some(sum)
                }
                _ => None,
            }?;
            if memo.is_empty() {
                // Preserve the ordinary initial capacity, allocating it only
                // after a successfully charged visit produced metadata.
                memo.reserve(16);
            }
            memo.push((key, result.clone()));
            Some(result)
        }

        let mut remaining = NODE_BUDGET;
        // This synchronous parser cannot introduce a new caller allowance.
        // Check once so ordinary requests skip per-node accounting overhead.
        let metadata = parse(
            self,
            &mut remaining,
            &mut Vec::new(),
            crate::computable::budget::is_active(),
        )?;
        metadata
            .separation_bits()
            .filter(|bits| *bits <= AlgebraicSeparation::MAX_LOG2)
    }

    fn algebraic_zero_precision(&self, min_precision: Precision) -> Option<Precision> {
        let bound = i64::try_from(self.algebraic_separation_bound_bits()?).ok()?;
        let target = -bound.checked_add(2)?;
        (target >= i64::from(min_precision))
            .then(|| Precision::try_from(target).ok())
            .flatten()
    }

    fn shared_constant_term(&self) -> Option<(SharedConstant, Rational)> {
        self.shared_constant_term_with_work(SymbolicWork { metered: false })
    }

    fn shared_constant_term_with_work(
        &self,
        work: SymbolicWork,
    ) -> Option<(SharedConstant, Rational)> {
        // Recognize "exact rational scale times one shared constant" through
        // lightweight wrappers. This supports pi-3/e-2 style sign certificates
        // without needing a full symbolic Real class.
        work.visit()?;
        match &self.internal.approximation {
            Approximation::Constant(constant) => Some((*constant, Rational::one())),
            Approximation::Negate(child) => {
                let (constant, scale) = child.shared_constant_term_with_work(work)?;
                Some((constant, scale.neg()))
            }
            Approximation::Offset(child, shift) => {
                let (constant, scale) = child.shared_constant_term_with_work(work)?;
                let factor = work.power_of_two(*shift)?;
                work.binary(&scale, &factor)?;
                Some((constant, scale * factor))
            }
            Approximation::Multiply(left, right) => {
                if let Some(scale) = work.rational_leaf(left)? {
                    let (constant, inner_scale) = right.shared_constant_term_with_work(work)?;
                    work.binary(&scale, &inner_scale)?;
                    return Some((constant, scale * inner_scale));
                }
                if let Some(scale) = work.rational_leaf(right)? {
                    let (constant, inner_scale) = left.shared_constant_term_with_work(work)?;
                    work.binary(&scale, &inner_scale)?;
                    return Some((constant, scale * inner_scale));
                }
                None
            }
            _ => None,
        }
    }

    fn integer_pi_plus_rational(&self) -> Option<(BigInt, Rational)> {
        // Trig reducers often see values like k*pi + r after symbolic algebra.
        // If k is an exact integer, the period/parity can be handled without
        // estimating a quotient or building a cancellation-prone residual.
        fn extract(term: &Computable, offset: &Computable) -> Option<(BigInt, Rational)> {
            let rational = offset.exact_rational()?;
            let residual_is_kernel_sized = rational.sign() == Sign::NoSign
                || rational.msd_exact().is_some_and(|msd| msd < 0)
                || Computable::exact_rational_half_pi_shortcut_magnitude(&rational).is_some();
            if !residual_is_kernel_sized {
                return None;
            }
            let (constant, scale) = term.shared_constant_term()?;
            let pi_scale = match constant {
                SharedConstant::Pi => scale,
                SharedConstant::Tau => scale * Rational::new(2),
                _ => return None,
            };
            pi_scale
                .to_big_integer()
                .map(|multiple| (multiple, rational))
        }

        match &self.internal.approximation {
            Approximation::Add(left, right) => {
                extract(left, right).or_else(|| extract(right, left))
            }
            _ => None,
        }
    }

    fn bound_from_strict_interval(lower: Rational, upper: Rational) -> BoundInfo {
        // Convert an interval that excludes zero into a reusable sign/MSD
        // certificate. If the interval crosses zero, preserve correctness by
        // returning Unknown.
        let zero = Rational::zero();
        let (sign, magnitude_lower, magnitude_upper) = if lower > zero {
            (Sign::Plus, lower, upper)
        } else if upper < zero {
            (Sign::Minus, upper.neg(), lower.neg())
        } else {
            return BoundInfo::Unknown;
        };

        let lower_msd = magnitude_lower.msd_exact();
        let upper_msd = magnitude_upper.msd_exact();
        let (msd, exact_msd) = match (lower_msd, upper_msd) {
            (Some(lower), Some(upper)) if lower == upper => (Some(lower), true),
            (Some(lower), Some(upper)) => (Some(lower.max(upper)), false),
            _ => (None, false),
        };

        BoundInfo::with_sign_msd(sign, msd, exact_msd)
    }

    fn constant_rational_sum_bound_with_work(
        term: &(SharedConstant, Rational),
        rational: &Rational,
        work: SymbolicWork,
    ) -> Option<BoundInfo> {
        // Specialized structural bound for c*K + q where K is a shared constant.
        // This is the computable-side companion to Real's ConstOffset class and
        // keeps generic Add nodes for pi-3 from needing approximation refinement.
        let (constant, scale) = term;
        let (lower, upper) = constant.interval();
        work.binary(&lower, scale)?;
        let scaled_lower = lower * scale;
        work.binary(&upper, scale)?;
        let scaled_upper = upper * scale;
        work.binary(&scaled_lower, &scaled_upper)?;
        let (lower, upper) = if scaled_lower <= scaled_upper {
            (scaled_lower, scaled_upper)
        } else {
            (scaled_upper, scaled_lower)
        };

        work.binary(&lower, rational)?;
        work.binary(&upper, rational)?;
        let lower = lower + rational;
        let upper = upper + rational;
        work.read(&lower)?;
        work.read(&upper)?;
        Some(Self::bound_from_strict_interval(lower, upper))
    }

    pub(crate) fn cached_at_precision(&self, p: Precision) -> Option<BigInt> {
        // A cached value at precision q can answer any less precise request p
        // by shifting, but not a more precise one. Shared constants use the
        // process-wide cache; other nodes keep their cache beside the node.
        if let Approximation::Constant(constant) = &self.internal.approximation {
            return Self::cached_constant_at_precision(*constant, p);
        }

        self.internal.cached_at_precision(p)
    }

    fn cached_constant_at_precision(constant: SharedConstant, p: Precision) -> Option<BigInt> {
        if let Some(cached) = Self::cached_shared_constant_at_precision(constant, p) {
            return Some(cached);
        }
        if constant == SharedConstant::Tau
            && let Some(pi_precision) = p.checked_sub(1)
            && let Some(cached) =
                Self::cached_shared_constant_at_precision(SharedConstant::Pi, pi_precision)
        {
            // tau is exactly 2*pi, so a pi approximation at precision p-1
            // is already a tau approximation at precision p. Populate the
            // tau cache from pi instead of re-running the Machin pi kernel
            // when callers ask for tau after pi has been warmed.
            Self::store_shared_constant_cache_value(SharedConstant::Tau, p, cached.clone());
            return Some(cached);
        }
        if constant == SharedConstant::Pi
            && let Some(tau_precision) = p.checked_add(1)
            && let Some(cached) =
                Self::cached_shared_constant_at_precision(SharedConstant::Tau, tau_precision)
        {
            // The same identity works in reverse: a tau approximation at
            // precision p+1 is already a pi approximation at precision p.
            // This matters for applications that use tau for trig
            // construction and later format pi; reuse the costly Machin
            // approximation instead of recomputing it under a different
            // shared-constant key.
            Self::store_shared_constant_cache_value(SharedConstant::Pi, p, cached.clone());
            return Some(cached);
        }
        None
    }

    fn cached_shared_constant_at_precision(
        constant: SharedConstant,
        p: Precision,
    ) -> Option<BigInt> {
        SHARED_CONSTANT_CACHES[constant.cache_index()].at_precision(p)
    }

    fn store_shared_constant_cache_value(constant: SharedConstant, p: Precision, value: BigInt) {
        SHARED_CONSTANT_CACHES[constant.cache_index()].store(p, value);
    }

    fn store_cache_value(
        &self,
        signal: &Option<Signal>,
        p: Precision,
        value: BigInt,
    ) -> Result<(), Problem> {
        // Store only exact node approximation results, not temporary scaled
        // values. For shared constants this updates the process-wide cache so
        // every cloned constant wrapper and worker thread benefits.
        //
        // Kernels propagate failure before this method is called. Cancellation
        // may still arrive after a kernel completes; propagate that observation
        // while leaving previously completed cache entries intact.
        if should_stop(signal) || evaluation_exhausted() {
            return Err(Problem::Exhausted);
        }
        let approximation_bound = Self::bound_from_approx(p, &value);
        if approximation_bound != BoundInfo::Unknown {
            // Discover structural certificates before publishing a numerical
            // bound. Otherwise an approximation-first query can occupy an
            // uninitialized slot and hide an exact rational or root MSD.
            self.cheap_bound();
            if evaluation_exhausted() {
                return Err(Problem::Exhausted);
            }
            // A separated approximation may add a sign or magnitude to the
            // structural evidence. Atomic publication combines compatible
            // proofs without dropping an existing exact MSD or sign.
            self.internal.facts.publish_bound(approximation_bound);
        }
        if let Some(constant) = self.shared_constant_kind() {
            Self::store_shared_constant_cache_value(constant, p, value);
        } else {
            self.internal.store_cache_value(p, value);
        }
        Ok(())
    }

    fn cached_bound(&self) -> Option<BoundInfo> {
        match self.internal.facts.bound() {
            BoundCache::Invalid => None,
            BoundCache::Valid(info) => Some(info),
        }
    }

    fn store_bound(&self, info: &BoundInfo) {
        if evaluation_exhausted() {
            return;
        }
        self.internal.facts.publish_bound(*info);
    }

    fn rational_kernel_sign(kind: &Approximation) -> Option<Sign> {
        use Approximation::*;
        // Stored kernel names do not prove their private argument ranges.
        // These borrowed integer comparisons certify only cheap real domains
        // and sign intervals; everything else remains Unknown.
        match kind {
            AsinRational(r)
            | PrescaledSinRational(r)
            | PrescaledTanRational(r)
            | PrescaledCotHalfPiMinusRational(r) => {
                (r.numerator() <= r.denominator()).then_some(r.sign())
            }
            AtanhRational(r) => (r.numerator() < r.denominator()).then_some(r.sign()),
            PrescaledCosRational(r) | PrescaledSinHalfPiMinusRational(r) => {
                (r.numerator() <= r.denominator()).then_some(Sign::Plus)
            }
            PrescaledCosHalfPiMinusRational(r) => {
                (!r.magnitude_at_least_power_of_two(1)).then_some(r.sign())
            }
            AcosPositiveRational(r) if r.numerator() <= r.denominator() => {
                Some(if r.is_one() { Sign::NoSign } else { Sign::Plus })
            }
            AcosNegativeRational(r) if r.numerator() <= r.denominator() => Some(
                if r.sign() == Sign::Minus && r.numerator() == r.denominator() {
                    Sign::NoSign
                } else {
                    Sign::Plus
                },
            ),
            _ => None,
        }
    }

    fn small_quotient_sign(child: &Self, budget: usize) -> Option<Sign> {
        // Serialized private nodes carry no constructor-domain certificate.
        // |x| < 1 proves both removable quotients strictly positive, including
        // their exact-zero continuations. Reuse only a certified magnitude.
        let magnitude = child.cheap_bound_shallow(budget)?.known_msd()?;
        magnitude.is_none_or(|msd| msd <= -1).then_some(Sign::Plus)
    }

    fn unit_interval_sign(child: &Self, closed: bool, budget: usize) -> Option<Sign> {
        let bound = child.cheap_bound_shallow(budget)?;
        if bound
            .known_msd()
            .is_some_and(|msd| msd.is_none_or(|msd| msd < 0))
        {
            return bound.known_sign();
        }
        let value = child.bounded_rational_value()?;
        (value.numerator() < value.denominator()
            || (closed && value.numerator() == value.denominator()))
        .then_some(value.sign())
    }

    fn acosh_sign(child: &Self) -> Option<Sign> {
        if !child.has_finite_real_certificate() {
            return None;
        }
        if let Some(value) = child.bounded_rational_value() {
            return (value.sign() == Sign::Plus && value.numerator() >= value.denominator())
                .then_some(if value.is_one() {
                    Sign::NoSign
                } else {
                    Sign::Plus
                });
        }
        match &child.internal.approximation {
            Approximation::One => Some(Sign::NoSign),
            Approximation::Int(n) if n == signed::ONE.deref() => Some(Sign::NoSign),
            Approximation::Int(n) if n > signed::ONE.deref() => Some(Sign::Plus),
            Approximation::Ratio(r) if r.is_one() => Some(Sign::NoSign),
            Approximation::Ratio(r)
                if r.sign() == Sign::Plus && r.magnitude_at_least_power_of_two(0) =>
            {
                Some(Sign::Plus)
            }
            _ => {
                let bound = child.cheap_bound_shallow(8)?;
                (bound.known_sign() == Some(Sign::Plus)
                    && bound.known_msd().flatten().is_some_and(|msd| msd >= 1))
                .then_some(Sign::Plus)
            }
        }
    }

    fn cheap_bound_shallow(&self, budget: usize) -> Option<BoundInfo> {
        // First try a shallow recursive walk. It is faster for common small
        // trees and avoids allocating the explicit stack used by deep chains.
        if let Some(info) = self.cached_bound() {
            return Some(info);
        }
        if budget == 0 || !charge_evaluation_work() {
            return None;
        }
        let info = match &self.internal.approximation {
            Approximation::One => Some(BoundInfo::with_sign(Sign::Plus, Some(0))),
            Approximation::Int(n) => Some(if n.sign() == Sign::NoSign {
                BoundInfo::Zero
            } else {
                BoundInfo::with_sign(
                    n.sign(),
                    crate::verified::word::checked_bit_length_msd(
                        n.magnitude().bits(),
                        1,
                        false,
                        0,
                    ),
                )
            }),
            Approximation::Constant(constant) => Some(constant.bound_info()),
            Approximation::Ratio(r) => Some(BoundInfo::from_rational(r)),
            Approximation::AtanRational(r) => Some(BoundInfo::with_sign_msd(r.sign(), None, false)),
            Approximation::AsinhRational(r) => {
                Some(BoundInfo::with_sign_msd(r.sign(), None, false))
            }
            kind @ (Approximation::AsinRational(_)
            | Approximation::AtanhRational(_)
            | Approximation::PrescaledSinRational(_)
            | Approximation::PrescaledTanRational(_)
            | Approximation::PrescaledCosRational(_)
            | Approximation::PrescaledCosHalfPiMinusRational(_)
            | Approximation::PrescaledSinHalfPiMinusRational(_)
            | Approximation::PrescaledCotHalfPiMinusRational(_)
            | Approximation::AcosPositiveRational(_)
            | Approximation::AcosNegativeRational(_)) => Some(
                Self::rational_kernel_sign(kind).map_or(BoundInfo::Unknown, |sign| {
                    BoundInfo::with_sign_msd(sign, None, false)
                }),
            ),
            Approximation::SincSmall(child) | Approximation::CoscSmall(child) => Some(
                Self::small_quotient_sign(child, budget - 1).map_or(BoundInfo::Unknown, |sign| {
                    BoundInfo::with_sign_msd(sign, None, false)
                }),
            ),
            Approximation::Negate(child) => {
                child.cheap_bound_shallow(budget - 1).map(BoundInfo::negate)
            }
            Approximation::Offset(child, n) => child
                .cheap_bound_shallow(budget - 1)
                .map(|bound| bound.map_msd(|value| value.checked_add(*n))),
            Approximation::Inverse(child) => child
                .cheap_bound_shallow(budget - 1)
                .map(BoundInfo::inverse),
            Approximation::Square(child) => {
                child.cheap_bound_shallow(budget - 1).map(BoundInfo::square)
            }
            Approximation::Sqrt(child) => {
                child.cheap_bound_shallow(budget - 1).map(BoundInfo::sqrt)
            }
            Approximation::Multiply(left, right) => {
                let left = left.cheap_bound_shallow(budget - 1)?;
                let right = right.cheap_bound_shallow(budget - 1)?;
                let bound = left.multiply(right);
                Some(
                    if bound == BoundInfo::Zero && !self.has_finite_real_certificate() {
                        BoundInfo::Unknown
                    } else {
                        bound
                    },
                )
            }
            Approximation::Add(left, right) => {
                let left = left.cheap_bound_shallow(budget - 1)?;
                let right = right.cheap_bound_shallow(budget - 1)?;
                Some(left.add(right))
            }
            _ => Some(if let Some((prec, appr)) = self.cached() {
                Self::bound_from_approx(prec, &appr)
            } else {
                BoundInfo::Unknown
            }),
        };
        if let Some(ref value) = info {
            self.store_bound(value);
        }
        info
    }

    fn cheap_bound(&self) -> BoundInfo {
        const SHALLOW_BOUND_BUDGET: usize = 24;

        // The public structural API leans on this method heavily. It must stay
        // conservative: a false NonZero or sign certificate is a correctness
        // bug, while Unknown only costs later refinement.
        if let Some(info) = self.cached_bound() {
            return info;
        }

        if let Some(bound) = self.cheap_bound_shallow(SHALLOW_BOUND_BUDGET) {
            return bound;
        }

        enum Frame<'a> {
            Eval(&'a Computable),
            FinishNegate(&'a Computable),
            FinishOffset(&'a Computable, i32),
            FinishInverse(&'a Computable),
            FinishSquare(&'a Computable),
            FinishSqrt(&'a Computable),
            FinishAdd(&'a Computable),
            FinishMultiply(&'a Computable),
        }

        fn direct_bound(node: &Computable) -> Option<BoundInfo> {
            if let Some(bound) = node.cached_bound() {
                return Some(bound);
            }
            match &node.internal.approximation {
                Approximation::One => Some(BoundInfo::with_sign(Sign::Plus, Some(0))),
                Approximation::Int(n) => Some(if n.sign() == Sign::NoSign {
                    BoundInfo::Zero
                } else {
                    BoundInfo::with_sign(
                        n.sign(),
                        crate::verified::word::checked_bit_length_msd(
                            n.magnitude().bits(),
                            1,
                            false,
                            0,
                        ),
                    )
                }),
                Approximation::Constant(constant) => Some(constant.bound_info()),
                Approximation::Ratio(r) => Some(BoundInfo::from_rational(r)),
                Approximation::AtanRational(r) => {
                    Some(BoundInfo::with_sign_msd(r.sign(), None, false))
                }
                Approximation::AsinhRational(r) => {
                    Some(BoundInfo::with_sign_msd(r.sign(), None, false))
                }
                kind @ (Approximation::AsinRational(_)
                | Approximation::AtanhRational(_)
                | Approximation::PrescaledSinRational(_)
                | Approximation::PrescaledTanRational(_)
                | Approximation::PrescaledCosRational(_)
                | Approximation::PrescaledCosHalfPiMinusRational(_)
                | Approximation::PrescaledSinHalfPiMinusRational(_)
                | Approximation::PrescaledCotHalfPiMinusRational(_)
                | Approximation::AcosPositiveRational(_)
                | Approximation::AcosNegativeRational(_)) => Some(
                    Computable::rational_kernel_sign(kind).map_or(BoundInfo::Unknown, |sign| {
                        BoundInfo::with_sign_msd(sign, None, false)
                    }),
                ),
                Approximation::SincSmall(child) | Approximation::CoscSmall(child) => Some(
                    Computable::small_quotient_sign(child, 8).map_or(BoundInfo::Unknown, |sign| {
                        BoundInfo::with_sign_msd(sign, None, false)
                    }),
                ),
                Approximation::Negate(_)
                | Approximation::Offset(_, _)
                | Approximation::Inverse(_)
                | Approximation::Square(_)
                | Approximation::Sqrt(_)
                | Approximation::Add(_, _)
                | Approximation::Multiply(_, _) => None,
                _ => Some(if let Some((prec, appr)) = node.cached() {
                    Computable::bound_from_approx(prec, &appr)
                } else {
                    BoundInfo::Unknown
                }),
            }
        }

        // Reserve small fixed-size stacks because bound queries are often called
        // on long symbolic chains and should not allocate repeatedly under
        // repeated structural fact traffic.
        let mut frames = Vec::with_capacity(16);
        let mut values: Vec<BoundInfo> = Vec::with_capacity(8);
        frames.push(Frame::Eval(self));

        // Deep addition/multiplication chains are common after algebra kernels.
        // Use an explicit stack so structural fact discovery cannot recurse
        // through thousands of nodes.
        while let Some(frame) = frames.pop() {
            if !charge_evaluation_work() {
                return self.cached_bound().unwrap_or(BoundInfo::Unknown);
            }
            match frame {
                Frame::Eval(node) => {
                    if let Some(bound) = direct_bound(node) {
                        node.store_bound(&bound);
                        values.push(bound);
                        continue;
                    }

                    match &node.internal.approximation {
                        Approximation::Negate(child) => {
                            frames.push(Frame::FinishNegate(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Offset(child, n) => {
                            frames.push(Frame::FinishOffset(node, *n));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Inverse(child) => {
                            frames.push(Frame::FinishInverse(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Square(child) => {
                            frames.push(Frame::FinishSquare(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Sqrt(child) => {
                            frames.push(Frame::FinishSqrt(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Add(left, right) => {
                            frames.push(Frame::FinishAdd(node));
                            frames.push(Frame::Eval(right));
                            frames.push(Frame::Eval(left));
                        }
                        Approximation::Multiply(left, right) => {
                            frames.push(Frame::FinishMultiply(node));
                            frames.push(Frame::Eval(right));
                            frames.push(Frame::Eval(left));
                        }
                        _ => unreachable!("direct_bound should handle non-structural nodes"),
                    }
                }
                Frame::FinishNegate(node) => {
                    let value = values.pop().expect("negate bound should exist");
                    let result = value.negate();
                    node.store_bound(&result);
                    values.push(result);
                }
                Frame::FinishOffset(node, offset) => {
                    let value = values.pop().expect("offset bound should exist");
                    let result = value.map_msd(|msd| msd.checked_add(offset));
                    node.store_bound(&result);
                    values.push(result);
                }
                Frame::FinishInverse(node) => {
                    let value = values.pop().expect("inverse bound should exist");
                    let result = value.inverse();
                    node.store_bound(&result);
                    values.push(result);
                }
                Frame::FinishSquare(node) => {
                    let value = values.pop().expect("square bound should exist");
                    let result = value.square();
                    node.store_bound(&result);
                    values.push(result);
                }
                Frame::FinishSqrt(node) => {
                    let value = values.pop().expect("sqrt bound should exist");
                    let result = value.sqrt();
                    node.store_bound(&result);
                    values.push(result);
                }
                Frame::FinishAdd(node) => {
                    let right = values.pop().expect("add rhs bound should exist");
                    let left = values.pop().expect("add lhs bound should exist");
                    let result = left.add(right);
                    node.store_bound(&result);
                    values.push(result);
                }
                Frame::FinishMultiply(node) => {
                    let right = values.pop().expect("multiply rhs bound should exist");
                    let left = values.pop().expect("multiply lhs bound should exist");
                    let bound = left.multiply(right);
                    let result = if bound == BoundInfo::Zero && !node.has_finite_real_certificate()
                    {
                        BoundInfo::Unknown
                    } else {
                        bound
                    };
                    node.store_bound(&result);
                    values.push(result);
                }
            }
        }

        let result = values
            .pop()
            .expect("bound evaluation should produce a result");
        self.store_bound(&result);
        result
    }

    fn binary64_filter_interval(&self, remaining: &mut usize) -> Option<Binary64Interval> {
        // The filter is deliberately on-demand and bounded. It carries no
        // fields in every node and gives up on unsupported, oversized, deep,
        // non-finite, or out-of-range scale expressions; sign_until then runs
        // its unchanged arbitrary-precision path.
        if !charge_evaluation_work() {
            return None;
        }
        *remaining = remaining.checked_sub(1)?;
        match &self.internal.approximation {
            Approximation::One => Binary64Interval::exact(1.0),
            Approximation::Int(value) => {
                if value.magnitude().bits() > 53 {
                    return None;
                }
                Binary64Interval::exact(num::ToPrimitive::to_f64(value)?)
            }
            Approximation::Ratio(value) => Binary64Interval::from_rational(value),
            // These explicit adjacent-binary64 enclosures are independently
            // checked against high-precision MPFR constants in the unit tests.
            Approximation::Constant(SharedConstant::E) => Binary64Interval::new(
                f64::from_bits(0x4005_bf0a_8b14_5768),
                f64::from_bits(0x4005_bf0a_8b14_576a),
            ),
            Approximation::Constant(SharedConstant::Pi) => Binary64Interval::new(
                f64::from_bits(0x4009_21fb_5444_2d17),
                f64::from_bits(0x4009_21fb_5444_2d19),
            ),
            Approximation::Constant(_) => None,
            Approximation::Negate(child) => {
                Some(child.binary64_filter_interval(remaining)?.negate())
            }
            Approximation::Offset(child, shift) => {
                let biased_exponent = shift.checked_add(1_023)?;
                if !(1..=2_046).contains(&biased_exponent) {
                    return None;
                }
                let scale = f64::from_bits(u64::try_from(biased_exponent).ok()? << 52);
                child
                    .binary64_filter_interval(remaining)?
                    .multiply(Binary64Interval::exact(scale)?)
            }
            Approximation::Inverse(child) => child.binary64_filter_interval(remaining)?.inverse(),
            Approximation::Square(child) => child.binary64_filter_interval(remaining)?.square(),
            Approximation::Add(left, right) => left
                .binary64_filter_interval(remaining)?
                .add(right.binary64_filter_interval(remaining)?),
            Approximation::Multiply(left, right) => left
                .binary64_filter_interval(remaining)?
                .multiply(right.binary64_filter_interval(remaining)?),
            Approximation::LinearCombination3(form) => {
                let mut result = Binary64Interval::exact(0.0)?;
                for (coefficient, value) in form.coefficients.iter().zip(&form.values) {
                    let coefficient = coefficient.binary64_filter_interval(remaining)?;
                    let value = Binary64Interval::from_rational(value)?;
                    result = result.add(coefficient.multiply(value)?)?;
                }
                Some(result)
            }
            _ => None,
        }
    }

    #[inline(never)]
    fn binary64_filter_sign_until(&self, min_precision: Precision) -> Option<Sign> {
        let mut remaining = 32;
        let interval = self.binary64_filter_interval(&mut remaining)?;
        // Do not let the fixed-width filter silently exceed the caller's
        // precision floor. The interval must lie beyond the same 2^p band that
        // the scaled arbitrary-precision approximation uses for a decision.
        // This preserves Unknown at p=0 for close values such as pi-103993/33102.
        let threshold = Binary64Interval::power_of_two(min_precision);
        if interval.lower > threshold {
            Some(Sign::Plus)
        } else if interval.upper < -threshold {
            Some(Sign::Minus)
        } else if interval.lower == 0.0 && interval.upper == 0.0 {
            Some(Sign::NoSign)
        } else {
            None
        }
    }

    fn exact_sign(&self) -> Option<Sign> {
        // `exact_sign` is stronger than "current approximation sign": it means
        // the expression shape or a separated cached approximation proves the
        // sign. Unknown is cached separately so impossible structural proofs do
        // not repeat on every predicate query.
        let (cached_bound, cached_sign) = self.internal.facts.snapshot();
        if let ExactSignCache::Valid(sign) = cached_sign {
            return Some(sign);
        }
        if let BoundCache::Valid(bound) = cached_bound
            && let Some(sign) = bound.known_sign()
        {
            // A structural or numeric bound can already certify this sign
            // even when an earlier sign-only search retained Unknown.
            self.internal
                .facts
                .publish_exact_sign(ExactSignCache::Valid(sign));
            return Some(sign);
        }
        if let Some((_, appr)) = self.cached()
            && appr.abs() > BigInt::one()
        {
            let sign = appr.sign();
            self.internal
                .facts
                .publish_exact_sign(ExactSignCache::Valid(sign));
            return Some(sign);
        }
        // Completed certificates above remain reusable. An unsuccessful
        // rational/domain preflight must not allocate a fresh traversal after
        // the shared allowance has failed.
        if evaluation_exhausted() {
            return self.immediate_sign().map(private_sign);
        }
        if matches!(self.internal.approximation, Approximation::Add(_, _))
            && let Some(sign) = self.inverse_trig_linear_sign()
        {
            self.internal
                .facts
                .publish_exact_sign(ExactSignCache::Valid(sign));
            return Some(sign);
        }
        if cached_sign == ExactSignCache::Unknown {
            return None;
        }
        enum Frame<'a> {
            Eval(&'a Computable),
            FinishNegate(&'a Computable),
            FinishOffset(&'a Computable),
            FinishInverse(&'a Computable),
            FinishSquare(&'a Computable),
            FinishSqrt(&'a Computable),
            FinishAdd(&'a Computable),
            FinishMultiply(&'a Computable),
        }

        fn cached_exact_sign(node: &Computable) -> Option<Option<Sign>> {
            let (cached_bound, cached_sign) = node.internal.facts.snapshot();
            if !matches!(cached_sign, ExactSignCache::Valid(_))
                && let BoundCache::Valid(bound) = cached_bound
                && let Some(sign) = bound.known_sign()
            {
                node.internal
                    .facts
                    .publish_exact_sign(ExactSignCache::Valid(sign));
                return Some(Some(sign));
            }
            match cached_sign {
                ExactSignCache::Invalid => None,
                ExactSignCache::Unknown => {
                    if let Some((_, appr)) = node.cached()
                        && appr.abs() > BigInt::one()
                    {
                        let sign = appr.sign();
                        node.internal
                            .facts
                            .publish_exact_sign(ExactSignCache::Valid(sign));
                        Some(Some(sign))
                    } else {
                        Some(None)
                    }
                }
                ExactSignCache::Valid(sign) => Some(Some(sign)),
            }
        }

        fn exact_sign_direct(node: &Computable) -> Option<Option<Sign>> {
            // Direct cases either know their sign structurally or are known not
            // to be structurally decidable without visiting children.
            if let Some(sign) = cached_exact_sign(node) {
                return Some(sign);
            }

            if let Some((_, appr)) = node.cached()
                && appr.abs() > BigInt::one()
            {
                return Some(Some(appr.sign()));
            }

            match &node.internal.approximation {
                Approximation::One => Some(Some(Sign::Plus)),
                Approximation::Int(n) => Some(Some(n.sign())),
                Approximation::Constant(_) => Some(Some(Sign::Plus)),
                Approximation::Ratio(r) => Some(Some(r.sign())),
                Approximation::IntegralAtan(n) => Some((!n.is_zero()).then_some(n.sign())),
                Approximation::AtanRational(r) => Some(Some(r.sign())),
                Approximation::AsinhRational(r) => Some(Some(r.sign())),
                kind @ (Approximation::AsinRational(_)
                | Approximation::AtanhRational(_)
                | Approximation::PrescaledSinRational(_)
                | Approximation::PrescaledTanRational(_)
                | Approximation::PrescaledCosRational(_)
                | Approximation::PrescaledCosHalfPiMinusRational(_)
                | Approximation::PrescaledSinHalfPiMinusRational(_)
                | Approximation::PrescaledCotHalfPiMinusRational(_)
                | Approximation::AcosPositiveRational(_)
                | Approximation::AcosNegativeRational(_)) => {
                    Some(Computable::rational_kernel_sign(kind))
                }
                Approximation::SincSmall(child) | Approximation::CoscSmall(child) => {
                    Some(Computable::small_quotient_sign(child, 8))
                }
                Approximation::Erfc(child) | Approximation::NormalSf(child) => {
                    Some(child.has_finite_real_certificate().then_some(Sign::Plus))
                }
                Approximation::AcoshNearOne(child) | Approximation::AcoshDirect(child) => {
                    Some(Computable::acosh_sign(child))
                }
                Approximation::AcosPositive(_) | Approximation::NormalInterval { .. } => Some(None),
                Approximation::LogPnorm(child)
                | Approximation::LogNormalSf(child)
                | Approximation::LogDnorm(child) => {
                    Some(child.has_finite_real_certificate().then_some(Sign::Minus))
                }
                Approximation::PrescaledAsin(child) | Approximation::AsinDeferred(child) => {
                    Some(Computable::unit_interval_sign(child, true, 8))
                }
                Approximation::AtanhDirect(child) | Approximation::PrescaledAtanh(child) => {
                    Some(Computable::unit_interval_sign(child, false, 8))
                }
                Approximation::PrescaledAtan(child)
                | Approximation::AtanDeferred(child)
                | Approximation::AsinhNearZero(child)
                | Approximation::AsinhDirect(child)
                | Approximation::PrescaledAsinh(child)
                | Approximation::Expm1(child) => Some(child.exact_sign()),
                Approximation::PrescaledExp(child) => {
                    Some(child.has_finite_real_certificate().then_some(Sign::Plus))
                }
                Approximation::Negate(_)
                | Approximation::Offset(_, _)
                | Approximation::Inverse(_)
                | Approximation::Square(_)
                | Approximation::Sqrt(_)
                | Approximation::Add(_, _)
                | Approximation::Multiply(_, _) => None,
                _ => Some(None),
            }
        }

        fn store_exact_sign(node: &Computable, sign: Option<Sign>) {
            if evaluation_exhausted() {
                return;
            }
            // A walk can produce a tentative Unknown before the root's
            // quadratic/Laurent fallback runs. If that later work exhausts the
            // caller allowance, retaining this marker would suppress a fresh
            // unlimited retry. Budgeted searches retain completed proofs only;
            // ordinary searches keep their existing negative memoization.
            if sign.is_none() && crate::computable::budget::is_active() {
                return;
            }
            node.internal.facts.publish_exact_sign(match sign {
                Some(sign) => ExactSignCache::Valid(sign),
                None => ExactSignCache::Unknown,
            });
        }

        // Structural sign on deep chains stays allocation-light so predicate-heavy
        // code does not needlessly allocate during exact-sign walks.
        let mut frames = Vec::with_capacity(16);
        let mut values: Vec<Option<Sign>> = Vec::with_capacity(8);
        frames.push(Frame::Eval(self));

        // Mirror cheap_bound's nonrecursive traversal for deep structural
        // expressions. This matters for predicate-heavy code that asks only for
        // sign and never needs numeric approximation.
        while let Some(frame) = frames.pop() {
            if !charge_evaluation_work() {
                return self.immediate_sign().map(private_sign);
            }
            match frame {
                Frame::Eval(node) => {
                    if let Some(sign) = exact_sign_direct(node) {
                        store_exact_sign(node, sign);
                        values.push(sign);
                        continue;
                    }

                    match &node.internal.approximation {
                        Approximation::Negate(child) => {
                            frames.push(Frame::FinishNegate(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Offset(child, _) => {
                            frames.push(Frame::FinishOffset(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Inverse(child) => {
                            frames.push(Frame::FinishInverse(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Square(child) => {
                            frames.push(Frame::FinishSquare(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Sqrt(child) => {
                            frames.push(Frame::FinishSqrt(node));
                            frames.push(Frame::Eval(child));
                        }
                        Approximation::Add(left, right) => {
                            frames.push(Frame::FinishAdd(node));
                            frames.push(Frame::Eval(right));
                            frames.push(Frame::Eval(left));
                        }
                        Approximation::Multiply(left, right) => {
                            frames.push(Frame::FinishMultiply(node));
                            frames.push(Frame::Eval(right));
                            frames.push(Frame::Eval(left));
                        }
                        _ => unreachable!("exact_sign_direct should handle non-structural nodes"),
                    }
                }
                Frame::FinishNegate(node) => {
                    let value = values.pop().expect("negate sign should exist");
                    let result = value.map(negate_sign);
                    store_exact_sign(node, result);
                    values.push(result);
                }
                Frame::FinishOffset(node) => {
                    let value = values.pop().expect("offset sign should exist");
                    store_exact_sign(node, value);
                    values.push(value);
                }
                Frame::FinishInverse(node) => {
                    let value = values.pop().expect("inverse sign should exist");
                    let result = match value {
                        Some(Sign::Plus) => Some(Sign::Plus),
                        Some(Sign::Minus) => Some(Sign::Minus),
                        _ => None,
                    };
                    store_exact_sign(node, result);
                    values.push(result);
                }
                Frame::FinishSquare(node) => {
                    let value = values.pop().expect("square sign should exist");
                    let result = match value {
                        Some(Sign::NoSign) => Some(Sign::NoSign),
                        Some(_) => Some(Sign::Plus),
                        None => None,
                    };
                    store_exact_sign(node, result);
                    values.push(result);
                }
                Frame::FinishSqrt(node) => {
                    let value = values.pop().expect("sqrt sign should exist");
                    let result = match value {
                        Some(Sign::NoSign) => Some(Sign::NoSign),
                        Some(Sign::Plus) => Some(Sign::Plus),
                        _ => None,
                    };
                    store_exact_sign(node, result);
                    values.push(result);
                }
                Frame::FinishAdd(node) => {
                    let right = values.pop().expect("add rhs sign should exist");
                    let left = values.pop().expect("add lhs sign should exist");
                    let result = match (left, right) {
                        (Some(Sign::NoSign), sign) | (sign, Some(Sign::NoSign)) => sign,
                        (Some(Sign::Plus), Some(Sign::Plus)) => Some(Sign::Plus),
                        (Some(Sign::Minus), Some(Sign::Minus)) => Some(Sign::Minus),
                        _ => None,
                    }
                    .or_else(|| node.exact_positive_exp_difference_sign());
                    store_exact_sign(node, result);
                    values.push(result);
                }
                Frame::FinishMultiply(node) => {
                    let right = values.pop().expect("multiply rhs sign should exist");
                    let left = values.pop().expect("multiply lhs sign should exist");
                    let result = match (left, right) {
                        (Some(Sign::NoSign), _) | (_, Some(Sign::NoSign)) => {
                            node.has_finite_real_certificate().then_some(Sign::NoSign)
                        }
                        (Some(Sign::Plus), Some(Sign::Plus))
                        | (Some(Sign::Minus), Some(Sign::Minus)) => Some(Sign::Plus),
                        (Some(Sign::Plus), Some(Sign::Minus))
                        | (Some(Sign::Minus), Some(Sign::Plus)) => Some(Sign::Minus),
                        _ => None,
                    };
                    store_exact_sign(node, result);
                    values.push(result);
                }
            }
        }

        let mut result = values
            .pop()
            .expect("exact sign evaluation should produce a result");
        if result.is_none() {
            result = self.exact_quadratic_surd_sign();
        }
        store_exact_sign(self, result);
        result
    }

    fn exact_quadratic_surd_sign(&self) -> Option<Sign> {
        let work = SymbolicWork::current();
        let (rational, scale, radicand) = self.exact_quadratic_surd_parts()?;
        if scale.sign() == Sign::NoSign {
            return Some(rational.sign());
        }
        if rational.sign() == Sign::NoSign || rational.sign() == scale.sign() {
            return Some(scale.sign());
        }
        work.binary(&rational, &rational)?;
        let rational_square = &rational * &rational;
        work.binary(&scale, &scale)?;
        let scale_square = &scale * &scale;
        let radicand = radicand?;
        work.binary(&scale_square, &radicand)?;
        let radical_square = scale_square * radicand;
        work.binary(&rational_square, &radical_square)?;
        Some(
            match rational_square
                .partial_cmp(&radical_square)
                .expect("finite exact rationals are totally ordered")
            {
                Ordering::Less => scale.sign(),
                Ordering::Equal => Sign::NoSign,
                Ordering::Greater => rational.sign(),
            },
        )
    }

    pub(crate) fn exact_pure_quadratic_surd(&self) -> Option<(Rational, Rational)> {
        let (rational, scale, radicand) = self.exact_quadratic_surd_parts()?;
        if rational.sign() != Sign::NoSign {
            return None;
        }
        Some((scale, radicand?))
    }

    pub(crate) fn exact_quadratic_surd_parts(
        &self,
    ) -> Option<(Rational, Rational, Option<Rational>)> {
        // Project the shared bounded normal form after cancellation. Requiring
        // every intermediate expression to use one radical would miss exact
        // quadratic values assembled from independent geometric directions.
        let work = SymbolicWork::current();
        let polynomial = self.pi_laurent_polynomial(64)?;
        let value = match polynomial.terms.as_slice() {
            [] => (Rational::zero(), Rational::zero(), None),
            [(0, coefficient)] if coefficient.atoms.is_empty() => {
                work.read(&coefficient.rational)?;
                match coefficient.radicals.as_slice() {
                    [] => (coefficient.rational.clone(), Rational::zero(), None),
                    [(radicand, scale)] => {
                        work.read(scale)?;
                        work.read(radicand)?;
                        (
                            coefficient.rational.clone(),
                            scale.clone(),
                            Some(radicand.clone()),
                        )
                    }
                    _ => return None,
                }
            }
            _ => return None,
        };
        crate::trace_dispatch!("computable", "structural", "quadratic-surd");
        Some(value)
    }

    #[cfg(test)]
    pub(super) fn planning_msd(&self) -> Option<Option<Precision>> {
        self.cheap_bound().planning_msd()
    }

    pub(crate) fn planning_sign_and_msd(&self) -> (Option<Sign>, Option<Option<Precision>>) {
        let bound = self.cheap_bound();
        (bound.known_sign(), bound.planning_msd())
    }

    pub(crate) fn certified_sign_and_msd(&self) -> (Option<Sign>, Option<Option<Precision>>) {
        // An upper magnitude bound does not supply the lower bound that some
        // error-sensitive precision plans need. Require an exact binade here
        // or let the caller obtain a fresh approximation.
        self.cheap_bound().certified_sign_and_msd()
    }

    pub(crate) fn exact_rational(&self) -> Option<Rational> {
        // Only exact leaf nodes are exposed here. Keeping this narrow prevents
        // constructor shortcuts from accidentally forcing approximation of a
        // composite just to discover that it is not rational.
        match &self.internal.approximation {
            Approximation::One => Some(Rational::one()),
            Approximation::Int(n) => Some(Rational::from_bigint(n.clone())),
            Approximation::Ratio(r) => Some(r.clone()),
            _ => None,
        }
    }

    /// Recognize rational arithmetic and positive-root identities without
    /// cancelling opaque operands. In particular, x-x is not a domain proof
    /// when x may be undefined. Traversal and coefficient growth are capped.
    pub(crate) fn bounded_rational_value(&self) -> Option<Rational> {
        const MAX_BITS: u64 = 4_096;
        fn has_square_root_form(node: &Computable) -> bool {
            matches!(
                node.internal.approximation,
                Approximation::Sqrt(_)
                    | Approximation::Constant(SharedConstant::Sqrt2 | SharedConstant::Sqrt3)
            )
        }
        fn square_root_radicand(
            node: &Computable,
            depth: u8,
            work: &mut u8,
            meter: SymbolicWork,
        ) -> Option<Rational> {
            if depth == 0 || *work == 0 {
                return None;
            }
            meter.visit()?;
            *work -= 1;
            let value = match &node.internal.approximation {
                Approximation::Sqrt(child) => visit(child, depth - 1, work, meter)?,
                Approximation::Constant(SharedConstant::Sqrt2) => Rational::new(2),
                Approximation::Constant(SharedConstant::Sqrt3) => Rational::new(3),
                _ => return None,
            };
            (value.sign() != Sign::Minus).then_some(value)
        }
        fn visit(
            node: &Computable,
            depth: u8,
            work: &mut u8,
            meter: SymbolicWork,
        ) -> Option<Rational> {
            if depth == 0 || *work == 0 {
                return None;
            }
            meter.visit()?;
            *work -= 1;
            let value = match &node.internal.approximation {
                Approximation::One => Rational::one(),
                Approximation::Int(n) if n.magnitude().bits() <= MAX_BITS => {
                    meter.integer(n)?;
                    Rational::from_bigint(n.clone())
                }
                Approximation::Ratio(r) => meter.bounded_rational(r, MAX_BITS)??.clone(),
                Approximation::Negate(child) => {
                    let value = visit(child, depth - 1, work, meter)?;
                    meter.read(&value)?;
                    -value
                }
                Approximation::Inverse(child) => {
                    let value = visit(child, depth - 1, work, meter)?;
                    meter.read(&value)?;
                    value.inverse().ok()?
                }
                Approximation::Sqrt(child) => {
                    let value = visit(child, depth - 1, work, meter)?;
                    meter.root(&value)?;
                    value.perfect_nth_root(2)?
                }
                Approximation::NthRoot(child, degree)
                    if (3..=Computable::MAX_DIRECT_NTH_ROOT_DEGREE).contains(degree) =>
                {
                    let value = visit(child, depth - 1, work, meter)?;
                    // This node represents a positive root, including odd
                    // degrees. Negative radicands cannot be a domain witness.
                    if value.sign() == Sign::Minus {
                        return None;
                    }
                    meter.root(&value)?;
                    value.perfect_nth_root(*degree)?
                }
                Approximation::Square(child) if has_square_root_form(child) => {
                    square_root_radicand(child, depth - 1, work, meter)?
                }
                Approximation::Square(child) => {
                    let value = visit(child, depth - 1, work, meter)?;
                    meter.read(&value)?;
                    meter.binary(&value, &value)?;
                    value.clone() * value
                }
                Approximation::Add(left, right) => {
                    let left = visit(left, depth - 1, work, meter)?;
                    let right = visit(right, depth - 1, work, meter)?;
                    meter.binary(&left, &right)?;
                    left + right
                }
                Approximation::Multiply(left, right)
                    if has_square_root_form(left) && has_square_root_form(right) =>
                {
                    // Certify both radicands separately before combining them.
                    // sqrt(-1)*sqrt(-1) must never become a real witness.
                    let left = square_root_radicand(left, depth - 1, work, meter)?;
                    let right = square_root_radicand(right, depth - 1, work, meter)?;
                    meter.binary(&left, &right)?;
                    let product = left * right;
                    meter.root(&product)?;
                    product.perfect_nth_root(2)?
                }
                Approximation::Multiply(left, right) => {
                    let left = visit(left, depth - 1, work, meter)?;
                    let right = visit(right, depth - 1, work, meter)?;
                    meter.binary(&left, &right)?;
                    left * right
                }
                Approximation::Offset(child, shift) if shift.unsigned_abs() <= MAX_BITS as u32 => {
                    let value = visit(child, depth - 1, work, meter)?;
                    meter.allocate_bits(u64::from(shift.unsigned_abs()) + 1)?;
                    if *shift < 0 {
                        meter.read(&value)?;
                        value.divide_by_power_of_two(-shift)?
                    } else {
                        let scale = Rational::from_bigint(BigInt::one() << *shift as usize);
                        meter.binary(&value, &scale)?;
                        value * scale
                    }
                }
                _ => return None,
            };
            // Arithmetic operands and shifts are bounded before allocation, so
            // temporary results also have bounded width before this check.
            (value.numerator().bits() <= MAX_BITS && value.denominator().bits() <= MAX_BITS)
                .then_some(value)
        }
        visit(self, 32, &mut 64, SymbolicWork::current())
    }
}
