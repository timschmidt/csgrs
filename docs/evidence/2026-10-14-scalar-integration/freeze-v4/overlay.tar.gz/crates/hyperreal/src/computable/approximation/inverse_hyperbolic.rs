fn acosh_near_one(
    signal: &Option<Signal>,
    c: &Computable,
    p: Precision,
) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Near one, acosh(x) is ln1p((x - 1) + sqrt(x^2 - 1)). Deferring the graph
        // keeps construction cheap for endpoint-adjacent scalar rows without
        // changing the cancellation-avoiding approximation identity.
        let one = Computable::one();
        let shifted = c.clone().add(one.clone().negate());
        let radicand = c.clone().square().add(one.negate());
        shifted
            .add(radicand.sqrt())
            .ln_1p()
            .approx_signal(signal, p)?
    })
}

fn acosh_direct(signal: &Option<Signal>, c: &Computable, p: Precision) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Large acosh inputs use ln(x + sqrt(x^2 - 1)); this node is used by Real
        // construction paths where allocating that graph eagerly is the bottleneck.
        let one = Computable::one();
        let radicand = c.clone().square().add(one.negate());
        c.clone()
            .add(radicand.sqrt())
            .ln()
            .approx_signal(signal, p)?
    })
}

fn asinh_near_zero(
    signal: &Option<Signal>,
    c: &Computable,
    p: Precision,
) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Near zero, asinh(x) is evaluated through ln1p(x + x^2/(sqrt(1+x^2)+1)).
        // This deferred node removes construction overhead but preserves the
        // cancellation-resistant formula used by the public Real path.
        let square = c.clone().square();
        let one = Computable::one();
        let denominator = square.clone().add(one.clone()).sqrt().add(one);
        c.clone()
            .add(square.multiply(denominator.inverse()))
            .ln_1p()
            .approx_signal(signal, p)?
    })
}

fn asinh_direct(signal: &Option<Signal>, c: &Computable, p: Precision) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Large asinh inputs use ln(x + sqrt(1+x^2)); deferring the direct identity
        // keeps scalar construction from allocating the sqrt/log graph eagerly.
        let radicand = c.clone().square().add(Computable::one());
        c.clone()
            .add(radicand.sqrt())
            .ln()
            .approx_signal(signal, p)?
    })
}

fn asinh_outside_series(
    signal: &Option<Signal>,
    c: &Computable,
    p: Precision,
) -> Result<BigInt, Problem> {
    // The failed half-unit range check separates the input from zero. Odd
    // symmetry keeps the logarithm identity away from negative cancellation.
    let negative = c.approx_signal(signal, -4)?.sign() == Sign::Minus;
    let positive = if negative {
        c.clone().negate()
    } else {
        c.clone()
    };
    let approximation = asinh_direct(signal, &positive, p.min(0))?;
    // asinh is unbounded. Coarse requests need a value before rescaling, also
    // keeping i32::MAX out of the logarithm's internal precision arithmetic.
    let approximation = if p > 0 {
        scale(approximation, -p)
    } else {
        approximation
    };
    Ok(if negative {
        -approximation
    } else {
        approximation
    })
}

// Approximate asinh(c) for small |c|.
fn asinh_computable(
    signal: &Option<Signal>,
    c: &Computable,
    p: Precision,
) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Dedicated tiny-argument asinh series. It avoids constructing the generic
        // ln(x + sqrt(1+x^2)) or ln1p expression for exact tiny rational inputs.
        if !c.inverse_series_argument_at_most_half(signal)? {
            return asinh_outside_series(signal, c, p);
        }
        if p >= 1 {
            return Ok(Zero::zero());
        }

        let iterations_needed: i32 = -p / 2 + 4;
        let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
        let op_prec = calc_precision - 3;
        let op_appr = c.approx_signal(signal, op_prec)?;
        let op_squared = scale(&op_appr * &op_appr, op_prec);

        // This is the asin recurrence with alternating sign:
        // asinh(x) = x - x^3/6 + 3x^5/40 - ...
        let max_trunc_error = BigUint::one()
            << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
        let mut current_term = scale(op_appr, op_prec - calc_precision);
        let mut sum = current_term.clone();
        let mut n = 0_i32;

        while current_term.magnitude() > &max_trunc_error {
            if should_stop(signal) {
                return Err(Problem::Exhausted);
            }
            n += 1;
            current_term = scale(current_term * &op_squared, op_prec);
            let (numerator, denominator) = inverse_sine_series_coefficients(n);
            current_term *= numerator;
            current_term /= denominator;
            current_term = -current_term;
            sum += &current_term;
        }

        scale(sum, calc_precision - p)
    })
}

fn asinh_rational(signal: &Option<Signal>, r: &Rational, p: Precision) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Direct exact-rational variant of the tiny asinh series. It is the same
        // recurrence as `asinh_computable`, but it feeds the stored Rational
        // straight to the final precision request instead of allocating a temporary
        // Ratio node and child cache.
        if should_stop(signal) {
            return Err(Problem::Exhausted);
        }
        if r.compare_magnitude(&HALF_RATIONAL) == core::cmp::Ordering::Greater {
            return asinh_outside_series(signal, &Computable::rational(r.clone()), p);
        }
        if p >= 1 {
            return Ok(Zero::zero());
        }

        let iterations_needed: i32 = -p / 2 + 4;
        let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
        let op_prec = calc_precision - 3;
        let op_appr = ratio(r, op_prec)?;
        let op_squared = scale(&op_appr * &op_appr, op_prec);

        let max_trunc_error = BigUint::one()
            << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
        let mut current_term = scale(op_appr, op_prec - calc_precision);
        let mut sum = current_term.clone();
        let mut n = 0_i32;

        while current_term.magnitude() > &max_trunc_error {
            if should_stop(signal) {
                return Err(Problem::Exhausted);
            }
            n += 1;
            current_term = scale(current_term * &op_squared, op_prec);
            let (numerator, denominator) = inverse_sine_series_coefficients(n);
            current_term *= numerator;
            current_term /= denominator;
            current_term = -current_term;
            sum += &current_term;
        }

        scale(sum, calc_precision - p)
    })
}

fn atanh_direct(signal: &Option<Signal>, c: &Computable, p: Precision) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;
    c.certify_unit_interval(signal, false)?;
    if p >= 1 {
        // The function is unbounded near +/-1. Obtain a unit-scale value before
        // coarsening, also avoiding overflow in the transform at i32::MAX.
        return Ok(scale(atanh_direct(signal, c, 0)?, -p));
    }

    Ok({
        // Endpoint atanh construction should not eagerly allocate the full exact
        // log-ratio graph. Approximation still uses the stable identity
        // atanh(x) = 1/2 * ln((1+x)/(1-x)).
        let one = Computable::one();
        let numerator = one.clone().add(c.clone());
        let denominator = one.add(c.clone().negate());
        numerator
            .multiply(denominator.inverse())
            .ln()
            .multiply(Computable::rational(HALF_RATIONAL.clone()))
            .approx_signal(signal, p)?
    })
}

// Approximate atanh(c) for small |c|.
fn atanh_computable(
    signal: &Option<Signal>,
    c: &Computable,
    p: Precision,
) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        // Dedicated tiny-argument atanh series. Prove its domain before both the
        // fixed error budget and the coarse-zero shortcut, including stored nodes.
        if should_stop(signal) {
            return Err(Problem::Exhausted);
        }
        if p >= 1 {
            if c.inverse_series_argument_is_small(signal)? {
                return Ok(Zero::zero());
            }
            return atanh_direct(signal, c, p);
        }

        let iterations_needed: i32 = -p / 2 + 4;
        let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
        let op_prec = calc_precision - 3;
        let op_appr = c.approx_signal(signal, op_prec)?;
        // The sample is already required by the series. bits(|a|) <= -op_prec-3
        // leaves one integer unit for its error and proves |c| <= 1/8.
        if op_appr.magnitude().bits()
            > u64::try_from(-op_prec - 3).expect("tiny-series scale is positive")
        {
            if should_stop(signal) {
                return Err(Problem::Exhausted);
            }
            return atanh_direct(signal, c, p);
        }
        let op_squared = scale(&op_appr * &op_appr, op_prec);

        // Borrowed magnitude checks matter here because tiny inverse-hyperbolic
        // benches run many short series from cold caches.
        let max_trunc_error = BigUint::one()
            << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
        let mut current_power = scale(op_appr, op_prec - calc_precision);
        let mut current_term = current_power.clone();
        let mut sum = current_term.clone();
        let mut n = 1_i32;

        while current_term.magnitude() > &max_trunc_error {
            if should_stop(signal) {
                return Err(Problem::Exhausted);
            }
            n += 2;
            current_power = scale(current_power * &op_squared, op_prec);
            current_term = &current_power / n;
            sum += &current_term;
        }

        scale(sum, calc_precision - p)
    })
}

fn atanh_rational(signal: &Option<Signal>, r: &Rational, p: Precision) -> Result<BigInt, Problem> {
    let p = crate::computable::checked_approximation_precision(p)?;

    Ok({
        if r.numerator() >= r.denominator() {
            return Err(Problem::NotANumber);
        }
        if r.sign() == Sign::NoSign {
            return Ok(BigInt::zero());
        }
        // Raw serialized inputs can bypass the tiny-series constructor. Prove
        // |r| < 1/8 before its error budget and coarse-zero shortcut.
        if r.msd_exact().is_none_or(|msd| msd >= -3) {
            let argument = Computable::rational(r.clone());
            if p >= 1 {
                // Coarsen a complete unit-scale value rather than shifting
                // an extreme precision through the logarithm reduction graph.
                return Ok(scale(atanh_direct(signal, &argument, 0)?, -p));
            }
            return atanh_direct(signal, &argument, p);
        }
        // Direct exact-rational variant of the tiny atanh series. This mirrors the
        // direct rational trig kernels: preserve the symbolic rational payload and
        // round only once at the requested working precision.
        if p >= 1 {
            return Ok(Zero::zero());
        }

        let iterations_needed: i32 = -p / 2 + 4;
        let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
        let op_prec = calc_precision - 3;
        let op_appr = ratio(r, op_prec)?;
        let op_squared = scale(&op_appr * &op_appr, op_prec);

        let max_trunc_error = BigUint::one()
            << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
        let mut current_power = scale(op_appr, op_prec - calc_precision);
        let mut current_term = current_power.clone();
        let mut sum = current_term.clone();
        let mut n = 1_i32;

        while current_term.magnitude() > &max_trunc_error {
            if should_stop(signal) {
                return Err(Problem::Exhausted);
            }
            n += 2;
            current_power = scale(current_power * &op_squared, op_prec);
            current_term = &current_power / n;
            sum += &current_term;
        }

        scale(sum, calc_precision - p)
    })
}
