//! Core computable expression graph.
//!
//! This facade keeps the shared imports and includes semantic implementation
//! slices. The included files remain in one module so private graph/cache
//! invariants and hot constructor rewrites keep their original visibility.

use crate::computable::approximation::{
    Approximation, LinearCombination3, NormalQuantileData, SharedConstant,
};
use crate::{MagnitudeBits, Problem, Rational, RealSign, RealStructuralFacts, ZeroKnowledge};
use core::cmp::Ordering;
use num::Signed;
use num::{BigInt, BigUint, bigint::Sign};
use num::{One, Zero};
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};
use std::{
    collections::HashSet,
    ops::{Deref, Neg},
    sync::{Arc, LazyLock},
};

include!("node/bounds.rs");
include!("node/evaluation_budget.rs");
include!("node/symbolic_work.rs");
include!("node/representation.rs");
include!("node/primitive_constructors.rs");
include!("node/structural_analysis.rs");
include!("node/approximation_bound.rs");
include!("node/domain_certificates.rs");
include!("node/trig_lattice.rs");
include!("node/trig_periodic.rs");
include!("node/trig_operands.rs");
include!("node/trig_domain.rs");
include!("node/domain_validation.rs");
include!("node/exp_relation.rs");
include!("node/exp_relation_reuse.rs");
include!("node/exp_trig.rs");
include!("node/logarithms.rs");
include!("node/roots_inverse_hyperbolic.rs");
include!("node/algebra.rs");
include!("node/quadratic_tower.rs");
include!("node/radical_tower.rs");
include!("node/approximation_queries.rs");
include!("node/scale.rs");
include!("node/tests.rs");
include!("node/exp_relation_tests.rs");
include!("node/exp_relation_reuse_tests.rs");
include!("node/linear_demand_tests.rs");
include!("node/fractional_separation_tests.rs");
include!("node/cache_rescale_tests.rs");
include!("node/precision_boundary_tests.rs");
include!("node/magnitude_boundary_tests.rs");
include!("node/certified_planning_tests.rs");

include!("node/evaluation_failure_tests.rs");
include!("node/algebra_domain_tests.rs");
include!("node/cache_magnitude_tests.rs");
include!("node/cache_publication_tests.rs");
include!("node/magnitude_upper_bound_tests.rs");
include!("node/scaled_lower_magnitude_tests.rs");
include!("node/private_kernel_domain_tests.rs");
include!("node/private_trig_range_tests.rs");
include!("node/trig_lattice_tests.rs");
include!("node/trig_periodic_tests.rs");
include!("node/trig_operands_tests.rs");
include!("node/evaluation_budget_tests.rs");
include!("node/algebraic_budget_tests.rs");
include!("node/normal_form_budget_tests.rs");
include!("node/inverse_trig_budget_tests.rs");
include!("node/algebraic_leaf_tests.rs");
include!("node/inverse_trig_dag_tests.rs");
include!("node/structural_comparison_budget_tests.rs");
include!("node/algebraic_preflight_tests.rs");
include!("node/rational_preflight_tests.rs");
include!("node/inverse_constructor_probe_tests.rs");
include!("node/inverse_constructor_preflight_tests.rs");
include!("node/integer_scale_tests.rs");
include!("node/log_range_probe_tests.rs");
include!("node/domain_sign_tests.rs");
include!("node/domain_bound_tests.rs");
