    fn circular_support_relation(
        &mut self,
        first_curve: &Curve2,
        second_curve: &Curve2,
        policy: &CurveContext,
    ) -> ExactCurveResult<Option<CircleCircleRelation>> {
        let (Some(first), Some(second)) = (
            retained_curve_circular_support(first_curve),
            retained_curve_circular_support(second_curve),
        ) else {
            return Ok(None);
        };
        // Small batches do not create keys or initialize an unused index.
        let key = if self.circular_support_relations.len() >= 32 {
            ExactCircularSupportPairKey::new(first, second)
        } else {
            None
        };
        if key.is_some() && self.circular_support_index.is_none() {
            self.circular_support_index = Some(CircularSupportIndex::from_relations(
                &self.circular_support_relations,
            ));
        }
        let matches = |position: usize| {
            let entry = &self.circular_support_relations[position];
            entry.first.center == *first.center
                && entry.first.radius_squared == *first.radius_squared
                && entry.second.center == *second.center
                && entry.second.radius_squared == *second.radius_squared
        };
        let retained = if let (Some(index), Some(key)) = (&self.circular_support_index, &key) {
            let indexed = index.exact.get(key).copied();
            // Unindexed entries retain their original equality proof and
            // priority over a later indexed witness, including after warming.
            index
                .unkeyed
                .iter()
                .copied()
                .take_while(|&position| indexed.is_none_or(|cached| position < cached))
                .find(|&position| matches(position))
                .or(indexed)
        } else {
            (0..self.circular_support_relations.len()).find(|&position| matches(position))
        };
        if let Some(position) = retained {
            return Ok(Some(
                self.circular_support_relations[position].relation.clone(),
            ));
        }
        let relation = circle_relation_from_supports(
            first.center,
            first.radius_squared,
            second.center,
            second.radius_squared,
            policy,
        )
        .map_err(|cause| {
            ExactCurveError::invalid(CurveOperation2::Intersection, first_curve.family(), cause)
        })?;
        let position = self.circular_support_relations.len();
        self.circular_support_relations
            .push(CircularSupportRelationCacheEntry {
                first: RationalQuadraticCircle2 {
                    center: first.center.clone(),
                    radius_squared: first.radius_squared.clone(),
                    tangent_contacts: None,
                },
                second: RationalQuadraticCircle2 {
                    center: second.center.clone(),
                    radius_squared: second.radius_squared.clone(),
                    tangent_contacts: None,
                },
                relation: relation.clone(),
            });
        if let Some(index) = &mut self.circular_support_index {
            if let Some(key) = key {
                index.exact.entry(key).or_insert(position);
            } else {
                index.unkeyed.push(position);
            }
        }
        Ok(Some(relation))
    }
