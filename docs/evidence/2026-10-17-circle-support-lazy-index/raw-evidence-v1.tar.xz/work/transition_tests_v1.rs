
#[test]
fn mixed_supports_keep_exact_witnesses_when_a_larger_batch_changes_lookup() {
    use num::BigInt;

    let result = crate::evaluate_under(PredicatePolicy::STRICT, || {
        let large = Real::from(hyperreal::Rational::from_bigint(
            (BigInt::from(1_u8) << 1_048_576_usize) + BigInt::from(3_u8),
        ));
        let centers = (0..80)
            .map(|n| match n % 19 {
                0 => Real::pi() + Real::from(n * 32),
                1 => &large + Real::from(n * 32),
                _ => Real::from(n * 32),
            })
            .collect::<Vec<_>>();
        let mut cache = CurveIntersectionBatchCache::default();
        for x in &centers {
            secant(
                query(
                    &mut cache,
                    &circle(x.clone(), Real::from(5)),
                    &circle(x + Real::from(6), Real::from(5)),
                ),
                x + Real::from(3),
                Real::from(4),
            );
        }
        assert_eq!(cache.circular_support_relations.len(), centers.len());
        for x in centers.iter().rev() {
            secant(
                query(
                    &mut cache,
                    &circle(x.clone(), Real::from(5)),
                    &circle(x + Real::from(6), Real::from(5)),
                ),
                x + Real::from(3),
                Real::from(4),
            );
        }
        assert_eq!(cache.circular_support_relations.len(), centers.len());
        for x in [&centers[0], &centers[1], &centers[79]] {
            assert!(matches!(
                query(
                    &mut cache,
                    &circle(x.clone(), Real::from(5)),
                    &circle(x + Real::from(11), Real::from(5)),
                ),
                CircleCircleRelation::Disjoint
            ));
            secant(
                query(
                    &mut cache,
                    &circle(x.clone(), Real::from(5)),
                    &circle(x + Real::from(6), Real::from(5)),
                ),
                x + Real::from(3),
                Real::from(4),
            );
        }
        assert_eq!(cache.circular_support_relations.len(), centers.len() + 3);
    });
    assert!(result.certified().is_some());
}
