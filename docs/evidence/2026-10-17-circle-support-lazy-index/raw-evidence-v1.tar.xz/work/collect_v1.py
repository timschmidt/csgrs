"""Retain exact evidence bytes in a verified archive without altering originals."""
import gzip
import hashlib
import json
import tarfile
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import RUNTIME, W, dump, read, sha

decision = read(W / 'decision-v1.json')
for name in ['reproduction-v1', 'build-v1', 'cost-preflight-v1', 'cost-matched-v1',
             'support-cost-preflight-v1', 'support-cost-matched-v1', 'heap-v1',
             'corpus-v1', 'all-feature-library-v1', 'proposal-v1', 'shared-aggregate-v1']:
    result = read(RUNTIME / name / 'result.json')
    assert result['complete'] and result['output_closed']
    assert not result.get('command_failures', result.get('failures', []))
assert all(sha(path) == digest for path, digest in decision['input_sha256'].items())
output = RUNTIME / 'collection-v1'
assert not output.exists()
members, physical_only = {}, {}
for root, prefix in [(W, 'work'), (RUNTIME, 'run')]:
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in ['baseline-source', 'candidate-source', 'runtime-source-mirror']
               for part in relative.parts):
            continue
        with path.open('rb') as stream:
            executable = stream.read(4) == b'\x7fELF'
        if executable or path.suffix in ['.rmeta', '.zst']:
            physical_only[str(path)] = {'sha256': sha(path), 'bytes': path.stat().st_size}
            continue
        assert not path.is_symlink()
        members[prefix + '/' + str(relative)] = {
            'original': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
output.mkdir()
archive = output / 'raw-evidence-v1.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as container:
    for name, item in members.items():
        path = Path(item['original'])
        info = tarfile.TarInfo(name)
        info.size = item['bytes']
        info.mode = 0o644
        info.mtime = 0
        with path.open('rb') as stream:
            container.addfile(info, stream)
verified = set()
with tarfile.open(archive, 'r:xz') as container:
    for info in container:
        assert info.isfile() and info.name in members and info.name not in verified
        item = members[info.name]
        assert info.size == item['bytes']
        with container.extractfile(info) as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == item['sha256']
        verified.add(info.name)
assert verified == set(members)
assert all(sha(item['original']) == item['sha256'] for item in members.values())
assert all(sha(path) == item['sha256'] for path, item in physical_only.items())
with gzip.open(output / 'archive-members-v1.json.gz', 'wt') as stream:
    json.dump(members, stream, sort_keys=True)
dump(output / 'result.json', {
    'complete': True, 'output_closed': True,
    'archive': str(archive), 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
    'archive_members': str(output / 'archive-members-v1.json.gz'),
    'archive_members_sha256': sha(output / 'archive-members-v1.json.gz'),
    'member_count': len(members), 'uncompressed_member_bytes': sum(v['bytes'] for v in members.values()),
    'all_member_bytes_independently_verified': True, 'original_files_unchanged': True,
    'archive_metadata_is_normalized': True, 'metadata_roundtrip_claimed': False,
    'physical_artifacts_not_duplicated_in_git': physical_only,
    'excluded_source_mirrors_remain_physically_retained': True,
    'input_sha256': {str(path): sha(path) for path in [Path(__file__), W / 'decision-v1.json']},
    'source_changes_applied': False, 'cache_admitted': False, 'full_plan_complete': False,
})
print(json.dumps({'members': len(members), 'raw_bytes': sum(v['bytes'] for v in members.values()),
                  'archive_bytes': archive.stat().st_size, 'every_member_verified': True}))
