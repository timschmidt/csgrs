"""Reproduce the rejected small-batch cost, then build a lazy isolated index."""
import gzip
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, resources, run, sha, violation

base = 'f638d2df303d68103b09c3179c78601642879bf1'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == base
subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--cached', '--quiet'], cwd=ROOT, check=True)
assert violation(resources()) is None
old = Path('/run/user/1000/csgrs-circle-support-small-batches-v1/build-v1')
prior, previous = read(old / 'protocol.json'), read(old / 'result.json')
assert previous['complete'] and previous['output_closed'] and not previous['command_failures']
assert subprocess.check_output(['rustc', '-vV'], text=True) == prior['rustc']
assert all(sha(path) == digest for path, digest in prior['read_only_dependencies_sha256'].items())
with gzip.open(old / 'main-input-hashes.json.gz', 'rt') as stream:
    old_main = json.load(stream)
main = {path: sha(ROOT / path) for path in old_main}
assert {path for path in main if main[path] != old_main[path]} == {'docs/properties-status.json'}
repro = RUNTIME / 'reproduction-v1'
repro.mkdir(exist_ok=False)
reproduced = []
dump(repro / 'protocol.json', {'base_commit': base, 'new_prototype_not_modified': True,
    'current_production_equivalent_to_retained_baseline': True,
    'input_sha256': {str(path): sha(path) for path in [Path(__file__), W / 'runner_v1.py',
        W / 'contract-v1.md', old / 'protocol.json', old / 'result.json']},
    'binaries': previous['binaries'], 'scope': 'One fresh observation; does not replace the seven-repetition E43 decision.'})
for label, binary in previous['binaries'].items():
    assert sha(binary['path']) == binary['sha256']
    row = run(repro, label, [binary['path'],
        'curve_intersection::circle_support_small_batch_probe::small_batch_complete_cost',
        '--exact', '--ignored', '--nocapture', '--test-threads=1'], repro,
        {'CIRCLE_SMALL_BATCH_N': '8'})
    reproduced.append(row)
    assert row['exit_code'] == 0
    assert 'CIRCLE_SMALL_CERTAINTY Certified' in (repro / (label + '.stdout')).read_text()
dump(repro / 'commands.json', reproduced)
dump(repro / 'result.json', {'complete': True, 'output_closed': True,
    'command_failures': [], 'main_production_equivalent_to_e43_baseline': True})

output = RUNTIME / 'build-v1'
output.mkdir(exist_ok=False)
pins = {str(path): sha(path) for path in [Path(__file__), W / 'runner_v1.py',
    W / 'contract-v1.md', W / 'lazy_index_type_v1.rs', W / 'lazy_lookup_v1.rs',
    W / 'transition_tests_v1.rs', old / 'protocol.json', old / 'result.json', repro / 'result.json']}
sources, commands = {}, []
intersection = 'crates/hypercurve/src/curve_intersection.rs'
for label, description in prior['sources'].items():
    source = output / (label + '-source')
    source.mkdir()
    for path, digest in description['sha256'].items():
        original = Path(description['path']) / path
        assert sha(original) == digest
        dest = source / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, dest)
    tests = source / 'crates/hypercurve/src/circle_support_cache_tests.rs'
    tests.write_text(tests.read_text() + (W / 'transition_tests_v1.rs').read_text())
    probe = source / 'crates/hypercurve/src/circle_support_small_batch_probe.rs'
    text = probe.read_text()
    old_sizes = '[1, 4, 8, 9, 16, 128]'
    assert text.count(old_sizes) == 1
    probe.write_text(text.replace(old_sizes, '[1, 4, 8, 9, 16, 31, 32, 33, 64, 128]'))
    path = source / intersection
    if label == 'candidate':
        text = path.read_text()
        old_fields = '''    exact_circular_support_index: HashMap<ExactCircularSupportPairKey, usize>,
    unkeyed_circular_support_relations: Vec<usize>,'''
        assert text.count(old_fields) == 1
        text = text.replace(old_fields, '    circular_support_index: Option<CircularSupportIndex>,')
        anchor = '#[derive(Debug)]\nstruct CircularPointParameterCacheEntry {'
        assert text.count(anchor) == 1
        text = text.replace(anchor, (W / 'lazy_index_type_v1.rs').read_text() + '\n' + anchor)
        start = text.index('    fn circular_support_relation(')
        end = text.index('\n    fn circular_point_parameters(', start)
        text = text[:start] + (W / 'lazy_lookup_v1.rs').read_text() + text[end:]
        path.write_text(text)
        readme = source / 'crates/hypercurve/README.md'
        docs = readme.read_text()
        old_docs = '''  synchronous operation under one predicate policy. Batches of up to eight
  retained entries use ordered equality lookup. Larger batches index exact
  rational centers and squared radii when their scalar storage class is not
  `VeryLarge`; symbolic and very large supports retain ordered equality lookup.
'''
        new_docs = '''  synchronous operation under one predicate policy. Small batches use ordered
  equality lookup without building keys or an index. Once at least 32 relations
  are retained, an eligible query lazily indexes the retained exact rational
  centers and squared radii whose scalar storage class is not `VeryLarge`.
  Symbolic and very large supports retain ordered equality lookup.
'''
        assert docs.count(old_docs) == 1
        readme.write_text(docs.replace(old_docs, new_docs))
    commands.append(run(output, label + '-format', ['rustfmt', '--edition', '2024',
        '--config', 'skip_children=true', str(path), str(tests), str(probe)], source))
    assert commands[-1]['exit_code'] == 0
    sources[label] = {'path': str(source), 'sha256': {
        str(path.relative_to(source)): sha(path) for path in source.rglob('*') if path.is_file()}}
for relative in ['crates/hypercurve/src/circle_support_cache_tests.rs',
                 'crates/hypercurve/src/circle_support_small_batch_probe.rs',
                 'crates/hypercurve/src/circle_support_cost_probe.rs',
                 'crates/hypercurve/src/circle_support_coefficient_probe.rs']:
    assert sha(Path(sources['baseline']['path']) / relative) == sha(Path(sources['candidate']['path']) / relative)
for label in sources:
    for relative in [intersection, 'crates/hypercurve/src/circle_support_cache_tests.rs',
                     'crates/hypercurve/src/circle_support_small_batch_probe.rs', 'crates/hypercurve/README.md']:
        result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--',
            str(Path(prior['sources'][label]['path']) / relative),
            str(Path(sources[label]['path']) / relative)], capture_output=True)
        assert result.returncode in [0, 1]
        (output / (label + '-' + Path(relative).name + '.patch')).write_bytes(result.stdout)
with gzip.open(output / 'main-input-hashes.json.gz', 'wt') as stream:
    json.dump(main, stream, sort_keys=True)
dump(output / 'protocol.json', {
    'base_commit': base, 'sources': sources, 'input_sha256': pins,
    'read_only_dependencies_sha256': prior['read_only_dependencies_sha256'],
    'externs': prior['externs'], 'rustc': prior['rustc'], 'hardware': prior['hardware'],
    'features': prior['features'], 'main_input_hashes_sha256': sha(output / 'main-input-hashes.json.gz'),
    'same_tests_and_diagnostics': True, 'completed_targets_reopened': False,
    'external_timeout_seconds': 1800, 'address_space_bytes': 8 * 1024**3,
    'initial_resources': resources(),
    'clippy_version': subprocess.check_output(['clippy-driver', '--version'], text=True),
    'direct_clippy_scope': 'No-feature diagnostic test harness, not the full Cargo target/feature/manifest matrix.',
})
binaries = {}
for label, description in sources.items():
    source = Path(description['path'])
    binary = output / (label + '-tests')
    command = ['rustc', '--crate-name', 'hypercurve', '--edition=2024', '--test',
        'crates/hypercurve/src/lib.rs', '-C', 'opt-level=3', '-C', 'codegen-units=16',
        '-C', 'embed-bitcode=no', '-D', 'warnings',
        '-L', 'dependency=' + str(Path(prior['externs']['hyperreal']).parent), '-o', str(binary)]
    for name, path in prior['externs'].items():
        command += ['--extern', name + '=' + path]
    row = run(output, label, command, source)
    commands.append(row)
    dump(output / 'commands.json', commands)
    if row['exit_code'] != 0:
        break
    binaries[label] = {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size}
    commands.append(run(output, label + '-contracts', [str(binary),
        'curve_intersection::circle_support_cache_tests::', '--nocapture', '--test-threads=1'], source))
    lint = command.copy()
    lint[0] = 'clippy-driver'
    lint[lint.index('-o') + 1] = str(output / (label + '.rmeta'))
    lint.append('--emit=metadata')
    commands.append(run(output, label + '-clippy', lint, source))
    dump(output / 'commands.json', commands)
    if any(row['exit_code'] != 0 for row in commands):
        break
assert all(sha(path) == digest for path, digest in (pins | prior['read_only_dependencies_sha256']).items())
assert all(sha(Path(value['path']) / path) == digest
           for value in sources.values() for path, digest in value['sha256'].items())
assert all(sha(Path(value['path']) / path) == digest
           for value in prior['sources'].values() for path, digest in value['sha256'].items())
assert all(sha(ROOT / path) == digest for path, digest in main.items())
failures = [row['name'] for row in commands if row['exit_code'] != 0]
dump(output / 'result.json', {'complete': True, 'output_closed': True, 'binaries': binaries,
    'command_failures': failures, 'main_sources_unchanged': True,
    'frozen_sources_and_dependencies_unchanged': True, 'cache_admitted': False})
raise SystemExit(0 if len(binaries) == 2 and not failures else 101)
