#[derive(Debug, Default)]
struct CircularSupportIndex {
    exact: HashMap<ExactCircularSupportPairKey, usize>,
    unkeyed: Vec<usize>,
}

impl CircularSupportIndex {
    fn from_relations(entries: &[CircularSupportRelationCacheEntry]) -> Self {
        let mut index = Self::default();
        for (position, entry) in entries.iter().enumerate() {
            let first = CircularSupportRef {
                center: &entry.first.center,
                radius_squared: &entry.first.radius_squared,
            };
            let second = CircularSupportRef {
                center: &entry.second.center,
                radius_squared: &entry.second.radius_squared,
            };
            if let Some(key) = ExactCircularSupportPairKey::new(first, second) {
                // Keep the first retained witness if a value has several owners.
                index.exact.entry(key).or_insert(position);
            } else {
                index.unkeyed.push(position);
            }
        }
        index
    }
}
