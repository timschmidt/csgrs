"""Record full local qualification and the measured retention decision."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import RUNTIME, W, dump, read, sha

names = ['reproduction-v1', 'build-v1', 'cost-preflight-v1', 'cost-matched-v1',
         'support-cost-preflight-v1', 'support-cost-matched-v1', 'heap-v1',
         'corpus-v1', 'all-feature-library-v1', 'proposal-v1', 'shared-aggregate-v1']
results = {name: read(RUNTIME / name / 'result.json') for name in names}
assert all(value['complete'] and value['output_closed'] for value in results.values())
assert all(not value.get('command_failures', value.get('failures', [])) for value in results.values())
small = read(RUNTIME / 'cost-matched-v1/summary.json')
support = results['support-cost-matched-v1']
heap = results['heap-v1']
aggregate = results['shared-aggregate-v1']
assert results['cost-matched-v1']['process_samples'] == 140
assert support['process_samples'] == 210 and support['all_exact_rows_equal_and_certified']
assert len(heap['measurements']) == 20 and heap['all_instrumented_witnesses_identical']
assert aggregate['process_samples'] == 112
comparison = aggregate['comparison']
rejected = comparison['predeclared_rejection_criterion_met']
retention = 'rejected' if rejected else 'unadmitted'
status = ('rejected: lazy index retains a stable shared-support warm-hit regression' if rejected else
          'unadmitted: lazy index completes local qualification; measured transition costs and downstream acceptance remain open')
proposal = results['proposal-v1']
assert all(sha(Path(proposal['source']) / path) == digest for path, digest in proposal['proposal_sha256'].items())
library = {}
for name in ['corpus-v1', 'all-feature-library-v1']:
    value = results[name]
    assert value['source_mirror_unchanged'] and not value['property_persistence_warnings']
    assert len(value['test_summaries']) == 1
    state, passed, failed, ignored, measured, filtered = value['test_summaries'][0]
    assert state == 'ok' and failed == measured == filtered == '0'
    library[name] = {'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
group_percent = (comparison['candidate_over_baseline_median'] - 1) * 100
lines = [
    '# Lazy circular-support index qualification', '',
    '**' + status[0].upper() + status[1:] + '.** Production is unchanged. The original',
    '35-file native bundle and both earlier index proposals remain rejected; independently',
    'admitted repairs remain intact. The full properties plan remains open.', '',
    'The owning Hypercurve cache now avoids constructing keys or an index for small',
    'batches. After 32 retained relations, an eligible exact query lazily indexes',
    'prior entries while retaining first-match priority and symbolic/very-large',
    'fallback. This isolated proposal is preserved for review and is not applied.', '',
    'All eight previous cache regressions remain intact. A ninth checks 80 mixed',
    'symbolic, million-bit and ordinary rational supports, rebuilt owners and',
    'changed geometry across activation. Both matched builds pass all nine tests',
    'and strict direct Clippy for the no-feature test harness.', '',
    '| Full library configuration | Passed | Failed | Existing/diagnostic ignored |',
    '| --- | ---: | ---: | ---: |',
]
for name, value in library.items():
    lines.append(f"| {name} | {value['passed']} | {value['failed']} | {value['ignored']} |")
lines += [
    '', 'All-feature diagnostic Clippy also passed. The no-feature corpus preserves',
    'one original manual benchmark and three explicitly executed diagnostic tests;',
    'the all-feature corpus preserves six original manual benchmarks and those',
    'same three diagnostics. No source-mirror mutation or property-persistence',
    'warning occurred. Counts overlap across configurations and do not measure',
    'coverage. Full Cargo target/feature/manifest, integration, docs, examples,',
    'benches, downstream native/report and real-binding gates remain unexecuted.', '',
    'The complete small-batch comparison retained every earlier size and added',
    '31, 32, 33 and 64. All 140 matched processes / 280 phases preserve the independent',
    '3-4-5 oracle, strict certification and exact ordered rows. Each phase performs',
    'at least 65,536 queries with full output materialization and validation.', '',
    '| Pairs | Baseline cold s | Lazy cold s | Baseline warm s | Lazy warm s |',
    '| ---: | ---: | ---: | ---: | ---: |',
]
for count in sorted({row['count'] for row in small}):
    cold = next(row for row in small if row['count'] == count and row['phase'] == 'cold')
    warm = next(row for row in small if row['count'] == count and row['phase'] == 'warm')
    lines.append(f"| {count} | {cold['baseline_median_seconds']:.9f} | {cold['candidate_median_seconds']:.9f} | {warm['baseline_median_seconds']:.9f} | {warm['candidate_median_seconds']:.9f} |")
lines += [
    '', 'The earlier 4/8/9-pair cold regressions are absent in this comparison.',
    'Cold activation at 33 pairs is consistently 9.33% slower, with separated',
    'sample ranges. That remains an unfavorable result despite falling below',
    'the predeclared 10% decisive threshold. The small warm-4 median is also',
    '1.76% higher with overlapping ranges; all raw observations are retained.', '',
    'The original fifteen-case corpus also completed: 210 matched processes /',
    '420 phases, all independently checked and Certified, with exact ordered rows',
    'identical across variants and cache phases. Median phase seconds:', '',
    '| Case | Baseline cold | Lazy cold | Baseline warm | Lazy warm |',
    '| --- | ---: | ---: | ---: | ---: |',
]
comparisons = support['comparisons']
for case, parameter in dict.fromkeys((row['case'], row['parameter']) for row in comparisons):
    cold = next(row for row in comparisons if (row['case'], row['parameter'], row['phase']) == (case, parameter, 'cold'))['median_seconds']
    warm = next(row for row in comparisons if (row['case'], row['parameter'], row['phase']) == (case, parameter, 'warm'))['median_seconds']
    lines.append(f"| {case} {parameter} | {cold['baseline']:.9f} | {cold['candidate']:.9f} | {warm['baseline']:.9f} | {warm['candidate']:.9f} |")
lines += [
    '', 'Single-query and other short phases are diagnostic controls, not precise',
    'general speed factors. The shared-center warm controls suggested extra cost,',
    'so a separately predeclared follow-up reused the exact same binaries and',
    '20,000-query probe after both full-library processes were terminal.', '',
    'It collected seven matched groups of eight fresh processes per variant:',
    '112 processes, each requiring exact Disjoint rows and a strict receipt.',
    'Each group sums 160,000 warm queries. This is an aggregate of independent',
    'fresh-process phases, not one contiguous timing or an end-to-end workload.',
    f"The baseline median group took {comparison['baseline_median_seconds']:.9f} s;",
    f"the candidate took {comparison['candidate_median_seconds']:.9f} s ({group_percent:+.2f}%).",
    f"Positive paired group differences: {comparison['positive_paired_differences']}/7;",
    f"candidate range wholly above baseline: {comparison['candidate_range_above_baseline']}.",
    f"The predeclared rejection rule is {'met' if rejected else 'not met'}.", '',
    'All 20 complete-process allocation observations preserve the uninstrumented',
    'exact witnesses. Instrumented times are excluded from latency comparisons.',
    'One-pair allocation counts now match. Heap results include construction,',
    'queries, validation, output and teardown; they do not isolate cache heap or',
    'establish an internal bound. Diagnostic executable size is not package size.', '',
    '| Workload | Baseline allocations / peak | Lazy allocations / peak |',
    '| --- | --- | --- |',
]
for case, parameter in dict.fromkeys((row['case'], row['parameter']) for row in heap['measurements']):
    values = {row['variant']: row for row in heap['measurements'] if row['case'] == case and row['parameter'] == parameter}
    b, c = values['baseline'], values['candidate']
    lines.append(f"| {case} {parameter} | {b['allocation_calls']} / {b['peak_heap_human_readable']} | {c['allocation_calls']} / {c['peak_heap_human_readable']} |")
lines += [
    '', 'The next implementation hypothesis is an early direct return for small',
    'cache hits before index bookkeeping, combined with a separately evaluated',
    'activation threshold. Neither change is implemented or admitted here.',
    'The existing complete workload gates, hard fixtures and exact-output/report',
    'contracts remain required before reconsidering native track integration.', '',
    'Raw logs, commands, source/feature/dependency/toolchain records, all samples,',
    'helpers and the reviewable proposal are retained in a verified lossless',
    'archive with per-member hashes. Original physical outputs remain untouched.',
    'Only the permitted current_work ledger value changes. The inherited 27,093',
    'missing paths remain disclosed; this is not a whole-history audit, a release',
    'claim or completion of the properties plan.', '',
]
(W / 'progress-v1.md').write_text('\n'.join(lines))
inputs = [Path(__file__), W / 'contract-v1.md', W / 'shared-aggregate-contract-v1.md', W / 'progress-v1.md']
for name in names:
    inputs.extend(path for filename in ['protocol.json', 'commands.json', 'result.json']
                  if (path := RUNTIME / name / filename).is_file())
dump(W / 'decision-v1.json', {
    'complete': True, 'main_parent_commit': read(RUNTIME / 'build-v1/protocol.json')['base_commit'],
    'status': status, 'retention_decision': retention, 'cache_index_admitted': False,
    'source_changes_applied': False, 'implementation_sha256': {},
    'proposal_sha256': proposal['proposal_sha256'],
    'input_sha256': {str(path): sha(path) for path in inputs},
    'library_results': library, 'matched_small_processes': 140, 'matched_support_processes': 210,
    'aggregate_shared_processes': 112, 'aggregate_shared_comparison': comparison,
    'small_cold_33_regression_retained': next(row for row in small if row['count'] == 33 and row['phase'] == 'cold'),
    'allocation_observations': 20, 'diagnostic_binary_sizes': heap['binary_sizes'],
    'native_disposition_preserved': True, 'pending_native_paths_remaining': 0,
    'full_archived_integration_admitted': False, 'native_runtime_admitted': False,
    'full_plan_complete': False,
    'limits': ['Private-kernel comparison; no end-to-end, package-size or isolated-cache-heap claim.',
        'Internal work and heap-byte bounds remain open; experiments use external containment.',
        'Full affected Cargo/downstream/native/report/binding and release validation remains open.',
        '27,093 inherited missing physical artifacts remain disclosed.'],
    'next': ['Evaluate an early direct small-hit return and activation cost without weakening any previous case.',
        'Require all affected downstream, original native workload/report and real binding gates before retention.',
        'Continue every remaining property and target, including ordinary strict completion, provenance and the shipped user path.'],
})
print(status)
