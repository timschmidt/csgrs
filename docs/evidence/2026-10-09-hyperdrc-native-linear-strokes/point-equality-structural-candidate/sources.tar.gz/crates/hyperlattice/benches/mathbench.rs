use std::{cell::Cell, collections::BTreeMap, env, fs, hint::black_box, path::Path};

use criterion::{BatchSize, BenchmarkGroup, Criterion};
use hyperlattice::Rational;
use hyperlattice::{Complex, Matrix3, Matrix4, Real, SignedAxis4, Vector3, Vector4};
use symbolica::domains::float::RealLike;

#[path = "support/benchmark_report.rs"]
#[allow(dead_code)]
mod benchmark_report;

include!("mathbench/engines.rs");
include!("mathbench/fixtures.rs");
include!("mathbench/comparisons.rs");
include!("mathbench/scalar_ops.rs");
include!("mathbench/complex_ops.rs");
include!("mathbench/vector_ops.rs");
include!("mathbench/matrix_ops.rs");
include!("mathbench/borrowed_ops.rs");
include!("mathbench/representation_ops.rs");
include!("mathbench/dispatch_trace.rs");
include!("mathbench/report.rs");

fn initialize_symbolica() {
    if let Some(key) = load_symbolica_license_key() {
        let _ = symbolica::LicenseManager::set_license_key(&key);
    } else if !symbolica::LicenseManager::is_licensed() {
        // Example fallback for users who want the bench to request a hobbyist key:
        // let _ = symbolica::LicenseManager::request_hobbyist_license("YOUR_NAME", "YOUR_EMAIL");
    }

    // In restricted mode, Symbolica builds Rayon’s global pool the first time
    // its workspace is touched. Do that here on the benchmark thread before
    // Criterion or another dependency initializes Rayon first.
    let _ = symbolica::state::Workspace::get_local();
}

fn load_symbolica_license_key() -> Option<String> {
    env::var("SYMBOLICA_LICENSE_KEY")
        .ok()
        .map(|key| key.trim().to_owned())
        .filter(|key| !key.is_empty())
        .or_else(|| {
            fs::read_to_string(".symbolica-license")
                .ok()
                .map(|key| key.trim().to_owned())
                .filter(|key| !key.is_empty())
        })
}

fn main() {
    let args: Vec<String> = env::args().collect();
    // Dispatch trace can be targeted with this comma-separated pattern list so
    // we can measure narrow regression surfaces while avoiding a full trace
    // run during normal iteration.
    // Note: comma-delimited fragments are matched with substring checks by
    // design to keep filter overhead low and stable in benchmark-driver code.
    let trace_filter = args.iter().enumerate().find_map(|(index, arg)| {
        arg.strip_prefix("--trace-dispatch-filter=")
            .map(std::string::ToString::to_string)
            .or_else(|| {
                (arg == "--trace-dispatch-filter" && index + 1 < args.len())
                    .then(|| args[index + 1].clone())
            })
    });

    if args.iter().any(|arg| arg == "--update-benchmarks-md") {
        update_benchmarks_doc();
        update_complete_benchmark_report();
        return;
    }

    let trace_only = args
        .iter()
        .any(|arg| arg == "--write-dispatch-trace-md" || arg == "--dispatch-trace-only");
    if trace_only {
        begin_dispatch_trace_run(trace_filter.as_deref());
    }

    // Restricted Symbolica aborts as a second instance when any child process
    // is spawned while it holds its instance port. Criterion probes for
    // gnuplot when it is built and spawns it for every plot, so build it
    // before initializing Symbolica and plot in process.
    let criterion = Criterion::default().plotting_backend(criterion::PlottingBackend::Plotters);
    let mut criterion = if trace_only {
        criterion.with_filter("$^")
    } else {
        criterion.configure_from_args()
    };
    initialize_symbolica();
    bench_vectors(&mut criterion);
    bench_matrix3(&mut criterion);
    bench_matrix4(&mut criterion);
    bench_scalar_trig(&mut criterion);
    bench_scalar_operations(&mut criterion);
    bench_scalar_sqrt_cases(&mut criterion);
    bench_scalar_hyperbolic_cases(&mut criterion);
    bench_scalar_hyperbolic_f64_cases(&mut criterion);
    bench_large_integer_exp(&mut criterion);
    bench_complex_operations(&mut criterion);
    bench_complex_mul_cold(&mut criterion);
    bench_vector_operations(&mut criterion);
    bench_matrix_operations(&mut criterion);
    bench_targeted_matrix_forms(&mut criterion);
    bench_borrowed_operations(&mut criterion);
    bench_real_representations(&mut criterion);
    if trace_only {
        write_dispatch_trace_report();
    } else {
        criterion.final_summary();
        update_benchmarks_doc();
        update_complete_benchmark_report();
    }
}

fn update_complete_benchmark_report() {
    if benchmark_report::reports_disabled() {
        return;
    }
    match benchmark_report::write_benchmarks_md() {
        Ok(summary) => eprintln!(
            "updated {} from {} Criterion rows, {} comparisons, and {} benchmark suites",
            summary.path.display(),
            summary.rows,
            summary.comparisons,
            summary.suites,
        ),
        Err(error) => eprintln!("failed to update complete benchmark report: {error}"),
    }
}
