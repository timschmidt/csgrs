//! Real-centered linear algebra primitives backed by exact hyperreal arithmetic.
//!
//! `hyperlattice` exposes complex numbers, 2D/3D/4D vectors, and 3x3/4x4
//! matrices whose coordinate and scalar type is [`Real`]. Primitive
//! floating-point values are supported only at API edges: finite `f32`/`f64`
//! inputs are lifted through checked [`Real`] constructors, and
//! [`Real::to_f64_lossy`] provides a named lossy export for rendering, IO, and
//! other external libraries.
//!
//! Most arithmetic that can fail returns [`BlasResult`]. Checked APIs use
//! [`ZeroKnowledge`] and reject both definite zero and unknown-zero divisors,
//! returning [`Problem::UnknownZero`] for the latter.
//!
//! Exactness is carried as conservative structure, not by eagerly
//! canonicalizing every coordinate after every vector or matrix operation.
//! Lattice-owned facts such as sparsity, shared scales, determinant schedules,
//! and transform kinds are non-certifying scheduling metadata until an exact
//! `Real` or predicate route consumes them.
//!
//! # Examples
//!
//! ```
//! use hyperlattice::{Matrix3, Real, Vector3};
//!
//! fn r(value: i32) -> Real {
//!     value.into()
//! }
//!
//! let v = Vector3::new([r(3), r(4), r(0)]);
//! assert_eq!(v.dot(&v), r(25));
//! assert_eq!(Real::sqrt(v.dot(&v)).unwrap(), r(5));
//!
//! let identity = Matrix3::identity();
//! assert_eq!(identity * v.clone(), v);
//! ```

#![warn(missing_docs)]

pub use hyperreal::{
    DomainFacts, DomainStatus, ExpressionDegree, MagnitudeBits, Rational, RationalStorageClass,
    Real, RealExactSetDenominatorKind, RealExactSetDyadicExponentClass, RealExactSetFacts,
    RealExactSetSignPattern, RealSign, RealStructuralFacts, SymbolicDependencyMask, ZeroKnowledge,
    ZeroOneMinusOneStatus,
};

mod trace;
pub(crate) use trace::trace_dispatch;

mod error;
pub use error::{AbortSignal, BlasResult, CheckedBlasResult, Problem};

mod kernels;
pub(crate) use kernels::{ExactRationalKind, RealKernelExt};

mod algebra2;
pub use algebra2::{
    Displacement2Facts, Orient2Facts, ProductSum2Facts, ProductTerm2Facts, displacement2,
    displacement2_facts, dot2, orient2_expr, orient2_expr_facts, positive_product_sum2,
    product_sum2_facts, product_term2_facts, signed_product_sum2, squared_distance2, squared_norm2,
    wedge2,
};

mod scalar;
pub use scalar::{reciprocal_checked, reciprocal_ref_checked};

mod complex;
pub use complex::Complex;

mod vector;
pub use vector::{
    Axis2, SharedScaleVec, SignedAxis2, Vector2, Vector2Facts, Vector3, Vector3Facts, Vector4,
    Vector4Facts, Vector4HomogeneousKind, VectorSharedScaleFacts, VectorSharedScaleView,
};

mod point;
pub use point::{
    Point2, Point2Facts, Point3, Point3Facts, PointSharedScaleFacts, PointSharedScaleView,
};

mod aabb;
pub use aabb::Aabb;

mod projective;
pub use projective::{
    HomogeneousLine3, HomogeneousPoint3, Plane3Coefficients, ProjectivePlane3,
    homogeneous_point_plane_expression, intersect_homogeneous_line_plane, intersect_three_planes,
    intersect_two_planes,
};

mod matrix;
pub use matrix::{
    Matrix3, Matrix3StructuralFacts, Matrix3TransformKind, Matrix4, Matrix4StructuralFacts,
    Matrix4TransformKind, MatrixDeterminantScheduleHint, SignedAxis4,
};

#[cfg(feature = "arbitrary")]
mod arbitrary_impls;
