//! High-voltage, ESD, and protective-interface readiness checks.
//!
//! These checks use parsed KiCad copper, board outline geometry, and net-name
//! heuristics to flag geometry that usually needs safety, surge, or system-ESD
//! review before a production release.
//!
//! Reliability note: high-voltage and ESD intent from net names is suspect for
//! isolated domains, chassis strategies, and untranslated safety rules. Verify
//! against creepage/clearance standards and the system grounding design.

use crate::PcbRegionExt;
use crate::Scalar;

use crate::checks::offset_for_check;
use crate::checks::spatial::CopperSpatialIndex;
use crate::geometry::multipolygon_to_shapes_scalar;
use crate::kicad::{BoardModel, CopperFeature};
use crate::report::{Severity, Violation};

use super::outline::{axis_aligned_outline_rect, feature_bounds_inside_rect_margin};
use super::{difference_for_check, intersection_for_check};

/// Warn when likely high-voltage copper enters the board-edge review band.
///
/// This is a heuristic readiness check over parsed KiCad copper. It uses
/// net-name intent and the parsed board outline to make edge creepage and
/// clearance review visible before release documentation is assembled. On the
/// common rectangular-board path, it first applies the shared strict edge-band
/// bounds predicate, then keeps exact CSG as the reporting decision.
pub fn high_voltage_edge_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    edge_clearance: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("high-voltage-edge-readiness", &[&board.source], || {
        let Some(outline) = &board.board_outline else {
            return Ok(Vec::new());
        };
        let outline_rect = axis_aligned_outline_rect(outline);
        let broad_phase_clearance = scalar_broad_phase_radius(edge_clearance);
        let allowed = match offset_for_check(
            outline,
            -edge_clearance.clone(),
            "high-voltage-edge-readiness",
            vec!["KiCad Edge.Cuts".into()],
        ) {
            Ok(allowed) => allowed,
            Err(uncertainty) => return Ok(vec![*uncertainty]),
        };
        let mut violations = Vec::new();
        let mut skipped_rect_inside = 0_usize;
        let mut exact_difference_count = 0_usize;

        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_voltage_net(net) {
                continue;
            }
            if outline_rect.as_ref().is_some_and(|rect| {
                feature_bounds_inside_rect_margin(feature, rect, broad_phase_clearance)
            }) {
                skipped_rect_inside += 1;
                continue;
            }

            exact_difference_count += 1;
            let intrusion = match difference_for_check(
                &feature.region,
                &allowed,
                "high-voltage-edge-readiness",
                vec![feature.layer.clone(), "KiCad Edge.Cuts".into()],
            ) {
                Ok(intrusion) => intrusion,
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            };
            let shapes =
                multipolygon_to_shapes_scalar(&intrusion.try_to_multipolygon()?, min_area)?;
            if shapes.is_empty() {
                continue;
            }

            violations.push(Violation::new(
            "high-voltage-edge-readiness",
            Severity::Warning,
            vec![feature.layer.clone(), "KiCad Edge.Cuts".to_string()],
            None,
            shapes,
            vec![feature.try_location_f64()?],
            Some(format!(
                "likely high-voltage net {net} is within {edge_clearance:.6} of the board edge; review edge creepage, clearance, and routed-slot barrier intent"
            )),
        ));
        }

        log::trace!(
            "high-voltage edge readiness: source={} selected_layers={} outline_fast_path={} skipped_rect_inside={} exact_difference_checks={} edge_clearance={edge_clearance:.6} violations={}",
            board.source,
            selected_layers.len(),
            outline_rect.is_some(),
            skipped_rect_inside,
            exact_difference_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when likely high-voltage copper is close to unrelated copper.
///
/// The check expands likely high-voltage features by `clearance` and compares
/// them to different-net copper on the same selected layer. Boundary-distance
/// fallback keeps thin features visible even when polygon intersections produce
/// no reportable area.
pub fn voltage_clearance_readiness(
    board: &BoardModel,
    clearance: &Scalar,
    selected_layers: &[String],
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("voltage-clearance-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let broad_phase_clearance = scalar_broad_phase_radius(clearance);
        let feature_index = CopperSpatialIndex::new(&features, broad_phase_clearance);
        let high_voltage_indices = features
            .iter()
            .enumerate()
            .filter_map(|(index, feature)| {
                feature
                    .net
                    .as_deref()
                    .is_some_and(looks_high_voltage_net)
                    .then_some(index)
            })
            .collect::<Vec<_>>();
        log::trace!(
            "voltage-clearance readiness: source={} features={} high_voltage_features={} buckets={} clearance={clearance:.6}",
            board.source,
            features.len(),
            high_voltage_indices.len(),
            feature_index.bucket_count()
        );
        let mut violations = Vec::new();
        let mut candidate_count = 0_usize;
        let mut exact_pair_count = 0_usize;

        for &left_index in &high_voltage_indices {
            let left = features[left_index];
            for right_index in feature_index.same_layer_near_feature(left, broad_phase_clearance) {
                candidate_count += 1;
                let right = features[right_index];
                if left_index == right_index {
                    continue;
                }
                if left.net.is_none() || left.net == right.net {
                    continue;
                }
                let left_high_voltage = left.net.as_deref().is_some_and(looks_high_voltage_net);
                let right_high_voltage = right.net.as_deref().is_some_and(looks_high_voltage_net);
                if !left_high_voltage && !right_high_voltage {
                    continue;
                }
                if right_high_voltage && right_index < left_index {
                    continue;
                }
                if !regiones_within_clearance(&left.region, &right.region, broad_phase_clearance) {
                    continue;
                }
                exact_pair_count += 1;

                let expanded = match offset_for_check(
                    &left.region,
                    clearance.clone(),
                    "voltage-clearance-readiness",
                    vec![left.layer.clone()],
                ) {
                    Ok(expanded) => expanded,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                let overlap = match intersection_for_check(
                    &expanded,
                    &right.region,
                    "voltage-clearance-readiness",
                    vec![left.layer.clone()],
                ) {
                    Ok(overlap) => overlap,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                let shapes =
                    multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                let locations = if shapes.is_empty()
                    && crate::checks::boundaries_within_for_check(
                        &left.region,
                        &right.region,
                        clearance,
                        "voltage-clearance-readiness",
                        &[&left.layer],
                        &mut violations,
                    ) == Some(true)
                {
                    vec![left.try_location_f64()?, right.try_location_f64()?]
                } else {
                    Vec::new()
                };
                if shapes.is_empty() && locations.is_empty() {
                    continue;
                }

                violations.push(Violation::new(
                "voltage-clearance-readiness",
                Severity::Warning,
                vec![left.layer.clone()],
                None,
                shapes,
                locations,
                Some(format!(
                    "likely high-voltage net {:?} is within {clearance:.6} of net {:?}; review voltage-class creepage and clearance",
                    if left_high_voltage { &left.net } else { &right.net },
                    if left_high_voltage { &right.net } else { &left.net }
                )),
            ));
            }
        }

        log::trace!(
            "voltage-clearance readiness: source={} candidate_pairs={} exact_pairs={} violations={}",
            board.source,
            candidate_count,
            exact_pair_count,
            violations.len()
        );
        debug_assert!(exact_pair_count <= candidate_count);

        Ok(violations)
    })
}

/// Warn when likely high-voltage copper is close to protective earth/chassis.
///
/// General voltage spacing already reports high-voltage proximity to unrelated
/// copper. This companion gives PE/chassis boundaries their own review item so
/// safety intent does not get lost among ordinary spacing findings. IPC-2221B
/// frames electrical clearance as a board-design constraint. Cheap bounding-
/// box rejection precedes exact offset/intersection or boundary distance.
pub fn protective_earth_spacing_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    clearance: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "protective-earth-spacing-readiness",
        &[&board.source],
        || {
            let features = selected_copper_features(board, selected_layers);
            let high_voltage = features
                .iter()
                .copied()
                .filter(|feature| feature.net.as_deref().is_some_and(looks_high_voltage_net))
                .collect::<Vec<_>>();
            let protective = features
                .iter()
                .copied()
                .filter(|feature| {
                    feature
                        .net
                        .as_deref()
                        .is_some_and(looks_protective_earth_net)
                })
                .collect::<Vec<_>>();
            let broad_phase_clearance = scalar_broad_phase_radius(clearance);
            let protective_index = CopperSpatialIndex::new(&protective, broad_phase_clearance);
            log::trace!(
                "protective-earth spacing readiness: source={} high_voltage={} protective={} buckets={} clearance={clearance:.6}",
                board.source,
                high_voltage.len(),
                protective.len(),
                protective_index.bucket_count()
            );

            let mut violations = Vec::new();
            let mut candidate_count = 0_usize;
            let mut exact_pair_count = 0_usize;
            for hv in high_voltage {
                for pe_index in protective_index.same_layer_near_feature(hv, broad_phase_clearance)
                {
                    candidate_count += 1;
                    let pe = protective[pe_index];
                    if hv.net == pe.net {
                        continue;
                    }
                    if !regiones_within_clearance(&hv.region, &pe.region, broad_phase_clearance) {
                        continue;
                    }
                    exact_pair_count += 1;

                    let expanded = match offset_for_check(
                        &hv.region,
                        clearance.clone(),
                        "protective-earth-spacing-readiness",
                        vec![hv.layer.clone()],
                    ) {
                        Ok(expanded) => expanded,
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    };
                    let overlap = match intersection_for_check(
                        &expanded,
                        &pe.region,
                        "protective-earth-spacing-readiness",
                        vec![hv.layer.clone()],
                    ) {
                        Ok(overlap) => overlap,
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    };
                    let shapes =
                        multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                    let fallback_hit = shapes.is_empty()
                        && crate::checks::boundaries_within_for_check(
                            &hv.region,
                            &pe.region,
                            clearance,
                            "protective-earth-spacing-readiness",
                            &[&hv.layer],
                            &mut violations,
                        ) == Some(true);
                    if shapes.is_empty() && !fallback_hit {
                        continue;
                    }

                    violations.push(Violation::new(
                "protective-earth-spacing-readiness",
                Severity::Warning,
                vec![hv.layer.clone()],
                None,
                shapes,
                if fallback_hit {
                    vec![
                        hv.try_location_f64()?,
                        pe.try_location_f64()?,
                    ]
                } else {
                    Vec::new()
                },
                Some(format!(
                    "likely high-voltage net {:?} is within {clearance:.6} of protective/chassis net {:?}; review protective-earth clearance, creepage, slots, coating, and safety documentation",
                    hv.net, pe.net
                )),
            ));
                }
            }

            log::trace!(
                "protective-earth spacing readiness: source={} candidate_pairs={} exact_pairs={} violations={}",
                board.source,
                candidate_count,
                exact_pair_count,
                violations.len()
            );
            debug_assert!(exact_pair_count <= candidate_count);

            Ok(violations)
        },
    )
}

/// Warn when ordinary copper crowds likely surge/fuse/MOV protection copper.
///
/// Surge protection devices deliberately connect to hazardous or chassis domains,
/// so this check does not flag high-voltage, ground, PE/chassis, same-net, or
/// other surge-protection copper. It reports unrelated ordinary copper inside
/// the local keepout band around likely MOV, GDT, spark-gap, TVS, or fuse nets.
/// IEC 61000-4-5 defines the surge-immunity context behind this review.
pub fn surge_protection_keepout_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    keepout: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "surge-protection-keepout-readiness",
        &[&board.source],
        || {
            let features = selected_copper_features(board, selected_layers);
            let surge = features
                .iter()
                .copied()
                .filter(|feature| {
                    feature
                        .net
                        .as_deref()
                        .is_some_and(looks_surge_protection_net)
                })
                .collect::<Vec<_>>();
            let broad_phase_keepout = scalar_broad_phase_radius(keepout);
            let feature_index = CopperSpatialIndex::new(&features, broad_phase_keepout);
            log::trace!(
                "surge protection keepout readiness: source={} features={} surge_features={} buckets={} keepout={keepout:.6}",
                board.source,
                features.len(),
                surge.len(),
                feature_index.bucket_count()
            );

            let mut violations = Vec::new();
            let mut candidate_count = 0_usize;
            let mut exact_pair_count = 0_usize;
            for source in surge {
                for neighbor_index in
                    feature_index.same_layer_near_feature(source, broad_phase_keepout)
                {
                    candidate_count += 1;
                    let neighbor = features[neighbor_index];
                    if std::ptr::eq(source, neighbor) {
                        continue;
                    }
                    if source.net == neighbor.net
                        || neighbor
                            .net
                            .as_deref()
                            .is_some_and(allowed_surge_neighbor_net)
                    {
                        continue;
                    }
                    if !regiones_within_clearance(
                        &source.region,
                        &neighbor.region,
                        broad_phase_keepout,
                    ) {
                        continue;
                    }
                    exact_pair_count += 1;

                    let expanded = match offset_for_check(
                        &source.region,
                        keepout.clone(),
                        "surge-protection-keepout-readiness",
                        vec![source.layer.clone()],
                    ) {
                        Ok(expanded) => expanded,
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    };
                    let overlap = match intersection_for_check(
                        &expanded,
                        &neighbor.region,
                        "surge-protection-keepout-readiness",
                        vec![source.layer.clone()],
                    ) {
                        Ok(overlap) => overlap,
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    };
                    let shapes =
                        multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                    let fallback_hit = shapes.is_empty()
                        && crate::checks::boundaries_within_for_check(
                            &source.region,
                            &neighbor.region,
                            keepout,
                            "surge-protection-keepout-readiness",
                            &[&source.layer],
                            &mut violations,
                        ) == Some(true);
                    if shapes.is_empty() && !fallback_hit {
                        continue;
                    }

                    violations.push(Violation::new(
                "surge-protection-keepout-readiness",
                Severity::Warning,
                vec![source.layer.clone()],
                None,
                shapes,
                if fallback_hit {
                    vec![
                        source.try_location_f64()?,
                        neighbor.try_location_f64()?,
                    ]
                } else {
                    Vec::new()
                },
                Some(format!(
                    "likely surge/fuse protection net {:?} has unrelated copper from net {:?} inside keepout {keepout:.6}; review MOV, GDT, spark-gap, fuse, and surge-current isolation geometry",
                    source.net, neighbor.net
                )),
            ));
                }
            }

            log::trace!(
                "surge protection keepout readiness: source={} candidate_pairs={} exact_pairs={} violations={}",
                board.source,
                candidate_count,
                exact_pair_count,
                violations.len()
            );
            debug_assert!(exact_pair_count <= candidate_count);

            Ok(violations)
        },
    )
}

fn regiones_within_clearance(
    left: &crate::PcbRegion,
    right: &crate::PcbRegion,
    clearance: f64,
) -> bool {
    let Some(left_bounds) = left.conservative_bounds() else {
        return true;
    };
    let Some(right_bounds) = right.conservative_bounds() else {
        return true;
    };

    // Cheap AABB broad phase before exact offset/intersection work.
    left_bounds.min().x - clearance <= right_bounds.max().x
        && left_bounds.max().x + clearance >= right_bounds.min().x
        && left_bounds.min().y - clearance <= right_bounds.max().y
        && left_bounds.max().y + clearance >= right_bounds.min().y
}

fn scalar_broad_phase_radius(value: &Scalar) -> f64 {
    let projected = value
        .to_f64_lossy()
        .expect("safety broad-phase radius must fit the finite compatibility index");
    if projected > 0.0 {
        projected.next_up()
    } else {
        0.0
    }
}

fn exact_point_distance_scalar(left: &[Scalar; 2], right: &[Scalar; 2]) -> Option<Scalar> {
    let dx = &left[0] - &right[0];
    let dy = &left[1] - &right[1];
    (&dx * &dx + &dy * &dy).sqrt().ok()
}

/// Warn when exposed connector-like nets lack nearby ESD protection copper.
///
/// Nets that look like connector, RF, or high-speed interfaces and sit near the
/// board edge should usually have nearby ESD, chassis, shield, or ground copper.
/// This check reports those entry points for system-level ESD review.
pub fn esd_protection_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    edge_distance: &Scalar,
    protection_search_radius: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("esd-protection-readiness", &[&board.source], || {
        let Some(outline) = &board.board_outline else {
            return Ok(Vec::new());
        };

        let features = selected_copper_features(board, selected_layers);
        let protection_features = features
            .iter()
            .copied()
            .filter(|feature| {
                feature.net.as_deref().is_some_and(|net| {
                    looks_esd_protection_net(net) || looks_chassis_net(net) || looks_ground_net(net)
                })
            })
            .collect::<Vec<_>>();
        let broad_phase_radius = scalar_broad_phase_radius(protection_search_radius);
        let protection_index = CopperSpatialIndex::new(&protection_features, broad_phase_radius);
        log::trace!(
            "ESD protection readiness: source={} features={} protection_features={} buckets={} edge_distance={edge_distance:#.6} protection_radius={protection_search_radius:#.6}",
            board.source,
            features.len(),
            protection_features.len(),
            protection_index.bucket_count()
        );
        let mut violations = Vec::new();
        let mut edge_candidate_count = 0_usize;
        let mut protection_candidate_count = 0_usize;
        let mut exact_protection_checks = 0_usize;

        for feature in features {
            let Some(net) = feature.net.as_deref() else {
                continue;
            };
            if !looks_connector_edge_rate_net(net) || looks_esd_protection_net(net) {
                continue;
            }

            let Some(edge_gap) = crate::checks::boundary_distance_for_check(
                &feature.region,
                outline,
                "esd-protection-readiness",
                &[&feature.layer],
                &mut violations,
            ) else {
                continue;
            };
            if crate::checks::metric_cmp_for_check(
                &edge_gap,
                edge_distance,
                "esd-protection-readiness",
                &[&feature.layer],
                &mut violations,
            )
            .is_none_or(|order| order.is_gt())
            {
                continue;
            }
            edge_candidate_count += 1;

            let protection_candidates =
                protection_index.same_layer_near_feature(feature, broad_phase_radius);
            protection_candidate_count += protection_candidates.len();
            let has_protection = protection_candidates.into_iter().any(|protection_index| {
                exact_protection_checks += 1;
                let protection = protection_features[protection_index];
                !std::ptr::eq(protection, feature)
                    && exact_point_distance_scalar(&feature.location, &protection.location)
                        .is_some_and(|distance| {
                            crate::scalar::le(&distance, protection_search_radius)
                        })
            });
            if has_protection {
                continue;
            }

            violations.push(Violation::new(
                "esd-protection-readiness",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "likely edge connector net {net:?} is {edge_gap:#.6} from board edge without parsed ESD/chassis/ground protection copper within {protection_search_radius:#.6}"
                )),
            ));
        }

        log::trace!(
            "ESD protection readiness: source={} edge_candidates={} protection_candidates={} exact_protection_checks={} violations={}",
            board.source,
            edge_candidate_count,
            protection_candidate_count,
            exact_protection_checks,
            violations.len()
        );
        debug_assert!(exact_protection_checks <= protection_candidate_count);

        Ok(violations)
    })
}

/// Warn when parsed TVS/ESD clamp copper lacks a nearby low-impedance return.
///
/// System-level ESD pulses are fast enough that parasitic inductance in the
/// clamp path can dominate protection behavior. This check reports likely
/// ESD/TVS/protection nets that do not have nearby same-layer ground or chassis
/// copper. ESD surge `di/dt` across PCB parasitic inductance can add substantial
/// voltage at the protected device; IEC 61000-4-2 defines the standardized ESD
/// waveform that makes clamp-path inductance relevant.
pub fn esd_return_path_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    return_search_radius: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("esd-return-path-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let return_features = features
            .iter()
            .copied()
            .filter(|feature| {
                feature
                    .net
                    .as_deref()
                    .is_some_and(|net| looks_ground_net(net) || looks_chassis_net(net))
            })
            .collect::<Vec<_>>();
        let broad_phase_radius = scalar_broad_phase_radius(return_search_radius);
        let return_index = CopperSpatialIndex::new(&return_features, broad_phase_radius);
        log::trace!(
            "ESD return-path readiness: source={} features={} return_features={} buckets={} radius={return_search_radius:#.6}",
            board.source,
            features.len(),
            return_features.len(),
            return_index.bucket_count()
        );
        let mut violations = Vec::new();
        let mut esd_count = 0_usize;
        let mut return_candidate_count = 0_usize;
        let mut exact_return_checks = 0_usize;

        for feature in features {
            let Some(net) = feature.net.as_deref() else {
                continue;
            };
            if !looks_esd_protection_net(net) {
                continue;
            }
            esd_count += 1;

            let return_candidates =
                return_index.same_layer_near_feature(feature, broad_phase_radius);
            return_candidate_count += return_candidates.len();
            let has_return = return_candidates.into_iter().any(|return_index| {
                exact_return_checks += 1;
                let return_feature = return_features[return_index];
                !std::ptr::eq(return_feature, feature)
                    && exact_point_distance_scalar(&feature.location, &return_feature.location)
                        .is_some_and(|distance| crate::scalar::le(&distance, return_search_radius))
            });
            if has_return {
                continue;
            }

            violations.push(Violation::new(
                "esd-return-path-readiness",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "likely ESD protection net {net:?} has no parsed same-layer ground or chassis return copper within {return_search_radius:#.6}; review TVS clamp loop inductance and discharge path"
                )),
            ));
        }

        log::trace!(
            "ESD return-path readiness: source={} esd_features={} return_candidates={} exact_return_checks={} violations={}",
            board.source,
            esd_count,
            return_candidate_count,
            exact_return_checks,
            violations.len()
        );
        debug_assert!(exact_return_checks <= return_candidate_count);

        Ok(violations)
    })
}

fn selected_copper_features<'a>(
    board: &'a BoardModel,
    selected_layers: &[String],
) -> Vec<&'a CopperFeature> {
    board
        .copper
        .iter()
        .filter(|feature| selected_layers.is_empty() || selected_layers.contains(&feature.layer))
        .collect()
}

fn looks_high_voltage_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "HV", "HIGHV", "MAINS", "LINE", "NEUTRAL", "LIVE", "VAC", "AC_L", "AC_N", "RECT", "BULK",
        "400V", "240V", "230V", "120V", "48V",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_high_speed_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "USB", "D+", "D-", "DP", "DM", "CLK", "CLOCK", "TX", "RX", "SERDES", "PCIE", "PCI", "MIPI",
        "LVDS", "HDMI", "ETH", "RGMII", "SGMII", "SATA", "CAN",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_rf_or_antenna_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "RF", "ANT", "ANTENNA", "GNSS", "GPS", "WIFI", "BT_", "BLE", "LTE",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_chassis_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    matches!(
        normalized.as_str(),
        "CHASSIS" | "SHIELD" | "EARTH" | "PE" | "PROTECTIVE_EARTH"
    ) || normalized.ends_with("_SHIELD")
        || normalized.ends_with("-SHIELD")
        || normalized.contains("CHASSIS")
}

fn looks_protective_earth_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    matches!(
        normalized.as_str(),
        "PE" | "EARTH" | "PROTECTIVE_EARTH" | "PROTECTIVE-EARTH" | "SAFETY_GND"
    ) || normalized.contains("CHASSIS")
        || normalized.contains("SHIELD")
        || normalized.ends_with("_PE")
        || normalized.ends_with("-PE")
        || normalized.contains("EARTH")
}

fn looks_ground_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    matches!(
        normalized.as_str(),
        "GND" | "GROUND" | "PGND" | "AGND" | "DGND"
    ) || normalized.ends_with("_GND")
        || normalized.ends_with("-GND")
}

fn looks_connector_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "CONN",
        "CONNECTOR",
        "USB",
        "JACK",
        "SOCKET",
        "PLUG",
        "HEADER",
        "VBUS",
        "SHIELD",
        "CHASSIS",
        "CARD_EDGE",
        "EDGE_CONN",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_connector_edge_rate_net(net: &str) -> bool {
    looks_connector_net(net) || looks_high_speed_net(net) || looks_rf_or_antenna_net(net)
}

fn looks_esd_protection_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "ESD",
        "TVS",
        "CLAMP",
        "PROTECT",
        "PROTECTION",
        "SURGE",
        "SPARK",
        "TRANSIENT",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_surge_protection_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "MOV", "VARISTOR", "GDT", "SPARK", "SPARKGAP", "SURGE", "FUSE", "FUSED", "TVS", "PTC",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn allowed_surge_neighbor_net(net: &str) -> bool {
    looks_high_voltage_net(net)
        || looks_ground_net(net)
        || looks_protective_earth_net(net)
        || looks_surge_protection_net(net)
}

#[cfg(test)]
mod tests {
    use std::time::Instant;

    use crate::LayerMetadata;
    use crate::geometry::{circle_polygon, polygons_to_profile, rect_polygon};
    use crate::kicad::{BoardModel, CopperFeature, CopperKind};

    use super::{
        esd_protection_readiness, esd_return_path_readiness, high_voltage_edge_readiness,
        protective_earth_spacing_readiness, surge_protection_keepout_readiness,
        voltage_clearance_readiness,
    };

    #[test]
    fn esd_return_path_readiness_reports_clamp_without_ground_or_chassis() {
        let board = board_with_copper(vec![copper_disc(
            "USB_ESD_CLAMP",
            CopperKind::Pad,
            [0.0, 0.0],
            0.20,
        )]);

        let violations = esd_return_path_readiness(&board, &[], &crate::scalar::scalar("0.50"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "esd-return-path-readiness");
    }

    #[test]
    fn esd_return_path_readiness_accepts_nearby_return_or_selected_out_layer() {
        let board = board_with_copper(vec![
            copper_disc_on_layer("USB_ESD_CLAMP", CopperKind::Pad, "B.Cu", [0.0, 0.0], 0.20),
            copper_disc_on_layer("CHASSIS", CopperKind::Pad, "B.Cu", [0.25, 0.0], 0.20),
        ]);

        assert!(esd_return_path_readiness(&board, &[], &crate::scalar::scalar("0.50")).is_empty());
        assert!(
            esd_return_path_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.50")
            )
            .is_empty()
        );
    }

    #[test]
    fn voltage_clearance_readiness_reports_likely_high_voltage_proximity() {
        let board = board_with_copper(vec![
            copper_rect("HV_BUS", CopperKind::Segment, "F.Cu", 0.0, 0.0, 1.0, 0.2),
            copper_rect("GND", CopperKind::Segment, "F.Cu", 1.1, 0.0, 2.0, 0.2),
        ]);

        let violations = voltage_clearance_readiness(
            &board,
            &crate::scalar::scalar("0.30"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "voltage-clearance-readiness");
    }

    #[test]
    fn voltage_clearance_readiness_culls_sparse_copper_fields() {
        let mut copper = sparse_rects("GPIO", 2_000, 100.0);
        copper.push(copper_rect(
            "HV_BUS",
            CopperKind::Segment,
            "F.Cu",
            0.0,
            0.0,
            1.0,
            0.2,
        ));
        copper.push(copper_rect(
            "GND_NEAR",
            CopperKind::Segment,
            "F.Cu",
            1.1,
            0.0,
            2.0,
            0.2,
        ));
        copper.push(copper_rect(
            "GND_OTHER_LAYER",
            CopperKind::Segment,
            "B.Cu",
            1.1,
            0.0,
            2.0,
            0.2,
        ));
        let board = board_with_copper(copper);

        let violations = voltage_clearance_readiness(
            &board,
            &crate::scalar::scalar("0.30"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(violations[0].message.as_ref().is_some_and(|message| {
            message.contains("GND_NEAR") && !message.contains("GND_OTHER_LAYER")
        }));
    }

    #[test]
    fn protective_earth_spacing_readiness_reports_hv_near_chassis() {
        let board = board_with_copper(vec![
            copper_rect("HV_BUS", CopperKind::Segment, "F.Cu", 0.0, 0.0, 1.0, 0.2),
            copper_rect("PE", CopperKind::Segment, "F.Cu", 1.2, 0.0, 2.0, 0.2),
        ]);

        let violations = protective_earth_spacing_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "protective-earth-spacing-readiness");
    }

    #[test]
    fn protective_earth_spacing_readiness_allows_distant_or_non_protective_copper() {
        let distant = board_with_copper(vec![
            copper_rect("HV_BUS", CopperKind::Segment, "F.Cu", 0.0, 0.0, 1.0, 0.2),
            copper_rect("PE", CopperKind::Segment, "F.Cu", 2.0, 0.0, 3.0, 0.2),
        ]);
        let ordinary = board_with_copper(vec![
            copper_rect("HV_BUS", CopperKind::Segment, "F.Cu", 0.0, 0.0, 1.0, 0.2),
            copper_rect("GPIO", CopperKind::Segment, "F.Cu", 1.2, 0.0, 2.0, 0.2),
        ]);

        assert!(
            protective_earth_spacing_readiness(
                &distant,
                &[],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert!(
            protective_earth_spacing_readiness(
                &ordinary,
                &[],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn protective_earth_spacing_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_rect("HV_BUS", CopperKind::Segment, "B.Cu", 0.0, 0.0, 1.0, 0.2),
            copper_rect("CHASSIS", CopperKind::Segment, "B.Cu", 1.2, 0.0, 2.0, 0.2),
        ]);

        assert!(
            protective_earth_spacing_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            protective_earth_spacing_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn protective_earth_spacing_readiness_culls_sparse_large_cases() {
        let mut copper = vec![copper_rect(
            "HV_BUS",
            CopperKind::Segment,
            "F.Cu",
            0.0,
            0.0,
            1.0,
            0.2,
        )];
        for index in 0..500 {
            let x = 100.0 + index as f64 * 2.0;
            copper.push(copper_rect(
                "CHASSIS",
                CopperKind::Segment,
                "F.Cu",
                x,
                0.0,
                x + 1.0,
                0.2,
            ));
        }
        let board = board_with_copper(copper);

        let violations = protective_earth_spacing_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn surge_protection_keepout_readiness_reports_unrelated_copper() {
        let board = board_with_copper(vec![
            copper_rect("MOV_LINE", CopperKind::Pad, "F.Cu", 0.0, 0.0, 0.5, 0.5),
            copper_rect("GPIO", CopperKind::Segment, "F.Cu", 0.7, 0.0, 1.2, 0.5),
        ]);

        let violations = surge_protection_keepout_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "surge-protection-keepout-readiness");
    }

    #[test]
    fn surge_protection_keepout_readiness_allows_expected_surge_neighbors() {
        let board = board_with_copper(vec![
            copper_rect("MOV_LINE", CopperKind::Pad, "F.Cu", 0.0, 0.0, 0.5, 0.5),
            copper_rect("HV_BUS", CopperKind::Segment, "F.Cu", 0.7, 0.0, 1.2, 0.5),
            copper_rect("PE", CopperKind::Segment, "F.Cu", -0.7, 0.0, -0.2, 0.5),
            copper_rect("GND", CopperKind::Segment, "F.Cu", 0.0, 0.7, 0.5, 1.2),
        ]);

        let violations = surge_protection_keepout_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn surge_protection_keepout_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_rect("FUSE_IN", CopperKind::Pad, "B.Cu", 0.0, 0.0, 0.5, 0.5),
            copper_rect("GPIO", CopperKind::Segment, "B.Cu", 0.7, 0.0, 1.2, 0.5),
        ]);

        assert!(
            surge_protection_keepout_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            surge_protection_keepout_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn surge_protection_keepout_readiness_culls_sparse_large_cases() {
        let mut copper = vec![copper_rect(
            "MOV_LINE",
            CopperKind::Pad,
            "F.Cu",
            0.0,
            0.0,
            0.5,
            0.5,
        )];
        for index in 0..500 {
            let x = 100.0 + index as f64 * 2.0;
            copper.push(copper_rect(
                "GPIO",
                CopperKind::Segment,
                "F.Cu",
                x,
                0.0,
                x + 0.5,
                0.5,
            ));
        }
        let board = board_with_copper(copper);

        let violations = surge_protection_keepout_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn high_voltage_edge_readiness_reports_hv_copper_near_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_rect(
            "HV_BUS",
            CopperKind::Segment,
            "F.Cu",
            0.2,
            4.0,
            1.0,
            4.4,
        )];

        let violations = high_voltage_edge_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.80"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "high-voltage-edge-readiness");
    }

    #[test]
    fn high_voltage_edge_readiness_culls_rectangular_interior_copper_fields() {
        let mut board = board_with_outline(square(0.0, 0.0, 100.0, 100.0));
        board.copper = (0..2_000)
            .map(|index| {
                let x = 5.0 + (index % 50) as f64 * 1.5;
                let y = 5.0 + (index / 50) as f64 * 1.5;
                copper_rect(
                    &format!("HV_BUS_{index}"),
                    CopperKind::Segment,
                    "F.Cu",
                    x,
                    y,
                    x + 0.5,
                    y + 0.2,
                )
            })
            .collect();
        board.copper.push(copper_rect(
            "MAINS_L",
            CopperKind::Segment,
            "F.Cu",
            0.20,
            50.0,
            1.0,
            50.2,
        ));

        let started = Instant::now();
        let violations = high_voltage_edge_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.80"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed().as_secs_f64() < 2.0,
            "high-voltage edge review should skip rectangular interior copper before exact difference"
        );
    }

    #[test]
    fn esd_protection_readiness_reports_unprotected_edge_connector_net() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![copper_rect(
            "USB_D_P",
            CopperKind::Pad,
            "F.Cu",
            0.4,
            8.0,
            1.0,
            8.6,
        )];

        let violations = esd_protection_readiness(
            &board,
            &[],
            &crate::scalar::scalar("1.0"),
            &crate::scalar::scalar("2.0"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "esd-protection-readiness");
    }

    #[test]
    fn esd_protection_readiness_culls_sparse_protection_fields() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = sparse_rects("USB_TVS", 2_000, 100.0);
        board.copper.push(copper_rect(
            "USB_D_P",
            CopperKind::Pad,
            "F.Cu",
            0.4,
            8.0,
            1.0,
            8.6,
        ));
        board.copper.push(copper_rect(
            "USB_TVS_NEAR",
            CopperKind::Pad,
            "F.Cu",
            1.4,
            8.0,
            2.0,
            8.6,
        ));

        assert!(
            esd_protection_readiness(
                &board,
                &[],
                &crate::scalar::scalar("1.0"),
                &crate::scalar::scalar("2.0")
            )
            .is_empty()
        );
    }

    #[test]
    fn esd_return_path_readiness_culls_sparse_return_fields() {
        let mut copper = sparse_rects("GND", 2_000, 100.0);
        copper.push(copper_disc(
            "USB_ESD_CLAMP",
            CopperKind::Pad,
            [0.0, 0.0],
            0.20,
        ));
        copper.push(copper_disc("CHASSIS", CopperKind::Pad, [0.25, 0.0], 0.20));
        let board = board_with_copper(copper);

        assert!(esd_return_path_readiness(&board, &[], &crate::scalar::scalar("0.50")).is_empty());
    }

    fn board_with_copper(copper: Vec<CopperFeature>) -> BoardModel {
        BoardModel {
            source: "test".to_string(),
            copper,
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        }
    }

    fn board_with_outline(outline: crate::geometry::Polygon<f64>) -> BoardModel {
        BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: Vec::new(),
            board_outline: Some(polygons_to_profile(
                vec![outline],
                Some(LayerMetadata {
                    name: "outline".to_string(),
                }),
            )),
            panel_features: None,
        }
    }

    fn square(min_x: f64, min_y: f64, max_x: f64, max_y: f64) -> crate::geometry::Polygon<f64> {
        rect_polygon(
            [(min_x + max_x) / 2.0, (min_y + max_y) / 2.0],
            [max_x - min_x, max_y - min_y],
            0.0,
        )
    }

    fn copper_rect(
        net: &str,
        kind: CopperKind,
        layer: &str,
        min_x: f64,
        min_y: f64,
        max_x: f64,
        max_y: f64,
    ) -> CopperFeature {
        CopperFeature {
            layer: layer.to_string(),
            net: Some(net.to_string()),
            kind,
            location: [
                crate::geometry::exact_real((min_x + max_x) / 2.0),
                crate::geometry::exact_real((min_y + max_y) / 2.0),
            ],
            region: polygons_to_profile(
                vec![rect_polygon(
                    [(min_x + max_x) / 2.0, (min_y + max_y) / 2.0],
                    [max_x - min_x, max_y - min_y],
                    0.0,
                )],
                Some(LayerMetadata {
                    name: "test rect".to_string(),
                }),
            ),
        }
    }

    fn copper_disc(
        net: &str,
        kind: CopperKind,
        location: [f64; 2],
        diameter: f64,
    ) -> CopperFeature {
        copper_disc_on_layer(net, kind, "F.Cu", location, diameter)
    }

    fn copper_disc_on_layer(
        net: &str,
        kind: CopperKind,
        layer: &str,
        location: [f64; 2],
        diameter: f64,
    ) -> CopperFeature {
        CopperFeature {
            layer: layer.to_string(),
            net: Some(net.to_string()),
            kind,
            location: [
                crate::geometry::exact_real(location[0]),
                crate::geometry::exact_real(location[1]),
            ],
            region: polygons_to_profile(
                vec![circle_polygon(location, diameter / 2.0, 32)],
                Some(LayerMetadata {
                    name: "test disc".to_string(),
                }),
            ),
        }
    }

    fn sparse_rects(prefix: &str, count: usize, offset_x: f64) -> Vec<CopperFeature> {
        (0..count)
            .map(|index| {
                let x = offset_x + (index % 100) as f64 * 3.0;
                let y = (index / 100) as f64 * 3.0;
                copper_rect(
                    &format!("{prefix}{index}"),
                    CopperKind::Segment,
                    "F.Cu",
                    x,
                    y,
                    x + 1.0,
                    y + 0.2,
                )
            })
            .collect()
    }
}
