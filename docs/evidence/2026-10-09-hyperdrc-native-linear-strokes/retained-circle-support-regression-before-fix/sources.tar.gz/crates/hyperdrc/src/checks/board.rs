//! Board-level checks that need nets, drills, vias, or panel features.
//!
//! Reliability note: many board-level checks infer intent from net names,
//! component-like copper geometry, or parsed KiCad features. These areas are
//! suspect for false positives and false negatives on unusual naming schemes,
//! custom footprints, filled zones, and panel drawings; release decisions should
//! double-check the source board and fabrication notes.

use super::minimum_bounding_dimension;
use std::collections::{BTreeMap, BTreeSet, HashMap};

use hyperlimit::compare_reals;

use super::outline::{
    axis_aligned_outline_rect_with_grid, feature_bounds_inside_rect_margin_with_grid,
    feature_bounds_inside_rect_with_grid,
};
mod ipc;
mod points;
pub use points::{
    chassis_stitching_readiness, chassis_stitching_readiness_with_grid,
    connector_return_path_readiness, decoupling_proximity_readiness, edge_stitching_readiness,
    edge_stitching_readiness_with_grid, power_via_array_readiness, return_path_readiness,
};

pub use ipc::{apply_ipc356_nets, ipc356_coverage, ipc356_drill_diameter};

use super::spatial::CopperSpatialIndex;
use super::{difference_for_check, intersection_for_check, offset_for_check};
use crate::PREDICATE_POLICY;
use crate::checks::drill::{drill_radius_with_clearance, drills_to_region};
use crate::geometry::{
    MultiPolygon, Rect, SourceGridFacts, multipolygon_to_shapes_scalar, polygons_to_profile,
};
use crate::kicad::{BoardModel, CopperFeature, CopperKind, DrillFeature};
use crate::report::{Severity, Violation};
use crate::{LayerMetadata, PcbRegion, PcbRegionExt, Scalar};

/// Warn when parsed KiCad copper is narrower than the configured width.
///
/// IPC-2221B treats conductor geometry as a board-level design constraint.
/// This check keeps etch-sensitive narrow copper visible during readiness
/// review and uses the parsed feature bounding box as a conservative
/// proxy, so suspect findings should be verified against the native CAD rule
/// deck and fabrication limits.
pub fn copper_width_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    minimum_width: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("copper-width-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let mut measured_features = 0usize;
        let mut violations = Vec::new();

        for feature in &features {
            let Some(Some(width)) = crate::checks::geometry_result_for_check(
                minimum_bounding_dimension(&feature.region),
                "copper-width-readiness",
                &[&feature.layer],
                &mut violations,
            ) else {
                continue;
            };
            if crate::scalar::le(&width, &Scalar::zero()) {
                continue;
            }
            measured_features += 1;
            if crate::scalar::ge(&width, minimum_width) {
                continue;
            }

            violations.push(Violation::new(
                "copper-width-readiness",
                Severity::Error,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "parsed {:?} copper width {width:.6} is below minimum {minimum_width:.6}",
                    feature.kind
                )),
            ));
        }

        log::trace!(
            "copper-width readiness: source={} selected_features={} measured_features={} selected_layers={} minimum_width={minimum_width:.6} violations={}",
            board.source,
            features.len(),
            measured_features,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when parsed KiCad copper has no assigned net.
///
/// IPC-D-356B exists to exchange bare-board electrical test intent; after KiCad
/// parsing and any IPC-D-356 annotation pass, remaining unnetted copper is
/// suspect for intentional shields, mechanical copper, parser misses, or true
/// release-data gaps. This check only reports the ambiguity so a reviewer can
/// confirm the source board and test handoff.
pub fn copper_net_intent(board: &BoardModel, selected_layers: &[String]) -> Vec<Violation> {
    crate::checks::run_geometry_check("copper-net-intent", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let mut violations = Vec::new();

        for feature in &features {
            if feature.net.is_some() {
                continue;
            }
            violations.push(Violation::new(
                "copper-net-intent",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "parsed {:?} copper has no net after KiCad parsing and IPC-D-356 annotation",
                    feature.kind
                )),
            ));
        }

        log::trace!(
            "copper-net intent: source={} selected_features={} selected_layers={} violations={}",
            board.source,
            features.len(),
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `via_in_pad_readiness` design-readiness check or report helper.
///
/// The spatial index only proposes nearby same-layer pads; exact CSG overlap
/// decides the finding. This makes via-in-pad fill, tent, and paste handoff risk
/// visible for review.
pub fn via_in_pad_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("via-in-pad-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let vias = features
            .iter()
            .filter(|feature| feature.kind == CopperKind::Via)
            .copied()
            .collect::<Vec<_>>();
        let pads = features
            .iter()
            .filter(|feature| feature.kind == CopperKind::Pad)
            .copied()
            .collect::<Vec<_>>();
        let pad_spatial_index = CopperSpatialIndex::new(&pads, 1.0);
        log::trace!(
            "via-in-pad readiness: source={} vias={} pads={} buckets={} min_area={min_area:#.9}",
            board.source,
            vias.len(),
            pads.len(),
            pad_spatial_index.bucket_count()
        );
        let mut violations = Vec::new();
        let mut candidate_count = 0_usize;

        for via in vias {
            for pad_index in pad_spatial_index.same_layer_near_feature(via, 0.0) {
                candidate_count += 1;
                let pad = pads[pad_index];
                if via.layer != pad.layer || via.net.is_none() || via.net != pad.net {
                    continue;
                }
                if !regiones_within_clearance(&via.region, &pad.region, 0.0) {
                    continue;
                }

                let overlap = match intersection_for_check(
                    &via.region,
                    &pad.region,
                    "via-in-pad-readiness",
                    vec![via.layer.clone()],
                ) {
                    Ok(overlap) => overlap,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                let shapes =
                    multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                if shapes.is_empty() {
                    continue;
                }

                violations.push(Violation::new(
                "via-in-pad-readiness",
                Severity::Warning,
                vec![via.layer.clone()],
                None,
                shapes,
                vec![via.try_location_f64()?, pad.try_location_f64()?],
                Some(
                    "via copper overlaps a same-net pad; confirm via-in-pad fill, tenting, or paste treatment"
                        .to_string(),
                ),
            ));
            }
        }

        log::trace!(
            "via-in-pad readiness: source={} candidate_pairs={} violations={}",
            board.source,
            candidate_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `teardrop_readiness` design-readiness check or report helper.
///
/// The rule is a release-readiness proxy for pad/via entry robustness rather
/// than a true teardrop synthesizer. IPC-2221B treats conductor-to-land joins as
/// a design reliability concern; HyperDRC keeps that review visible by finding
/// narrow same-net segment entries after a spatial broad phase filters the
/// candidate anchors.
pub fn teardrop_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    min_neck_width: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("teardrop-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let segments = features
            .iter()
            .filter(|feature| feature.kind == CopperKind::Segment)
            .copied()
            .collect::<Vec<_>>();
        let anchors = features
            .iter()
            .filter(|feature| matches!(feature.kind, CopperKind::Pad | CopperKind::Via))
            .copied()
            .collect::<Vec<_>>();
        let anchor_index = CopperSpatialIndex::new(&anchors, 1.0);
        log::trace!(
            "teardrop readiness: source={} segments={} anchors={} buckets={} min_neck_width={min_neck_width:.6} min_area={min_area:.9}",
            board.source,
            segments.len(),
            anchors.len(),
            anchor_index.bucket_count()
        );
        let mut violations = Vec::new();
        let mut candidate_count = 0_usize;

        for segment in segments {
            let Some(segment_width) = minimum_bounding_dimension(&segment.region)? else {
                continue;
            };
            if crate::scalar::ge(&segment_width, min_neck_width) {
                continue;
            }

            for anchor_index in anchor_index.same_layer_near_feature(segment, 0.0) {
                candidate_count += 1;
                let anchor = anchors[anchor_index];
                if segment.layer != anchor.layer
                    || segment.net.is_none()
                    || segment.net != anchor.net
                {
                    continue;
                }

                let overlap = match intersection_for_check(
                    &segment.region,
                    &anchor.region,
                    "teardrop-readiness",
                    vec![segment.layer.clone()],
                ) {
                    Ok(overlap) => overlap,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                let shapes =
                    multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                if shapes.is_empty() {
                    continue;
                }

                violations.push(Violation::new(
                "teardrop-readiness",
                Severity::Warning,
                vec![segment.layer.clone()],
                None,
                shapes,
                vec![
                    segment.try_location_f64()?,
                    anchor.try_location_f64()?,
                ],
                Some(format!(
                    "same-net segment neck width {segment_width:.6} into {:?} is below {min_neck_width:.6}; consider teardrops or wider entry geometry",
                    anchor.kind
                )),
            ));
            }
        }

        log::trace!(
            "teardrop readiness: source={} candidate_pairs={} violations={}",
            board.source,
            candidate_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `plane_clearance_readiness` design-readiness check or report helper.
///
/// Non-plated drill keepouts are matched to candidate copper zones with a
/// deterministic grid broad phase before exact CSG overlap review. This preserves the
/// conservative antipad-readiness predicate while avoiding every drill scanning
/// every zone on sparse mechanical-heavy boards.
pub fn plane_clearance_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("plane-clearance-readiness", &[&board.source], || {
        let zones = selected_copper_features(board, selected_layers)
            .into_iter()
            .filter(|feature| feature.kind == CopperKind::Zone)
            .collect::<Vec<_>>();
        let maximum_drill_radius = board
            .drills
            .iter()
            .filter(|drill| !drill.plated)
            .filter_map(DrillFeature::diameter_f64_compatibility)
            .map(|diameter| diameter / 2.0)
            .fold(0.0_f64, f64::max);
        let zone_index = CopperSpatialIndex::new(&zones, maximum_drill_radius);
        let mut violations = Vec::new();
        let mut drill_count = 0usize;
        let mut candidate_pairs = 0usize;

        for drill in &board.drills {
            if drill.plated {
                continue;
            }
            drill_count += 1;
            let drill_radius = crate::scalar::half(&drill.diameter);
            let broad_phase_radius = scalar_broad_phase_radius(&drill_radius);
            let candidates =
                zone_index.all_layers_near_circle(drill.try_location_f64()?, broad_phase_radius);
            candidate_pairs += candidates.len();
            if candidates.is_empty() {
                continue;
            }
            let hole = PcbRegion::new(
                crate::geometry::circle_region(
                    &[drill.location[0].clone(), drill.location[1].clone()],
                    &(drill_radius.clone()),
                )?,
                Some(LayerMetadata {
                    name: "mechanical hole".to_string(),
                }),
            );

            for candidate_index in candidates {
                let zone = zones[candidate_index];
                let overlap = match intersection_for_check(
                    &hole,
                    &zone.region,
                    "plane-clearance-readiness",
                    vec![zone.layer.clone(), "KiCad NPTH drills".into()],
                ) {
                    Ok(overlap) => overlap,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                let mut shapes =
                    multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                let hole_contained = zone
                    .region
                    .classify_xy(drill.location[0].clone(), drill.location[1].clone())?
                    == hypercurve::RegionPointLocation::Inside;
                if shapes.is_empty() && hole_contained {
                    // A hole wholly contained by a zone has no boundary crossing.
                    // Classify the exact center against the exact filled region so
                    // containment does not depend on a finite polygon fallback.
                    shapes = multipolygon_to_shapes_scalar(&hole.try_to_multipolygon()?, min_area)?;
                }
                let hole_area = Scalar::pi() * &drill_radius * &drill_radius;
                let contained_area_exceeds_gate = hole_contained
                    && compare_reals(&hole_area, min_area, PREDICATE_POLICY).value()
                        == Some(std::cmp::Ordering::Greater);
                if shapes.is_empty() && !contained_area_exceeds_gate {
                    continue;
                }

                violations.push(Violation::new(
                "plane-clearance-readiness",
                Severity::Warning,
                vec![zone.layer.clone(), "KiCad NPTH drills".to_string()],
                None,
                shapes,
                vec![drill.try_location_f64()?, zone.try_location_f64()?],
                Some(
                    "non-plated mechanical hole intersects copper zone; review plane antipad or pour clearance intent"
                        .to_string(),
                ),
            ));
            }
        }
        log::trace!(
            "plane clearance readiness: source={} zones={} non_plated_drills={} spatial_buckets={} candidate_pairs={} violations={}",
            board.source,
            zones.len(),
            drill_count,
            zone_index.bucket_count(),
            candidate_pairs,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `board_edge_exposure` design-readiness check or report helper.
pub fn board_edge_exposure(
    board: &BoardModel,
    selected_layers: &[String],
    min_area: &Scalar,
) -> Vec<Violation> {
    board_edge_exposure_with_grid(
        board,
        selected_layers,
        min_area,
        SourceGridFacts::PRIMITIVE_FLOAT_EDGE,
    )
}

/// Run board-edge exposure with retained source-grid facts.
///
/// The rectangular fast path is a certified broad-phase decision using exact
/// lifted comparisons. Source representation facts remain available until the
/// predicate chooses arithmetic.
pub fn board_edge_exposure_with_grid(
    board: &BoardModel,
    selected_layers: &[String],
    min_area: &Scalar,
    grid: SourceGridFacts,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("board-edge-exposure", &[&board.source], || {
        let Some(outline) = &board.board_outline else {
            return Ok(Vec::new());
        };
        let outline_rect = axis_aligned_outline_rect_with_grid(outline, grid);
        let mut violations = Vec::new();
        let mut skipped_rect_inside = 0_usize;
        let mut exact_difference_count = 0_usize;

        for feature in selected_copper_features(board, selected_layers) {
            if outline_rect
                .as_ref()
                .is_some_and(|rect| feature_bounds_inside_rect_with_grid(feature, rect, grid))
            {
                skipped_rect_inside += 1;
                continue;
            }

            exact_difference_count += 1;
            let outside_outline = match difference_for_check(
                &feature.region,
                outline,
                "board-edge-exposure",
                vec![feature.layer.clone(), "KiCad Edge.Cuts".into()],
            ) {
                Ok(outside) => outside,
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            };
            let shapes =
                multipolygon_to_shapes_scalar(&outside_outline.try_to_multipolygon()?, min_area)?;
            if shapes.is_empty() {
                continue;
            }

            violations.push(Violation::new(
            "board-edge-exposure",
            Severity::Warning,
            vec![feature.layer.clone(), "KiCad Edge.Cuts".to_string()],
            None,
            shapes,
            vec![feature.try_location_f64()?],
            Some(format!(
                "parsed {:?} copper extends outside the board outline; confirm edge plating, castellations, or copper pullback intent",
                feature.kind
            )),
        ));
        }

        log::trace!(
            "board-edge exposure: source={} selected_layers={} outline_fast_path={} skipped_rect_inside={} exact_difference_checks={} violations={}",
            board.source,
            selected_layers.len(),
            outline_rect.is_some(),
            skipped_rect_inside,
            exact_difference_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `high_speed_edge_readiness` design-readiness check or report helper.
pub fn high_speed_edge_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    edge_clearance: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    high_speed_edge_readiness_with_grid(
        board,
        selected_layers,
        edge_clearance,
        min_area,
        SourceGridFacts::PRIMITIVE_FLOAT_EDGE,
    )
}

/// Run high-speed edge readiness with retained source-grid facts.
///
/// The rectangular edge-band predicate uses exact lifted comparisons with
/// source-unit provenance before allowing an interior feature to skip CSG.
pub fn high_speed_edge_readiness_with_grid(
    board: &BoardModel,
    selected_layers: &[String],
    edge_clearance: &Scalar,
    min_area: &Scalar,
    grid: SourceGridFacts,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("high-speed-edge-readiness", &[&board.source], || {
        let Some(outline) = &board.board_outline else {
            return Ok(Vec::new());
        };
        let outline_rect = axis_aligned_outline_rect_with_grid(outline, grid);
        let broad_phase_clearance = scalar_broad_phase_radius(edge_clearance);
        let allowed = match offset_for_check(
            outline,
            -edge_clearance.clone(),
            "high-speed-edge-readiness",
            vec!["KiCad Edge.Cuts".into()],
        ) {
            Ok(allowed) => allowed,
            Err(uncertainty) => return Ok(vec![*uncertainty]),
        };
        let mut violations = Vec::new();
        let mut skipped_rect_inside = 0_usize;
        let mut exact_difference_count = 0_usize;

        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_speed_net(net) {
                continue;
            }
            if outline_rect.as_ref().is_some_and(|rect| {
                feature_bounds_inside_rect_margin_with_grid(
                    feature,
                    rect,
                    broad_phase_clearance,
                    grid,
                )
            }) {
                skipped_rect_inside += 1;
                continue;
            }

            exact_difference_count += 1;
            let intrusion = match difference_for_check(
                &feature.region,
                &allowed,
                "high-speed-edge-readiness",
                vec![feature.layer.clone(), "KiCad Edge.Cuts".into()],
            ) {
                Ok(intrusion) => intrusion,
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            };
            let shapes =
                multipolygon_to_shapes_scalar(&intrusion.try_to_multipolygon()?, min_area)?;
            if shapes.is_empty() {
                continue;
            }

            violations.push(Violation::new(
            "high-speed-edge-readiness",
            Severity::Warning,
            vec![feature.layer.clone(), "KiCad Edge.Cuts".to_string()],
            None,
            shapes,
            vec![feature.try_location_f64()?],
            Some(format!(
                "likely high-speed net {net} is within {edge_clearance:.6} of the board edge; review EMC, return-current, and connector-edge intent"
            )),
        ));
        }

        log::trace!(
            "high-speed edge readiness: source={} selected_layers={} outline_fast_path={} skipped_rect_inside={} exact_difference_checks={} edge_clearance={edge_clearance:.6} violations={}",
            board.source,
            selected_layers.len(),
            outline_rect.is_some(),
            skipped_rect_inside,
            exact_difference_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when non-edge intent copper appears inside the board-edge pullback band.
pub fn edge_copper_pullback_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    edge_clearance: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    edge_copper_pullback_readiness_with_grid(
        board,
        selected_layers,
        edge_clearance,
        min_area,
        SourceGridFacts::PRIMITIVE_FLOAT_EDGE,
    )
}

/// Run edge-copper pullback readiness with retained source-grid facts.
///
/// Both the rectangular edge-band fast path and the boundary-distance fallback
/// consume exact lifted predicates with rule/source provenance. Final CSG
/// shapes remain report geometry at HyperDRC's current compatibility boundary.
pub fn edge_copper_pullback_readiness_with_grid(
    board: &BoardModel,
    selected_layers: &[String],
    edge_clearance: &Scalar,
    min_area: &Scalar,
    grid: SourceGridFacts,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("edge-copper-pullback-readiness", &[&board.source], || {
        let Some(outline) = &board.board_outline else {
            return Ok(Vec::new());
        };
        let outline_rect = axis_aligned_outline_rect_with_grid(outline, grid);
        let broad_phase_clearance = scalar_broad_phase_radius(edge_clearance);
        let allowed = match offset_for_check(
            outline,
            -edge_clearance.clone(),
            "edge-copper-pullback-readiness",
            vec!["KiCad Edge.Cuts".into()],
        ) {
            Ok(allowed) => allowed,
            Err(uncertainty) => return Ok(vec![*uncertainty]),
        };
        let mut violations = Vec::new();
        let mut skipped_rect_inside = 0_usize;
        let mut exact_difference_count = 0_usize;

        for feature in selected_copper_features(board, selected_layers) {
            if let Some(net) = &feature.net
                && (looks_high_speed_net(net)
                    || looks_high_voltage_net(net)
                    || looks_edge_intent_net(net))
            {
                continue;
            }
            if outline_rect.as_ref().is_some_and(|rect| {
                feature_bounds_inside_rect_margin_with_grid(
                    feature,
                    rect,
                    broad_phase_clearance,
                    grid,
                )
            }) {
                skipped_rect_inside += 1;
                continue;
            }

            exact_difference_count += 1;
            let intrusion = match difference_for_check(
                &feature.region,
                &allowed,
                "edge-copper-pullback-readiness",
                vec![feature.layer.clone(), "KiCad Edge.Cuts".into()],
            ) {
                Ok(intrusion) => intrusion,
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            };
            let shapes =
                multipolygon_to_shapes_scalar(&intrusion.try_to_multipolygon()?, min_area)?;
            let has_edge_intrusion = !shapes.is_empty()
                || (crate::checks::boundaries_within_for_check(
                    &feature.region,
                    outline,
                    edge_clearance,
                    "edge-copper-pullback-readiness",
                    &[&feature.layer],
                    &mut violations,
                ) == Some(true));
            if !has_edge_intrusion {
                continue;
            }

            violations.push(Violation::new(
            "edge-copper-pullback-readiness",
            Severity::Warning,
            vec![feature.layer.clone(), "KiCad Edge.Cuts".to_string()],
            None,
            shapes,
            vec![feature.try_location_f64()?],
            Some(format!(
                "non-edge-intent copper appears within {edge_clearance:.6} board-edge clearance band; review edge pullback and copper-to-edge intent"
            )),
        ));
        }

        log::trace!(
            "edge copper-pullback readiness: source={} selected_layers={} outline_fast_path={} skipped_rect_inside={} exact_difference_checks={} edge_clearance={edge_clearance:.6} violations={}",
            board.source,
            selected_layers.len(),
            outline_rect.is_some(),
            skipped_rect_inside,
            exact_difference_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `acid-trap` KiCad trace-junction readiness helper.
///
/// Layer-level acid-trap checks find acute polygon vertices after all copper is
/// flattened. This board-level helper keeps KiCad segment identity long enough
/// to identify same-net traces that join at an acute angle. The check is a DFM
/// review heuristic, not a wet-etch process simulator. Copper wet-etch profiles
/// depend on process transport conditions, so HyperDRC reports
/// suspect junction geometry for review instead of claiming a specific
/// corrosion or over-etch failure. A deterministic grid proposes segment pairs
/// before exact CSG overlap and junction-angle review.
pub fn trace_junction_acid_trap_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    max_angle_degrees: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "trace-junction-acid-trap-readiness",
        &[&board.source],
        || {
            let segments = selected_copper_features(board, selected_layers)
                .into_iter()
                .filter(|feature| feature.kind == CopperKind::Segment)
                .filter(|feature| feature.net.is_some())
                .collect::<Vec<_>>();
            let segment_bounds = segments
                .iter()
                .map(|segment| {
                    segment
                        .region
                        .try_to_multipolygon()
                        .map(|view| view.bounding_rect())
                })
                .collect::<Result<Vec<_>, _>>()?;
            let segment_index = CopperSpatialIndex::new(&segments, 0.0);
            let mut violations = Vec::new();
            let mut candidate_pairs = 0usize;
            let mut exact_pairs = 0usize;

            for left_index in 0..segments.len() {
                let left = segments[left_index];
                let Some(left_bounds) = &segment_bounds[left_index] else {
                    continue;
                };
                for right_index in segment_index.same_layer_near_feature(left, 0.0) {
                    if right_index <= left_index {
                        continue;
                    }
                    let right = segments[right_index];
                    if left.layer != right.layer || left.net != right.net {
                        continue;
                    }
                    candidate_pairs += 1;
                    let Some(right_bounds) = &segment_bounds[right_index] else {
                        continue;
                    };
                    if !rects_overlap(left_bounds, right_bounds) {
                        continue;
                    }

                    exact_pairs += 1;
                    let overlap = match intersection_for_check(
                        &left.region,
                        &right.region,
                        "trace-junction-acid-trap-readiness",
                        vec![left.layer.clone()],
                    ) {
                        Ok(overlap) => overlap,
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    };
                    let overlap_polygons = overlap.try_to_multipolygon()?;
                    let shapes = multipolygon_to_shapes_scalar(&overlap_polygons, min_area)?;
                    if shapes.is_empty() {
                        continue;
                    }
                    let Some(junction) = multipolygon_center(&overlap_polygons) else {
                        continue;
                    };
                    let Some(angle) =
                        point_angle_degrees_scalar(&left.location, junction, &right.location)
                    else {
                        continue;
                    };
                    if crate::scalar::le(&angle, &Scalar::zero())
                        || crate::scalar::ge(&angle, max_angle_degrees)
                    {
                        continue;
                    }

                    let net = left.net.as_deref().unwrap_or("unknown");
                    violations.push(Violation::new(
                "acid-trap-trace-junction",
                Severity::Warning,
                vec![left.layer.clone()],
                None,
                shapes,
                vec![
                    junction,
                    left.try_location_f64()?,
                    right.try_location_f64()?,
                ],
                Some(format!(
                    "same-net trace junction on {net} forms an acute {angle:#.3} degree angle below {max_angle_degrees:#.3}; review acid-trap and etch-cleanout risk"
                )),
            ));
                }
            }
            log::trace!(
                "trace-junction acid-trap readiness: source={} segments={} spatial_buckets={} candidate_pairs={} exact_pairs={} selected_layers={} violations={}",
                board.source,
                segments.len(),
                segment_index.bucket_count(),
                candidate_pairs,
                exact_pairs,
                selected_layers.len(),
                violations.len()
            );

            Ok(violations)
        },
    )
}

/// Run the `controlled_impedance_readiness` design-readiness check or report helper.
/// Warn when likely high-speed nets change layers without a parsed via.
///
/// This is not an impedance solver. It is a release-readiness guard based on
/// IPC-2221B's requirement to treat controlled routing and conductor geometry
/// as explicit board-design constraints: when a high-speed net appears on
/// multiple selected copper layers without a same-net via, the parser view is
/// internally inconsistent and should be reviewed before relying on downstream
/// field or stackup checks.
pub fn controlled_impedance_readiness(
    board: &BoardModel,
    selected_layers: &[String],
) -> Vec<Violation> {
    crate::checks::run_geometry_check("controlled-impedance-readiness", &[&board.source], || {
        let mut nets: BTreeMap<String, NetLayerUse> = BTreeMap::new();
        let mut high_speed_features = 0usize;

        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_speed_net(net) {
                continue;
            }
            high_speed_features += 1;

            let entry = nets.entry(net.clone()).or_default();
            entry.layers.insert(feature.layer.clone());
            entry.locations.push(feature.try_location_f64()?);
            if feature.kind == CopperKind::Via {
                entry.has_via = true;
            }
        }

        let net_count = nets.len();
        let violations = nets
            .into_iter()
            .filter(|(_, usage)| usage.layers.len() > 1 && !usage.has_via)
            .map(|(net, usage)| {
                let layers = usage.layers.into_iter().collect::<Vec<_>>();
                Violation::new(
                    "controlled-impedance-readiness",
                    Severity::Warning,
                    layers.clone(),
                    None,
                    Vec::new(),
                    usage.locations,
                    Some(format!(
                        "likely high-speed net {net} appears on {} copper layers without a parsed same-net via; confirm layer-change and return-path intent",
                        layers.len()
                    )),
                )
            })
            .collect::<Vec<_>>();
        log::trace!(
            "controlled-impedance readiness: source={} high_speed_features={} high_speed_nets={} selected_layers={} violations={}",
            board.source,
            high_speed_features,
            net_count,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when inferred differential-pair sides are missing or split by layer.
///
/// Pair membership is inferred from common suffixes, so the result is a
/// readiness prompt rather than a formal constraint proof. Coupled pair
/// structure is treated as explicit design intent; this check makes missing or
/// layer-divergent inferred sides visible before release.
pub fn differential_pair_readiness(
    board: &BoardModel,
    selected_layers: &[String],
) -> Vec<Violation> {
    crate::checks::run_geometry_check("differential-pair-readiness", &[&board.source], || {
        let mut pairs: BTreeMap<String, DifferentialPairUse> = BTreeMap::new();
        let mut inferred_features = 0usize;

        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            let Some((pair, side)) = differential_pair_key(net) else {
                continue;
            };
            inferred_features += 1;

            let entry = pairs.entry(pair).or_default();
            match side {
                DifferentialSide::Positive => {
                    entry.positive_layers.insert(feature.layer.clone());
                    entry.positive_locations.push(feature.try_location_f64()?);
                }
                DifferentialSide::Negative => {
                    entry.negative_layers.insert(feature.layer.clone());
                    entry.negative_locations.push(feature.try_location_f64()?);
                }
            }
        }

        let pair_count = pairs.len();
        let mut violations = Vec::new();
        for (pair, usage) in pairs {
            let has_positive = !usage.positive_layers.is_empty();
            let has_negative = !usage.negative_layers.is_empty();
            if !has_positive || !has_negative {
                let mut layers = usage.positive_layers.clone();
                layers.extend(usage.negative_layers.clone());
                let mut locations = usage.positive_locations.clone();
                locations.extend(usage.negative_locations.clone());
                let missing = if has_positive { "negative" } else { "positive" };
                violations.push(Violation::new(
                    "differential-pair-readiness",
                    Severity::Warning,
                    layers.into_iter().collect(),
                    None,
                    Vec::new(),
                    locations,
                    Some(format!(
                        "likely differential pair {pair} is missing its {missing} side on selected copper layers"
                    )),
                ));
                continue;
            }

            if usage.positive_layers != usage.negative_layers {
                let mut layers = usage.positive_layers.clone();
                layers.extend(usage.negative_layers.clone());
                let mut locations = usage.positive_locations;
                locations.extend(usage.negative_locations);
                violations.push(Violation::new(
                    "differential-pair-readiness",
                    Severity::Warning,
                    layers.into_iter().collect(),
                    None,
                    Vec::new(),
                    locations,
                    Some(format!(
                        "likely differential pair {pair} has positive and negative sides on different selected copper layers"
                    )),
                ));
            }
        }

        log::trace!(
            "differential-pair readiness: source={} inferred_features={} inferred_pairs={} selected_layers={} violations={}",
            board.source,
            inferred_features,
            pair_count,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when inferred differential-pair sides are farther apart than expected.
///
/// This is a readiness heuristic over parsed copper, not a coupled-line field
/// solver. Pair spacing is treated as explicit routing intent. Candidate
/// positive/negative side matches use the shared copper spatial broad phase
/// before exact boundary-distance
/// checks. If no close candidate exists, the check falls back to exact nearest
/// distance so true "too far apart" findings still include a measured gap.
pub fn differential_pair_spacing_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    maximum_pair_gap: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "differential-pair-spacing-readiness",
        &[&board.source],
        || {
            let mut pairs: BTreeMap<String, DifferentialPairFeatureUse<'_>> = BTreeMap::new();
            let mut inferred_features = 0usize;

            for feature in selected_copper_features(board, selected_layers) {
                let Some(net) = &feature.net else {
                    continue;
                };
                let Some((pair, side)) = differential_pair_key(net) else {
                    continue;
                };
                inferred_features += 1;

                let entry = pairs.entry(pair).or_default();
                match side {
                    DifferentialSide::Positive => entry.positive.push(feature),
                    DifferentialSide::Negative => entry.negative.push(feature),
                }
            }

            let pair_count = pairs.len();
            let mut candidate_pairs = 0usize;
            let mut exact_pairs = 0usize;
            let mut violations = Vec::new();
            let broad_phase_gap = scalar_broad_phase_radius(maximum_pair_gap);
            for (pair, usage) in pairs {
                let mut layers = BTreeSet::new();
                layers.extend(usage.positive.iter().map(|feature| feature.layer.clone()));
                layers.extend(usage.negative.iter().map(|feature| feature.layer.clone()));

                for layer in layers {
                    let positives = usage
                        .positive
                        .iter()
                        .copied()
                        .filter(|feature| feature.layer == layer)
                        .collect::<Vec<_>>();
                    let negatives = usage
                        .negative
                        .iter()
                        .copied()
                        .filter(|feature| feature.layer == layer)
                        .collect::<Vec<_>>();
                    if positives.is_empty() || negatives.is_empty() {
                        continue;
                    }

                    let negative_index = CopperSpatialIndex::new(&negatives, broad_phase_gap);
                    let has_close_side = positives.iter().any(|positive| {
                        negative_index
                            .same_layer_near_feature(positive, broad_phase_gap)
                            .into_iter()
                            .any(|negative_index| {
                                candidate_pairs += 1;
                                exact_pairs += 1;
                                crate::checks::boundaries_within_for_check(
                                    &positive.region,
                                    &negatives[negative_index].region,
                                    maximum_pair_gap,
                                    "differential-pair-spacing-readiness",
                                    &[&layer],
                                    &mut violations,
                                ) == Some(true)
                            })
                    });
                    if has_close_side {
                        continue;
                    }

                    let nearest = crate::checks::geometry_result_for_check(
                        crate::checks::distance::minimum_metric(
                            positives
                                .iter()
                                .flat_map(|positive| {
                                    negatives.iter().map(move |negative| (*positive, *negative))
                                })
                                .map(|(positive, negative)| {
                                    exact_pairs += 1;
                                    crate::checks::distance::region_boundary_distance(
                                        &positive.region,
                                        &negative.region,
                                    )
                                    .map(|gap| gap.map(|gap| ((positive, negative), gap)))
                                }),
                        ),
                        "differential-pair-spacing-readiness",
                        &[&layer],
                        &mut violations,
                    )
                    .flatten();
                    let Some(((positive, negative), gap)) = nearest else {
                        continue;
                    };
                    let positive_location = positive.try_location_f64()?;
                    let negative_location = negative.try_location_f64()?;

                    violations.push(Violation::new(
                    "differential-pair-spacing-readiness",
                    Severity::Warning,
                    vec![layer],
                    None,
                    Vec::new(),
                    vec![positive_location, negative_location],
                    Some(format!(
                        "likely differential pair {pair} has nearest parsed pair-side spacing {gap:.6} above review threshold {maximum_pair_gap:.6}"
                    )),
                ));
                }
            }

            log::trace!(
                "differential-pair spacing readiness: source={} inferred_features={} inferred_pairs={} candidate_pairs={} exact_pairs={} selected_layers={} threshold={maximum_pair_gap:.6} violations={}",
                board.source,
                inferred_features,
                pair_count,
                candidate_pairs,
                exact_pairs,
                selected_layers.len(),
                violations.len()
            );

            Ok(violations)
        },
    )
}

/// Warn when one side of a parsed differential pair has asymmetric via count or
/// layer coverage relative to the opposite side.
pub fn differential_pair_via_symmetry_readiness(
    board: &BoardModel,
    selected_layers: &[String],
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "differential-pair-via-symmetry-readiness",
        &[&board.source],
        || {
            let mut pairs: BTreeMap<String, DifferentialPairViaUse> = BTreeMap::new();

            for feature in selected_copper_features(board, selected_layers) {
                let Some(net) = &feature.net else {
                    continue;
                };
                let Some((pair, side)) = differential_pair_key(net) else {
                    continue;
                };
                if feature.kind != CopperKind::Via {
                    continue;
                }

                let entry = pairs.entry(pair).or_default();
                match side {
                    DifferentialSide::Positive => {
                        entry.positive_via_count += 1;
                        entry.positive_via_layers.insert(feature.layer.clone());
                        entry
                            .positive_via_locations
                            .push(feature.try_location_f64()?);
                    }
                    DifferentialSide::Negative => {
                        entry.negative_via_count += 1;
                        entry.negative_via_layers.insert(feature.layer.clone());
                        entry
                            .negative_via_locations
                            .push(feature.try_location_f64()?);
                    }
                }
            }

            let mut violations = Vec::new();
            for (pair, usage) in pairs {
                if usage.positive_via_count == 0 && usage.negative_via_count == 0 {
                    continue;
                }
                if usage.positive_via_count == usage.negative_via_count
                    && usage.positive_via_layers == usage.negative_via_layers
                {
                    continue;
                }

                let mut layers = usage.positive_via_layers.clone();
                layers.extend(usage.negative_via_layers.clone());
                let mut locations = usage.positive_via_locations;
                locations.extend(usage.negative_via_locations);

                let mismatch = if usage.positive_via_count != usage.negative_via_count {
                    format!(
                        "uneven via count {}:{}",
                        usage.positive_via_count, usage.negative_via_count
                    )
                } else {
                    "mismatched via layers".to_string()
                };

                violations.push(Violation::new(
                    "differential-pair-via-symmetry-readiness",
                    Severity::Warning,
                    layers.into_iter().collect(),
                    None,
                    Vec::new(),
                    locations,
                    Some(format!(
                        "differential pair {pair} has asymmetric via symmetry ({mismatch})"
                    )),
                ));
            }

            Ok(violations)
        },
    )
}

/// Warn when likely differential-pair copper lacks nearby same-layer ground.
///
/// This is a guard/return-path readiness check, not a field solver. IPC-2221B
/// treats conductor spacing and return-path planning as board-design concerns;
/// here we simply require some parsed ground copper near each differential side
/// so missing guard/coplanar/reference intent is visible before release.
/// Ground candidates use a deterministic grid broad phase before exact geometry
/// distance/overlap review.
pub fn differential_pair_return_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    guard_distance: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "differential-pair-return-readiness",
        &[&board.source],
        || {
            let features = selected_copper_features(board, selected_layers);
            let ground_features = features
                .iter()
                .copied()
                .filter(|feature| feature.net.as_deref().is_some_and(looks_ground_net))
                .collect::<Vec<_>>();
            let broad_phase_distance = scalar_broad_phase_radius(guard_distance);
            let ground_index = CopperSpatialIndex::new(&ground_features, broad_phase_distance);
            let mut violations = Vec::new();
            let mut candidate_pairs = 0usize;

            for feature in &features {
                let feature = *feature;
                let Some(net) = &feature.net else {
                    continue;
                };
                let Some((pair, side)) = differential_pair_key(net) else {
                    continue;
                };

                let mut has_guard = false;
                for ground_index in
                    ground_index.same_layer_near_feature(feature, broad_phase_distance)
                {
                    candidate_pairs += 1;
                    match copper_features_touch_scalar(
                        feature,
                        ground_features[ground_index],
                        guard_distance,
                        "differential-pair-return-readiness",
                    ) {
                        Ok(true) => {
                            has_guard = true;
                            break;
                        }
                        Ok(false) => {}
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    }
                }
                if has_guard {
                    continue;
                }

                let side_label = match side {
                    DifferentialSide::Positive => "positive",
                    DifferentialSide::Negative => "negative",
                };
                violations.push(Violation::new(
                "differential-pair-return-readiness",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "likely differential pair {pair} {side_label} side on net {net} has no parsed same-layer ground copper within {guard_distance:.6}; review guard, reference, and return-path intent"
                )),
            ));
            }
            log::trace!(
                "differential-pair return readiness: source={} features={} ground_features={} ground_buckets={} candidate_pairs={} guard_distance={guard_distance:.6} violations={}",
                board.source,
                features.len(),
                ground_features.len(),
                ground_index.bucket_count(),
                candidate_pairs,
                violations.len()
            );

            Ok(violations)
        },
    )
}

/// Warn when likely high-speed nets have no parsed ground-zone context.
///
/// IPC-2221B treats return-path and layer-stack planning as board-design
/// constraints. This coarse check only verifies that at least one parsed ground
/// zone exists on the selected copper set before higher-fidelity void and
/// split-plane checks try to reason about coverage.
pub fn reference_plane_readiness(board: &BoardModel, selected_layers: &[String]) -> Vec<Violation> {
    crate::checks::run_geometry_check("reference-plane-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let has_ground_zone = features.iter().any(|feature| {
            feature.kind == CopperKind::Zone && feature.net.as_deref().is_some_and(looks_ground_net)
        });
        if has_ground_zone {
            log::trace!(
                "reference-plane readiness: source={} features={} selected_layers={} has_ground_zone=true violations=0",
                board.source,
                features.len(),
                selected_layers.len()
            );
            return Ok(Vec::new());
        }

        let mut nets: BTreeMap<String, NetLayerUse> = BTreeMap::new();
        for feature in &features {
            let feature = *feature;
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_speed_net(net) {
                continue;
            }

            let entry = nets.entry(net.clone()).or_default();
            entry.layers.insert(feature.layer.clone());
            entry.locations.push(feature.try_location_f64()?);
        }

        let high_speed_nets = nets.len();
        let violations = nets
            .into_iter()
            .map(|(net, usage)| {
                Violation::new(
                    "reference-plane-readiness",
                    Severity::Warning,
                    usage.layers.into_iter().collect(),
                    None,
                    Vec::new(),
                    usage.locations,
                    Some(format!(
                        "likely high-speed net {net} has no parsed ground zone on selected copper layers; review reference-plane and return-path continuity"
                    )),
                )
            })
            .collect::<Vec<_>>();
        log::trace!(
            "reference-plane readiness: source={} features={} high_speed_nets={} selected_layers={} has_ground_zone=false violations={}",
            board.source,
            features.len(),
            high_speed_nets,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `reference_plane_void_readiness` design-readiness check or report helper.
///
/// Ground-zone candidates use the shared copper spatial index before exact
/// feature-minus-reference-plane CSG subtraction. This preserves exact
/// geometry for the final void decision.
pub fn reference_plane_void_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("reference-plane-void-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let ground_features = features
            .iter()
            .copied()
            .filter(|feature| {
                feature.kind == CopperKind::Zone
                    && feature.net.as_deref().is_some_and(looks_ground_net)
            })
            .collect::<Vec<_>>();
        if ground_features.is_empty() {
            return Ok(Vec::new());
        }
        let ground_index = CopperSpatialIndex::new(&ground_features, 0.0);

        let mut violations = Vec::new();
        let mut candidate_features = 0usize;
        let mut candidate_ground_zones = 0usize;
        for feature in features {
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_speed_net(net) || feature.kind == CopperKind::Via {
                continue;
            }
            candidate_features += 1;

            let candidates = ground_index.all_layers_near_feature(feature, 0.0);
            candidate_ground_zones += candidates.len();
            let shapes = if candidates.is_empty() {
                multipolygon_to_shapes_scalar(&feature.region.try_to_multipolygon()?, min_area)?
            } else {
                let mut ground_polygons = Vec::new();
                for ground_index in candidates {
                    ground_polygons.extend(
                        ground_features[ground_index]
                            .region
                            .try_to_multipolygon()?
                            .0,
                    );
                }
                let ground = polygons_to_profile(
                    ground_polygons,
                    Some(LayerMetadata {
                        name: "KiCad ground zones".to_string(),
                    }),
                );
                let uncovered = match difference_for_check(
                    &feature.region,
                    &ground,
                    "reference-plane-void-readiness",
                    vec![feature.layer.clone(), "KiCad ground zones".into()],
                ) {
                    Ok(uncovered) => uncovered,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                multipolygon_to_shapes_scalar(&uncovered.try_to_multipolygon()?, min_area)?
            };
            if shapes.is_empty() {
                continue;
            }

            violations.push(Violation::new(
            "reference-plane-void-readiness",
            Severity::Warning,
            vec![feature.layer.clone(), "KiCad ground zones".to_string()],
            None,
            shapes,
            vec![feature.try_location_f64()?],
            Some(format!(
                "likely high-speed net {net} has copper without overlapping parsed ground-zone coverage; review split-plane and void-crossing return path"
            )),
        ));
        }

        log::trace!(
            "reference-plane void readiness: source={} high_speed_features={} ground_zones={} ground_buckets={} candidate_ground_zones={} violations={}",
            board.source,
            candidate_features,
            ground_features.len(),
            ground_index.bucket_count(),
            candidate_ground_zones,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `orphaned_zone_readiness` design-readiness check or report helper.
///
/// Parsed pad, via, and segment anchors are indexed once, then each zone only
/// reviews same-layer nearby anchor candidates before exact CSG or boundary
/// distance confirmation. The grid is a conservative broad phase, while zone
/// connectivity remains an exact geometry decision.
pub fn orphaned_zone_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    anchor_tolerance: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("orphaned-zone-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let anchors = features
            .iter()
            .copied()
            .filter(|feature| feature.kind != CopperKind::Zone)
            .collect::<Vec<_>>();
        let broad_phase_tolerance = scalar_broad_phase_radius(anchor_tolerance);
        let anchor_index = CopperSpatialIndex::new(&anchors, broad_phase_tolerance);
        let mut violations = Vec::new();
        let mut candidate_anchors = 0usize;

        for zone in features
            .iter()
            .filter(|feature| feature.kind == CopperKind::Zone)
        {
            let Some(net) = &zone.net else {
                continue;
            };
            let candidates = anchor_index.same_layer_near_feature(zone, broad_phase_tolerance);
            candidate_anchors += candidates.len();
            let mut has_anchor = false;
            for anchor_index in candidates {
                let anchor = anchors[anchor_index];
                if anchor.net.as_deref() != Some(net.as_str()) {
                    continue;
                }
                match copper_features_touch_scalar(
                    anchor,
                    zone,
                    anchor_tolerance,
                    "orphaned-zone-readiness",
                ) {
                    Ok(true) => {
                        has_anchor = true;
                        break;
                    }
                    Ok(false) => {}
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                }
            }
            if has_anchor {
                continue;
            }

            violations.push(Violation::new(
                "orphaned-zone-readiness",
                Severity::Warning,
                vec![zone.layer.clone()],
                None,
                Vec::new(),
                vec![zone.try_location_f64()?],
                Some(format!(
                    "copper zone on net {net} has no parsed same-net pad, via, or segment within {anchor_tolerance:.6}; review zone refill and connectivity"
                )),
            ));
        }

        log::trace!(
            "orphaned-zone readiness: source={} zones={} anchors={} anchor_buckets={} candidate_anchors={} violations={}",
            board.source,
            features
                .iter()
                .filter(|feature| feature.kind == CopperKind::Zone)
                .count(),
            anchors.len(),
            anchor_index.bucket_count(),
            candidate_anchors,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `same_net_island_readiness` design-readiness check or report helper.
///
/// Same-net connectivity is still decided by exact overlap/distance predicates,
/// but a deterministic grid proposes candidate edges. That keeps sparse same-net
/// copper fields from requiring an all-pairs connectivity walk.
pub fn same_net_island_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    connection_tolerance: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("same-net-island-readiness", &[&board.source], || {
        let mut by_net_layer: BTreeMap<(String, String), Vec<&CopperFeature>> = BTreeMap::new();
        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            by_net_layer
                .entry((net.clone(), feature.layer.clone()))
                .or_default()
                .push(feature);
        }

        let mut violations = Vec::new();
        for ((net, layer), features) in by_net_layer {
            if features.len() < 2 {
                continue;
            }
            let component_result = match copper_components(&features, connection_tolerance) {
                Ok(result) => result,
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            };
            let components = component_result.components;
            log::trace!(
                "same-net island readiness: net={} layer={} features={} spatial_buckets={} exact_pairs={} components={}",
                net,
                layer,
                features.len(),
                component_result.spatial_buckets,
                component_result.exact_pairs,
                components.len()
            );
            if components.len() < 2 {
                continue;
            }

            let locations = components
                .iter()
                .filter_map(|component| {
                    component
                        .first()
                        .map(|index| features[*index].try_location_f64())
                })
                .collect::<Result<Vec<_>, _>>()?;
            violations.push(Violation::new(
                "same-net-island-readiness",
                Severity::Warning,
                vec![layer],
                None,
                Vec::new(),
                locations,
                Some(format!(
                    "net {net} appears as {} disconnected copper islands on one selected layer; review routing, zone refill, or intentional no-connect handling",
                    components.len()
                )),
            ));
        }

        Ok(violations)
    })
}

/// Warn when likely high-current nets change layers with too few parsed vias.
///
/// IPC-2152 frames current carrying capacity as a design-specific board
/// constraint. This check conservatively flags
/// layer-changing likely power nets whose parsed same-net via count is below the
/// redundancy threshold used by this readiness profile.
pub fn high_current_readiness(board: &BoardModel, selected_layers: &[String]) -> Vec<Violation> {
    crate::checks::run_geometry_check("high-current-readiness", &[&board.source], || {
        let mut nets: BTreeMap<String, NetLayerUse> = BTreeMap::new();
        let mut high_current_features = 0usize;

        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_current_net(net) {
                continue;
            }
            high_current_features += 1;

            let entry = nets.entry(net.clone()).or_default();
            entry.layers.insert(feature.layer.clone());
            entry.locations.push(feature.try_location_f64()?);
            if feature.kind == CopperKind::Via {
                entry.via_count += 1;
            }
        }

        let net_count = nets.len();
        let violations = nets
            .into_iter()
            .filter(|(_, usage)| usage.layers.len() > 1 && usage.via_count < 2)
            .map(|(net, usage)| {
                let layers = usage.layers.into_iter().collect::<Vec<_>>();
                Violation::new(
                    "high-current-readiness",
                    Severity::Warning,
                    layers.clone(),
                    None,
                    Vec::new(),
                    usage.locations,
                    Some(format!(
                        "likely high-current net {net} changes across {} copper layers with only {} parsed same-net via(s); review via array and current-sharing intent",
                        layers.len(),
                        usage.via_count
                    )),
                )
            })
            .collect::<Vec<_>>();
        log::trace!(
            "high-current readiness: source={} high_current_features={} high_current_nets={} selected_layers={} violations={}",
            board.source,
            high_current_features,
            net_count,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when likely high-current nets have no parsed same-net copper zone.
///
/// IPC-2152 frames current carrying capacity as a board-specific design
/// decision rather than a simple trace-width constant. This readiness check is
/// therefore conservative: it infers power intent from net names and asks for a
/// parsed pour/plane/zone on each selected high-current net so reviewers can
/// confirm current-spreading intent before release.
pub fn power_plane_readiness(board: &BoardModel, selected_layers: &[String]) -> Vec<Violation> {
    crate::checks::run_geometry_check("power-plane-readiness", &[&board.source], || {
        let mut nets: BTreeMap<String, NetLayerUse> = BTreeMap::new();
        let mut high_current_features = 0usize;

        for feature in selected_copper_features(board, selected_layers) {
            let Some(net) = &feature.net else {
                continue;
            };
            if !looks_high_current_net(net) {
                continue;
            }
            high_current_features += 1;

            let entry = nets.entry(net.clone()).or_default();
            entry.layers.insert(feature.layer.clone());
            entry.locations.push(feature.try_location_f64()?);
            if feature.kind == CopperKind::Zone {
                entry.has_zone = true;
            }
        }

        let net_count = nets.len();
        let violations = nets
            .into_iter()
            .filter(|(_, usage)| !usage.has_zone)
            .map(|(net, usage)| {
                Violation::new(
                    "power-plane-readiness",
                    Severity::Warning,
                    usage.layers.into_iter().collect(),
                    None,
                    Vec::new(),
                    usage.locations,
                    Some(format!(
                        "likely high-current net {net} has no parsed same-net copper zone on selected layers; review pour, plane, and current-spreading intent"
                    )),
                )
            })
            .collect::<Vec<_>>();
        log::trace!(
            "power-plane readiness: source={} high_current_features={} high_current_nets={} selected_layers={} violations={}",
            board.source,
            high_current_features,
            net_count,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when likely high-current copper has a narrow local neck.
///
/// IPC-2152 covers board-level current-carrying capacity. This check reviews
/// local current-density constrictions using parsed copper bounds as a conservative
/// neck proxy, so suspect findings should be verified against native geometry,
/// stackup, copper weight, temperature rise, and current requirements.
pub fn high_current_neck_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    minimum_power_width: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("high-current-neck-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let mut high_current_features = 0usize;
        let mut measured_features = 0usize;
        let mut violations = Vec::new();

        for feature in &features {
            let Some(net) = feature.net.as_deref() else {
                continue;
            };
            if !looks_high_current_net(net) {
                continue;
            }
            high_current_features += 1;

            let Some(Some(width)) = crate::checks::geometry_result_for_check(
                minimum_bounding_dimension(&feature.region),
                "high-current-neck-readiness",
                &[&feature.layer],
                &mut violations,
            ) else {
                continue;
            };
            if crate::scalar::le(&width, &Scalar::zero()) {
                continue;
            }
            measured_features += 1;
            if crate::scalar::ge(&width, minimum_power_width) {
                continue;
            }

            violations.push(Violation::new(
                "high-current-neck-readiness",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "likely high-current net {net} has {:?} copper neck width {width:.6} below preferred power width {minimum_power_width:.6}",
                    feature.kind
                )),
            ));
        }

        log::trace!(
            "high-current neck readiness: source={} selected_features={} high_current_features={} measured_features={} selected_layers={} minimum_power_width={minimum_power_width:.6} violations={}",
            board.source,
            features.len(),
            high_current_features,
            measured_features,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when likely card-edge/gold-finger nets contain via copper.
///
/// IPC-4552B and IPC-4553A surface-finish guidance treats edge-contact finish,
/// plating, and wear surfaces as explicit fabrication intent. This readiness
/// check is deliberately conservative: it infers finger nets from names and
/// reports vias on those nets so reviewers can confirm no-via finger geometry,
/// bevel keepouts, and plating notes before release.
pub fn gold_finger_readiness(board: &BoardModel, selected_layers: &[String]) -> Vec<Violation> {
    crate::checks::run_geometry_check("gold-finger-readiness", &[&board.source], || {
        let features = selected_copper_features(board, selected_layers);
        let mut finger_features = 0usize;
        let mut finger_vias = 0usize;
        let mut violations = Vec::new();

        for feature in &features {
            let Some(net) = feature.net.as_deref() else {
                continue;
            };
            if !looks_gold_finger_net(net) {
                continue;
            }
            finger_features += 1;
            if feature.kind != CopperKind::Via {
                continue;
            }
            finger_vias += 1;

            violations.push(Violation::new(
                "gold-finger-readiness",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "likely gold-finger net {net} has via copper; review no-via finger plating and bevel keepout rules"
                )),
            ));
        }

        log::trace!(
            "gold-finger readiness: source={} selected_features={} finger_features={} finger_vias={} selected_layers={} violations={}",
            board.source,
            features.len(),
            finger_features,
            finger_vias,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Warn when likely card-edge contact copper is not close to the board edge.
///
/// IPC-4552B and IPC-4553A surface-finish guidance makes contact plating an
/// explicit fabrication handoff. Card-edge contacts also depend on bevel and
/// edge placement, so this check treats likely finger pads/segments far from the
/// parsed outline as suspect release data. It uses exact polygon boundary
/// distance; naming and outline inference are still conservative readiness
/// signals that should be confirmed against the fabrication drawing.
pub fn gold_finger_edge_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    edge_distance: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("gold-finger-edge-readiness", &[&board.source], || {
        let Some(outline) = &board.board_outline else {
            log::trace!(
                "gold-finger edge readiness: source={} selected_layers={} has_outline=false edge_distance={edge_distance:.6} violations=0",
                board.source,
                selected_layers.len()
            );
            return Ok(Vec::new());
        };

        let features = selected_copper_features(board, selected_layers);
        let mut finger_features = 0usize;
        let mut measured_features = 0usize;
        let mut violations = Vec::new();

        for feature in &features {
            let Some(net) = feature.net.as_deref() else {
                continue;
            };
            if !looks_gold_finger_net(net)
                || !matches!(feature.kind, CopperKind::Pad | CopperKind::Segment)
            {
                continue;
            }
            finger_features += 1;
            let Some(gap) = crate::checks::boundary_distance_for_check(
                &feature.region,
                outline,
                "gold-finger-edge-readiness",
                &[&feature.layer],
                &mut violations,
            ) else {
                continue;
            };
            measured_features += 1;
            if crate::checks::metric_cmp_for_check(
                &gap,
                edge_distance,
                "gold-finger-edge-readiness",
                &[&feature.layer],
                &mut violations,
            )
            .is_none_or(|order| !order.is_gt())
            {
                continue;
            }

            violations.push(Violation::new(
                "gold-finger-edge-readiness",
                Severity::Warning,
                vec![feature.layer.clone()],
                None,
                Vec::new(),
                vec![feature.try_location_f64()?],
                Some(format!(
                    "likely gold-finger net {net} is {gap:.6} from board edge, beyond expected edge-finger band {edge_distance:.6}; review card-edge placement and bevel intent"
                )),
            ));
        }

        log::trace!(
            "gold-finger edge readiness: source={} selected_features={} finger_features={} measured_features={} selected_layers={} has_outline=true edge_distance={edge_distance:.6} violations={}",
            board.source,
            features.len(),
            finger_features,
            measured_features,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `gold_finger_spacing_readiness` design-readiness check or report helper.
///
/// Candidate contact pairs are selected with the shared spatial broad phase and
/// then checked with the exact offset/intersection predicate. This keeps sparse card-edge connector fields from
/// degrading into all-pairs CSG work.
pub fn gold_finger_spacing_readiness(
    board: &BoardModel,
    selected_layers: &[String],
    minimum_spacing: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("gold-finger-spacing-readiness", &[&board.source], || {
        let fingers = selected_copper_features(board, selected_layers)
            .into_iter()
            .filter(|feature| feature.net.as_deref().is_some_and(looks_gold_finger_net))
            .filter(|feature| matches!(feature.kind, CopperKind::Pad | CopperKind::Segment))
            .collect::<Vec<_>>();
        let broad_phase_spacing = scalar_broad_phase_radius(minimum_spacing);
        let finger_index = CopperSpatialIndex::new(&fingers, broad_phase_spacing);
        let mut exact_pair_count = 0_usize;
        let mut violations = Vec::new();

        for left_index in 0..fingers.len() {
            let left = fingers[left_index];
            for right_index in finger_index.same_layer_near_feature(left, broad_phase_spacing) {
                if right_index <= left_index {
                    continue;
                }
                let right = fingers[right_index];
                if left.net == right.net {
                    continue;
                }

                exact_pair_count += 1;
                let overlap = match intersection_for_check(
                    &left.region,
                    &right.region,
                    "gold-finger-spacing-readiness",
                    vec![left.layer.clone()],
                ) {
                    Ok(overlap) => overlap,
                    Err(uncertainty) => return Ok(vec![*uncertainty]),
                };
                let shapes =
                    multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                let fallback_hit = shapes.is_empty()
                    && (crate::checks::boundaries_within_for_check(
                        &left.region,
                        &right.region,
                        minimum_spacing,
                        "gold-finger-spacing-readiness",
                        &[&left.layer],
                        &mut violations,
                    ) == Some(true));
                if shapes.is_empty() && !fallback_hit {
                    continue;
                }

                violations.push(Violation::new(
                "gold-finger-spacing-readiness",
                Severity::Warning,
                vec![left.layer.clone()],
                None,
                shapes,
                vec![
                    left.try_location_f64()?,
                    right.try_location_f64()?,
                ],
                Some(format!(
                    "likely gold-finger nets {:?} and {:?} are within finger spacing {minimum_spacing:.6}; review contact pitch, plating, mask opening, and bevel tolerances",
                    left.net, right.net
                )),
            ));
            }
        }
        log::trace!(
            "gold-finger spacing readiness: source={} fingers={} spatial_buckets={} exact_pairs={} minimum_spacing={minimum_spacing:.6} violations={}",
            board.source,
            fingers.len(),
            finger_index.bucket_count(),
            exact_pair_count,
            violations.len()
        );

        Ok(violations)
    })
}

/// Run the `gold_finger_drill_keepout_readiness` design-readiness check or report helper.
///
/// Drill keepouts are circular mechanical blockers and gold-finger copper can
/// be sparse on large panels, so the check uses the shared spatial broad phase
/// before exact keepout/copper CSG intersection.
pub fn gold_finger_drill_keepout_readiness(
    board: &BoardModel,
    extra_drills: &[DrillFeature],
    selected_layers: &[String],
    keepout: &Scalar,
    _min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check(
        "gold-finger-drill-keepout-readiness",
        &[&board.source],
        || {
            let finger_features = selected_copper_features(board, selected_layers)
                .into_iter()
                .filter(|feature| feature.net.as_deref().is_some_and(looks_gold_finger_net))
                .collect::<Vec<_>>();
            let mut drills = board.drills.clone();
            drills.extend_from_slice(extra_drills);
            let maximum_radius = drills
                .iter()
                .filter_map(|drill| drill_radius_with_clearance(drill, keepout))
                .fold(None, |maximum: Option<Scalar>, radius| {
                    Some(match maximum {
                        Some(maximum) if crate::scalar::ge(&maximum, &radius) => maximum,
                        _ => radius,
                    })
                })
                .map_or(0.0, |radius| scalar_broad_phase_radius(&radius));
            let finger_index = CopperSpatialIndex::new(&finger_features, maximum_radius);
            let mut exact_pair_count = 0_usize;
            let mut violations = Vec::new();

            for drill in &drills {
                let Some(keepout_radius) = drill_radius_with_clearance(drill, keepout) else {
                    continue;
                };
                let broad_phase_radius = scalar_broad_phase_radius(&keepout_radius);

                for finger_index in finger_index
                    .all_layers_near_circle(drill.try_location_f64()?, broad_phase_radius)
                {
                    let finger = finger_features[finger_index];
                    exact_pair_count += 1;

                    let Some(location) = crate::checks::geometry_result_for_check(
                        finger
                            .region
                            .classify_xy(drill.location[0].clone(), drill.location[1].clone()),
                        "gold-finger-drill-keepout-readiness",
                        &[&finger.layer],
                        &mut violations,
                    ) else {
                        continue;
                    };
                    let center_inside = location != hypercurve::RegionPointLocation::Outside;
                    if !center_inside
                        && (crate::checks::point_boundary_within_for_check(
                            &drill.location,
                            &finger.region,
                            &keepout_radius,
                            "gold-finger-drill-keepout-readiness",
                            &[&finger.layer],
                            &mut violations,
                        ) == Some(false))
                    {
                        continue;
                    }

                    violations.push(Violation::new(
                    "gold-finger-drill-keepout-readiness",
                    Severity::Warning,
                    vec![finger.layer.clone()],
                    None,
                    Vec::new(),
                    vec![
                        drill.try_location_f64()?,
                        finger.try_location_f64()?,
                    ],
                    Some(format!(
                        "likely gold-finger copper {:?} intersects drill/mechanical keepout {keepout:.6}; review no-drill finger plating and bevel keepout",
                        finger.net
                    )),
                ));
                }
            }
            log::trace!(
                "gold-finger drill keepout readiness: source={} fingers={} drills={} spatial_buckets={} exact_pairs={} keepout={keepout:.6} violations={}",
                board.source,
                finger_features.len(),
                drills.len(),
                finger_index.bucket_count(),
                exact_pair_count,
                violations.len()
            );

            Ok(violations)
        },
    )
}

#[derive(Default)]
struct NetLayerUse {
    layers: BTreeSet<String>,
    locations: Vec<[f64; 2]>,
    has_via: bool,
    via_count: usize,
    has_zone: bool,
}

#[derive(Copy, Clone, Eq, PartialEq)]
enum DifferentialSide {
    Positive,
    Negative,
}

#[derive(Default)]
struct DifferentialPairUse {
    positive_layers: BTreeSet<String>,
    negative_layers: BTreeSet<String>,
    positive_locations: Vec<[f64; 2]>,
    negative_locations: Vec<[f64; 2]>,
}

#[derive(Default)]
struct DifferentialPairFeatureUse<'a> {
    positive: Vec<&'a CopperFeature>,
    negative: Vec<&'a CopperFeature>,
}

#[derive(Default)]
struct DifferentialPairViaUse {
    positive_via_count: usize,
    negative_via_count: usize,
    positive_via_layers: BTreeSet<String>,
    negative_via_layers: BTreeSet<String>,
    positive_via_locations: Vec<[f64; 2]>,
    negative_via_locations: Vec<[f64; 2]>,
}

fn differential_pair_key(net: &str) -> Option<(String, DifferentialSide)> {
    let normalized = net.trim().to_ascii_uppercase();
    let patterns = [
        ("_DP", DifferentialSide::Positive),
        ("-DP", DifferentialSide::Positive),
        (".DP", DifferentialSide::Positive),
        ("_DM", DifferentialSide::Negative),
        ("-DM", DifferentialSide::Negative),
        (".DM", DifferentialSide::Negative),
        ("D+", DifferentialSide::Positive),
        ("D-", DifferentialSide::Negative),
        ("_P", DifferentialSide::Positive),
        ("-P", DifferentialSide::Positive),
        (".P", DifferentialSide::Positive),
        ("_N", DifferentialSide::Negative),
        ("-N", DifferentialSide::Negative),
        (".N", DifferentialSide::Negative),
    ];

    for (suffix, side) in patterns {
        let Some(base) = normalized.strip_suffix(suffix) else {
            continue;
        };
        let base = base
            .trim_end_matches(['_', '-', '.', '/', ' '])
            .trim_start_matches(['_', '-', '.', '/', ' ']);
        if !base.is_empty() {
            return Some((base.to_string(), side));
        }
    }

    None
}

fn looks_high_speed_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "USB", "D+", "D-", "DP", "DM", "CLK", "CLOCK", "TX", "RX", "SERDES", "PCIE", "PCI", "MIPI",
        "LVDS", "HDMI", "ETH", "RGMII", "SGMII", "SATA", "CAN",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_high_current_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "VBAT", "VBUS", "VIN", "VCC", "VDD", "VOUT", "PWR", "POWER", "MOTOR", "PHASE", "+12V",
        "+5V", "+3V3", "12V", "5V", "3V3", "1V8",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_high_voltage_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "HV", "HIGHV", "MAINS", "LINE", "NEUTRAL", "LIVE", "VAC", "AC_L", "AC_N", "RECT", "BULK",
        "400V", "240V", "230V", "120V", "48V",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_rf_or_antenna_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "RF", "ANT", "ANTENNA", "GNSS", "GPS", "WIFI", "BT_", "BLE", "LTE",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_chassis_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    matches!(
        normalized.as_str(),
        "CHASSIS" | "SHIELD" | "EARTH" | "PE" | "PROTECTIVE_EARTH"
    ) || normalized.ends_with("_SHIELD")
        || normalized.ends_with("-SHIELD")
        || normalized.contains("CHASSIS")
}

fn looks_ground_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    matches!(
        normalized.as_str(),
        "GND" | "GROUND" | "PGND" | "AGND" | "DGND"
    ) || normalized.ends_with("_GND")
        || normalized.ends_with("-GND")
}

fn looks_gold_finger_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = ["GOLD", "FINGER", "EDGE", "CARD_EDGE", "CONN_EDGE"];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_connector_net(net: &str) -> bool {
    let normalized = net.to_ascii_uppercase();
    let tokens = [
        "CONN",
        "CONNECTOR",
        "USB",
        "JACK",
        "SOCKET",
        "PLUG",
        "HEADER",
        "VBUS",
        "SHIELD",
        "CHASSIS",
        "CARD_EDGE",
        "EDGE_CONN",
    ];

    tokens.iter().any(|token| normalized.contains(token))
}

fn looks_connector_edge_rate_net(net: &str) -> bool {
    looks_connector_net(net) || looks_high_speed_net(net) || looks_rf_or_antenna_net(net)
}

fn looks_edge_intent_net(net: &str) -> bool {
    looks_gold_finger_net(net) || looks_chassis_net(net)
}

/// Review selected same-layer KiCad copper for different-net spacing.
///
/// A shared grid proposes candidates, and every surviving pair still runs the
/// exact offset/intersection predicate below.
pub fn net_spacing(
    board: &BoardModel,
    clearance: &Scalar,
    selected_layers: &[String],
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("different-net-spacing", &[&board.source], || {
        let broad_phase_clearance = scalar_broad_phase_radius(clearance);
        let features = selected_copper_features(board, selected_layers);
        let bounds = features
            .iter()
            .map(|feature| feature.region.conservative_bounds())
            .collect::<Vec<_>>();
        let feature_index = CopperSpatialIndex::new(&features, broad_phase_clearance);
        let mut violations = Vec::new();
        let mut candidate_pairs = 0_usize;
        let mut exact_pairs = 0_usize;

        for left_index in 0..features.len() {
            let left = features[left_index];
            if left.net.is_none() {
                continue;
            }
            for right_index in feature_index.same_layer_near_feature(left, broad_phase_clearance) {
                if right_index <= left_index {
                    continue;
                }
                candidate_pairs += 1;
                let right = features[right_index];
                if left.net == right.net {
                    continue;
                }
                if bounds[left_index]
                    .as_ref()
                    .zip(bounds[right_index].as_ref())
                    .is_some_and(|(left, right)| {
                        !rects_within_clearance(left, right, broad_phase_clearance)
                    })
                {
                    continue;
                }
                exact_pairs += 1;
                if let Err(uncertainty) =
                    collect_net_spacing_violation(left, right, clearance, min_area, &mut violations)
                {
                    return Ok(vec![*uncertainty]);
                }
            }
        }

        log::trace!(
            "different-net spacing: source={} features={} buckets={} candidate_pairs={} exact_pairs={} clearance={clearance:.6} selected_layers={} violations={}",
            board.source,
            features.len(),
            feature_index.bucket_count(),
            candidate_pairs,
            exact_pairs,
            selected_layers.len(),
            violations.len()
        );

        Ok(violations)
    })
}

fn collect_net_spacing_violation(
    left: &CopperFeature,
    right: &CopperFeature,
    clearance: &Scalar,
    min_area: &Scalar,
    violations: &mut Vec<Violation>,
) -> Result<(), Box<Violation>> {
    if !regiones_within_clearance(
        &left.region,
        &right.region,
        scalar_broad_phase_radius(clearance),
    ) {
        return Ok(());
    }

    // Exact intersection handles overlapping copper directly. Separated
    // features use the exact boundary-distance threshold below, which is
    // equivalent to testing membership in a Minkowski clearance offset without
    // materializing that offset region.
    let overlap = intersection_for_check(
        &left.region,
        &right.region,
        "different-net-spacing",
        vec![left.layer.clone()],
    )?;
    let shapes = crate::checks::required_geometry_for_check(
        multipolygon_to_shapes_scalar(
            &overlap.try_to_multipolygon().map_err(|uncertainty| {
                Box::new(crate::checks::geometry_uncertainty_violation(
                    "different-net-spacing",
                    vec![left.layer.clone()],
                    uncertainty,
                ))
            })?,
            min_area,
        ),
        "different-net-spacing",
        vec![left.layer.clone()],
    )?;
    let locations = if shapes.is_empty()
        && crate::checks::distance::region_boundaries_within(&left.region, &right.region, clearance)
            .map_err(|uncertainty| {
                Box::new(crate::checks::geometry_uncertainty_violation(
                    "different-net-spacing",
                    vec![left.layer.clone()],
                    uncertainty,
                ))
            })? {
        vec![
            crate::checks::required_geometry_for_check(
                left.try_location_f64(),
                "different-net-spacing",
                vec![left.layer.clone()],
            )?,
            crate::checks::required_geometry_for_check(
                right.try_location_f64(),
                "different-net-spacing",
                vec![left.layer.clone()],
            )?,
        ]
    } else {
        Vec::new()
    };
    if shapes.is_empty() && locations.is_empty() {
        return Ok(());
    }

    violations.push(Violation::new(
        "different-net-spacing",
        Severity::Error,
        vec![left.layer.clone()],
        None,
        shapes,
        locations,
        Some(format!(
            "net {:?} is within {clearance} of net {:?}",
            left.net, right.net
        )),
    ));
    Ok(())
}

fn rects_within_clearance(left: &Rect<f64>, right: &Rect<f64>, clearance: f64) -> bool {
    left.min().x - clearance <= right.max().x
        && left.max().x + clearance >= right.min().x
        && left.min().y - clearance <= right.max().y
        && left.max().y + clearance >= right.min().y
}

/// Review cross-layer copper proximity under fabrication registration tolerance.
///
/// Like [`net_spacing`], a layer-aware spatial grid proposes cross-layer feature
/// pairs, and the exact offset/intersection predicate makes the finding decision.
pub fn registration_tolerance(
    board: &BoardModel,
    tolerance: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("layer-registration-tolerance", &[&board.source], || {
        let broad_phase_tolerance = scalar_broad_phase_radius(tolerance);
        let features = selected_copper_features(board, &[]);
        let bounds = features
            .iter()
            .map(|feature| feature.region.conservative_bounds())
            .collect::<Vec<_>>();
        let feature_index = CopperSpatialIndex::new(&features, broad_phase_tolerance);
        let mut violations = Vec::new();
        let layers = features
            .iter()
            .map(|feature| feature.layer.clone())
            .collect::<BTreeSet<_>>();
        let mut candidate_pairs = 0_usize;
        let mut exact_pairs = 0_usize;

        for left_index in 0..features.len() {
            let left = features[left_index];
            for right_index in feature_index.all_layers_near_feature(left, broad_phase_tolerance) {
                if right_index <= left_index {
                    continue;
                }
                let right = features[right_index];
                if left.layer == right.layer {
                    continue;
                }
                candidate_pairs += 1;
                if bounds[left_index]
                    .as_ref()
                    .zip(bounds[right_index].as_ref())
                    .is_some_and(|(left, right)| {
                        !rects_within_clearance(left, right, broad_phase_tolerance)
                    })
                {
                    continue;
                }
                exact_pairs += 1;
                let (first, second) = if left.layer <= right.layer {
                    (left, right)
                } else {
                    (right, left)
                };
                let first_layer = first.layer.clone();
                let second_layer = second.layer.clone();
                if let Err(uncertainty) = collect_registration_tolerance_violation(
                    first,
                    second,
                    &first_layer,
                    &second_layer,
                    tolerance,
                    min_area,
                    &mut violations,
                ) {
                    return Ok(vec![*uncertainty]);
                }
            }
        }

        log::trace!(
            "registration tolerance: source={} features={} layers={} buckets={} candidate_pairs={} exact_pairs={} tolerance={tolerance:.6} violations={}",
            board.source,
            features.len(),
            layers.len(),
            feature_index.bucket_count(),
            candidate_pairs,
            exact_pairs,
            violations.len()
        );

        Ok(violations)
    })
}

fn collect_registration_tolerance_violation(
    left: &CopperFeature,
    right: &CopperFeature,
    left_layer: &str,
    right_layer: &str,
    tolerance: &Scalar,
    min_area: &Scalar,
    violations: &mut Vec<Violation>,
) -> Result<(), Box<Violation>> {
    if !regiones_within_clearance(
        &left.region,
        &right.region,
        scalar_broad_phase_radius(tolerance),
    ) {
        return Ok(());
    }

    // Treat registration tolerance as a feature-level proximity query rather
    // than a whole-layer boolean operation. Exact intersection handles
    // overlaps; the exact boundary-distance predicate handles separated
    // features without materializing a Minkowski offset.
    let overlap = intersection_for_check(
        &left.region,
        &right.region,
        "layer-registration-tolerance",
        vec![left_layer.to_string(), right_layer.to_string()],
    )?;
    let shapes = crate::checks::required_geometry_for_check(
        multipolygon_to_shapes_scalar(
            &overlap.try_to_multipolygon().map_err(|uncertainty| {
                Box::new(crate::checks::geometry_uncertainty_violation(
                    "layer-registration-tolerance",
                    vec![left_layer.to_owned(), right_layer.to_owned()],
                    uncertainty,
                ))
            })?,
            min_area,
        ),
        "layer-registration-tolerance",
        vec![left_layer.to_owned(), right_layer.to_owned()],
    )?;
    let locations = if shapes.is_empty()
        && crate::checks::distance::region_boundaries_within(&left.region, &right.region, tolerance)
            .map_err(|uncertainty| {
                Box::new(crate::checks::geometry_uncertainty_violation(
                    "layer-registration-tolerance",
                    vec![left_layer.to_owned(), right_layer.to_owned()],
                    uncertainty,
                ))
            })? {
        vec![
            crate::checks::required_geometry_for_check(
                left.try_location_f64(),
                "layer-registration-tolerance",
                vec![left_layer.to_owned(), right_layer.to_owned()],
            )?,
            crate::checks::required_geometry_for_check(
                right.try_location_f64(),
                "layer-registration-tolerance",
                vec![left_layer.to_owned(), right_layer.to_owned()],
            )?,
        ]
    } else {
        Vec::new()
    };
    if shapes.is_empty() && locations.is_empty() {
        return Ok(());
    }

    violations.push(Violation::new(
        "layer-registration-tolerance",
        Severity::Warning,
        vec![left_layer.to_string(), right_layer.to_string()],
        None,
        shapes,
        locations,
        Some(format!(
            "features on paired layers are within registration tolerance {tolerance}"
        )),
    ));
    Ok(())
}

/// Run the `panelization_clearance` design-readiness check or report helper.
///
/// Panel tabs, V-scores, route graphics, and stamp-hole drills are treated as
/// blocker geometry. Copper/blocker pairs first pass an AABB broad phase; exact intersection
/// and boundary-distance checks still decide every reported clearance finding.
pub fn panelization_clearance(
    board: &BoardModel,
    extra_drills: &[DrillFeature],
    clearance: &Scalar,
    min_area: &Scalar,
) -> Vec<Violation> {
    crate::checks::run_geometry_check("panelization-clearance", &[&board.source], || {
        let broad_phase_clearance = scalar_broad_phase_radius(clearance);
        let mut blockers = Vec::new();

        if let Some(panel_features) = &board.panel_features {
            blockers.push(panel_features.clone());
        }

        if !extra_drills.is_empty() {
            match drills_to_region(
                extra_drills,
                "Excellon panel drills",
                "panelization-clearance",
            ) {
                Ok(drills) => blockers.push(drills),
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            }
        }

        let npth = board
            .drills
            .iter()
            .filter(|drill| !drill.plated)
            .cloned()
            .collect::<Vec<_>>();
        if !npth.is_empty() {
            match drills_to_region(&npth, "KiCad NPTH panel drills", "panelization-clearance") {
                Ok(drills) => blockers.push(drills),
                Err(uncertainty) => return Ok(vec![*uncertainty]),
            }
        }

        let bounded_copper = board
            .copper
            .iter()
            .map(|copper| (copper, copper.region.conservative_bounds()))
            .collect::<Vec<_>>();
        let mut violations = Vec::new();
        let blocker_count = blockers.len();
        let mut blocker_polygon_count = 0_usize;
        let mut candidate_pairs = 0_usize;
        let mut exact_intersections = 0_usize;
        let mut fallback_hits = 0_usize;
        for blocker in blockers {
            let mut shapes = Vec::new();
            let mut fallback_hit = false;
            let mut locations = Vec::new();
            let mut layers = BTreeSet::new();

            for blocker_polygon in blocker.try_to_multipolygon()?.0 {
                blocker_polygon_count += 1;
                let blocker_piece =
                    PcbRegion::new_shared(blocker_polygon.shared_exact_region(), None);
                let blocker_geometry = MultiPolygon(vec![blocker_polygon]);
                let Some(blocker_bounds) = blocker_geometry.bounding_rect() else {
                    continue;
                };

                for (copper, copper_bounds) in &bounded_copper {
                    if copper_bounds.as_ref().is_some_and(|copper_bounds| {
                        !rects_within_clearance(
                            &blocker_bounds,
                            copper_bounds,
                            broad_phase_clearance,
                        )
                    }) {
                        continue;
                    }

                    candidate_pairs += 1;
                    // Panel features can be long routed tabs or score lines.
                    // Offsetting the entire panel region is unnecessarily expensive
                    // on dense boards, so use exact feature intersections plus the
                    // same boundary distance predicate the offset fallback used to
                    // represent copper inside the requested keepout band.
                    exact_intersections += 1;
                    let overlap = match intersection_for_check(
                        &blocker_piece,
                        &copper.region,
                        "panelization-clearance",
                        vec![copper.layer.clone()],
                    ) {
                        Ok(overlap) => overlap,
                        Err(uncertainty) => return Ok(vec![*uncertainty]),
                    };
                    let feature_shapes =
                        multipolygon_to_shapes_scalar(&overlap.try_to_multipolygon()?, min_area)?;
                    if feature_shapes.is_empty()
                        && (crate::checks::boundaries_within_for_check(
                            &blocker_piece,
                            &copper.region,
                            clearance,
                            "panelization-clearance",
                            &[&copper.layer],
                            &mut violations,
                        ) == Some(true))
                    {
                        fallback_hit = true;
                        fallback_hits += 1;
                        locations.push(copper.try_location_f64()?);
                    }
                    shapes.extend(feature_shapes);
                    layers.insert(copper.layer.clone());
                }
            }

            if shapes.is_empty() && !fallback_hit {
                continue;
            }

            violations.push(Violation::new(
                "panelization-clearance",
                Severity::Warning,
                if layers.is_empty() {
                    vec!["KiCad copper".to_string()]
                } else {
                    layers.into_iter().collect()
                },
                None,
                shapes,
                locations,
                Some(format!(
                    "copper is within panel feature clearance {clearance}"
                )),
            ));
        }

        log::trace!(
            "panelization clearance: source={} blockers={} blocker_polygons={} bounded_copper={} candidate_pairs={} exact_intersections={} fallback_hits={} clearance={clearance:.6} min_area={min_area:.9} violations={}",
            board.source,
            blocker_count,
            blocker_polygon_count,
            bounded_copper.len(),
            candidate_pairs,
            exact_intersections,
            fallback_hits,
            violations.len()
        );

        Ok(violations)
    })
}

fn copper_features_touch_scalar(
    left: &CopperFeature,
    right: &CopperFeature,
    tolerance: &Scalar,
    requested_check: &str,
) -> Result<bool, Box<Violation>> {
    let broad_phase_tolerance = scalar_broad_phase_radius(tolerance);
    if !regiones_within_clearance(&left.region, &right.region, broad_phase_tolerance) {
        return Ok(false);
    }

    let overlap = intersection_for_check(
        &left.region,
        &right.region,
        requested_check,
        vec![left.layer.clone()],
    )?;
    Ok(
        !crate::checks::is_empty_for_check(&overlap, requested_check, vec![left.layer.clone()])?
            || crate::checks::distance::region_boundaries_within(
                &left.region,
                &right.region,
                tolerance,
            )
            .map_err(|uncertainty| {
                Box::new(crate::checks::geometry_uncertainty_violation(
                    requested_check,
                    vec![left.layer.clone()],
                    uncertainty,
                ))
            })?,
    )
}

fn rects_overlap(left: &Rect<f64>, right: &Rect<f64>) -> bool {
    left.min().x <= right.max().x
        && left.max().x >= right.min().x
        && left.min().y <= right.max().y
        && left.max().y >= right.min().y
}

struct CopperComponentResult {
    components: Vec<Vec<usize>>,
    spatial_buckets: usize,
    exact_pairs: usize,
}

fn copper_components(
    features: &[&CopperFeature],
    tolerance: &Scalar,
) -> Result<CopperComponentResult, Box<Violation>> {
    let broad_phase_tolerance = scalar_broad_phase_radius(tolerance);
    let feature_index = CopperSpatialIndex::new(features, broad_phase_tolerance);
    let mut visited = vec![false; features.len()];
    let mut components = Vec::new();
    let mut exact_pairs = 0usize;

    for start in 0..features.len() {
        if visited[start] {
            continue;
        }

        let mut stack = vec![start];
        let mut component = Vec::new();
        visited[start] = true;
        while let Some(index) = stack.pop() {
            component.push(index);
            for candidate in
                feature_index.same_layer_near_feature(features[index], broad_phase_tolerance)
            {
                if visited[candidate] {
                    continue;
                }
                exact_pairs += 1;
                if !copper_features_touch_scalar(
                    features[index],
                    features[candidate],
                    tolerance,
                    "same-net-island-readiness",
                )? {
                    continue;
                }
                visited[candidate] = true;
                stack.push(candidate);
            }
        }
        components.push(component);
    }

    Ok(CopperComponentResult {
        components,
        spatial_buckets: feature_index.bucket_count(),
        exact_pairs,
    })
}

fn selected_copper_features<'a>(
    board: &'a BoardModel,
    selected_layers: &[String],
) -> Vec<&'a CopperFeature> {
    board
        .copper
        .iter()
        .filter(|feature| selected_layers.is_empty() || selected_layers.contains(&feature.layer))
        .collect()
}

fn scalar_broad_phase_radius(value: &Scalar) -> f64 {
    let projected = value
        .to_f64_lossy()
        .expect("board-check broad-phase radius must fit the finite compatibility index");
    if projected > 0.0 {
        projected.next_up()
    } else {
        0.0
    }
}

fn regiones_within_clearance(left: &PcbRegion, right: &PcbRegion, clearance: f64) -> bool {
    let Some(left_bounds) = left.conservative_bounds() else {
        return true;
    };
    let Some(right_bounds) = right.conservative_bounds() else {
        return true;
    };

    // Axis-aligned bounding boxes are used only as a broad-phase rejection
    // before exact polygon predicates: cheap conservative culling first, exact
    // distance or intersection only for surviving candidates.
    left_bounds.min().x - clearance <= right_bounds.max().x
        && left_bounds.max().x + clearance >= right_bounds.min().x
        && left_bounds.min().y - clearance <= right_bounds.max().y
        && left_bounds.max().y + clearance >= right_bounds.min().y
}

fn multipolygon_center(multipolygon: &MultiPolygon<f64>) -> Option<[f64; 2]> {
    let bounds = multipolygon.bounding_rect()?;
    Some([
        (bounds.min().x + bounds.max().x) / 2.0,
        (bounds.min().y + bounds.max().y) / 2.0,
    ])
}

fn point_angle_degrees_scalar(
    previous: &[Scalar; 2],
    current: [f64; 2],
    next: &[Scalar; 2],
) -> Option<Scalar> {
    let current_x = Scalar::try_from(current[0]).ok()?;
    let current_y = Scalar::try_from(current[1]).ok()?;
    let ax = &previous[0] - &current_x;
    let ay = &previous[1] - &current_y;
    let bx = &next[0] - current_x;
    let by = &next[1] - current_y;
    let a_len = (&ax * &ax + &ay * &ay).sqrt().ok()?;
    let b_len = (&bx * &bx + &by * &by).sqrt().ok()?;
    if crate::scalar::eq(&a_len, &Scalar::zero()) || crate::scalar::eq(&b_len, &Scalar::zero()) {
        return Some(Scalar::zero());
    }
    let mut cosine = ((&ax * &bx + &ay * &by) / (a_len * b_len)).ok()?;
    let negative_one = crate::scalar::scalar("-1");
    let one = crate::scalar::scalar("1");
    if crate::scalar::lt(&cosine, &negative_one) {
        cosine = negative_one;
    } else if crate::scalar::gt(&cosine, &one) {
        cosine = one;
    }
    let radians = cosine.acos().ok()?;
    (radians * crate::scalar::scalar("180") / Scalar::pi()).ok()
}

/// Run the `layer_names_csv` design-readiness check or report helper.
pub fn layer_names_csv(board: &BoardModel) -> String {
    let mut counts = HashMap::new();
    for feature in &board.copper {
        *counts
            .entry((feature.layer.clone(), feature.kind))
            .or_insert(0usize) += 1;
    }

    let mut layers = counts.into_iter().collect::<Vec<_>>();
    layers.sort_by(|left, right| left.0.cmp(&right.0));
    layers
        .into_iter()
        .map(|((layer, kind), count)| format!("{layer}:{}({count})", kind.as_str()))
        .collect::<Vec<_>>()
        .join(", ")
}

impl CopperKind {
    fn as_str(self) -> &'static str {
        match self {
            CopperKind::Pad => "pad",
            CopperKind::Via => "via",
            CopperKind::Segment => "segment",
            CopperKind::Zone => "zone",
            CopperKind::Artwork => "artwork",
        }
    }
}

#[cfg(test)]
mod tests {
    use std::time::Instant;

    use crate::geometry::{Coord, LineString, Polygon};

    use crate::geometry::{
        SourceGridFacts, SourceUnit, circle_polygon, line_polygon, polygons_to_profile,
    };
    use crate::kicad::{BoardModel, CopperFeature, CopperKind, DrillFeature};
    use crate::{LayerMetadata, PcbRegion, PcbRegionExt};

    use crate::checks::{
        annular_ring, annular_ring_tolerance, board_outline_drill_clearance,
        castellation_hole_readiness, castellation_intent, component_edge_clearance_readiness,
        component_hole_clearance_readiness, connector_rework_clearance_readiness,
        dense_pad_escape_readiness, drill_aspect_ratio, drill_spacing, drill_table_consistency,
        drill_to_copper_clearance, drills_to_region, esd_protection_readiness, fiducial_readiness,
        high_voltage_edge_readiness, hot_component_spacing_readiness, local_fiducial_readiness,
        mouse_bite_readiness, plating_intent, rf_keepout_readiness, rf_via_fence_readiness,
        routed_slot_readiness, sensitive_net_spacing_readiness, sensitive_return_readiness,
        switch_node_keepout_readiness, testpoint_accessibility_readiness,
        testpoint_coverage_readiness, thermal_copper_area_readiness,
        thermal_mechanical_keepout_readiness, thermal_pad_via_readiness, thermal_relief_readiness,
        thermal_via_readiness, tooling_hole_readiness, voltage_clearance_readiness,
    };
    use crate::ipc356::{Ipc356AccessSide, Ipc356FeatureType, Ipc356Point, Ipc356Soldermask};

    use super::{
        apply_ipc356_nets, board_edge_exposure, board_edge_exposure_with_grid,
        chassis_stitching_readiness, chassis_stitching_readiness_with_grid,
        connector_return_path_readiness, controlled_impedance_readiness, copper_net_intent,
        copper_width_readiness, decoupling_proximity_readiness, differential_pair_readiness,
        differential_pair_return_readiness, differential_pair_spacing_readiness,
        differential_pair_via_symmetry_readiness, edge_copper_pullback_readiness,
        edge_copper_pullback_readiness_with_grid, edge_stitching_readiness,
        edge_stitching_readiness_with_grid, gold_finger_drill_keepout_readiness,
        gold_finger_edge_readiness, gold_finger_readiness, gold_finger_spacing_readiness,
        high_current_neck_readiness, high_current_readiness, high_speed_edge_readiness,
        high_speed_edge_readiness_with_grid, ipc356_coverage, ipc356_drill_diameter, net_spacing,
        orphaned_zone_readiness, panelization_clearance, plane_clearance_readiness,
        power_plane_readiness, power_via_array_readiness, reference_plane_readiness,
        reference_plane_void_readiness, registration_tolerance, return_path_readiness,
        same_net_island_readiness, teardrop_readiness, trace_junction_acid_trap_readiness,
        via_in_pad_readiness,
    };

    #[test]
    fn annular_ring_flags_small_pad() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![CopperFeature {
                layer: "F.Cu".to_string(),
                net: Some("GND".to_string()),
                kind: CopperKind::Pad,
                location: [crate::Scalar::zero(), crate::Scalar::zero()],
                region: polygons_to_profile(
                    vec![circle_polygon([0.0, 0.0], 0.4, 32)],
                    Some(LayerMetadata {
                        name: "pad".to_string(),
                    }),
                ),
            }],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.7"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        assert_eq!(
            annular_ring(&board, &crate::scalar::scalar("0.1"), &[]).len(),
            1
        );
    }

    #[test]
    fn annular_ring_allows_via_at_minimum_ring() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![CopperFeature {
                layer: "F.Cu".to_string(),
                net: Some("GND".to_string()),
                kind: CopperKind::Via,
                location: [crate::Scalar::zero(), crate::Scalar::zero()],
                region: polygons_to_profile(
                    vec![circle_polygon([0.0, 0.0], 0.5, 64)],
                    Some(LayerMetadata {
                        name: "via".to_string(),
                    }),
                ),
            }],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.6"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        assert!(annular_ring(&board, &crate::scalar::scalar("0.1"), &[]).is_empty());
    }

    #[test]
    fn annular_ring_tolerance_reports_nominal_pass_worst_case_failure() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("GND", CopperKind::Via, [0.0, 0.0], 0.5)],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.7"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        let violations = annular_ring_tolerance(
            &board,
            &crate::scalar::scalar("0.14"),
            &crate::scalar::scalar("0.02"),
            &[],
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "annular-ring-tolerance");
    }

    #[test]
    fn annular_ring_tolerance_allows_compliant_or_already_nominal_failures() {
        let compliant = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("GND", CopperKind::Via, [0.0, 0.0], 0.5)],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.7"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };
        let nominal_failure = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("GND", CopperKind::Via, [0.0, 0.0], 0.4)],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.7"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        assert!(
            annular_ring_tolerance(
                &compliant,
                &crate::scalar::scalar("0.12"),
                &crate::scalar::scalar("0.02"),
                &[]
            )
            .is_empty()
        );
        assert!(
            annular_ring_tolerance(
                &nominal_failure,
                &crate::scalar::scalar("0.14"),
                &crate::scalar::scalar("0.02"),
                &[]
            )
            .is_empty()
        );
    }

    #[test]
    fn annular_ring_tolerance_respects_selected_layers() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc_on_layer(
                "GND",
                CopperKind::Via,
                "B.Cu",
                [0.0, 0.0],
                0.5,
            )],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.7"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        assert!(
            annular_ring_tolerance(
                &board,
                &crate::scalar::scalar("0.14"),
                &crate::scalar::scalar("0.02"),
                &["F.Cu".to_string()]
            )
            .is_empty()
        );
        assert_eq!(
            annular_ring_tolerance(
                &board,
                &crate::scalar::scalar("0.14"),
                &crate::scalar::scalar("0.02"),
                &["B.Cu".to_string()]
            )
            .len(),
            1
        );
    }

    #[test]
    fn plating_intent_reports_npth_with_nearby_copper() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.4)],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.6"),
                net: None,
                plated: false,
            }],
            board_outline: None,
            panel_features: None,
        };

        let violations = plating_intent(&board, &[], &crate::scalar::scalar("0.05"));

        assert_eq!(violations.len(), 1);
        assert!(
            violations[0]
                .message
                .as_deref()
                .unwrap()
                .contains("non-plated")
        );
    }

    #[test]
    fn plating_intent_reports_plated_drill_without_pad_or_via_copper() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_line(
                "GND",
                CopperKind::Segment,
                [0.0, 0.0],
                [1.0, 0.0],
                0.1,
            )],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.5),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.3"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        let violations = plating_intent(&board, &[], &crate::scalar::scalar("0.05"));

        assert_eq!(violations.len(), 1);
        assert!(
            violations[0]
                .message
                .as_deref()
                .unwrap()
                .contains("plated drill")
        );
    }

    #[test]
    fn plating_intent_allows_plated_drill_with_same_net_pad() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.4)],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.01),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.3"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        assert!(plating_intent(&board, &[], &crate::scalar::scalar("0.05")).is_empty());
    }

    #[test]
    fn plating_intent_culls_sparse_copper_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("SIG{index}"),
                    CopperKind::Pad,
                    [100.0 + index as f64 * 2.0, 100.0],
                    0.4,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_disc("GND", CopperKind::Pad, [0.01, 0.0], 0.4));
        copper.push(copper_disc("SIG_NEAR", CopperKind::Pad, [0.0, 2.0], 0.4));
        let board = BoardModel {
            source: "test".to_string(),
            copper,
            drills: vec![
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(0.0),
                        crate::geometry::exact_real(0.0),
                    ],
                    diameter: crate::scalar::scalar("0.3"),
                    net: Some("GND".to_string()),
                    plated: true,
                },
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(0.0),
                        crate::geometry::exact_real(2.0),
                    ],
                    diameter: crate::scalar::scalar("0.6"),
                    net: None,
                    plated: false,
                },
            ],
            board_outline: None,
            panel_features: None,
        };

        let started = std::time::Instant::now();
        let violations = plating_intent(&board, &[], &crate::scalar::scalar("0.05"));

        assert_eq!(violations.len(), 1);
        assert!(
            violations[0]
                .message
                .as_deref()
                .unwrap()
                .contains("non-plated")
        );
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "plating intent should cull sparse copper fields before exact center checks"
        );
    }

    #[test]
    fn routed_slot_readiness_reports_small_npth_mechanical_drills() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(2.0),
                ],
                diameter: crate::scalar::scalar("0.18"),
                net: None,
                plated: false,
            }],
            board_outline: None,
            panel_features: None,
        };

        let violations = routed_slot_readiness(&board, &crate::scalar::scalar("0.25"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "routed-slot-readiness");
        assert_eq!(violations[0].locations, vec![[1.0, 2.0]]);
    }

    #[test]
    fn routed_slot_readiness_allows_plated_zero_or_large_drills() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: vec![
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(0.0),
                        crate::geometry::exact_real(0.0),
                    ],
                    diameter: crate::scalar::scalar("0.18"),
                    net: Some("GND".to_string()),
                    plated: true,
                },
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(1.0),
                        crate::geometry::exact_real(0.0),
                    ],
                    diameter: crate::scalar::scalar("0.0"),
                    net: None,
                    plated: false,
                },
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(2.0),
                        crate::geometry::exact_real(0.0),
                    ],
                    diameter: crate::scalar::scalar("0.35"),
                    net: None,
                    plated: false,
                },
            ],
            board_outline: None,
            panel_features: None,
        };

        assert!(routed_slot_readiness(&board, &crate::scalar::scalar("0.25")).is_empty());
    }

    #[test]
    fn drill_aspect_ratio_flags_small_holes_for_board_thickness() {
        let drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.15"),
                net: None,
                plated: true,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: true,
            },
        ];

        let violations = drill_aspect_ratio(
            "drills",
            &drills,
            &crate::scalar::scalar("1.6"),
            &crate::scalar::scalar("10.0"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].locations, vec![[0.0, 0.0]]);
    }

    #[test]
    fn drill_aspect_ratio_reports_zero_diameter_without_dividing() {
        let drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.0"),
            net: None,
            plated: true,
        }];

        let violations = drill_aspect_ratio(
            "drills",
            &drills,
            &crate::scalar::scalar("1.6"),
            &crate::scalar::scalar("10.0"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            violations[0]
                .message
                .as_deref()
                .unwrap()
                .contains("undefined")
        );
    }

    #[test]
    fn drill_table_consistency_reports_kicad_excellon_diameter_conflicts() {
        let board_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.30"),
            net: Some("GND".to_string()),
            plated: true,
        }];
        let excellon_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.01),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.45"),
            net: None,
            plated: true,
        }];

        let violations = drill_table_consistency(
            &board_drills,
            &excellon_drills,
            &[],
            &crate::scalar::scalar("0.05"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "drill-table-consistency");
    }

    #[test]
    fn drill_table_consistency_reports_excellon_ipc356_diameter_conflicts() {
        let excellon_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.30"),
            net: None,
            plated: true,
        }];
        let points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("V1".to_string()),
            pin: None,
            location: [
                crate::geometry::exact_real(1.01),
                crate::geometry::exact_real(0.0),
            ],
            diameter: Some(crate::scalar::scalar("0.50")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let violations = drill_table_consistency(
            &[],
            &excellon_drills,
            &points,
            &crate::scalar::scalar("0.05"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(
            violations[0].layers,
            vec![
                "Excellon drills".to_string(),
                "IPC-D-356 drills".to_string()
            ]
        );
    }

    #[test]
    fn drill_table_consistency_allows_matching_or_unmatched_records() {
        let board_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.30"),
            net: Some("GND".to_string()),
            plated: true,
        }];
        let excellon_drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.01),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.31"),
                net: None,
                plated: true,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(10.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.90"),
                net: None,
                plated: true,
            },
        ];

        assert!(
            drill_table_consistency(
                &board_drills,
                &excellon_drills,
                &[],
                &crate::scalar::scalar("0.05")
            )
            .is_empty()
        );
    }

    #[test]
    fn copper_width_readiness_reports_narrow_kicad_feature() {
        let board = board_with_copper(vec![copper_line(
            "SIG",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.08,
        )]);

        let violations = copper_width_readiness(&board, &[], &crate::scalar::scalar("0.12"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "copper-width-readiness");
    }

    #[test]
    fn copper_width_readiness_allows_wide_or_degenerate_features() {
        let mut degenerate = copper_disc("SIG", CopperKind::Zone, [2.0, 0.0], 0.0);
        degenerate.region = polygons_to_profile(Vec::new(), None);
        let board = board_with_copper(vec![
            copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.16),
            degenerate,
        ]);

        assert!(copper_width_readiness(&board, &[], &crate::scalar::scalar("0.12")).is_empty());
    }

    #[test]
    fn copper_width_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "SIG",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.08,
        )]);

        assert!(
            copper_width_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.12")
            )
            .is_empty()
        );
        assert_eq!(
            copper_width_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.12")
            )
            .len(),
            1
        );
    }

    #[test]
    fn copper_width_readiness_handles_large_sparse_feature_sets() {
        let copper = (0..2_000)
            .map(|index| {
                let x = index as f64 * 2.0;
                copper_line("SIG", CopperKind::Segment, [x, 0.0], [x + 1.0, 0.0], 0.16)
            })
            .collect::<Vec<_>>();
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = copper_width_readiness(&board, &[], &crate::scalar::scalar("0.12"));

        assert!(violations.is_empty());
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "copper width readiness should stay linear over sparse feature sets"
        );
    }

    #[test]
    fn copper_net_intent_reports_unnetted_kicad_copper() {
        let mut unnetted = copper_disc("GND", CopperKind::Zone, [0.0, 0.0], 0.5);
        unnetted.net = None;
        let board = board_with_copper(vec![
            copper_disc("GND", CopperKind::Pad, [1.0, 0.0], 0.5),
            unnetted,
        ]);

        let violations = copper_net_intent(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "copper-net-intent");
        assert_eq!(violations[0].locations, vec![[0.0, 0.0]]);
    }

    #[test]
    fn copper_net_intent_respects_selected_layers() {
        let mut unnetted_front =
            copper_disc_on_layer("GND", CopperKind::Zone, "F.Cu", [0.0, 0.0], 0.5);
        unnetted_front.net = None;
        let mut unnetted_back =
            copper_disc_on_layer("GND", CopperKind::Zone, "B.Cu", [1.0, 0.0], 0.5);
        unnetted_back.net = None;
        let board = board_with_copper(vec![unnetted_front, unnetted_back]);

        let violations = copper_net_intent(&board, &["B.Cu".to_string()]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].layers, vec!["B.Cu".to_string()]);
    }

    #[test]
    fn copper_net_intent_handles_large_sparse_feature_sets() {
        let mut copper = (0..2_000)
            .map(|index| {
                let x = index as f64 * 2.0;
                copper_line("SIG", CopperKind::Segment, [x, 0.0], [x + 1.0, 0.0], 0.16)
            })
            .collect::<Vec<_>>();
        copper.push(unnetted_copper_disc_on_layer("F.Cu", [0.0, 2.0], 0.20));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = copper_net_intent(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "copper net-intent readiness should stay linear over sparse feature sets"
        );
    }

    #[test]
    fn net_spacing_flags_close_different_nets() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![feature("A", [0.0, 0.0]), feature("B", [0.9, 0.0])],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };

        assert_eq!(
            net_spacing(
                &board,
                &crate::scalar::scalar("0.2"),
                &[],
                &crate::scalar::scalar("1.0e-9"),
            )
            .len(),
            1
        );
    }

    #[test]
    fn net_spacing_covers_pad_via_and_via_spacing() {
        let selected_layers = vec!["F.Cu".to_string()];
        let pad = copper_disc("PAD", CopperKind::Pad, [0.0, 0.0], 0.12);
        let via_a = copper_disc("VIA_A", CopperKind::Via, [0.28, 0.0], 0.12);
        let via_b = copper_disc("VIA_B", CopperKind::Via, [0.56, 0.0], 0.12);
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![pad, via_a, via_b],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };

        let violations = net_spacing(
            &board,
            &crate::scalar::scalar("0.20"),
            &selected_layers,
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 2);
    }

    #[test]
    fn net_spacing_culls_large_sparse_feature_sets() {
        let mut copper = Vec::new();
        for index in 0..600 {
            copper.push(feature(
                &format!("N{index}"),
                [(index % 30) as f64 * 5.0, (index / 30) as f64 * 5.0],
            ));
        }
        copper.push(feature("NEAR", [0.6, 0.0]));
        let board = board_with_copper(copper);

        let start = std::time::Instant::now();
        let violations = net_spacing(
            &board,
            &crate::scalar::scalar("0.2"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed() < std::time::Duration::from_secs(2),
            "large sparse net-spacing check should stay in the broad phase"
        );
    }

    #[test]
    fn via_in_pad_readiness_reports_same_net_overlap() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![
                copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.30),
                copper_disc("GND", CopperKind::Via, [0.05, 0.0], 0.12),
            ],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };

        let violations = via_in_pad_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "via-in-pad-readiness");
    }

    #[test]
    fn via_in_pad_readiness_allows_distant_or_different_net_vias() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![
                copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.30),
                copper_disc("GND", CopperKind::Via, [1.0, 0.0], 0.12),
                copper_disc("SIG", CopperKind::Via, [0.0, 0.0], 0.12),
            ],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };

        assert!(via_in_pad_readiness(&board, &[], &crate::scalar::scalar("1.0e-9")).is_empty());
    }

    #[test]
    fn via_in_pad_readiness_respects_selected_layers() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![
                copper_disc_on_layer("GND", CopperKind::Pad, "B.Cu", [0.0, 0.0], 0.30),
                copper_disc_on_layer("GND", CopperKind::Via, "B.Cu", [0.0, 0.0], 0.12),
            ],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };

        assert!(
            via_in_pad_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            via_in_pad_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn via_in_pad_readiness_culls_sparse_pad_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("GND_{index}"),
                    CopperKind::Pad,
                    [100.0 + index as f64 * 4.0, 100.0],
                    0.30,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.30));
        copper.push(copper_disc("GND", CopperKind::Via, [0.05, 0.0], 0.12));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = via_in_pad_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "via-in-pad should spatially cull distant pads before exact overlap review"
        );
    }

    #[test]
    fn teardrop_readiness_reports_narrow_segment_into_pad() {
        let board = board_with_copper(vec![
            copper_disc("SIG", CopperKind::Pad, [0.0, 0.0], 0.25),
            copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.08),
        ]);

        let violations = teardrop_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.12"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "teardrop-readiness");
    }

    #[test]
    fn teardrop_readiness_allows_wide_or_different_net_segment_entries() {
        let board = board_with_copper(vec![
            copper_disc("SIG", CopperKind::Pad, [0.0, 0.0], 0.25),
            copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.16),
            copper_line("OTHER", CopperKind::Segment, [0.0, 0.0], [0.0, 1.0], 0.08),
        ]);

        assert!(
            teardrop_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.12"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn teardrop_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_disc_on_layer("SIG", CopperKind::Pad, "B.Cu", [0.0, 0.0], 0.25),
            copper_line_on_layer(
                "SIG",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.08,
            ),
        ]);

        assert!(
            teardrop_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.12"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            teardrop_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.12"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn teardrop_readiness_culls_sparse_anchor_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("SIG_{index}"),
                    CopperKind::Pad,
                    [100.0 + index as f64 * 4.0, 100.0],
                    0.25,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_disc("SIG", CopperKind::Pad, [0.0, 0.0], 0.25));
        copper.push(copper_line(
            "SIG",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.08,
        ));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = teardrop_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.12"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "teardrop review should spatially cull distant anchors before exact overlap review"
        );
    }

    #[test]
    fn thermal_relief_readiness_reports_pad_embedded_in_same_net_zone() {
        let board = board_with_copper(vec![
            copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.20),
            copper_rect("GND", CopperKind::Zone, "F.Cu", -1.0, -1.0, 1.0, 1.0),
        ]);

        let violations = thermal_relief_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "thermal-relief-readiness");
    }

    #[test]
    fn thermal_relief_readiness_allows_distant_or_different_net_zones() {
        let board = board_with_copper(vec![
            copper_disc("GND", CopperKind::Pad, [0.0, 0.0], 0.20),
            copper_rect("SIG", CopperKind::Zone, "F.Cu", -1.0, -1.0, 1.0, 1.0),
            copper_rect("GND", CopperKind::Zone, "F.Cu", 2.0, 2.0, 3.0, 3.0),
        ]);

        assert!(thermal_relief_readiness(&board, &[], &crate::scalar::scalar("1.0e-9")).is_empty());
    }

    #[test]
    fn thermal_relief_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_disc_on_layer("GND", CopperKind::Via, "B.Cu", [0.0, 0.0], 0.20),
            copper_rect("GND", CopperKind::Zone, "B.Cu", -1.0, -1.0, 1.0, 1.0),
        ]);

        assert!(
            thermal_relief_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            thermal_relief_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn plane_clearance_readiness_reports_npth_intersecting_zone() {
        let mut board = board_with_copper(vec![copper_rect(
            "GND",
            CopperKind::Zone,
            "F.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        )]);
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.5"),
            net: None,
            plated: false,
        }];

        let violations = plane_clearance_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "plane-clearance-readiness");
    }

    #[test]
    fn plane_clearance_readiness_allows_plated_or_distant_holes() {
        let mut board = board_with_copper(vec![copper_rect(
            "GND",
            CopperKind::Zone,
            "F.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        )]);
        board.drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.5"),
                net: Some("GND".to_string()),
                plated: true,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(3.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.5"),
                net: None,
                plated: false,
            },
        ];

        assert!(
            plane_clearance_readiness(&board, &[], &crate::scalar::scalar("1.0e-9")).is_empty()
        );
    }

    #[test]
    fn plane_clearance_readiness_respects_selected_layers() {
        let mut board = board_with_copper(vec![copper_rect(
            "GND",
            CopperKind::Zone,
            "B.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        )]);
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.5"),
            net: None,
            plated: false,
        }];

        assert!(
            plane_clearance_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            plane_clearance_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn plane_clearance_readiness_culls_sparse_zone_and_drill_fields() {
        let mut board = board_with_copper(
            (0..2_000)
                .map(|index| {
                    let x = 100.0 + index as f64 * 3.0;
                    copper_rect("GND", CopperKind::Zone, "F.Cu", x, 100.0, x + 1.0, 101.0)
                })
                .collect(),
        );
        board.drills = (0..400)
            .map(|index| DrillFeature {
                location: [
                    crate::geometry::exact_real(index as f64 * 3.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.5"),
                net: None,
                plated: false,
            })
            .collect();
        let start = Instant::now();

        let violations = plane_clearance_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert!(violations.is_empty());
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "plane clearance should index sparse zone/drill fields"
        );
    }

    #[test]
    fn board_edge_exposure_reports_copper_outside_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_disc("EDGE", CopperKind::Pad, [0.1, 5.0], 0.3)];

        let violations = board_edge_exposure(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "board-edge-exposure");
        assert_eq!(violations[0].locations, vec![[0.1, 5.0]]);
    }

    #[test]
    fn board_edge_exposure_accepts_retained_kicad_grid_for_rect_fast_path() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_disc("SIG", CopperKind::Pad, [1.0, 5.0], 0.3)];
        let grid = SourceGridFacts::primitive_float_edge(SourceUnit::KiCadMillimeter);

        assert!(
            board_edge_exposure_with_grid(&board, &[], &crate::scalar::scalar("1.0e-9"), grid)
                .is_empty()
        );
    }

    #[test]
    fn board_edge_exposure_allows_inset_copper_or_missing_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_disc("SIG", CopperKind::Pad, [1.0, 5.0], 0.3)];

        assert!(board_edge_exposure(&board, &[], &crate::scalar::scalar("1.0e-9")).is_empty());
        assert!(
            board_edge_exposure(
                &board_with_copper(board.copper),
                &[],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn board_edge_exposure_respects_selected_layers() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_disc_on_layer(
            "EDGE",
            CopperKind::Segment,
            "B.Cu",
            [0.1, 5.0],
            0.3,
        )];

        assert!(
            board_edge_exposure(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            board_edge_exposure(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn board_edge_exposure_culls_rectangular_interior_copper_fields() {
        let mut board = board_with_outline(square(0.0, 0.0, 100.0, 100.0));
        board.copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("SIG{index}"),
                    CopperKind::Pad,
                    [
                        5.0 + (index % 50) as f64 * 1.5,
                        5.0 + (index / 50) as f64 * 1.5,
                    ],
                    0.30,
                )
            })
            .collect();
        board.copper.push(copper_disc(
            "EDGE",
            CopperKind::Segment,
            [99.95, 50.0],
            0.30,
        ));

        let started = Instant::now();
        let violations = board_edge_exposure(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed().as_secs_f64() < 2.0,
            "board-edge exposure should skip rectangular interior copper before exact difference"
        );
    }

    #[test]
    fn high_speed_edge_readiness_reports_edge_rate_copper_near_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line(
            "USB_D+",
            CopperKind::Segment,
            [0.10, 1.0],
            [0.90, 1.0],
            0.10,
        )];

        let violations = high_speed_edge_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "high-speed-edge-readiness");
    }

    #[test]
    fn high_speed_edge_readiness_accepts_retained_kicad_grid_for_edge_band() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line(
            "USB_D+",
            CopperKind::Segment,
            [2.0, 2.0],
            [3.0, 2.0],
            0.10,
        )];
        let grid = SourceGridFacts::primitive_float_edge(SourceUnit::KiCadMillimeter);

        assert!(
            high_speed_edge_readiness_with_grid(
                &board,
                &[],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9"),
                grid
            )
            .is_empty()
        );
    }

    #[test]
    fn high_speed_edge_readiness_allows_inset_or_low_speed_copper() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line("USB_D+", CopperKind::Segment, [2.0, 2.0], [3.0, 2.0], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [0.10, 1.0], [0.90, 1.0], 0.10),
        ];

        assert!(
            high_speed_edge_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn high_speed_edge_readiness_respects_selected_layers() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line_on_layer(
            "PCIE_RX0",
            CopperKind::Segment,
            "B.Cu",
            [0.10, 1.0],
            [0.90, 1.0],
            0.10,
        )];

        assert!(
            high_speed_edge_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            high_speed_edge_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn high_speed_edge_readiness_culls_rectangular_interior_copper_fields() {
        let mut board = board_with_outline(square(0.0, 0.0, 100.0, 100.0));
        board.copper = (0..2_000)
            .map(|index| {
                copper_line(
                    &format!("USB_D{index}+"),
                    CopperKind::Segment,
                    [
                        5.0 + (index % 50) as f64 * 1.5,
                        5.0 + (index / 50) as f64 * 1.5,
                    ],
                    [
                        5.5 + (index % 50) as f64 * 1.5,
                        5.0 + (index / 50) as f64 * 1.5,
                    ],
                    0.10,
                )
            })
            .collect();
        board.copper.push(copper_line(
            "PCIE_RX0",
            CopperKind::Segment,
            [0.10, 50.0],
            [0.90, 50.0],
            0.10,
        ));

        let started = Instant::now();
        let violations = high_speed_edge_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed().as_secs_f64() < 2.0,
            "high-speed edge review should skip rectangular interior copper before exact difference"
        );
    }

    #[test]
    fn high_voltage_edge_readiness_reports_hv_copper_near_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line(
            "HV_400V",
            CopperKind::Segment,
            [0.20, 1.0],
            [0.90, 1.0],
            0.10,
        )];

        let violations = high_voltage_edge_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.80"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "high-voltage-edge-readiness");
    }

    #[test]
    fn high_voltage_edge_readiness_allows_inset_or_low_voltage_copper() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line("HV_400V", CopperKind::Segment, [2.0, 2.0], [3.0, 2.0], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [0.2, 1.0], [0.9, 1.0], 0.10),
        ];

        assert!(
            high_voltage_edge_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.80"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn high_voltage_edge_readiness_respects_selected_layers() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line_on_layer(
            "MAINS_L",
            CopperKind::Segment,
            "B.Cu",
            [0.20, 1.0],
            [0.90, 1.0],
            0.10,
        )];

        assert!(
            high_voltage_edge_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.80"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            high_voltage_edge_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.80"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn edge_copper_pullback_readiness_flags_non_edge_nets_near_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line(
            "SIG1",
            CopperKind::Segment,
            [0.10, 1.0],
            [0.90, 1.0],
            0.10,
        )];

        let violations = edge_copper_pullback_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "edge-copper-pullback-readiness");
    }

    #[test]
    fn edge_copper_pullback_readiness_accepts_retained_kicad_grid_for_boundary_distance() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![copper_line(
            "SIG1",
            CopperKind::Segment,
            [0.10, 1.0],
            [0.90, 1.0],
            0.10,
        )];
        let grid = SourceGridFacts::primitive_float_edge(SourceUnit::KiCadMillimeter);

        let violations = edge_copper_pullback_readiness_with_grid(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("1.0e-9"),
            grid,
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "edge-copper-pullback-readiness");
    }

    #[test]
    fn edge_copper_pullback_readiness_skips_edge_intent_nets() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line(
                "USB_D+",
                CopperKind::Segment,
                [0.10, 1.0],
                [0.90, 1.0],
                0.10,
            ),
            copper_line(
                "GOLD_EDGE_1",
                CopperKind::Segment,
                [0.10, 1.5],
                [0.90, 1.5],
                0.10,
            ),
            copper_line(
                "CHASSIS",
                CopperKind::Segment,
                [0.10, 2.0],
                [0.90, 2.0],
                0.10,
            ),
        ];

        assert!(
            edge_copper_pullback_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn edge_copper_pullback_readiness_respects_selected_layers() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line_on_layer(
                "SIG1",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 2.0],
                [3.0, 2.0],
                0.10,
            ),
            copper_line_on_layer(
                "SIG1",
                CopperKind::Segment,
                "F.Cu",
                [0.10, 0.1],
                [0.90, 0.1],
                0.10,
            ),
        ];

        assert_eq!(
            edge_copper_pullback_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
        assert!(
            edge_copper_pullback_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn edge_stitching_readiness_flags_high_speed_nets_near_edge_without_stitch() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line(
                "USB_D+",
                CopperKind::Segment,
                [0.10, 1.0],
                [0.90, 1.0],
                0.10,
            ),
            copper_disc("VDD", CopperKind::Via, [0.30, 1.0], 0.10),
        ];

        let violations = edge_stitching_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "edge-stitching-readiness");
    }

    #[test]
    fn edge_stitching_readiness_accepts_retained_kicad_grid_for_edge_checks() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line(
                "PCIe_TX_P",
                CopperKind::Segment,
                [0.10, 1.0],
                [0.90, 1.0],
                0.10,
            ),
            copper_disc("VDD", CopperKind::Via, [0.30, 1.0], 0.10),
        ];
        let grid = SourceGridFacts::primitive_float_edge(SourceUnit::KiCadMillimeter);

        let violations = edge_stitching_readiness_with_grid(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
            grid,
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "edge-stitching-readiness");
    }

    #[test]
    fn edge_stitching_readiness_skips_non_high_speed_or_rf_nets() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line("GPIO1", CopperKind::Segment, [0.10, 1.0], [0.90, 1.0], 0.10),
            copper_disc("GND", CopperKind::Via, [0.30, 1.0], 0.10),
        ];

        assert!(
            edge_stitching_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn edge_stitching_readiness_respects_selected_layers() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line_on_layer(
                "USB_D+",
                CopperKind::Segment,
                "B.Cu",
                [0.10, 1.0],
                [0.90, 1.0],
                0.10,
            ),
            copper_disc_on_layer("GND", CopperKind::Via, "F.Cu", [0.30, 1.0], 0.10),
        ];

        assert!(
            edge_stitching_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            edge_stitching_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn edge_stitching_readiness_allows_nearby_ground_stitching_via() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = vec![
            copper_line(
                "WIFI_ANT",
                CopperKind::Segment,
                [0.10, 1.0],
                [0.90, 1.0],
                0.10,
            ),
            copper_disc("GND", CopperKind::Via, [0.30, 1.0], 0.10),
            copper_line("VDD", CopperKind::Segment, [2.0, 1.0], [3.0, 1.0], 0.10),
        ];

        assert!(
            edge_stitching_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn edge_stitching_readiness_culls_sparse_ground_vias() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    "GND",
                    CopperKind::Via,
                    [100.0 + index as f64 * 2.0, 50.0],
                    0.10,
                )
            })
            .chain([copper_line(
                "USB_D+",
                CopperKind::Segment,
                [0.10, 1.0],
                [0.90, 1.0],
                0.10,
            )])
            .collect();

        let start = Instant::now();
        let violations = edge_stitching_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "edge stitching should index sparse ground-via fields"
        );
    }

    #[test]
    fn controlled_impedance_readiness_reports_high_speed_net_layer_change_without_via() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "USB_D+",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "USB_D+",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 0.0],
                [3.0, 0.0],
                0.12,
            ),
        ]);

        let violations = controlled_impedance_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "controlled-impedance-readiness");
        assert_eq!(violations[0].layers, vec!["B.Cu", "F.Cu"]);
    }

    #[test]
    fn controlled_impedance_readiness_allows_low_speed_or_via_transitioned_nets() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 0.0],
                [3.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "CLK_OUT",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 1.0],
                [1.0, 1.0],
                0.12,
            ),
            copper_line_on_layer(
                "CLK_OUT",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 1.0],
                [3.0, 1.0],
                0.12,
            ),
            copper_disc("CLK_OUT", CopperKind::Via, [1.5, 1.0], 0.15),
        ]);

        assert!(controlled_impedance_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn controlled_impedance_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "PCIE_TX0",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "PCIE_TX0",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 0.0],
                [3.0, 0.0],
                0.12,
            ),
        ]);

        assert!(controlled_impedance_readiness(&board, &["F.Cu".to_string()]).is_empty());
        assert_eq!(
            controlled_impedance_readiness(&board, &["F.Cu".to_string(), "B.Cu".to_string()]).len(),
            1
        );
    }

    #[test]
    fn differential_pair_readiness_reports_missing_mate() {
        let board = board_with_copper(vec![copper_line(
            "USB_D+",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.12,
        )]);

        let violations = differential_pair_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "differential-pair-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("missing its negative side"))
        );
    }

    #[test]
    fn differential_pair_readiness_reports_layer_mismatch() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "PCIE_TX0_P",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "PCIE_TX0_N",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.2],
                [1.0, 0.2],
                0.12,
            ),
        ]);

        let violations = differential_pair_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "differential-pair-readiness");
        assert_eq!(violations[0].layers, vec!["B.Cu", "F.Cu"]);
    }

    #[test]
    fn differential_pair_readiness_allows_matched_pair_on_same_layer() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.12),
            copper_line("USB_D-", CopperKind::Segment, [0.0, 0.2], [1.0, 0.2], 0.12),
        ]);

        assert!(differential_pair_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn differential_pair_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "LVDS_CLK_P",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.12,
        )]);

        assert!(differential_pair_readiness(&board, &["F.Cu".to_string()]).is_empty());
        assert_eq!(
            differential_pair_readiness(&board, &["B.Cu".to_string()]).len(),
            1
        );
    }

    #[test]
    fn differential_pair_spacing_readiness_reports_loose_pair_gap() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line("USB_D-", CopperKind::Segment, [0.0, 1.0], [1.0, 1.0], 0.10),
        ]);

        let violations =
            differential_pair_spacing_readiness(&board, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "differential-pair-spacing-readiness");
    }

    #[test]
    fn differential_pair_spacing_readiness_allows_close_or_unpaired_features() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line(
                "USB_D-",
                CopperKind::Segment,
                [0.0, 0.20],
                [1.0, 0.20],
                0.10,
            ),
            copper_line("GPIO1", CopperKind::Segment, [0.0, 1.0], [1.0, 1.0], 0.10),
        ]);

        assert!(
            differential_pair_spacing_readiness(&board, &[], &crate::scalar::scalar("0.30"))
                .is_empty()
        );
    }

    #[test]
    fn differential_pair_spacing_readiness_culls_large_passing_pair_fields() {
        let mut copper = vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line(
                "USB_D-",
                CopperKind::Segment,
                [0.0, 0.20],
                [1.0, 0.20],
                0.10,
            ),
        ];
        for index in 0..800 {
            let x = 100.0 + index as f64 * 2.0;
            copper.push(copper_line(
                "USB_D+",
                CopperKind::Segment,
                [x, 10.0],
                [x + 0.5, 10.0],
                0.10,
            ));
            copper.push(copper_line(
                "USB_D-",
                CopperKind::Segment,
                [x, 20.0],
                [x + 0.5, 20.0],
                0.10,
            ));
        }
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations =
            differential_pair_spacing_readiness(&board, &[], &crate::scalar::scalar("0.30"));
        let elapsed = started.elapsed();

        assert!(violations.is_empty());
        assert!(
            elapsed < std::time::Duration::from_secs(2),
            "passing pair spacing should stop after a spatially nearby side match, took {elapsed:?}"
        );
    }

    #[test]
    fn differential_pair_spacing_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "LVDS_CLK_P",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.10,
            ),
            copper_line_on_layer(
                "LVDS_CLK_N",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 1.0],
                [1.0, 1.0],
                0.10,
            ),
        ]);

        assert!(
            differential_pair_spacing_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .is_empty()
        );
        assert_eq!(
            differential_pair_spacing_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .len(),
            1
        );
    }

    #[test]
    fn differential_pair_via_symmetry_readiness_reports_uneven_counts() {
        let board = board_with_copper(vec![
            copper_line(
                "PCIE_TX0_P",
                CopperKind::Segment,
                [0.0, 0.0],
                [1.0, 0.0],
                0.10,
            ),
            copper_disc("PCIE_TX0_P", CopperKind::Via, [0.5, -0.1], 0.12),
            copper_line(
                "PCIE_TX0_N",
                CopperKind::Segment,
                [0.0, 0.2],
                [1.0, 0.2],
                0.10,
            ),
        ]);

        let violations = differential_pair_via_symmetry_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(
            violations[0].check,
            "differential-pair-via-symmetry-readiness"
        );
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("asymmetric via symmetry"))
        );
    }

    #[test]
    fn differential_pair_via_symmetry_readiness_reports_layer_mismatch() {
        let board = board_with_copper(vec![
            copper_disc_on_layer("PCIE_TX0_P", CopperKind::Via, "F.Cu", [0.0, 0.0], 0.12),
            copper_disc_on_layer("PCIE_TX0_N", CopperKind::Via, "B.Cu", [1.0, 0.0], 0.12),
        ]);

        let violations = differential_pair_via_symmetry_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
    }

    #[test]
    fn differential_pair_via_symmetry_readiness_ignores_non_via_features() {
        let board = board_with_copper(vec![
            copper_line(
                "PCIE_TX0_P",
                CopperKind::Segment,
                [0.0, 0.0],
                [1.0, 0.0],
                0.10,
            ),
            copper_line(
                "PCIE_TX0_N",
                CopperKind::Segment,
                [0.0, 0.2],
                [1.0, 0.2],
                0.10,
            ),
        ]);

        assert!(differential_pair_via_symmetry_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn differential_pair_via_symmetry_readiness_allows_balanced_pair_via_layers() {
        let board = board_with_copper(vec![
            copper_disc_on_layer("PCIE_TX0_P", CopperKind::Via, "F.Cu", [0.0, 0.0], 0.12),
            copper_disc_on_layer("PCIE_TX0_N", CopperKind::Via, "F.Cu", [1.0, 0.0], 0.12),
        ]);

        assert!(differential_pair_via_symmetry_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn differential_pair_return_readiness_reports_pair_without_same_layer_ground_guard() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line(
                "USB_D-",
                CopperKind::Segment,
                [0.0, 0.20],
                [1.0, 0.20],
                0.10,
            ),
        ]);

        let violations =
            differential_pair_return_readiness(&board, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 2);
        assert!(
            violations
                .iter()
                .all(|violation| violation.check == "differential-pair-return-readiness")
        );
    }

    #[test]
    fn differential_pair_return_readiness_allows_guarded_or_unpaired_copper() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line(
                "USB_D-",
                CopperKind::Segment,
                [0.0, 0.20],
                [1.0, 0.20],
                0.10,
            ),
            copper_line("GND", CopperKind::Segment, [0.0, -0.20], [1.0, -0.20], 0.10),
            copper_line("GND", CopperKind::Segment, [0.0, 0.40], [1.0, 0.40], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [2.0, 0.0], [3.0, 0.0], 0.10),
        ]);

        assert!(
            differential_pair_return_readiness(&board, &[], &crate::scalar::scalar("0.30"))
                .is_empty()
        );
    }

    #[test]
    fn differential_pair_return_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "LVDS_CLK_P",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.10,
        )]);

        assert!(
            differential_pair_return_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .is_empty()
        );
        assert_eq!(
            differential_pair_return_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .len(),
            1
        );
    }

    #[test]
    fn differential_pair_return_readiness_culls_sparse_ground_fields() {
        let mut copper = vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line(
                "USB_D-",
                CopperKind::Segment,
                [0.0, 0.20],
                [1.0, 0.20],
                0.10,
            ),
        ];
        for index in 0..2_000 {
            let x = 100.0 + index as f64 * 0.50;
            copper.push(copper_disc("GND", CopperKind::Via, [x, 10.0], 0.12));
        }
        let board = board_with_copper(copper);
        let start = Instant::now();

        let violations =
            differential_pair_return_readiness(&board, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 2);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "differential return lookup should index sparse same-layer ground fields"
        );
    }

    #[test]
    fn trace_junction_acid_trap_reports_acute_same_net_segments() {
        let shallow_angle_degrees = 20.0_f64;
        let board = board_with_copper(vec![
            copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.12),
            copper_line(
                "SIG",
                CopperKind::Segment,
                [0.0, 0.0],
                [
                    2.0 * shallow_angle_degrees.to_radians().cos(),
                    2.0 * shallow_angle_degrees.to_radians().sin(),
                ],
                0.12,
            ),
        ]);

        let violations = trace_junction_acid_trap_readiness(
            &board,
            &[],
            &crate::scalar::scalar("30.0"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "acid-trap-trace-junction");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("acute"))
        );
    }

    #[test]
    fn trace_junction_acid_trap_allows_obtuse_or_different_net_segments() {
        let obtuse = board_with_copper(vec![
            copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.12),
            copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [-1.0, 1.0], 0.12),
        ]);
        let different_net = board_with_copper(vec![
            copper_line("A", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.12),
            copper_line("B", CopperKind::Segment, [0.0, 0.0], [2.0, 0.2], 0.12),
        ]);

        assert!(
            trace_junction_acid_trap_readiness(
                &obtuse,
                &[],
                &crate::scalar::scalar("30.0"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert!(
            trace_junction_acid_trap_readiness(
                &different_net,
                &[],
                &crate::scalar::scalar("30.0"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn trace_junction_acid_trap_culls_sparse_segment_fields() {
        let mut copper = Vec::new();
        for index in 0..2_000 {
            let y = index as f64 * 0.50;
            copper.push(copper_line(
                "SIG",
                CopperKind::Segment,
                [100.0, y],
                [101.0, y],
                0.10,
            ));
        }
        let board = board_with_copper(copper);
        let start = Instant::now();

        let violations = trace_junction_acid_trap_readiness(
            &board,
            &[],
            &crate::scalar::scalar("30.0"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "trace-junction acid-trap review should index sparse same-net segment fields"
        );
    }

    #[test]
    fn reference_plane_readiness_reports_high_speed_without_ground_zone() {
        let board = board_with_copper(vec![copper_line(
            "USB_D+",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.12,
        )]);

        let violations = reference_plane_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "reference-plane-readiness");
    }

    #[test]
    fn reference_plane_readiness_allows_ground_zone() {
        let board = board_with_copper(vec![
            copper_line("CLK_OUT", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.12),
            copper_rect("GND", CopperKind::Zone, "F.Cu", -1.0, -1.0, 2.0, 1.0),
        ]);

        assert!(reference_plane_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn reference_plane_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "HDMI_CLK",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.12,
        )]);

        assert!(reference_plane_readiness(&board, &["F.Cu".to_string()]).is_empty());
        assert_eq!(
            reference_plane_readiness(&board, &["B.Cu".to_string()]).len(),
            1
        );
    }

    #[test]
    fn reference_plane_void_readiness_reports_high_speed_copper_outside_ground_zone() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.12),
            copper_rect("GND", CopperKind::Zone, "B.Cu", -0.5, -0.5, 0.5, 0.5),
        ]);

        let violations =
            reference_plane_void_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "reference-plane-void-readiness");
    }

    #[test]
    fn reference_plane_void_readiness_allows_covered_or_low_speed_copper() {
        let board = board_with_copper(vec![
            copper_line("USB_D+", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.12),
            copper_line("GPIO1", CopperKind::Segment, [2.0, 0.0], [3.0, 0.0], 0.12),
            copper_rect("GND", CopperKind::Zone, "B.Cu", -1.0, -1.0, 4.0, 1.0),
        ]);

        assert!(
            reference_plane_void_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"))
                .is_empty()
        );
    }

    #[test]
    fn reference_plane_void_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "HDMI_CLK",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.12,
            ),
            copper_rect("GND", CopperKind::Zone, "F.Cu", -1.0, -1.0, 2.0, 1.0),
        ]);

        assert!(
            reference_plane_void_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            reference_plane_void_readiness(
                &board,
                &["F.Cu".to_string(), "B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            0
        );
    }

    #[test]
    fn reference_plane_void_readiness_culls_sparse_ground_zones() {
        let mut copper = (0..2_000)
            .map(|index| {
                let x = 100.0 + (index % 100) as f64 * 3.0;
                let y = (index / 100) as f64 * 3.0;
                copper_rect("GND", CopperKind::Zone, "B.Cu", x, y, x + 0.5, y + 0.5)
            })
            .collect::<Vec<_>>();
        copper.push(copper_line(
            "USB_D+",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.12,
        ));
        copper.push(copper_rect(
            "GND",
            CopperKind::Zone,
            "B.Cu",
            -1.0,
            -1.0,
            2.0,
            1.0,
        ));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations =
            reference_plane_void_readiness(&board, &[], &crate::scalar::scalar("1.0e-9"));

        assert!(violations.is_empty());
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "reference-plane void should index sparse ground zones before exact subtraction"
        );
    }

    #[test]
    fn orphaned_zone_readiness_reports_zone_without_same_net_anchor() {
        let board = board_with_copper(vec![copper_rect(
            "GND",
            CopperKind::Zone,
            "F.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        )]);

        let violations = orphaned_zone_readiness(&board, &[], &crate::scalar::scalar("0.10"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "orphaned-zone-readiness");
    }

    #[test]
    fn orphaned_zone_readiness_allows_intersecting_or_near_same_net_anchor() {
        let board = board_with_copper(vec![
            copper_rect("GND", CopperKind::Zone, "F.Cu", -1.0, -1.0, 1.0, 1.0),
            copper_disc("GND", CopperKind::Via, [0.0, 0.0], 0.12),
            copper_rect("VBUS", CopperKind::Zone, "F.Cu", 2.0, 2.0, 3.0, 3.0),
            copper_line("VBUS", CopperKind::Segment, [3.05, 2.5], [3.5, 2.5], 0.10),
        ]);

        assert!(orphaned_zone_readiness(&board, &[], &crate::scalar::scalar("0.10")).is_empty());
    }

    #[test]
    fn orphaned_zone_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_rect(
            "GND",
            CopperKind::Zone,
            "B.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        )]);

        assert!(
            orphaned_zone_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.10")
            )
            .is_empty()
        );
        assert_eq!(
            orphaned_zone_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.10")
            )
            .len(),
            1
        );
    }

    #[test]
    fn orphaned_zone_readiness_culls_sparse_anchor_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                let x = 100.0 + (index % 100) as f64 * 3.0;
                let y = (index / 100) as f64 * 3.0;
                copper_disc("GND", CopperKind::Via, [x, y], 0.10)
            })
            .collect::<Vec<_>>();
        copper.push(copper_rect(
            "GND",
            CopperKind::Zone,
            "F.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        ));
        copper.push(copper_disc("GND", CopperKind::Via, [0.0, 0.0], 0.12));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = orphaned_zone_readiness(&board, &[], &crate::scalar::scalar("0.10"));

        assert!(violations.is_empty());
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "orphaned-zone readiness should index sparse anchors before exact zone connectivity"
        );
    }

    #[test]
    fn same_net_island_readiness_reports_disconnected_same_layer_copper() {
        let board = board_with_copper(vec![
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [3.0, 0.0], [4.0, 0.0], 0.10),
        ]);

        let violations = same_net_island_readiness(&board, &[], &crate::scalar::scalar("0.10"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "same-net-island-readiness");
        assert_eq!(violations[0].locations.len(), 2);
    }

    #[test]
    fn same_net_island_readiness_allows_touching_or_different_layer_copper() {
        let board = board_with_copper(vec![
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [1.0, 0.0], [2.0, 0.0], 0.10),
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "B.Cu",
                [3.0, 0.0],
                [4.0, 0.0],
                0.10,
            ),
        ]);

        assert!(same_net_island_readiness(&board, &[], &crate::scalar::scalar("0.10")).is_empty());
    }

    #[test]
    fn same_net_island_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.10,
            ),
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "B.Cu",
                [3.0, 0.0],
                [4.0, 0.0],
                0.10,
            ),
        ]);

        assert!(
            same_net_island_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.10")
            )
            .is_empty()
        );
        assert_eq!(
            same_net_island_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.10")
            )
            .len(),
            1
        );
    }

    #[test]
    fn same_net_island_readiness_culls_sparse_same_net_fields() {
        let mut copper = Vec::new();
        for index in 0..2_000 {
            let x = index as f64 * 2.0;
            copper.push(copper_line(
                "GPIO1",
                CopperKind::Segment,
                [x, 0.0],
                [x + 0.5, 0.0],
                0.10,
            ));
        }
        let board = board_with_copper(copper);
        let start = Instant::now();

        let violations = same_net_island_readiness(&board, &[], &crate::scalar::scalar("0.10"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].locations.len(), 2_000);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "same-net island connectivity should index sparse copper fields"
        );
    }

    #[test]
    fn high_current_readiness_reports_power_net_layer_change_with_single_via() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "VBUS",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.35,
            ),
            copper_line_on_layer(
                "VBUS",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 0.0],
                [3.0, 0.0],
                0.35,
            ),
            copper_disc("VBUS", CopperKind::Via, [1.5, 0.0], 0.15),
        ]);

        let violations = high_current_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "high-current-readiness");
        assert_eq!(violations[0].layers, vec!["B.Cu", "F.Cu"]);
    }

    #[test]
    fn high_current_readiness_allows_low_speed_or_redundant_via_nets() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 0.0],
                [3.0, 0.0],
                0.12,
            ),
            copper_line_on_layer(
                "+5V",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 1.0],
                [1.0, 1.0],
                0.35,
            ),
            copper_line_on_layer(
                "+5V",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 1.0],
                [3.0, 1.0],
                0.35,
            ),
            copper_disc("+5V", CopperKind::Via, [1.3, 1.0], 0.15),
            copper_disc("+5V", CopperKind::Via, [1.7, 1.0], 0.15),
        ]);

        assert!(high_current_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn high_current_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "12V",
                CopperKind::Segment,
                "F.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.35,
            ),
            copper_line_on_layer(
                "12V",
                CopperKind::Segment,
                "B.Cu",
                [2.0, 0.0],
                [3.0, 0.0],
                0.35,
            ),
        ]);

        assert!(high_current_readiness(&board, &["F.Cu".to_string()]).is_empty());
        assert_eq!(
            high_current_readiness(&board, &["F.Cu".to_string(), "B.Cu".to_string()]).len(),
            1
        );
    }

    #[test]
    fn power_via_array_readiness_reports_isolated_power_vias() {
        let board = board_with_copper(vec![
            copper_disc("VBUS", CopperKind::Via, [0.0, 0.0], 0.12),
            copper_disc("VBUS", CopperKind::Via, [2.0, 0.0], 0.12),
        ]);

        let violations = power_via_array_readiness(&board, &[], &crate::scalar::scalar("0.50"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "power-via-array-readiness");
        assert_eq!(violations[0].locations.len(), 2);
    }

    #[test]
    fn power_via_array_readiness_allows_clustered_or_low_current_vias() {
        let board = board_with_copper(vec![
            copper_disc("VBUS", CopperKind::Via, [0.0, 0.0], 0.12),
            copper_disc("VBUS", CopperKind::Via, [0.30, 0.0], 0.12),
            copper_disc("GPIO1", CopperKind::Via, [2.0, 0.0], 0.12),
            copper_disc("GPIO1", CopperKind::Via, [4.0, 0.0], 0.12),
        ]);

        assert!(power_via_array_readiness(&board, &[], &crate::scalar::scalar("0.50")).is_empty());
    }

    #[test]
    fn power_via_array_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_disc_on_layer("12V", CopperKind::Via, "B.Cu", [0.0, 0.0], 0.12),
            copper_disc_on_layer("12V", CopperKind::Via, "B.Cu", [2.0, 0.0], 0.12),
        ]);

        assert!(
            power_via_array_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.50")
            )
            .is_empty()
        );
        assert_eq!(
            power_via_array_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.50")
            )
            .len(),
            1
        );
    }

    #[test]
    fn power_via_array_readiness_culls_sparse_via_fields() {
        let mut copper = Vec::new();
        for index in 0..2_000 {
            copper.push(copper_disc(
                "VBUS",
                CopperKind::Via,
                [index as f64 * 2.0, 0.0],
                0.12,
            ));
        }
        let board = board_with_copper(copper);
        let start = Instant::now();

        let violations = power_via_array_readiness(&board, &[], &crate::scalar::scalar("0.50"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].locations.len(), 2_000);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "power via isolation should use indexed nearest-neighbor lookup"
        );
    }

    #[test]
    fn thermal_via_readiness_reports_power_zone_with_too_few_vias() {
        let board = board_with_copper(vec![
            copper_rect("VBUS", CopperKind::Zone, "F.Cu", -1.0, -1.0, 1.0, 1.0),
            copper_disc("VBUS", CopperKind::Via, [0.0, 0.0], 0.12),
        ]);

        let violations = thermal_via_readiness(&board, &[], 2, &crate::scalar::scalar("0.10"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "thermal-via-readiness");
    }

    #[test]
    fn thermal_via_readiness_allows_low_current_or_sufficient_vias() {
        let board = board_with_copper(vec![
            copper_rect("SIG", CopperKind::Zone, "F.Cu", -1.0, -1.0, 1.0, 1.0),
            copper_rect("VBUS", CopperKind::Zone, "F.Cu", 2.0, 2.0, 4.0, 4.0),
            copper_disc("VBUS", CopperKind::Via, [2.5, 2.5], 0.12),
            copper_disc("VBUS", CopperKind::Via, [3.5, 3.5], 0.12),
        ]);

        assert!(thermal_via_readiness(&board, &[], 2, &crate::scalar::scalar("0.10")).is_empty());
    }

    #[test]
    fn thermal_via_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_rect(
            "12V",
            CopperKind::Zone,
            "B.Cu",
            -1.0,
            -1.0,
            1.0,
            1.0,
        )]);

        assert!(
            thermal_via_readiness(
                &board,
                &["F.Cu".to_string()],
                2,
                &crate::scalar::scalar("0.10")
            )
            .is_empty()
        );
        assert_eq!(
            thermal_via_readiness(
                &board,
                &["B.Cu".to_string()],
                2,
                &crate::scalar::scalar("0.10")
            )
            .len(),
            1
        );
    }

    #[test]
    fn power_plane_readiness_reports_power_net_without_zone() {
        let board = board_with_copper(vec![copper_line(
            "VBUS",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.25,
        )]);

        let violations = power_plane_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "power-plane-readiness");
    }

    #[test]
    fn power_plane_readiness_allows_same_net_zone_or_low_current_net() {
        let board = board_with_copper(vec![
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.12),
            copper_rect("VDD_3V3", CopperKind::Zone, "F.Cu", -1.0, -1.0, 2.0, 1.0),
        ]);

        assert!(power_plane_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn power_plane_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "12V",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.25,
        )]);

        assert!(power_plane_readiness(&board, &["F.Cu".to_string()]).is_empty());
        assert_eq!(
            power_plane_readiness(&board, &["B.Cu".to_string()]).len(),
            1
        );
    }

    #[test]
    fn power_plane_readiness_handles_large_sparse_power_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                let x = index as f64 * 2.0;
                copper_line("GPIO1", CopperKind::Segment, [x, 0.0], [x + 1.0, 0.0], 0.12)
            })
            .collect::<Vec<_>>();
        copper.push(copper_line(
            "VBUS",
            CopperKind::Segment,
            [0.0, 2.0],
            [1.0, 2.0],
            0.25,
        ));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = power_plane_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "power-plane readiness should stay linear over sparse low-current fields"
        );
    }

    #[test]
    fn high_current_neck_readiness_reports_narrow_power_copper() {
        let board = board_with_copper(vec![copper_line(
            "VBUS",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.18,
        )]);

        let violations = high_current_neck_readiness(&board, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "high-current-neck-readiness");
    }

    #[test]
    fn high_current_neck_readiness_allows_low_current_or_wide_power_copper() {
        let board = board_with_copper(vec![
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.12),
            copper_line("VBUS", CopperKind::Segment, [0.0, 1.0], [1.0, 1.0], 0.35),
        ]);

        assert!(
            high_current_neck_readiness(&board, &[], &crate::scalar::scalar("0.30")).is_empty()
        );
    }

    #[test]
    fn high_current_neck_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "12V",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.18,
        )]);

        assert!(
            high_current_neck_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .is_empty()
        );
        assert_eq!(
            high_current_neck_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .len(),
            1
        );
    }

    #[test]
    fn high_current_neck_readiness_handles_large_sparse_power_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                let x = index as f64 * 2.0;
                copper_line("GPIO1", CopperKind::Segment, [x, 0.0], [x + 1.0, 0.0], 0.12)
            })
            .collect::<Vec<_>>();
        copper.push(copper_line(
            "VBUS",
            CopperKind::Segment,
            [0.0, 2.0],
            [1.0, 2.0],
            0.18,
        ));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = high_current_neck_readiness(&board, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "high-current neck readiness should stay linear over sparse low-current fields"
        );
    }

    #[test]
    fn voltage_clearance_readiness_reports_likely_high_voltage_proximity() {
        let board = board_with_copper(vec![
            copper_line("HV_400V", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.35], [1.0, 0.35], 0.1),
        ]);

        let violations = voltage_clearance_readiness(
            &board,
            &crate::scalar::scalar("0.30"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "voltage-clearance-readiness");
    }

    #[test]
    fn voltage_clearance_readiness_allows_low_voltage_or_distant_nets() {
        let board = board_with_copper(vec![
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
            copper_line("GPIO2", CopperKind::Segment, [0.0, 0.12], [1.0, 0.12], 0.1),
            copper_line("MAINS_L", CopperKind::Segment, [0.0, 2.0], [1.0, 2.0], 0.1),
            copper_line("GND", CopperKind::Segment, [0.0, 2.6], [1.0, 2.6], 0.1),
        ]);

        assert!(
            voltage_clearance_readiness(
                &board,
                &crate::scalar::scalar("0.30"),
                &[],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn voltage_clearance_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "48V",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.1,
            ),
            copper_line_on_layer(
                "GND",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.35],
                [1.0, 0.35],
                0.1,
            ),
        ]);

        assert!(
            voltage_clearance_readiness(
                &board,
                &crate::scalar::scalar("0.30"),
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            voltage_clearance_readiness(
                &board,
                &crate::scalar::scalar("0.30"),
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn sensitive_net_spacing_readiness_reports_sensitive_near_noisy_net() {
        let board = board_with_copper(vec![
            copper_line("RF_ANT", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
            copper_line(
                "MOTOR_PWM",
                CopperKind::Segment,
                [0.0, 0.35],
                [1.0, 0.35],
                0.1,
            ),
        ]);

        let violations = sensitive_net_spacing_readiness(
            &board,
            &crate::scalar::scalar("0.30"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "sensitive-net-spacing-readiness");
    }

    #[test]
    fn sensitive_net_spacing_readiness_allows_distant_or_non_noisy_neighbors() {
        let board = board_with_copper(vec![
            copper_line("RF_ANT", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.12], [1.0, 0.12], 0.1),
            copper_line("MIC_IN", CopperKind::Segment, [0.0, 2.0], [1.0, 2.0], 0.1),
            copper_line("SW_NODE", CopperKind::Segment, [0.0, 2.6], [1.0, 2.6], 0.1),
        ]);

        assert!(
            sensitive_net_spacing_readiness(
                &board,
                &crate::scalar::scalar("0.30"),
                &[],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn sensitive_net_spacing_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "ADC_IN",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.1,
            ),
            copper_line_on_layer(
                "CLK_OUT",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.35],
                [1.0, 0.35],
                0.1,
            ),
        ]);

        assert!(
            sensitive_net_spacing_readiness(
                &board,
                &crate::scalar::scalar("0.30"),
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            sensitive_net_spacing_readiness(
                &board,
                &crate::scalar::scalar("0.30"),
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn sensitive_return_readiness_reports_missing_same_layer_ground_guard() {
        let board = board_with_copper(vec![copper_line(
            "ADC_IN",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.10,
        )]);

        let violations = sensitive_return_readiness(&board, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "sensitive-return-readiness");
    }

    #[test]
    fn sensitive_return_readiness_allows_nearby_ground_or_low_sensitivity() {
        let board = board_with_copper(vec![
            copper_line("ADC_IN", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line("GND", CopperKind::Segment, [0.0, 0.20], [1.0, 0.20], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [2.0, 0.0], [3.0, 0.0], 0.10),
        ]);

        assert!(sensitive_return_readiness(&board, &[], &crate::scalar::scalar("0.30")).is_empty());
    }

    #[test]
    fn sensitive_return_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "MIC_IN",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.10,
        )]);

        assert!(
            sensitive_return_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .is_empty()
        );
        assert_eq!(
            sensitive_return_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.30")
            )
            .len(),
            1
        );
    }

    #[test]
    fn rf_keepout_readiness_reports_antenna_near_non_ground_copper() {
        let board = board_with_copper(vec![
            copper_line("RF_ANT", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [0.0, 0.50], [1.0, 0.50], 0.10),
        ]);

        let violations = rf_keepout_readiness(
            &board,
            &crate::scalar::scalar("0.60"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "rf-keepout-readiness");
    }

    #[test]
    fn rf_keepout_readiness_allows_ground_or_distant_copper() {
        let board = board_with_copper(vec![
            copper_line("RF_ANT", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_line("GND", CopperKind::Segment, [0.0, 0.20], [1.0, 0.20], 0.10),
            copper_line("GPIO1", CopperKind::Segment, [0.0, 2.0], [1.0, 2.0], 0.10),
        ]);

        assert!(
            rf_keepout_readiness(
                &board,
                &crate::scalar::scalar("0.60"),
                &[],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn rf_keepout_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![
            copper_line_on_layer(
                "WIFI_ANT",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.0],
                [1.0, 0.0],
                0.10,
            ),
            copper_line_on_layer(
                "GPIO1",
                CopperKind::Segment,
                "B.Cu",
                [0.0, 0.50],
                [1.0, 0.50],
                0.10,
            ),
        ]);

        assert!(
            rf_keepout_readiness(
                &board,
                &crate::scalar::scalar("0.60"),
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
        assert_eq!(
            rf_keepout_readiness(
                &board,
                &crate::scalar::scalar("0.60"),
                &["B.Cu".to_string()],
                &crate::scalar::scalar("1.0e-9")
            )
            .len(),
            1
        );
    }

    #[test]
    fn rf_via_fence_readiness_reports_rf_copper_without_nearby_ground_via() {
        let board = board_with_copper(vec![copper_line(
            "RF_ANT",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.10,
        )]);

        let violations = rf_via_fence_readiness(&board, &[], &crate::scalar::scalar("0.60"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "rf-via-fence-readiness");
    }

    #[test]
    fn rf_via_fence_readiness_allows_nearby_ground_via_or_non_rf_copper() {
        let board = board_with_copper(vec![
            copper_line("RF_ANT", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.10),
            copper_disc("GND", CopperKind::Via, [0.2, 0.2], 0.12),
            copper_line("GPIO1", CopperKind::Segment, [3.0, 0.0], [4.0, 0.0], 0.10),
        ]);

        assert!(rf_via_fence_readiness(&board, &[], &crate::scalar::scalar("0.60")).is_empty());
    }

    #[test]
    fn rf_via_fence_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "RF_FEED",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.10,
        )]);

        assert!(
            rf_via_fence_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.60")
            )
            .is_empty()
        );
        assert_eq!(
            rf_via_fence_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.60")
            )
            .len(),
            1
        );
    }

    #[test]
    fn chassis_stitching_readiness_reports_shield_without_ground_via() {
        let board = board_with_copper(vec![copper_line(
            "USB_SHIELD",
            CopperKind::Segment,
            [0.0, 0.0],
            [1.0, 0.0],
            0.20,
        )]);

        let violations = chassis_stitching_readiness(&board, &[], &crate::scalar::scalar("0.50"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "chassis-stitching-readiness");
    }

    #[test]
    fn chassis_stitching_readiness_allows_nearby_ground_via_or_signal_net() {
        let board = board_with_copper(vec![
            copper_line(
                "USB_SHIELD",
                CopperKind::Segment,
                [0.0, 0.0],
                [1.0, 0.0],
                0.20,
            ),
            copper_disc("GND", CopperKind::Via, [0.30, 0.0], 0.12),
            copper_line("GPIO1", CopperKind::Segment, [2.0, 0.0], [3.0, 0.0], 0.10),
        ]);

        assert!(
            chassis_stitching_readiness(&board, &[], &crate::scalar::scalar("0.50")).is_empty()
        );
    }

    #[test]
    fn chassis_stitching_readiness_accepts_retained_kicad_grid_for_point_radius() {
        let board = board_with_copper(vec![
            copper_disc("USB_SHIELD", CopperKind::Via, [0.0, 0.0], 0.20),
            copper_disc("GND", CopperKind::Via, [0.0, 0.50], 0.12),
        ]);
        let grid = SourceGridFacts::primitive_float_edge(SourceUnit::KiCadMillimeter);

        assert!(
            chassis_stitching_readiness_with_grid(
                &board,
                &[],
                &crate::scalar::scalar("0.50"),
                grid,
            )
            .is_empty()
        );
        assert_eq!(
            chassis_stitching_readiness_with_grid(
                &board,
                &[],
                &crate::scalar::scalar("0.499999"),
                grid,
            )
            .len(),
            1,
            "exact squared-distance comparison must keep the radius boundary strict"
        );
    }

    #[test]
    fn chassis_stitching_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_line_on_layer(
            "CHASSIS",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [1.0, 0.0],
            0.20,
        )]);

        assert!(
            chassis_stitching_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
            )
            .is_empty()
        );
        assert_eq!(
            chassis_stitching_readiness(
                &board,
                &["B.Cu".to_string()],
                &crate::scalar::scalar("0.50"),
            )
            .len(),
            1
        );
    }

    #[test]
    fn chassis_stitching_readiness_culls_sparse_ground_vias() {
        let board = board_with_copper(
            (0..2_000)
                .map(|index| {
                    copper_disc(
                        "GND",
                        CopperKind::Via,
                        [100.0 + index as f64 * 2.0, 50.0],
                        0.10,
                    )
                })
                .chain([copper_line(
                    "USB_SHIELD",
                    CopperKind::Segment,
                    [0.0, 0.0],
                    [1.0, 0.0],
                    0.20,
                )])
                .collect(),
        );

        let start = Instant::now();
        let violations = chassis_stitching_readiness(&board, &[], &crate::scalar::scalar("0.50"));

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "chassis stitching should index sparse ground-via fields"
        );
    }

    #[test]
    fn gold_finger_readiness_reports_via_on_likely_finger_net() {
        let board = board_with_copper(vec![copper_disc(
            "GOLD_FINGER_1",
            CopperKind::Via,
            [0.0, 0.0],
            0.12,
        )]);

        let violations = gold_finger_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "gold-finger-readiness");
    }

    #[test]
    fn gold_finger_readiness_allows_non_finger_vias_or_finger_pads() {
        let board = board_with_copper(vec![
            copper_disc("SIG", CopperKind::Via, [0.0, 0.0], 0.12),
            copper_disc("GOLD_FINGER_1", CopperKind::Pad, [1.0, 0.0], 0.20),
        ]);

        assert!(gold_finger_readiness(&board, &[]).is_empty());
    }

    #[test]
    fn gold_finger_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_disc_on_layer(
            "EDGE_CONN_1",
            CopperKind::Via,
            "B.Cu",
            [0.0, 0.0],
            0.12,
        )]);

        assert!(gold_finger_readiness(&board, &["F.Cu".to_string()]).is_empty());
        assert_eq!(
            gold_finger_readiness(&board, &["B.Cu".to_string()]).len(),
            1
        );
    }

    #[test]
    fn gold_finger_readiness_handles_large_sparse_non_finger_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    "SIG",
                    CopperKind::Via,
                    [100.0 + index as f64 * 2.0, 50.0],
                    0.10,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_disc(
            "EDGE_CONN_1",
            CopperKind::Via,
            [0.0, 0.0],
            0.12,
        ));
        let board = board_with_copper(copper);

        let started = Instant::now();
        let violations = gold_finger_readiness(&board, &[]);

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "gold-finger via-intent review should stay linear over sparse non-finger fields"
        );
    }

    #[test]
    fn gold_finger_edge_readiness_reports_finger_copper_away_from_edge() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![copper_rect(
            "GOLD_FINGER_1",
            CopperKind::Pad,
            "F.Cu",
            5.0,
            9.0,
            6.0,
            10.0,
        )];

        let violations = gold_finger_edge_readiness(&board, &[], &crate::scalar::scalar("1.0"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "gold-finger-edge-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("bevel intent"))
        );
    }

    #[test]
    fn gold_finger_edge_readiness_accepts_edge_fingers_or_missing_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![copper_rect(
            "GOLD_FINGER_1",
            CopperKind::Pad,
            "F.Cu",
            0.2,
            9.0,
            0.8,
            10.0,
        )];
        let no_outline = board_with_copper(vec![copper_rect(
            "GOLD_FINGER_2",
            CopperKind::Pad,
            "F.Cu",
            5.0,
            9.0,
            6.0,
            10.0,
        )]);

        assert!(gold_finger_edge_readiness(&board, &[], &crate::scalar::scalar("1.0")).is_empty());
        assert!(
            gold_finger_edge_readiness(&no_outline, &[], &crate::scalar::scalar("1.0")).is_empty()
        );
    }

    #[test]
    fn gold_finger_edge_readiness_handles_sparse_non_finger_fields() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = (0..2_000)
            .map(|index| {
                let x = 2.0 + (index % 100) as f64 * 0.10;
                let y = 2.0 + (index / 100) as f64 * 0.10;
                copper_rect("SIG", CopperKind::Pad, "F.Cu", x, y, x + 0.04, y + 0.04)
            })
            .chain([copper_rect(
                "GOLD_FINGER_1",
                CopperKind::Pad,
                "F.Cu",
                9.0,
                9.0,
                10.0,
                10.0,
            )])
            .collect();

        let started = Instant::now();
        let violations = gold_finger_edge_readiness(&board, &[], &crate::scalar::scalar("1.0"));

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "gold-finger edge review should stay linear over sparse non-finger fields"
        );
    }

    #[test]
    fn gold_finger_spacing_readiness_reports_tight_finger_pitch() {
        let board = board_with_copper(vec![
            copper_rect("GOLD_FINGER_1", CopperKind::Pad, "F.Cu", 0.0, 0.0, 0.5, 2.0),
            copper_rect(
                "GOLD_FINGER_2",
                CopperKind::Pad,
                "F.Cu",
                0.55,
                0.0,
                1.0,
                2.0,
            ),
        ]);

        let violations = gold_finger_spacing_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.10"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "gold-finger-spacing-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("contact pitch"))
        );
    }

    #[test]
    fn gold_finger_spacing_readiness_allows_distant_or_same_net_fingers() {
        let board = board_with_copper(vec![
            copper_rect("GOLD_FINGER_1", CopperKind::Pad, "F.Cu", 0.0, 0.0, 0.5, 2.0),
            copper_rect(
                "GOLD_FINGER_1",
                CopperKind::Pad,
                "F.Cu",
                0.55,
                0.0,
                1.0,
                2.0,
            ),
            copper_rect("GOLD_FINGER_2", CopperKind::Pad, "F.Cu", 2.0, 0.0, 2.5, 2.0),
        ]);

        assert!(
            gold_finger_spacing_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.10"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn gold_finger_spacing_readiness_culls_sparse_finger_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_rect(
                    &format!("GOLD_FINGER_{index}"),
                    CopperKind::Pad,
                    "F.Cu",
                    100.0 + index as f64 * 5.0,
                    0.0,
                    100.5 + index as f64 * 5.0,
                    2.0,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_rect(
            "GOLD_FINGER_A",
            CopperKind::Pad,
            "F.Cu",
            0.0,
            0.0,
            0.5,
            2.0,
        ));
        copper.push(copper_rect(
            "GOLD_FINGER_B",
            CopperKind::Pad,
            "F.Cu",
            0.55,
            0.0,
            1.0,
            2.0,
        ));
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = gold_finger_spacing_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.10"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "gold-finger spacing should cull sparse card-edge contacts before exact CSG"
        );
    }

    #[test]
    fn gold_finger_drill_keepout_readiness_reports_nearby_drills() {
        let board = board_with_copper(vec![copper_rect(
            "EDGE_CONN_1",
            CopperKind::Pad,
            "F.Cu",
            0.0,
            0.0,
            1.0,
            2.0,
        )]);
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.3),
                crate::geometry::exact_real(1.0),
            ],
            diameter: crate::scalar::scalar("0.6"),
            net: None,
            plated: false,
        }];

        let violations = gold_finger_drill_keepout_readiness(
            &board,
            &sidecar_drills,
            &[],
            &crate::scalar::scalar("0.2"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "gold-finger-drill-keepout-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("no-drill finger plating"))
        );
    }

    #[test]
    fn gold_finger_drill_keepout_readiness_accepts_distant_drills() {
        let board = board_with_copper(vec![copper_rect(
            "EDGE_CONN_1",
            CopperKind::Pad,
            "F.Cu",
            0.0,
            0.0,
            1.0,
            2.0,
        )]);
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(4.0),
                crate::geometry::exact_real(1.0),
            ],
            diameter: crate::scalar::scalar("0.6"),
            net: None,
            plated: false,
        }];

        assert!(
            gold_finger_drill_keepout_readiness(
                &board,
                &sidecar_drills,
                &[],
                &crate::scalar::scalar("0.2"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn gold_finger_drill_keepout_readiness_culls_sparse_finger_fields() {
        let copper = (0..2_000)
            .map(|index| {
                copper_rect(
                    &format!("GOLD_FINGER_{index}"),
                    CopperKind::Pad,
                    "F.Cu",
                    100.0 + index as f64 * 5.0,
                    0.0,
                    100.5 + index as f64 * 5.0,
                    2.0,
                )
            })
            .chain([copper_rect(
                "GOLD_FINGER_NEAR",
                CopperKind::Pad,
                "F.Cu",
                0.0,
                0.0,
                1.0,
                2.0,
            )])
            .collect::<Vec<_>>();
        let board = board_with_copper(copper);
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.25),
                crate::geometry::exact_real(1.0),
            ],
            diameter: crate::scalar::scalar("0.6"),
            net: None,
            plated: false,
        }];

        let started = std::time::Instant::now();
        let violations = gold_finger_drill_keepout_readiness(
            &board,
            &sidecar_drills,
            &[],
            &crate::scalar::scalar("0.4"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "gold-finger drill keepout should cull sparse finger fields before exact CSG"
        );
    }

    #[test]
    fn component_edge_clearance_readiness_reports_close_component_pads() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![
            copper_disc("U1_IO", CopperKind::Pad, [0.7, 10.0], 0.4),
            copper_disc("CARD_EDGE_1", CopperKind::Pad, [0.2, 2.0], 0.4),
            unnetted_copper_disc_on_layer("F.Cu", [0.8, 5.0], 0.4),
        ];

        let violations =
            component_edge_clearance_readiness(&board, &[], &crate::scalar::scalar("0.5"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "component-edge-clearance-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("depanelization"))
        );
    }

    #[test]
    fn component_edge_clearance_readiness_allows_inset_or_selected_out_pads() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![
            copper_disc_on_layer("U1_IO", CopperKind::Pad, "B.Cu", [0.7, 10.0], 0.4),
            copper_disc_on_layer("U2_IO", CopperKind::Pad, "F.Cu", [10.0, 10.0], 0.4),
        ];

        assert!(
            component_edge_clearance_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("0.5")
            )
            .is_empty()
        );
    }

    #[test]
    fn component_edge_clearance_readiness_culls_sparse_rectangular_boards() {
        let mut board = board_with_outline(square(0.0, 0.0, 200.0, 200.0));
        board.copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("U{index}_IO"),
                    CopperKind::Pad,
                    [
                        20.0 + (index % 80) as f64 * 2.0,
                        20.0 + (index / 80) as f64 * 2.0,
                    ],
                    0.50,
                )
            })
            .collect();
        board
            .copper
            .push(copper_disc("U_NEAR", CopperKind::Pad, [0.65, 100.0], 0.30));

        let started = std::time::Instant::now();
        let violations =
            component_edge_clearance_readiness(&board, &[], &crate::scalar::scalar("0.5"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].layers, vec!["F.Cu".to_string()]);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "component-edge clearance should reject interior rectangular-board pads before exact outline distance"
        );
    }

    #[test]
    fn component_hole_clearance_readiness_reports_pads_near_mechanical_holes() {
        let board = board_with_copper(vec![copper_disc(
            "U1_IO",
            CopperKind::Pad,
            [1.0, 0.0],
            0.30,
        )]);
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("1.0"),
            net: None,
            plated: false,
        }];

        let violations = component_hole_clearance_readiness(
            &board,
            &sidecar_drills,
            &[],
            &crate::scalar::scalar("0.30"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "component-hole-clearance-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("standoff"))
        );
    }

    #[test]
    fn component_hole_clearance_readiness_allows_distant_or_plated_holes() {
        let mut board = board_with_copper(vec![copper_disc(
            "U1_IO",
            CopperKind::Pad,
            [5.0, 0.0],
            0.30,
        )]);
        board.drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("1.0"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(5.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("1.0"),
                net: Some("U1_IO".to_string()),
                plated: true,
            },
        ];

        assert!(
            component_hole_clearance_readiness(
                &board,
                &[],
                &[],
                &crate::scalar::scalar("0.30"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn connector_rework_clearance_readiness_reports_tight_neighboring_pads() {
        let board = board_with_copper(vec![
            copper_rect("USB_VBUS", CopperKind::Pad, "F.Cu", 0.0, 0.0, 1.0, 1.0),
            copper_rect("GPIO1", CopperKind::Pad, "F.Cu", 1.10, 0.0, 1.60, 1.0),
        ]);

        let violations = connector_rework_clearance_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.20"),
            &crate::scalar::scalar("0.40"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "connector-rework-clearance-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("rework access"))
        );
    }

    #[test]
    fn connector_rework_clearance_readiness_allows_distant_or_small_pads() {
        let board = board_with_copper(vec![
            copper_rect("USB_VBUS", CopperKind::Pad, "F.Cu", 0.0, 0.0, 0.20, 0.20),
            copper_rect("GPIO1", CopperKind::Pad, "F.Cu", 1.10, 0.0, 1.60, 1.0),
            copper_rect("USB_D_P", CopperKind::Pad, "F.Cu", 5.0, 0.0, 6.0, 1.0),
            copper_rect("GPIO2", CopperKind::Pad, "F.Cu", 7.0, 0.0, 8.0, 1.0),
        ]);

        assert!(
            connector_rework_clearance_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.20"),
                &crate::scalar::scalar("0.40")
            )
            .is_empty()
        );
    }

    #[test]
    fn connector_return_path_readiness_reports_edge_rate_connector_without_ground_return() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![copper_rect(
            "USB_D_P",
            CopperKind::Pad,
            "F.Cu",
            0.4,
            8.0,
            1.0,
            8.6,
        )];

        let violations = connector_return_path_readiness(
            &board,
            &[],
            &crate::scalar::scalar("1.0"),
            &crate::scalar::scalar("2.0"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "connector-return-path-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("ground return"))
        );
    }

    #[test]
    fn connector_return_path_readiness_accepts_nearby_ground_or_inset_connector() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![
            copper_rect("USB_D_P", CopperKind::Pad, "F.Cu", 0.4, 8.0, 1.0, 8.6),
            copper_disc("GND", CopperKind::Via, [1.5, 8.3], 0.12),
            copper_rect("USB_D_N", CopperKind::Pad, "F.Cu", 5.0, 8.0, 5.6, 8.6),
        ];

        assert!(
            connector_return_path_readiness(
                &board,
                &[],
                &crate::scalar::scalar("1.0"),
                &crate::scalar::scalar("2.0")
            )
            .is_empty()
        );
    }

    #[test]
    fn connector_return_path_readiness_culls_sparse_ground_fields() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![copper_rect(
            "USB_D_P",
            CopperKind::Pad,
            "F.Cu",
            0.4,
            8.0,
            1.0,
            8.6,
        )];
        for index in 0..2_000 {
            board.copper.push(copper_disc(
                "GND",
                CopperKind::Via,
                [100.0 + index as f64 * 2.0, 50.0],
                0.12,
            ));
        }
        let start = Instant::now();

        let violations = connector_return_path_readiness(
            &board,
            &[],
            &crate::scalar::scalar("1.0"),
            &crate::scalar::scalar("2.0"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "connector return-path lookup should index sparse ground fields"
        );
    }

    #[test]
    fn decoupling_proximity_readiness_reports_power_feature_without_ground_return() {
        let board = board_with_copper(vec![
            copper_disc("VDD_3V3", CopperKind::Pad, [0.0, 0.0], 0.3),
            copper_disc("GND", CopperKind::Pad, [5.0, 0.0], 0.3),
        ]);

        let violations = decoupling_proximity_readiness(&board, &[], &crate::scalar::scalar("1.0"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "decoupling-proximity-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("decoupling capacitor loop"))
        );
    }

    #[test]
    fn decoupling_proximity_readiness_allows_nearby_ground_or_selected_out_layers() {
        let board = board_with_copper(vec![
            copper_disc("VDD_3V3", CopperKind::Pad, [0.0, 0.0], 0.3),
            copper_disc("GND", CopperKind::Pad, [0.8, 0.0], 0.3),
            copper_disc_on_layer("VBUS", CopperKind::Via, "B.Cu", [5.0, 0.0], 0.3),
            copper_disc_on_layer("GND", CopperKind::Via, "B.Cu", [5.8, 0.0], 0.3),
        ]);

        assert!(
            decoupling_proximity_readiness(&board, &[], &crate::scalar::scalar("1.0")).is_empty()
        );
        assert!(
            decoupling_proximity_readiness(
                &board,
                &["F.Cu".to_string()],
                &crate::scalar::scalar("1.0")
            )
            .is_empty()
        );
    }

    #[test]
    fn decoupling_proximity_readiness_culls_sparse_ground_fields() {
        let mut copper = vec![copper_disc("VDD_3V3", CopperKind::Pad, [0.0, 0.0], 0.3)];
        for index in 0..2_000 {
            copper.push(copper_disc(
                "GND",
                CopperKind::Pad,
                [100.0 + index as f64 * 2.0, 20.0],
                0.3,
            ));
        }
        let board = board_with_copper(copper);
        let start = Instant::now();

        let violations = decoupling_proximity_readiness(&board, &[], &crate::scalar::scalar("1.0"));

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "decoupling proximity lookup should index sparse ground fields"
        );
    }

    #[test]
    fn esd_protection_readiness_reports_unprotected_edge_connector_net() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![copper_rect(
            "USB_D_P",
            CopperKind::Pad,
            "F.Cu",
            0.4,
            8.0,
            1.0,
            8.6,
        )];

        let violations = esd_protection_readiness(
            &board,
            &[],
            &crate::scalar::scalar("1.0"),
            &crate::scalar::scalar("2.0"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "esd-protection-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("ESD"))
        );
    }

    #[test]
    fn esd_protection_readiness_accepts_nearby_tvs_chassis_or_inset_net() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![
            copper_rect("USB_D_P", CopperKind::Pad, "F.Cu", 0.4, 8.0, 1.0, 8.6),
            copper_disc("USB_ESD_CLAMP", CopperKind::Pad, [1.5, 8.3], 0.12),
            copper_rect("USB_D_N", CopperKind::Pad, "F.Cu", 5.0, 8.0, 5.6, 8.6),
        ];

        assert!(
            esd_protection_readiness(
                &board,
                &[],
                &crate::scalar::scalar("1.0"),
                &crate::scalar::scalar("2.0")
            )
            .is_empty()
        );
    }

    #[test]
    fn switch_node_keepout_readiness_reports_nearby_non_ground_copper() {
        let board = board_with_copper(vec![
            copper_rect("BUCK_SW", CopperKind::Segment, "F.Cu", 0.0, 0.0, 1.0, 0.5),
            copper_rect("ADC_IN", CopperKind::Segment, "F.Cu", 1.2, 0.0, 2.0, 0.5),
            copper_rect("GND", CopperKind::Zone, "F.Cu", 0.0, 2.0, 2.0, 3.0),
        ]);

        let violations = switch_node_keepout_readiness(
            &board,
            &[],
            crate::scalar::scalar("0.3"),
            &crate::scalar::scalar("1e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "switch-node-keepout-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("EMI"))
        );
    }

    #[test]
    fn switch_node_keepout_readiness_allows_same_net_ground_and_distant_copper() {
        let board = board_with_copper(vec![
            copper_rect("BUCK_SW", CopperKind::Segment, "F.Cu", 0.0, 0.0, 1.0, 0.5),
            copper_rect("BUCK_SW", CopperKind::Pad, "F.Cu", 1.1, 0.0, 1.5, 0.5),
            copper_rect("GND", CopperKind::Zone, "F.Cu", 1.2, 0.0, 2.0, 0.5),
            copper_rect("ADC_IN", CopperKind::Segment, "F.Cu", 4.0, 0.0, 5.0, 0.5),
        ]);

        assert!(
            switch_node_keepout_readiness(
                &board,
                &[],
                crate::scalar::scalar("0.3"),
                &crate::scalar::scalar("1e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn testpoint_coverage_readiness_reports_critical_nets_missing_ipc_records() {
        let board = board_with_copper(vec![
            copper_disc("VBUS", CopperKind::Pad, [0.0, 0.0], 0.4),
            copper_disc("STATUS_LED", CopperKind::Pad, [5.0, 0.0], 0.4),
            copper_disc("GND", CopperKind::Pad, [10.0, 0.0], 0.4),
        ]);
        let ipc_points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("TP1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(10.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: None,
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let violations = testpoint_coverage_readiness(&board, &ipc_points, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "testpoint-coverage-readiness");
        assert_eq!(violations[0].layers, vec!["VBUS"]);
    }

    #[test]
    fn testpoint_coverage_readiness_allows_covered_or_noncritical_nets() {
        let board = board_with_copper(vec![
            copper_disc("VBUS", CopperKind::Pad, [0.0, 0.0], 0.4),
            copper_disc("STATUS_LED", CopperKind::Pad, [5.0, 0.0], 0.4),
        ]);
        let ipc_points = vec![Ipc356Point {
            net: "vbus".to_string(),
            reference: Some("TP1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: None,
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        assert!(testpoint_coverage_readiness(&board, &ipc_points, &[]).is_empty());
    }

    #[test]
    fn testpoint_coverage_readiness_handles_sparse_critical_nets() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("VBUS_{index}"),
                    CopperKind::Pad,
                    [index as f64 * 2.0, 0.0],
                    0.4,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_disc(
            "VDD_MISSING",
            CopperKind::Pad,
            [9_000.0, 0.0],
            0.4,
        ));
        let points = (0..2_000)
            .map(|index| Ipc356Point {
                net: format!("VBUS_{index}"),
                reference: Some(format!("TP{index}")),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(index as f64 * 2.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: None,
                access_side: None,
                feature_type: None,
                soldermask: None,
            })
            .collect::<Vec<_>>();
        let board = board_with_copper(copper);

        let started = std::time::Instant::now();
        let violations = testpoint_coverage_readiness(&board, &points, &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].layers, vec!["VDD_MISSING"]);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "testpoint coverage should stay bounded on sparse critical-net sets"
        );
    }

    #[test]
    fn testpoint_accessibility_readiness_reports_probe_diameter_spacing_and_edge_risks() {
        let board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        let ipc_points = vec![
            Ipc356Point {
                net: "GND".to_string(),
                reference: Some("TP1".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(0.8),
                    crate::geometry::exact_real(10.0),
                ],
                diameter: Some(crate::scalar::scalar("0.20")),
                access_side: None,
                feature_type: None,
                soldermask: None,
            },
            Ipc356Point {
                net: "VBUS".to_string(),
                reference: Some("TP2".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(1.1),
                    crate::geometry::exact_real(10.0),
                ],
                diameter: Some(crate::scalar::scalar("0.30")),
                access_side: None,
                feature_type: None,
                soldermask: None,
            },
            Ipc356Point {
                net: "RESET".to_string(),
                reference: Some("TP3".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(10.0),
                    crate::geometry::exact_real(10.0),
                ],
                diameter: None,
                access_side: None,
                feature_type: None,
                soldermask: None,
            },
        ];

        let violations = testpoint_accessibility_readiness(
            &board,
            &ipc_points,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("0.20"),
            &crate::scalar::scalar("1.0"),
        );
        let messages = violations
            .iter()
            .filter_map(|violation| violation.message.as_deref())
            .collect::<Vec<_>>();

        assert!(
            messages
                .iter()
                .any(|message| message.contains("below minimum probe diameter"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("below fixture edge clearance"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("below fixture probe spacing"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("no parsed probe diameter"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("no soldermask access flag"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("no parsed access side"))
        );
    }

    #[test]
    fn testpoint_accessibility_readiness_allows_complete_accessible_points() {
        let board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        let ipc_points = vec![
            Ipc356Point {
                net: "GND".to_string(),
                reference: Some("TP1".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(5.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: Some(crate::scalar::scalar("0.35")),
                access_side: Some(Ipc356AccessSide::Top),
                feature_type: Some(Ipc356FeatureType::Smd),
                soldermask: Some(Ipc356Soldermask::Open),
            },
            Ipc356Point {
                net: "VBUS".to_string(),
                reference: Some("TP2".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(8.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: Some(crate::scalar::scalar("0.35")),
                access_side: Some(Ipc356AccessSide::Top),
                feature_type: Some(Ipc356FeatureType::Smd),
                soldermask: Some(Ipc356Soldermask::Open),
            },
        ];

        assert!(
            testpoint_accessibility_readiness(
                &board,
                &ipc_points,
                &crate::scalar::scalar("0.25"),
                &crate::scalar::scalar("0.20"),
                &crate::scalar::scalar("1.0"),
            )
            .is_empty()
        );
    }

    #[test]
    fn testpoint_accessibility_readiness_reports_mask_and_side_metadata_risks() {
        let board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        let ipc_points = vec![
            Ipc356Point {
                net: "TP_COVERED".to_string(),
                reference: Some("TP1".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(5.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: Some(crate::scalar::scalar("0.35")),
                access_side: Some(Ipc356AccessSide::Top),
                feature_type: Some(Ipc356FeatureType::Smd),
                soldermask: Some(Ipc356Soldermask::Covered),
            },
            Ipc356Point {
                net: "TP_UNKNOWN".to_string(),
                reference: Some("TP2".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(8.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: Some(crate::scalar::scalar("0.35")),
                access_side: Some(Ipc356AccessSide::Top),
                feature_type: Some(Ipc356FeatureType::Smd),
                soldermask: Some(Ipc356Soldermask::Unknown),
            },
            Ipc356Point {
                net: "TP_BOTH".to_string(),
                reference: Some("TP3".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(11.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: Some(crate::scalar::scalar("0.35")),
                access_side: Some(Ipc356AccessSide::Both),
                feature_type: Some(Ipc356FeatureType::Smd),
                soldermask: Some(Ipc356Soldermask::Open),
            },
        ];

        let violations = testpoint_accessibility_readiness(
            &board,
            &ipc_points,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("0.20"),
            &crate::scalar::scalar("1.0"),
        );
        let messages = violations
            .iter()
            .filter_map(|violation| violation.message.as_deref())
            .collect::<Vec<_>>();

        assert!(
            messages
                .iter()
                .any(|message| message.contains("marked soldermask-covered"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("unknown soldermask access"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("accessible from both sides"))
        );
    }

    #[test]
    fn testpoint_accessibility_readiness_reports_ipc_side_disagreeing_with_kicad_pad_side() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc_on_layer(
                "USB_D+",
                CopperKind::Pad,
                "B.Cu",
                [5.0, 5.0],
                0.20,
            )],
            drills: Vec::new(),
            board_outline: Some(region(vec![square(0.0, 0.0, 20.0, 20.0)])),
            panel_features: None,
        };
        let ipc_points = vec![Ipc356Point {
            net: "USB_D+".to_string(),
            reference: Some("TP1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(5.0),
                crate::geometry::exact_real(5.0),
            ],
            diameter: Some(crate::scalar::scalar("0.35")),
            access_side: Some(Ipc356AccessSide::Top),
            feature_type: Some(Ipc356FeatureType::Smd),
            soldermask: Some(Ipc356Soldermask::Open),
        }];

        let violations = testpoint_accessibility_readiness(
            &board,
            &ipc_points,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("0.20"),
            &crate::scalar::scalar("1.0"),
        );

        assert!(violations.iter().any(|violation| {
            violation.message.as_deref().is_some_and(|message| {
                message.contains("access side is top")
                    && message.contains("KiCad pad/via copper is only on bottom")
            })
        }));
    }

    #[test]
    fn testpoint_accessibility_readiness_allows_ipc_side_matching_kicad_pad_side() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc_on_layer(
                "USB_D+",
                CopperKind::Pad,
                "B.Cu",
                [5.0, 5.0],
                0.20,
            )],
            drills: Vec::new(),
            board_outline: Some(region(vec![square(0.0, 0.0, 20.0, 20.0)])),
            panel_features: None,
        };
        let ipc_points = vec![Ipc356Point {
            net: "USB_D+".to_string(),
            reference: Some("TP1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(5.0),
                crate::geometry::exact_real(5.0),
            ],
            diameter: Some(crate::scalar::scalar("0.35")),
            access_side: Some(Ipc356AccessSide::Bottom),
            feature_type: Some(Ipc356FeatureType::Smd),
            soldermask: Some(Ipc356Soldermask::Open),
        }];
        let messages = testpoint_accessibility_readiness(
            &board,
            &ipc_points,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("0.20"),
            &crate::scalar::scalar("1.0"),
        )
        .into_iter()
        .filter_map(|violation| violation.message)
        .collect::<Vec<_>>();

        assert!(
            !messages
                .iter()
                .any(|message| message.contains("nearby same-net KiCad pad/via copper"))
        );
    }

    #[test]
    fn tooling_hole_readiness_reports_missing_or_edge_close_tooling_holes() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.8),
                crate::geometry::exact_real(10.0),
            ],
            diameter: crate::scalar::scalar("1.0"),
            net: None,
            plated: false,
        }];

        let violations = tooling_hole_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.8"),
            &crate::scalar::scalar("4.0"),
            &crate::scalar::scalar("1.0"),
        );
        let messages = violations
            .iter()
            .filter_map(|violation| violation.message.as_deref())
            .collect::<Vec<_>>();

        assert!(
            messages
                .iter()
                .any(|message| message.contains("found 1 likely tooling hole"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("below fixture edge clearance"))
        );
    }

    #[test]
    fn tooling_hole_readiness_accepts_inset_board_and_sidecar_tooling_holes() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(5.0),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("1.5"),
            net: None,
            plated: false,
        }];
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(15.0),
                crate::geometry::exact_real(15.0),
            ],
            diameter: crate::scalar::scalar("1.5"),
            net: None,
            plated: false,
        }];

        assert!(
            tooling_hole_readiness(
                &board,
                &sidecar_drills,
                &crate::scalar::scalar("0.8"),
                &crate::scalar::scalar("4.0"),
                &crate::scalar::scalar("1.0"),
            )
            .is_empty()
        );
    }

    #[test]
    fn tooling_hole_readiness_filters_sparse_drill_tables() {
        let mut board = board_with_outline(square(0.0, 0.0, 100.0, 100.0));
        board.drills = (0..2_000)
            .map(|index| DrillFeature {
                location: [
                    crate::geometry::exact_real(200.0 + index as f64 * 2.0),
                    crate::geometry::exact_real(200.0),
                ],
                diameter: crate::scalar::scalar("0.40"),
                net: None,
                plated: false,
            })
            .chain([
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(10.0),
                        crate::geometry::exact_real(10.0),
                    ],
                    diameter: crate::scalar::scalar("1.50"),
                    net: None,
                    plated: false,
                },
                DrillFeature {
                    location: [
                        crate::geometry::exact_real(90.0),
                        crate::geometry::exact_real(90.0),
                    ],
                    diameter: crate::scalar::scalar("1.50"),
                    net: None,
                    plated: false,
                },
            ])
            .collect();

        let started = std::time::Instant::now();
        let violations = tooling_hole_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.8"),
            &crate::scalar::scalar("4.0"),
            &crate::scalar::scalar("1.0"),
        );

        assert!(violations.is_empty());
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "tooling-hole readiness should filter sparse drill tables before outline edge review"
        );
    }

    #[test]
    fn mouse_bite_readiness_reports_bad_diameter_and_spacing() {
        let sidecar_drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.20"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.30),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(2.00),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: None,
                plated: false,
            },
        ];

        let violations = mouse_bite_readiness(
            &board_with_copper(Vec::new()),
            &sidecar_drills,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("0.50"),
            &crate::scalar::scalar("0.40"),
            &crate::scalar::scalar("1.20"),
        );
        let messages = violations
            .iter()
            .filter_map(|violation| violation.message.as_deref())
            .collect::<Vec<_>>();

        assert!(
            messages
                .iter()
                .any(|message| message.contains("diameter") && message.contains("below minimum"))
        );
        assert!(
            messages
                .iter()
                .any(|message| message.contains("center spacing")
                    && message.contains("outside expected range"))
        );
    }

    #[test]
    fn mouse_bite_readiness_accepts_reasonable_small_npth_rows() {
        let sidecar_drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.70),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(1.40),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: None,
                plated: false,
            },
        ];

        assert!(
            mouse_bite_readiness(
                &board_with_copper(Vec::new()),
                &sidecar_drills,
                &crate::scalar::scalar("0.25"),
                &crate::scalar::scalar("0.50"),
                &crate::scalar::scalar("0.40"),
                &crate::scalar::scalar("1.20")
            )
            .is_empty()
        );
    }

    #[test]
    fn fiducial_readiness_reports_missing_and_edge_close_fiducials() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![
            unnetted_copper_disc_on_layer("F.Cu", [5.0, 5.0], 0.5),
            unnetted_copper_disc_on_layer("F.Cu", [0.6, 10.0], 0.5),
            copper_disc_on_layer("GND", CopperKind::Pad, "B.Cu", [10.0, 10.0], 0.5),
        ];

        let violations = fiducial_readiness(&board, &[], &crate::scalar::scalar("1.0"));

        assert!(violations.iter().any(|violation| {
            violation
                .message
                .as_deref()
                .is_some_and(|message| message.contains("likely fiducial is"))
        }));
        assert!(violations.iter().any(|violation| {
            violation.layers == vec!["B.Cu"]
                && violation
                    .message
                    .as_deref()
                    .is_some_and(|message| message.contains("0 likely fiducial"))
        }));
    }

    #[test]
    fn fiducial_readiness_allows_two_inset_side_fiducials() {
        let mut board = board_with_outline(square(0.0, 0.0, 20.0, 20.0));
        board.copper = vec![
            unnetted_copper_disc_on_layer("F.Cu", [4.0, 4.0], 0.5),
            unnetted_copper_disc_on_layer("F.Cu", [16.0, 16.0], 0.5),
        ];

        assert!(fiducial_readiness(&board, &[], &crate::scalar::scalar("1.0")).is_empty());
    }

    #[test]
    fn fiducial_readiness_culls_sparse_rectangular_interior_targets() {
        let mut board = board_with_outline(square(0.0, 0.0, 200.0, 200.0));
        board.copper = (0..2_000)
            .map(|index| {
                unnetted_copper_disc_on_layer(
                    "F.Cu",
                    [
                        20.0 + (index % 80) as f64 * 2.0,
                        20.0 + (index / 80) as f64 * 2.0,
                    ],
                    0.30,
                )
            })
            .collect();

        let started = std::time::Instant::now();
        let violations = fiducial_readiness(&board, &[], &crate::scalar::scalar("1.0"));

        assert!(violations.is_empty());
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "fiducial readiness should reject interior rectangular-board fiducials before exact outline distance"
        );
    }

    #[test]
    fn local_fiducial_readiness_reports_dense_clusters_without_nearby_fiducials() {
        let mut copper = dense_pad_cluster();
        copper.push(unnetted_copper_disc_on_layer("F.Cu", [20.0, 20.0], 0.5));
        copper.push(unnetted_copper_disc_on_layer("F.Cu", [22.0, 20.0], 0.5));

        let violations = local_fiducial_readiness(
            &board_with_copper(copper),
            &[],
            &crate::geometry::exact_real(0.8),
            &crate::geometry::exact_real(5.0),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "local-fiducial-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("only 0 likely local fiducial"))
        );
    }

    #[test]
    fn local_fiducial_readiness_accepts_nearby_local_fiducials_or_sparse_pads() {
        let mut copper = dense_pad_cluster();
        copper.push(unnetted_copper_disc_on_layer("F.Cu", [0.0, 3.0], 0.5));
        copper.push(unnetted_copper_disc_on_layer("F.Cu", [3.0, 0.0], 0.5));

        assert!(
            local_fiducial_readiness(
                &board_with_copper(copper),
                &[],
                &crate::geometry::exact_real(0.8),
                &crate::geometry::exact_real(5.0),
            )
            .is_empty()
        );

        let sparse = (0..8)
            .map(|index| {
                copper_disc(
                    &format!("PAD_{index}"),
                    CopperKind::Pad,
                    [index as f64, 0.0],
                    0.12,
                )
            })
            .collect::<Vec<_>>();
        assert!(
            local_fiducial_readiness(
                &board_with_copper(sparse),
                &[],
                &crate::geometry::exact_real(0.8),
                &crate::geometry::exact_real(5.0),
            )
            .is_empty()
        );
    }

    #[test]
    fn dense_pad_escape_readiness_reports_fine_pitch_cluster_without_escape_vias() {
        let board = board_with_copper(dense_pad_cluster());

        let violations = dense_pad_escape_readiness(
            &board,
            &[],
            &crate::geometry::exact_real(0.8),
            &crate::geometry::exact_real(2.0),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "dense-pad-escape-readiness");
    }

    #[test]
    fn dense_pad_escape_readiness_allows_sparse_or_via_escaped_clusters() {
        let mut sparse = Vec::new();
        for index in 0..16 {
            sparse.push(copper_disc(
                &format!("PAD_{index}"),
                CopperKind::Pad,
                [index as f64, 0.0],
                0.12,
            ));
        }
        assert!(
            dense_pad_escape_readiness(
                &board_with_copper(sparse),
                &[],
                &crate::geometry::exact_real(0.8),
                &crate::geometry::exact_real(2.0),
            )
            .is_empty()
        );

        let mut escaped = Vec::new();
        for x in 0..4 {
            for y in 0..4 {
                escaped.push(copper_disc(
                    &format!("BGA_{x}_{y}"),
                    CopperKind::Pad,
                    [x as f64 * 0.5, y as f64 * 0.5],
                    0.12,
                ));
            }
        }
        escaped.push(copper_disc("ESCAPE", CopperKind::Via, [0.75, 0.75], 0.15));

        assert!(
            dense_pad_escape_readiness(
                &board_with_copper(escaped),
                &[],
                &crate::geometry::exact_real(0.8),
                &crate::geometry::exact_real(2.0),
            )
            .is_empty()
        );
    }

    #[test]
    fn thermal_pad_via_readiness_reports_large_power_or_ground_pads_without_vias() {
        let board = board_with_copper(vec![
            copper_rect("GND", CopperKind::Pad, "F.Cu", 0.0, 0.0, 3.0, 3.0),
            copper_rect("GPIO", CopperKind::Pad, "F.Cu", 5.0, 0.0, 8.0, 3.0),
        ]);

        let violations = thermal_pad_via_readiness(&board, &[], &crate::scalar::scalar("2.0"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "thermal-pad-via-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("thermal via array"))
        );
    }

    #[test]
    fn thermal_pad_via_readiness_accepts_same_net_via_in_large_pad() {
        let board = board_with_copper(vec![
            copper_rect("GND", CopperKind::Pad, "F.Cu", 0.0, 0.0, 3.0, 3.0),
            copper_disc("GND", CopperKind::Via, [1.5, 1.5], 0.12),
        ]);

        assert!(thermal_pad_via_readiness(&board, &[], &crate::scalar::scalar("2.0")).is_empty());
    }

    #[test]
    fn thermal_copper_area_readiness_reports_power_feature_without_nearby_zone() {
        let board = board_with_copper(vec![
            copper_disc("VREG_OUT", CopperKind::Pad, [0.0, 0.0], 0.30),
            copper_rect("VREG_OUT", CopperKind::Zone, "F.Cu", 5.0, 0.0, 7.0, 2.0),
        ]);

        let violations = thermal_copper_area_readiness(&board, &[], &crate::scalar::scalar("2.0"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "thermal-copper-area-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("heat spreading"))
        );
    }

    #[test]
    fn thermal_copper_area_readiness_accepts_nearby_same_net_zone_or_low_power_net() {
        let board = board_with_copper(vec![
            copper_disc("VREG_OUT", CopperKind::Pad, [0.0, 0.0], 0.30),
            copper_rect("VREG_OUT", CopperKind::Zone, "F.Cu", 0.8, 0.0, 2.0, 1.0),
            copper_disc("GPIO1", CopperKind::Pad, [5.0, 0.0], 0.30),
        ]);

        assert!(
            thermal_copper_area_readiness(&board, &[], &crate::scalar::scalar("2.0")).is_empty()
        );
    }

    #[test]
    fn hot_component_spacing_readiness_reports_hot_feature_near_neighbor() {
        let board = board_with_copper(vec![
            copper_rect("LED_PWR", CopperKind::Pad, "F.Cu", 0.0, 0.0, 1.0, 1.0),
            copper_rect("SENSOR_OUT", CopperKind::Pad, "F.Cu", 1.2, 0.0, 2.0, 1.0),
            copper_rect("GND", CopperKind::Zone, "F.Cu", 0.0, 2.0, 2.0, 3.0),
        ]);

        let violations = hot_component_spacing_readiness(
            &board,
            &[],
            &crate::scalar::scalar("0.3"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "hot-component-spacing-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("derating"))
        );
    }

    #[test]
    fn hot_component_spacing_readiness_allows_ground_same_net_or_distant_neighbors() {
        let board = board_with_copper(vec![
            copper_rect("LED_PWR", CopperKind::Pad, "F.Cu", 0.0, 0.0, 1.0, 1.0),
            copper_rect("LED_PWR", CopperKind::Zone, "F.Cu", 1.2, 0.0, 2.0, 1.0),
            copper_rect("GND", CopperKind::Zone, "F.Cu", 1.2, 1.5, 2.0, 2.5),
            copper_rect("SENSOR_OUT", CopperKind::Pad, "F.Cu", 5.0, 0.0, 6.0, 1.0),
        ]);

        assert!(
            hot_component_spacing_readiness(
                &board,
                &[],
                &crate::scalar::scalar("0.3"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn thermal_mechanical_keepout_readiness_reports_hot_feature_near_hole() {
        let mut board = board_with_copper(vec![copper_rect(
            "HEATER_OUT",
            CopperKind::Pad,
            "F.Cu",
            0.0,
            0.0,
            1.0,
            1.0,
        )]);
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.4),
                crate::geometry::exact_real(0.5),
            ],
            diameter: crate::scalar::scalar("0.8"),
            net: None,
            plated: false,
        }];

        let violations = thermal_mechanical_keepout_readiness(
            &board,
            &[],
            &[],
            &crate::scalar::scalar("0.2"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "thermal-mechanical-keepout-readiness");
        assert!(
            violations[0]
                .message
                .as_deref()
                .is_some_and(|message| message.contains("heatsink"))
        );
    }

    #[test]
    fn thermal_mechanical_keepout_readiness_accepts_distant_or_plated_holes() {
        let mut board = board_with_copper(vec![copper_rect(
            "HEATER_OUT",
            CopperKind::Pad,
            "F.Cu",
            0.0,
            0.0,
            1.0,
            1.0,
        )]);
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.4),
                crate::geometry::exact_real(0.5),
            ],
            diameter: crate::scalar::scalar("0.8"),
            net: Some("HEATER_OUT".to_string()),
            plated: true,
        }];
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(5.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.8"),
            net: None,
            plated: false,
        }];

        assert!(
            thermal_mechanical_keepout_readiness(
                &board,
                &sidecar_drills,
                &[],
                &crate::scalar::scalar("0.2"),
                &crate::scalar::scalar("1.0e-9")
            )
            .is_empty()
        );
    }

    #[test]
    fn return_path_readiness_reports_high_speed_via_without_ground_stitch() {
        let board = board_with_copper(vec![copper_disc(
            "USB_D+",
            CopperKind::Via,
            [0.0, 0.0],
            0.12,
        )]);

        let violations = return_path_readiness(&board, &crate::scalar::scalar("0.50"), &[]);

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "return-path-readiness");
    }

    #[test]
    fn return_path_readiness_allows_nearby_ground_stitch_or_low_speed_vias() {
        let board = board_with_copper(vec![
            copper_disc("USB_D+", CopperKind::Via, [0.0, 0.0], 0.12),
            copper_disc("GND", CopperKind::Via, [0.30, 0.0], 0.12),
            copper_disc("GPIO1", CopperKind::Via, [2.0, 0.0], 0.12),
        ]);

        assert!(return_path_readiness(&board, &crate::scalar::scalar("0.50"), &[]).is_empty());
    }

    #[test]
    fn return_path_readiness_respects_selected_layers() {
        let board = board_with_copper(vec![copper_disc_on_layer(
            "PCIE_RX0",
            CopperKind::Via,
            "B.Cu",
            [0.0, 0.0],
            0.12,
        )]);

        assert!(
            return_path_readiness(
                &board,
                &crate::scalar::scalar("0.50"),
                &["F.Cu".to_string()]
            )
            .is_empty()
        );
        assert_eq!(
            return_path_readiness(
                &board,
                &crate::scalar::scalar("0.50"),
                &["B.Cu".to_string()]
            )
            .len(),
            1
        );
    }

    #[test]
    fn return_path_readiness_culls_sparse_ground_vias() {
        let board = board_with_copper(
            (0..2_000)
                .map(|index| {
                    copper_disc(
                        "GND",
                        CopperKind::Via,
                        [100.0 + index as f64 * 2.0, 50.0],
                        0.10,
                    )
                })
                .chain([copper_disc("USB_D+", CopperKind::Via, [0.0, 0.0], 0.12)])
                .collect(),
        );

        let start = Instant::now();
        let violations = return_path_readiness(&board, &crate::scalar::scalar("0.50"), &[]);

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed().as_secs_f64() < 2.0,
            "return-path via stitching should index sparse ground-via fields"
        );
    }

    #[test]
    fn net_spacing_distance_fallback_covers_trace_clearances() {
        assert_eq!(
            net_spacing(
                &board_with_copper(vec![
                    copper_line("A", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
                    copper_line("B", CopperKind::Segment, [0.0, 0.18], [1.0, 0.18], 0.1),
                ]),
                &crate::scalar::scalar("0.10"),
                &[],
                &crate::scalar::scalar("1.0e-9"),
            )
            .len(),
            1
        );

        assert_eq!(
            net_spacing(
                &board_with_copper(vec![
                    copper_line("A", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
                    copper_disc("B", CopperKind::Pad, [1.15, 0.0], 0.06),
                ]),
                &crate::scalar::scalar("0.10"),
                &[],
                &crate::scalar::scalar("1.0e-9"),
            )
            .len(),
            1
        );

        assert_eq!(
            net_spacing(
                &board_with_copper(vec![
                    copper_line("A", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
                    copper_disc("B", CopperKind::Via, [0.5, 0.20], 0.06),
                ]),
                &crate::scalar::scalar("0.10"),
                &[],
                &crate::scalar::scalar("1.0e-9"),
            )
            .len(),
            1
        );
    }

    #[test]
    fn net_spacing_allows_trace_clearances_above_threshold() {
        let board = board_with_copper(vec![
            copper_line("A", CopperKind::Segment, [0.0, 0.0], [1.0, 0.0], 0.1),
            copper_line("B", CopperKind::Segment, [0.0, 0.30], [1.0, 0.30], 0.1),
        ]);

        assert!(
            net_spacing(
                &board,
                &crate::scalar::scalar("0.10"),
                &[],
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn net_spacing_culls_sparse_different_net_fields() {
        let mut copper = (0..2_000)
            .map(|index| {
                copper_disc(
                    &format!("SIG{index}"),
                    CopperKind::Pad,
                    [100.0 + index as f64 * 2.0, 100.0],
                    0.10,
                )
            })
            .collect::<Vec<_>>();
        copper.push(copper_disc("A", CopperKind::Pad, [0.0, 0.0], 0.20));
        copper.push(copper_disc("B", CopperKind::Pad, [0.25, 0.0], 0.20));

        let started = Instant::now();
        let violations = net_spacing(
            &board_with_copper(copper),
            &crate::scalar::scalar("0.10"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "different-net-spacing");
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "different-net spacing should use the copper spatial index before exact offsets"
        );
    }

    #[test]
    fn drill_to_copper_clearance_flags_hole_trace_and_slot_trace_cases() {
        let trace = copper_line("SIG", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.1);
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![trace],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let extra_drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.5),
                    crate::geometry::exact_real(0.18),
                ],
                diameter: crate::scalar::scalar("0.2"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(1.5),
                    crate::geometry::exact_real(0.32),
                ],
                diameter: crate::scalar::scalar("0.2"),
                net: None,
                plated: false,
            },
        ];

        let violations = drill_to_copper_clearance(
            &board,
            &extra_drills,
            &crate::scalar::scalar("0.15"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
    }

    #[test]
    fn drill_to_copper_clearance_respects_layer_selection() {
        let trace = copper_line_on_layer(
            "SIG",
            CopperKind::Segment,
            "B.Cu",
            [0.0, 0.0],
            [2.0, 0.0],
            0.10,
        );
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![trace],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let extra_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.0),
                crate::geometry::exact_real(0.06),
            ],
            diameter: crate::scalar::scalar("0.1"),
            net: None,
            plated: false,
        }];

        let unselected = drill_to_copper_clearance(
            &board,
            &extra_drills,
            &crate::scalar::scalar("0.02"),
            &["F.Cu".to_string()],
            &crate::scalar::scalar("1.0e-9"),
        );
        let selected = drill_to_copper_clearance(
            &board,
            &extra_drills,
            &crate::scalar::scalar("0.02"),
            &["B.Cu".to_string()],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(unselected.is_empty());
        assert_eq!(selected.len(), 1);
    }

    #[test]
    fn drill_to_copper_clearance_includes_sidecar_drills() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_line(
                "SIG",
                CopperKind::Segment,
                [0.0, 0.0],
                [2.0, 0.0],
                0.10,
            )],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.8"),
                net: None,
                plated: false,
            }],
            board_outline: None,
            panel_features: None,
        };
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.2),
                crate::geometry::exact_real(0.55),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = drill_to_copper_clearance(
            &board,
            &sidecar_drills,
            &crate::scalar::scalar("0.15"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
    }

    #[test]
    fn drill_to_copper_clearance_ignores_same_net_plated_drills() {
        let trace = copper_line("GND", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.1);
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![trace],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.3"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };

        let violations = drill_to_copper_clearance(
            &board,
            &[],
            &crate::scalar::scalar("0.15"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn drill_to_copper_clearance_flags_same_net_npth_drills() {
        let trace = copper_line("GND", CopperKind::Segment, [0.0, 0.0], [2.0, 0.0], 0.1);
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![trace],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.3"),
                net: Some("GND".to_string()),
                plated: false,
            }],
            board_outline: None,
            panel_features: None,
        };

        let violations = drill_to_copper_clearance(
            &board,
            &[],
            &crate::scalar::scalar("0.15"),
            &[],
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "drill-to-copper-clearance");
    }

    #[test]
    fn drill_spacing_allows_tangent_drills_at_zero_clearance() {
        let drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.4),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
        ];

        assert!(drill_spacing(&drills, &[], &crate::scalar::scalar("0.0")).is_empty());
    }

    #[test]
    fn drill_spacing_reports_multiple_violating_pairs() {
        let drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.2),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.4),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
        ];

        assert_eq!(
            drill_spacing(&drills, &[], &crate::scalar::scalar("0.20")).len(),
            3
        );
    }

    #[test]
    fn drill_table_consistency_treats_exact_matches_with_tolerance_as_clean() {
        let board_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.30"),
            net: None,
            plated: true,
        }];
        let excellon_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.001),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.32"),
            net: None,
            plated: true,
        }];

        assert!(
            drill_table_consistency(
                &board_drills,
                &excellon_drills,
                &[],
                &crate::scalar::scalar("0.04")
            )
            .is_empty()
        );
    }

    #[test]
    fn drill_table_consistency_reports_kicad_excellon_and_ipc_conflicts() {
        let board_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.20"),
            net: None,
            plated: true,
        }];
        let excellon_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.001),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.35"),
            net: None,
            plated: true,
        }];
        let points = vec![Ipc356Point {
            net: "SIG".to_string(),
            reference: Some("X1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(0.001),
                crate::geometry::exact_real(0.0),
            ],
            diameter: Some(crate::scalar::scalar("0.50")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let violations = drill_table_consistency(
            &board_drills,
            &excellon_drills,
            &points,
            &crate::scalar::scalar("0.04"),
        );

        assert_eq!(violations.len(), 2);
    }

    #[test]
    fn drill_spacing_flags_close_holes_and_allows_compliant_holes() {
        let drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.55),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(2.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
        ];

        let violations = drill_spacing(&drills, &[], &crate::scalar::scalar("0.20"));

        assert_eq!(violations.len(), 1);
        assert!(
            violations[0]
                .message
                .as_deref()
                .unwrap()
                .contains("below clearance")
        );
    }

    #[test]
    fn drill_spacing_includes_excellon_sidecar_hits() {
        let board_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.0),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: Some("GND".to_string()),
            plated: true,
        }];
        let excellon_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.5),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.3"),
            net: None,
            plated: false,
        }];

        let violations = drill_spacing(
            &board_drills,
            &excellon_drills,
            &crate::scalar::scalar("0.20"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].locations.len(), 2);
    }

    #[test]
    fn board_outline_drill_clearance_reports_hole_near_edge() {
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.4),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &drills,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "board-outline-drill-clearance");
    }

    #[test]
    fn board_outline_drill_clearance_allows_inset_hole() {
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(1.0),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        assert!(
            board_outline_drill_clearance(
                "KiCad drills",
                "KiCad Edge.Cuts",
                &outline,
                &drills,
                &[],
                &crate::scalar::scalar("0.25"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn board_outline_drill_clearance_allows_clearance_boundary_touch() {
        // When the drill keepout only touches the outline boundary, there is no
        // positive-area area outside the board profile to report as a violation.
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.45),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &drills,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn board_outline_drill_clearance_flags_just_outside_clearance() {
        // A drill shifted slightly inside the clearance envelope should still
        // generate a concrete geometry violation.
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.449),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &drills,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].locations, vec![[0.449, 5.0]]);
    }

    #[test]
    fn board_outline_drill_clearance_includes_all_drill_sources_in_label() {
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let board_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(9.6),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];
        let extra_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.2),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad + Excellon drills",
            "KiCad Edge.Cuts",
            &outline,
            &board_drills,
            &extra_drills,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 2);
        for violation in &violations {
            assert_eq!(
                violation.layers,
                vec![
                    "KiCad + Excellon drills".to_string(),
                    "KiCad Edge.Cuts".to_string()
                ]
            );
        }
        assert!(
            violations
                .iter()
                .any(|violation| violation.locations == vec![[0.2, 5.0]])
        );
        assert!(
            violations
                .iter()
                .any(|violation| violation.locations == vec![[9.6, 5.0]])
        );
    }

    #[test]
    fn board_outline_drill_clearance_min_area_filters_tiny_penetration() {
        // Tiny floating-point-edge intrusions should be suppressible through
        // min_area, which prevents reporting extremely small geometry artifacts.
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let drills = vec![DrillFeature {
            // Keepout is 0.35 radius; center is only 0.0001 mm outside the
            // minimum 0.25-mm clearance.
            location: [
                crate::geometry::exact_real(0.3501),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.2"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &drills,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-4"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn board_outline_drill_clearance_includes_excellon_sidecar_drills() {
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let extra_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(9.8),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad plus Excellon drills",
            "KiCad Edge.Cuts",
            &outline,
            &[],
            &extra_drills,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].locations, vec![[9.8, 5.0]]);
    }

    #[test]
    fn board_outline_drill_clearance_is_orientation_invariant() {
        let outline = region(vec![reversed_square(0.0, 0.0, 10.0, 10.0)]);
        let drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.4),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: None,
            plated: false,
        }];

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &drills,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
    }

    #[test]
    fn board_outline_drill_clearance_with_empty_drill_sources_is_noop() {
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &[],
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn board_outline_drill_clearance_flags_each_hole_that_intrudes_clearance_band() {
        let outline = region(vec![square(0.0, 0.0, 10.0, 10.0)]);
        let board_drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.4),
                    crate::geometry::exact_real(2.5),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(5.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(9.6),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
        ];

        let violations = board_outline_drill_clearance(
            "KiCad drills",
            "KiCad Edge.Cuts",
            &outline,
            &board_drills,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 2);
    }

    #[test]
    fn castellation_intent_reports_plated_hole_crossing_outline() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.1),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.4"),
            net: Some("EDGE".to_string()),
            plated: true,
        }];

        let violations = castellation_intent(&board, &crate::scalar::scalar("1.0e-9"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "castellation-intent");
    }

    #[test]
    fn castellation_intent_allows_inset_or_non_plated_holes() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: Some("PTH".to_string()),
                plated: true,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.1),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: false,
            },
        ];

        assert!(castellation_intent(&board, &crate::scalar::scalar("1.0e-9")).is_empty());
    }

    #[test]
    fn castellation_hole_readiness_reports_undersized_edge_hole() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.1),
                crate::geometry::exact_real(5.0),
            ],
            diameter: crate::scalar::scalar("0.3"),
            net: Some("EDGE".to_string()),
            plated: true,
        }];

        let violations = castellation_hole_readiness(
            &board,
            &crate::scalar::scalar("0.5"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "castellation-hole-readiness");
    }

    #[test]
    fn castellation_hole_readiness_allows_large_inset_or_non_plated_holes() {
        let mut board = board_with_outline(square(0.0, 0.0, 10.0, 10.0));
        board.drills = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.1),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: crate::scalar::scalar("0.6"),
                net: Some("EDGE".to_string()),
                plated: true,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(5.0),
                ],
                diameter: crate::scalar::scalar("0.3"),
                net: Some("PTH".to_string()),
                plated: true,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.1),
                    crate::geometry::exact_real(4.0),
                ],
                diameter: crate::scalar::scalar("0.3"),
                net: None,
                plated: false,
            },
        ];

        assert!(
            castellation_hole_readiness(
                &board,
                &crate::scalar::scalar("0.5"),
                &crate::scalar::scalar("1.0e-9"),
            )
            .is_empty()
        );
    }

    #[test]
    fn drill_spacing_flags_conservative_slot_keepouts() {
        let rectangular_slots = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("1.8"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(2.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("1.7"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(5.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("1.0"),
                net: None,
                plated: false,
            },
        ];

        let violations = drill_spacing(&rectangular_slots, &[], &crate::scalar::scalar("0.30"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "drill-spacing");
    }

    #[test]
    fn panelization_clearance_flags_copper_near_panel_features_and_stamp_holes() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("SIG", CopperKind::Pad, [0.12, 0.0], 0.08)],
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.2"),
                net: None,
                plated: false,
            }],
            board_outline: None,
            panel_features: Some(polygons_to_profile(
                vec![line_polygon([0.0, -1.0], [0.0, 1.0], 0.05).unwrap()],
                Some(LayerMetadata {
                    name: "KiCad Panel".to_string(),
                }),
            )),
        };
        let extra_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.2),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.2"),
            net: None,
            plated: false,
        }];

        let violations = panelization_clearance(
            &board,
            &extra_drills,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 2);
    }

    #[test]
    fn panelization_clearance_flags_copper_near_tab_route_and_v_score() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![
                copper_disc("TAB", CopperKind::Pad, [0.0, 0.0], 0.08),
                copper_disc("VSCORE", CopperKind::Pad, [2.0, 0.0], 0.08),
            ],
            drills: Vec::new(),
            board_outline: None,
            panel_features: Some(polygons_to_profile(
                vec![
                    line_polygon([0.0, -1.0], [0.0, 1.0], 0.05).unwrap(),
                    line_polygon([2.0, -1.0], [2.0, 1.0], 0.05).unwrap(),
                ],
                Some(LayerMetadata {
                    name: "KiCad panel features".to_string(),
                }),
            )),
        };

        let violations = panelization_clearance(
            &board,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(
            violations[0].check, "panelization-clearance",
            "{:?}",
            violations[0].message
        );
    }

    #[test]
    fn panelization_clearance_checks_sidecar_drills_without_panel_features() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("SIG", CopperKind::Pad, [0.12, 0.0], 0.08)],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let sidecar_drills = vec![DrillFeature {
            location: [
                crate::geometry::exact_real(0.2),
                crate::geometry::exact_real(0.0),
            ],
            diameter: crate::scalar::scalar("0.2"),
            net: None,
            plated: false,
        }];

        let violations = panelization_clearance(
            &board,
            &sidecar_drills,
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(
            violations[0].check, "panelization-clearance",
            "{:?}",
            violations[0].message
        );
    }

    #[test]
    fn panelization_clearance_culls_large_sparse_copper_fields() {
        let mut copper = Vec::new();
        for index in 0..800 {
            copper.push(copper_disc(
                &format!("N{index}"),
                CopperKind::Pad,
                [10.0 + (index % 40) as f64 * 5.0, (index / 40) as f64 * 5.0],
                0.08,
            ));
        }
        copper.push(copper_disc("NEAR", CopperKind::Pad, [0.12, 0.0], 0.08));
        let board = BoardModel {
            source: "test".to_string(),
            copper,
            drills: Vec::new(),
            board_outline: None,
            panel_features: Some(polygons_to_profile(
                vec![line_polygon([0.0, -1.0], [0.0, 1.0], 0.05).unwrap()],
                Some(LayerMetadata {
                    name: "KiCad panel features".to_string(),
                }),
            )),
        };

        let start = std::time::Instant::now();
        let violations = panelization_clearance(
            &board,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed() < std::time::Duration::from_secs(2),
            "panelization clearance should avoid whole-board copper intersections"
        );
    }

    #[test]
    fn panelization_clearance_with_no_panel_blockers_is_noop() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![copper_disc("SIG", CopperKind::Pad, [0.10, 0.0], 0.08)],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let violations = panelization_clearance(
            &board,
            &[],
            &crate::scalar::scalar("0.25"),
            &crate::scalar::scalar("1000.0"),
        );

        assert!(violations.is_empty());
    }

    #[test]
    fn drills_to_region_preserves_metadata() {
        let holes = vec![
            DrillFeature {
                location: [
                    crate::geometry::exact_real(0.0),
                    crate::geometry::exact_real(0.0),
                ],
                diameter: crate::scalar::scalar("0.2"),
                net: None,
                plated: false,
            },
            DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(1.0),
                ],
                diameter: crate::scalar::scalar("0.4"),
                net: None,
                plated: true,
            },
        ];

        let region = drills_to_region(&holes, "test panel drills", "test")
            .expect("test drill geometry should certify");

        assert_eq!(
            region.metadata().as_ref().unwrap().name,
            "test panel drills"
        );
        assert_eq!(region.try_to_multipolygon().unwrap().0.len(), 2);
    }

    #[test]
    fn registration_tolerance_flags_close_features_on_different_layers() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: vec![
                copper_disc_on_layer("TOP", CopperKind::Pad, "F.Cu", [0.0, 0.0], 0.2),
                copper_disc_on_layer("BOT", CopperKind::Pad, "B.Cu", [0.3, 0.0], 0.2),
                copper_disc_on_layer("INNER", CopperKind::Pad, "In1.Cu", [2.0, 0.0], 0.2),
            ],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };

        let violations = registration_tolerance(
            &board,
            &crate::scalar::scalar("0.15"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].layers, vec!["B.Cu", "F.Cu"]);
    }

    #[test]
    fn registration_tolerance_culls_large_sparse_layer_sets() {
        let mut copper = Vec::new();
        for index in 0..400 {
            let x = (index % 20) as f64 * 5.0;
            let y = (index / 20) as f64 * 5.0;
            copper.push(copper_disc_on_layer(
                &format!("F{index}"),
                CopperKind::Pad,
                "F.Cu",
                [x, y],
                0.2,
            ));
            copper.push(copper_disc_on_layer(
                &format!("B{index}"),
                CopperKind::Pad,
                "B.Cu",
                [x + 2.0, y + 2.0],
                0.2,
            ));
        }
        copper.push(copper_disc_on_layer(
            "B_NEAR",
            CopperKind::Pad,
            "B.Cu",
            [0.3, 0.0],
            0.2,
        ));
        let board = board_with_copper(copper);

        let start = std::time::Instant::now();
        let violations = registration_tolerance(
            &board,
            &crate::scalar::scalar("0.15"),
            &crate::scalar::scalar("1.0e-9"),
        );

        assert_eq!(violations.len(), 1);
        assert!(
            start.elapsed() < std::time::Duration::from_secs(2),
            "large sparse registration check should stay in the broad phase"
        );
    }

    #[test]
    fn ipc356_points_annotate_nearby_copper() {
        let mut board = BoardModel {
            source: "test".to_string(),
            copper: vec![CopperFeature {
                layer: "F.Cu".to_string(),
                net: None,
                kind: CopperKind::Pad,
                location: [crate::scalar::scalar("1"), crate::scalar::scalar("2")],
                region: polygons_to_profile(
                    vec![circle_polygon([1.0, 2.0], 0.5, 32)],
                    Some(LayerMetadata {
                        name: "feature".to_string(),
                    }),
                ),
            }],
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("U1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(1.02),
                crate::geometry::exact_real(2.0),
            ],
            diameter: None,
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        apply_ipc356_nets(&mut board, &points, &crate::scalar::scalar("0.1")).unwrap();

        assert_eq!(board.copper[0].net.as_deref(), Some("GND"));
        assert!(ipc356_coverage(&board, &points, &crate::scalar::scalar("0.1")).is_empty());
    }

    #[test]
    fn ipc356_points_recover_missing_drill_net_and_diameter() {
        let mut board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(2.0),
                ],
                diameter: crate::scalar::scalar("0.0"),
                net: None,
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "PWR".to_string(),
            reference: Some("TP1".to_string()),
            pin: None,
            location: [
                crate::geometry::exact_real(1.01),
                crate::geometry::exact_real(2.0),
            ],
            diameter: Some(crate::scalar::scalar("0.45")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        apply_ipc356_nets(&mut board, &points, &crate::scalar::scalar("0.1")).unwrap();

        assert_eq!(board.drills[0].net.as_deref(), Some("PWR"));
        assert_eq!(board.drills[0].diameter, crate::scalar::scalar("0.45"));
    }

    #[test]
    fn ipc356_points_do_not_copy_far_drill_diameter() {
        let mut board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(2.0),
                ],
                diameter: crate::scalar::scalar("0.0"),
                net: None,
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "PWR".to_string(),
            reference: Some("TP1".to_string()),
            pin: None,
            location: [
                crate::geometry::exact_real(10.0),
                crate::geometry::exact_real(20.0),
            ],
            diameter: Some(crate::scalar::scalar("0.45")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        apply_ipc356_nets(&mut board, &points, &crate::scalar::scalar("0.1")).unwrap();

        assert!(board.drills[0].net.is_none());
        assert_eq!(board.drills[0].diameter, 0.0);
    }

    #[test]
    fn ipc356_annotation_culls_sparse_copper_and_drill_fields() {
        let mut board = BoardModel {
            source: "test".to_string(),
            copper: (0..2_000)
                .map(|index| {
                    copper_disc(
                        "NO_NET",
                        CopperKind::Pad,
                        [100.0 + index as f64 * 5.0, 0.0],
                        0.2,
                    )
                })
                .chain([CopperFeature {
                    layer: "F.Cu".to_string(),
                    net: None,
                    kind: CopperKind::Pad,
                    location: [crate::scalar::scalar("1"), crate::scalar::scalar("2")],
                    region: polygons_to_profile(
                        vec![circle_polygon([1.0, 2.0], 0.5, 32)],
                        Some(LayerMetadata {
                            name: "feature".to_string(),
                        }),
                    ),
                }])
                .collect(),
            drills: (0..2_000)
                .map(|index| DrillFeature {
                    location: [
                        crate::geometry::exact_real(100.0 + index as f64 * 5.0),
                        crate::geometry::exact_real(10.0),
                    ],
                    diameter: crate::scalar::scalar("0.2"),
                    net: None,
                    plated: true,
                })
                .chain([DrillFeature {
                    location: [
                        crate::geometry::exact_real(1.0),
                        crate::geometry::exact_real(3.0),
                    ],
                    diameter: crate::scalar::scalar("0.0"),
                    net: None,
                    plated: true,
                }])
                .collect(),
            board_outline: None,
            panel_features: None,
        };
        let points = vec![
            Ipc356Point {
                net: "GND".to_string(),
                reference: Some("U1".to_string()),
                pin: Some("1".to_string()),
                location: [
                    crate::geometry::exact_real(1.02),
                    crate::geometry::exact_real(2.0),
                ],
                diameter: None,
                access_side: None,
                feature_type: None,
                soldermask: None,
            },
            Ipc356Point {
                net: "PWR".to_string(),
                reference: Some("TP1".to_string()),
                pin: None,
                location: [
                    crate::geometry::exact_real(1.01),
                    crate::geometry::exact_real(3.0),
                ],
                diameter: Some(crate::scalar::scalar("0.45")),
                access_side: None,
                feature_type: None,
                soldermask: None,
            },
        ];

        let started = std::time::Instant::now();
        apply_ipc356_nets(&mut board, &points, &crate::scalar::scalar("0.1")).unwrap();

        assert_eq!(
            board.copper.last().and_then(|copper| copper.net.as_deref()),
            Some("GND")
        );
        assert_eq!(
            board.drills.last().and_then(|drill| drill.net.as_deref()),
            Some("PWR")
        );
        assert_eq!(
            board.drills.last().map(|drill| &drill.diameter),
            Some(&crate::scalar::scalar("0.45"))
        );
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "IPC-D-356 annotation should index sparse copper and drill fields"
        );
    }

    #[test]
    fn ipc356_coverage_reports_missing_test_record_copper() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "N/C".to_string(),
            reference: Some("J1".to_string()),
            pin: Some("2".to_string()),
            location: [
                crate::geometry::exact_real(10.0),
                crate::geometry::exact_real(20.0),
            ],
            diameter: None,
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let violations = ipc356_coverage(&board, &points, &crate::scalar::scalar("0.1"));

        assert_eq!(violations.len(), 1);
        assert!(violations[0].message.as_deref().unwrap().contains("J1.2"));
    }

    #[test]
    fn ipc356_coverage_culls_sparse_copper_fields() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: (0..2_000)
                .map(|index| {
                    copper_disc(
                        "SIG",
                        CopperKind::Pad,
                        [100.0 + index as f64 * 5.0, 0.0],
                        0.2,
                    )
                })
                .chain([copper_disc("GND", CopperKind::Pad, [1.0, 2.0], 0.2)])
                .collect(),
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("U1".to_string()),
            pin: Some("1".to_string()),
            location: [
                crate::geometry::exact_real(1.02),
                crate::geometry::exact_real(2.0),
            ],
            diameter: None,
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let started = std::time::Instant::now();
        let violations = ipc356_coverage(&board, &points, &crate::scalar::scalar("0.1"));

        assert!(violations.is_empty());
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "IPC-D-356 coverage should cull sparse copper fields by point index"
        );
    }

    #[test]
    fn ipc356_drill_diameter_reports_conflicting_drill_table_data() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(2.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("V1".to_string()),
            pin: None,
            location: [
                crate::geometry::exact_real(1.01),
                crate::geometry::exact_real(2.0),
            ],
            diameter: Some(crate::scalar::scalar("0.50")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let violations = ipc356_drill_diameter(&board, &points, &crate::scalar::scalar("0.05"));

        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].check, "ipc356-drill-diameter");
    }

    #[test]
    fn ipc356_drill_diameter_allows_matching_drills_within_tolerance() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: vec![DrillFeature {
                location: [
                    crate::geometry::exact_real(1.0),
                    crate::geometry::exact_real(2.0),
                ],
                diameter: crate::scalar::scalar("0.30"),
                net: Some("GND".to_string()),
                plated: true,
            }],
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("V1".to_string()),
            pin: None,
            location: [
                crate::geometry::exact_real(1.01),
                crate::geometry::exact_real(2.0),
            ],
            diameter: Some(crate::scalar::scalar("0.31")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        assert!(ipc356_drill_diameter(&board, &points, &crate::scalar::scalar("0.05")).is_empty());
    }

    #[test]
    fn ipc356_drill_diameter_culls_sparse_drill_fields() {
        let board = BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: (0..2_000)
                .map(|index| DrillFeature {
                    location: [
                        crate::geometry::exact_real(100.0 + index as f64 * 5.0),
                        crate::geometry::exact_real(0.0),
                    ],
                    diameter: crate::scalar::scalar("0.30"),
                    net: Some("GND".to_string()),
                    plated: true,
                })
                .chain([DrillFeature {
                    location: [
                        crate::geometry::exact_real(1.0),
                        crate::geometry::exact_real(2.0),
                    ],
                    diameter: crate::scalar::scalar("0.30"),
                    net: Some("GND".to_string()),
                    plated: true,
                }])
                .collect(),
            board_outline: None,
            panel_features: None,
        };
        let points = vec![Ipc356Point {
            net: "GND".to_string(),
            reference: Some("V1".to_string()),
            pin: None,
            location: [
                crate::geometry::exact_real(1.01),
                crate::geometry::exact_real(2.0),
            ],
            diameter: Some(crate::scalar::scalar("0.50")),
            access_side: None,
            feature_type: None,
            soldermask: None,
        }];

        let started = std::time::Instant::now();
        let violations = ipc356_drill_diameter(&board, &points, &crate::scalar::scalar("0.05"));

        assert_eq!(violations.len(), 1);
        assert!(
            started.elapsed() < std::time::Duration::from_secs(2),
            "IPC-D-356 drill diameter comparison should index sparse drill fields"
        );
    }

    fn feature(net: &str, location: [f64; 2]) -> CopperFeature {
        copper_disc(net, CopperKind::Pad, location, 0.5)
    }

    fn board_with_copper(copper: Vec<CopperFeature>) -> BoardModel {
        BoardModel {
            source: "test".to_string(),
            copper,
            drills: Vec::new(),
            board_outline: None,
            panel_features: None,
        }
    }

    fn board_with_outline(outline: Polygon<f64>) -> BoardModel {
        BoardModel {
            source: "test".to_string(),
            copper: Vec::new(),
            drills: Vec::new(),
            board_outline: Some(region(vec![outline])),
            panel_features: None,
        }
    }

    fn region(polygons: Vec<Polygon<f64>>) -> PcbRegion {
        polygons_to_profile(
            polygons,
            Some(LayerMetadata {
                name: "outline".to_string(),
            }),
        )
    }

    fn square(min_x: f64, min_y: f64, max_x: f64, max_y: f64) -> Polygon<f64> {
        Polygon::new(
            LineString::from(vec![
                Coord { x: min_x, y: min_y },
                Coord { x: max_x, y: min_y },
                Coord { x: max_x, y: max_y },
                Coord { x: min_x, y: max_y },
                Coord { x: min_x, y: min_y },
            ]),
            Vec::new(),
        )
    }

    fn reversed_square(min_x: f64, min_y: f64, max_x: f64, max_y: f64) -> Polygon<f64> {
        Polygon::new(
            LineString::from(vec![
                Coord { x: min_x, y: min_y },
                Coord { x: min_x, y: max_y },
                Coord { x: max_x, y: max_y },
                Coord { x: max_x, y: min_y },
                Coord { x: min_x, y: min_y },
            ]),
            Vec::new(),
        )
    }

    fn copper_disc(net: &str, kind: CopperKind, location: [f64; 2], radius: f64) -> CopperFeature {
        copper_disc_on_layer(net, kind, "F.Cu", location, radius)
    }

    fn copper_disc_on_layer(
        net: &str,
        kind: CopperKind,
        layer: &str,
        location: [f64; 2],
        radius: f64,
    ) -> CopperFeature {
        CopperFeature {
            layer: layer.to_string(),
            net: Some(net.to_string()),
            kind,
            location: [
                crate::geometry::exact_real(location[0]),
                crate::geometry::exact_real(location[1]),
            ],
            region: polygons_to_profile(
                vec![circle_polygon(location, radius, 32)],
                Some(LayerMetadata {
                    name: "feature".to_string(),
                }),
            ),
        }
    }

    fn unnetted_copper_disc_on_layer(
        layer: &str,
        location: [f64; 2],
        radius: f64,
    ) -> CopperFeature {
        CopperFeature {
            layer: layer.to_string(),
            net: None,
            kind: CopperKind::Pad,
            location: [
                crate::geometry::exact_real(location[0]),
                crate::geometry::exact_real(location[1]),
            ],
            region: polygons_to_profile(
                vec![circle_polygon(location, radius, 32)],
                Some(LayerMetadata {
                    name: "fiducial".to_string(),
                }),
            ),
        }
    }

    fn copper_line(
        net: &str,
        kind: CopperKind,
        start: [f64; 2],
        end: [f64; 2],
        width: f64,
    ) -> CopperFeature {
        copper_line_on_layer(net, kind, "F.Cu", start, end, width)
    }

    fn copper_line_on_layer(
        net: &str,
        kind: CopperKind,
        layer: &str,
        start: [f64; 2],
        end: [f64; 2],
        width: f64,
    ) -> CopperFeature {
        CopperFeature {
            layer: layer.to_string(),
            net: Some(net.to_string()),
            kind,
            location: [
                crate::geometry::exact_real((start[0] + end[0]) / 2.0),
                crate::geometry::exact_real((start[1] + end[1]) / 2.0),
            ],
            region: polygons_to_profile(
                vec![line_polygon(start, end, width).unwrap()],
                Some(LayerMetadata {
                    name: "feature".to_string(),
                }),
            ),
        }
    }

    fn copper_rect(
        net: &str,
        kind: CopperKind,
        layer: &str,
        min_x: f64,
        min_y: f64,
        max_x: f64,
        max_y: f64,
    ) -> CopperFeature {
        CopperFeature {
            layer: layer.to_string(),
            net: Some(net.to_string()),
            kind,
            location: [
                crate::geometry::exact_real((min_x + max_x) / 2.0),
                crate::geometry::exact_real((min_y + max_y) / 2.0),
            ],
            region: polygons_to_profile(
                vec![square(min_x, min_y, max_x, max_y)],
                Some(LayerMetadata {
                    name: "feature".to_string(),
                }),
            ),
        }
    }

    fn dense_pad_cluster() -> Vec<CopperFeature> {
        let mut copper = Vec::new();
        for x in 0..4 {
            for y in 0..4 {
                copper.push(copper_disc(
                    &format!("BGA_{x}_{y}"),
                    CopperKind::Pad,
                    [x as f64 * 0.5, y as f64 * 0.5],
                    0.12,
                ));
            }
        }
        copper
    }
}
