//! Native `hypercurve` coverage for closed-loop shape cases from an upstream
//! shape-boolean regression set.
//!
//! The source cases also covered shape transforms, open polyline clipping,
//! spatial-index refresh, and full shape area accounting. This file keeps only
//! the cases that map directly to `hypercurve`'s current region model: closed
//! material contours, hole contours, and boolean membership semantics.

mod support;
use hypercurve::{
    BooleanOp, BulgeVertex2, Contour2, CurveRegion2, Point2, PredicatePolicy, Real,
    RegionPointLocation,
};

type HPoint = Point2;
type HReal = Real;
type HContour = Contour2;
type HRegion = CurveRegion2;
type Rect = (f64, f64, f64, f64);

fn s(value: f64) -> HReal {
    HReal::try_from(value).unwrap()
}

fn p(x: f64, y: f64) -> HPoint {
    HPoint::new(s(x), s(y))
}

fn vertex(x: f64, y: f64) -> BulgeVertex2 {
    BulgeVertex2::new(p(x, y), s(0.0))
}

fn policy() -> PredicatePolicy {
    PredicatePolicy::STRICT
}

fn rectangle((xmin, ymin, xmax, ymax): Rect) -> HContour {
    Contour2::from_bulge_vertices(&[
        vertex(xmin, ymin),
        vertex(xmax, ymin),
        vertex(xmax, ymax),
        vertex(xmin, ymax),
    ])
    .unwrap()
}

fn region(materials: &[Rect], holes: &[Rect]) -> HRegion {
    crate::support::under(&policy(), || {
        CurveRegion2::try_from_native_contours(
            materials.iter().copied().map(rectangle).collect(),
            holes.iter().copied().map(rectangle).collect(),
        )
    })
    .unwrap()
    .into_value()
}

fn inside(region: &HRegion, x: f64, y: f64) -> bool {
    match crate::support::under(&policy(), || region.classify_point(&p(x, y).into()))
        .unwrap()
        .into_value()
    {
        RegionPointLocation::Inside => true,
        RegionPointLocation::Outside => false,
        other => panic!("sample ({x}, {y}) should avoid boundaries, got {other:?}"),
    }
}

fn expected_boolean(in_a: bool, in_b: bool, op: BooleanOp) -> bool {
    match op {
        BooleanOp::Union => in_a || in_b,
        BooleanOp::Intersection => in_a && in_b,
        BooleanOp::Difference => in_a && !in_b,
        BooleanOp::Xor => in_a != in_b,
    }
}

fn assert_boolean_samples(
    first: &HRegion,
    second: &HRegion,
    op: BooleanOp,
    expected_materials: usize,
    expected_holes: usize,
    samples: &[(f64, f64)],
) -> HRegion {
    let result = crate::support::under(&policy(), || first.boolean_region(second, op))
        .unwrap()
        .into_value();

    let Some(native) = crate::support::under(&policy(), || result.native_contours_fast_path())
        .unwrap()
        .value
    else {
        panic!("expected native line topology for PR #59 {op:?}");
    };

    assert_eq!(
        native.material_contours().len(),
        expected_materials,
        "material count for {op:?}"
    );
    assert_eq!(
        native.hole_contours().len(),
        expected_holes,
        "hole count for {op:?}"
    );

    for &(x, y) in samples {
        assert_eq!(
            inside(&result, x, y),
            expected_boolean(inside(first, x, y), inside(second, x, y), op),
            "sample ({x}, {y}) differed for {op:?}"
        );
    }

    result
}
#[test]
fn pr59_multi_island_disjoint_identities() {
    let first = region(&[(0.0, 0.0, 10.0, 10.0), (20.0, 0.0, 30.0, 10.0)], &[]);
    let second = region(&[(100.0, 0.0, 110.0, 10.0)], &[]);
    let samples = [(5.0, 5.0), (25.0, 5.0), (105.0, 5.0), (50.0, 5.0)];

    assert_boolean_samples(&first, &second, BooleanOp::Union, 3, 0, &samples);
    assert_boolean_samples(&first, &second, BooleanOp::Intersection, 0, 0, &samples);
    assert_boolean_samples(&first, &second, BooleanOp::Difference, 2, 0, &samples);
    assert_boolean_samples(&first, &second, BooleanOp::Xor, 3, 0, &samples);
}

#[test]
fn pr59_bridge_overlaps_two_islands() {
    let islands = region(&[(0.0, 0.0, 10.0, 10.0), (20.0, 0.0, 30.0, 10.0)], &[]);
    let bridge = region(&[(5.0, -5.0, 25.0, 15.0)], &[]);
    let samples = [
        (2.5, 5.0),
        (7.5, 5.0),
        (15.0, 0.0),
        (22.5, 5.0),
        (27.5, 5.0),
        (15.0, 12.5),
        (15.0, 20.0),
    ];

    assert_boolean_samples(&islands, &bridge, BooleanOp::Union, 1, 0, &samples);
    assert_boolean_samples(&islands, &bridge, BooleanOp::Intersection, 2, 0, &samples);
    assert_boolean_samples(&islands, &bridge, BooleanOp::Difference, 2, 0, &samples);
}

#[test]
fn pr59_chain_bridge_merges_three_islands() {
    let islands = region(
        &[
            (0.0, 0.0, 6.0, 6.0),
            (10.0, 0.0, 16.0, 6.0),
            (20.0, 0.0, 26.0, 6.0),
        ],
        &[],
    );
    let bridge = region(&[(3.0, -2.0, 23.0, 8.0)], &[]);
    let samples = [
        (1.0, 1.0),
        (5.0, 1.0),
        (8.0, 0.0),
        (13.0, 3.0),
        (18.0, 0.0),
        (24.0, 3.0),
        (12.0, 7.0),
        (30.0, 3.0),
    ];

    assert_boolean_samples(&islands, &bridge, BooleanOp::Union, 1, 0, &samples);
    assert_boolean_samples(&islands, &bridge, BooleanOp::Intersection, 3, 0, &samples);
    assert_boolean_samples(&islands, &bridge, BooleanOp::Difference, 2, 0, &samples);
    assert_boolean_samples(&islands, &bridge, BooleanOp::Xor, 3, 1, &samples);
}

#[test]
fn pr59_ring_difference_adds_second_hole() {
    let ring = region(&[(0.0, 0.0, 10.0, 10.0)], &[(3.0, 3.0, 7.0, 7.0)]);
    let cutter = region(&[(1.0, 1.0, 2.0, 2.0)], &[]);
    let samples = [(1.5, 1.5), (2.5, 2.5), (5.0, 5.0), (8.0, 8.0), (11.0, 11.0)];

    assert_boolean_samples(&ring, &cutter, BooleanOp::Difference, 1, 2, &samples);
    assert_boolean_samples(&ring, &cutter, BooleanOp::Intersection, 1, 0, &samples);
    assert_boolean_samples(&ring, &cutter, BooleanOp::Xor, 1, 2, &samples);
}

#[test]
fn pr59_near_coincident_island_in_hole_is_not_cancelled() {
    let moat = 1e-4;
    let donut = region(&[(-10.0, -10.0, 10.0, 10.0)], &[(-5.0, -5.0, 5.0, 5.0)]);
    let island = region(&[(-5.0 + moat, -5.0 + moat, 5.0 - moat, 5.0 - moat)], &[]);
    let samples = [
        (0.0, 0.0),
        (4.99995, 0.0),
        (5.00005, 0.0),
        (8.0, 0.0),
        (11.0, 0.0),
    ];

    assert_boolean_samples(&donut, &island, BooleanOp::Union, 2, 1, &samples);
    assert_boolean_samples(&donut, &island, BooleanOp::Intersection, 0, 0, &samples);
    assert_boolean_samples(&donut, &island, BooleanOp::Difference, 1, 1, &samples);
    assert_boolean_samples(&donut, &island, BooleanOp::Xor, 2, 1, &samples);
}

#[test]
fn pr59_large_coordinate_hole_overlap_keeps_membership() {
    let base = 1_000_000_000.0;
    let first = region(
        &[(base, base, base + 100.0, base + 100.0)],
        &[(base + 20.0, base + 20.0, base + 80.0, base + 80.0)],
    );
    let second = region(
        &[(base + 50.0, base - 10.0, base + 120.0, base + 60.0)],
        &[],
    );
    let samples = [
        (base + 10.0, base + 10.0),
        (base + 40.0, base + 40.0),
        (base + 55.0, base + 10.0),
        (base + 55.0, base + 40.0),
        (base + 90.0, base + 50.0),
        (base + 110.0, base + 50.0),
    ];

    assert_boolean_samples(&first, &second, BooleanOp::Union, 1, 1, &samples);
    assert_boolean_samples(&first, &second, BooleanOp::Intersection, 1, 0, &samples);
    assert_boolean_samples(&first, &second, BooleanOp::Difference, 1, 0, &samples);
    assert_boolean_samples(&first, &second, BooleanOp::Xor, 3, 0, &samples);
}

#[test]
fn pr59_deep_island_lake_nesting_survives_all_ops() {
    let nested = region(
        &[
            (0.0, 0.0, 100.0, 100.0),
            (20.0, 20.0, 80.0, 80.0),
            (40.0, 40.0, 60.0, 60.0),
        ],
        &[(10.0, 10.0, 90.0, 90.0), (30.0, 30.0, 70.0, 70.0)],
    );
    let rect_in_deep_lake = region(&[(35.0, 35.0, 38.0, 38.0)], &[]);
    let samples = [
        (5.0, 5.0),
        (15.0, 15.0),
        (25.0, 25.0),
        (36.0, 36.0),
        (45.0, 45.0),
        (65.0, 65.0),
        (85.0, 85.0),
        (95.0, 95.0),
    ];

    assert_boolean_samples(
        &nested,
        &rect_in_deep_lake,
        BooleanOp::Union,
        4,
        2,
        &samples,
    );
    assert_boolean_samples(
        &nested,
        &rect_in_deep_lake,
        BooleanOp::Intersection,
        0,
        0,
        &samples,
    );
    assert_boolean_samples(
        &nested,
        &rect_in_deep_lake,
        BooleanOp::Difference,
        3,
        2,
        &samples,
    );
    assert_boolean_samples(&nested, &rect_in_deep_lake, BooleanOp::Xor, 4, 2, &samples);
}
