mod support;
use hypercurve::{
    BezierAreaMomentPrefixSums2, BezierAreaPrefixSums2, BezierLineImageFitRelation,
    BezierParallelApproximationCurve2, BezierParallelVerificationOptions, BezierParameter2,
    CircularArc2, Classification, CubicBezier2, Curve2, CurveError, CurveParameter2,
    CurveParameterRange2, CurvePath2, CurveRegion2, CurveRegionLoopRole, FillRule, LineSeg2,
    OffsetCornerStyle2, Point2, PredicatePolicy, QuadraticBezier2, Rational, RationalBezier2,
    RationalQuadraticBezier2, Real, WorkBudget, WorkUsage, evaluate_with_budget,
};
use num::bigint::{BigInt, BigUint};
use proptest::prelude::*;

fn r(value: i32) -> Real {
    value.into()
}

fn p(x: i32, y: i32) -> Point2 {
    Point2::new(r(x), r(y))
}

fn policy() -> PredicatePolicy {
    PredicatePolicy::STRICT
}

fn q(numerator: i32, denominator: i32) -> Real {
    (r(numerator) / r(denominator)).unwrap()
}

fn real_representation_samples() -> Vec<Real> {
    let rational = |numerator: i64, denominator: u64| {
        Real::new(Rational::fraction(numerator, denominator).unwrap())
    };
    let pi = Real::pi();
    let exp_two = r(2).exp().unwrap();
    let sqrt_two = r(2).sqrt().unwrap();
    let ln_two = r(2).ln().unwrap();
    let ln_three = r(3).ln().unwrap();
    vec![
        r(7),
        rational(17, 31),
        Real::new(Rational::from_bigint(BigInt::from(1_u8) << 256)),
        Real::new(
            Rational::from_bigint_fraction(
                (BigInt::from(1_u8) << 257) + BigInt::from(19_u8),
                (BigUint::from(1_u8) << 193) + BigUint::from(7_u8),
            )
            .unwrap(),
        ),
        Real::try_from(0.1_f32).unwrap(),
        Real::try_from(0.1_f64).unwrap(),
        pi.clone(),
        &pi * &pi,
        pi.clone().inverse().unwrap(),
        exp_two.clone(),
        &pi * &exp_two,
        (&exp_two / &pi).unwrap(),
        &(&pi * &pi) * &exp_two,
        &pi - r(3),
        sqrt_two.clone(),
        &pi * &sqrt_two,
        &(&(&pi * &pi) * &exp_two) * &sqrt_two,
        ln_two.clone(),
        Real::one() + &ln_two,
        &ln_two * &ln_three,
        r(2).log10().unwrap(),
        r(3).log2().unwrap(),
        rational(1, 5).sin_pi(),
        rational(1, 5).tan_pi().unwrap(),
        r(1).sin(),
    ]
}

fn exact_parameter(parameter: &BezierParameter2) -> &Real {
    match parameter {
        BezierParameter2::Exact(parameter) => parameter,
        BezierParameter2::Algebraic(_) => panic!("expected represented exact parameter"),
    }
}

fn assert_real_eq(left: &Real, right: &Real) {
    assert_eq!(left.partial_cmp(right), Some(std::cmp::Ordering::Equal));
}

#[test]
fn quadratic_line_image_fit_offsets_as_exact_line() {
    let bezier = QuadraticBezier2::new(p(0, 0), p(1, 0), p(2, 0));

    let fit = crate::support::under_classified_result(&policy(), || bezier.fit_exact_line_image())
        .unwrap();
    let Classification::Decided(BezierLineImageFitRelation::Fit(fit)) = fit else {
        panic!("collinear quadratic should be a certified line image");
    };
    assert_eq!(fit.line().start(), &p(0, 0));
    assert_eq!(fit.line().end(), &p(2, 0));

    let offset = fit.offset_left_exact(r(1)).unwrap();
    assert_eq!(offset.line().start(), &p(0, 1));
    assert_eq!(offset.line().end(), &p(2, 1));
}

#[test]
fn rational_quadratic_conic_line_image_fit_offsets_as_exact_line() {
    let conic =
        RationalQuadraticBezier2::try_new(p(0, 0), p(1, 0), p(2, 0), r(1), r(2), r(1)).unwrap();

    let fit = crate::support::under_classified_result(&policy(), || conic.fit_exact_line_image())
        .unwrap();
    let Classification::Decided(BezierLineImageFitRelation::Fit(fit)) = fit else {
        panic!("same-sign collinear rational quadratic should be a certified line image");
    };
    assert_eq!(fit.control_point_count(), 3);
    assert_eq!(fit.line().start(), &p(0, 0));
    assert_eq!(fit.line().end(), &p(2, 0));

    let offset = fit.offset_left_exact(r(1)).unwrap();
    assert_eq!(offset.line().start(), &p(0, 1));
    assert_eq!(offset.line().end(), &p(2, 1));
}

#[test]
fn retained_circular_charts_are_not_lines_after_promotion_and_restriction() {
    let center = Point2::new(Real::pi(), Real::e());
    for radius in [q(1, 7), r(2).sqrt().unwrap(), "1e100".parse().unwrap()] {
        for clockwise in [false, true] {
            let arc = CircularArc2::try_from_center(
                Point2::new(center.x() + &radius, center.y().clone()),
                Point2::new(center.x().clone(), center.y() + &radius),
                center.clone(),
                clockwise,
            )
            .unwrap();
            for span in arc.rational_bezier_decomposition().unwrap().spans() {
                let quadratic = span.curve();
                let promoted = RationalBezier2::from(quadratic.clone());
                let variants = [
                    promoted.clone(),
                    promoted.reversed(),
                    promoted.elevated_to_degree(5).unwrap(),
                    promoted.subcurve_between_exact(&q(1, 3), &q(2, 3)).unwrap(),
                ];
                for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
                    let outcome = evaluate_with_budget(policy, WorkBudget::ZERO, || {
                        assert!(matches!(
                            quadratic.fit_exact_line_image().unwrap(),
                            BezierLineImageFitRelation::NotLine
                        ));
                        for curve in &variants {
                            assert!(matches!(
                                curve.fit_exact_line_image().unwrap(),
                                BezierLineImageFitRelation::NotLine
                            ));
                        }
                    });
                    assert!(outcome.result.unwrap().certified().is_some());
                    assert_eq!(outcome.usage, WorkUsage::default());
                }
            }
        }
    }
}

#[test]
fn bezier_area_prefix_sums_answer_exact_ranges() {
    let first = QuadraticBezier2::new(p(0, 0), p(1, 1), p(2, 0));
    let second = QuadraticBezier2::new(p(2, 0), p(3, -1), p(4, 0));
    let curves = [first, second];

    let area_prefixes = BezierAreaPrefixSums2::from_quadratics(curves.iter()).unwrap();
    assert_eq!(area_prefixes.segment_count(), 2);
    assert_eq!(
        area_prefixes.range_contribution(0..1).unwrap(),
        curves[0].signed_area_contribution().unwrap()
    );
    assert_eq!(
        area_prefixes.range_contribution(1..2).unwrap(),
        curves[1].signed_area_contribution().unwrap()
    );
    assert_eq!(
        area_prefixes.range_contribution(0..2).unwrap(),
        area_prefixes.total().clone()
    );
    let reversed_start = 2;
    let reversed_end = 1;
    assert_eq!(
        area_prefixes.range_contribution(reversed_start..reversed_end),
        Err(CurveError::InvalidBezierRange)
    );

    let moment_prefixes = BezierAreaMomentPrefixSums2::from_quadratics(curves.iter()).unwrap();
    assert_eq!(moment_prefixes.segment_count(), 2);
    assert_eq!(
        moment_prefixes.range_contribution(0..2).unwrap(),
        moment_prefixes.total().clone()
    );
    assert_eq!(
        moment_prefixes.range_contribution(0..1).unwrap(),
        curves[0].area_moments_contribution().unwrap()
    );
}

#[test]
fn retained_quadratic_parallel_evaluates_exact_point_and_derivative() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 1), p(2, 0));
    let parallel = source.parallel_left(r(2)).unwrap();

    let point =
        match crate::support::under_classified_result(&policy(), || parallel.point_at(&q(1, 2)))
            .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => panic!("midpoint was uncertain: {reason:?}"),
        };
    assert_eq!(point, Point2::new(r(1), q(5, 2)));

    let derivative = match crate::support::under_classified_result(&policy(), || {
        parallel.derivative_at(&q(1, 2))
    })
    .unwrap()
    {
        Classification::Decided(derivative) => derivative,
        Classification::Uncertain(reason) => {
            panic!("parallel derivative was uncertain: {reason:?}")
        }
    };
    assert_eq!(derivative.dx(), &r(6));
    assert_eq!(derivative.dy(), &r(0));
}

#[test]
fn zero_distance_parallel_is_exact_source_even_at_source_cusp() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 0), p(0, 0));
    let parallel = source.parallel_left(r(0)).unwrap();
    let midpoint = q(1, 2);
    let point =
        match crate::support::under_classified_result(&policy(), || parallel.point_at(&midpoint))
            .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("identity parallel was uncertain: {reason:?}")
            }
        };
    assert_eq!(point, source.point_at(midpoint));
    let analysis = match crate::support::under_classified_result(&policy(), || {
        parallel.singularity_analysis(&CurveParameterRange2::unit())
    })
    .unwrap()
    {
        Classification::Decided(analysis) => analysis,
        Classification::Uncertain(reason) => panic!("identity analysis was uncertain: {reason:?}"),
    };
    assert_eq!(analysis.source_singularities().len(), 1);
    assert_eq!(
        exact_parameter(&analysis.source_singularities()[0]),
        &q(1, 2)
    );
    assert!(analysis.parallel_cusps().is_empty());
}

#[test]
fn finite_parallel_singularity_ranges_preserve_charts_and_normal_sheets() {
    // P(t)=(t,(t-2)^2) has speed squared 1+4(t-2)^2. Its left
    // distance-1/2 parallel has exactly one cusp, at t=2; the negative
    // distance has none. P(4s) gives the identical geometry on a native chart.
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for scale in [1, 4] {
            let cusp = q(2, scale);
            let source = QuadraticBezier2::new(
                p(0, 4),
                Point2::new(q(scale, 2), r(4 - 2 * scale)),
                p(scale, (scale - 2) * (scale - 2)),
            );
            let elevated = CubicBezier2::new(
                source.start().clone(),
                source.start().lerp(source.control(), q(2, 3)),
                source.end().lerp(source.control(), q(2, 3)),
                source.end().clone(),
            );
            let rational = RationalBezier2::try_new(
                source.control_points().into_iter().cloned().collect(),
                vec![r(-2); 3],
            )
            .unwrap();
            for family in [
                hypercurve::BezierParallelSource2::Quadratic(source),
                hypercurve::BezierParallelSource2::Cubic(elevated),
                hypercurve::BezierParallelSource2::Rational(rational),
            ] {
                for distance in [-1, 0, 1] {
                    let parallel =
                        hypercurve::BezierParallel2::from_source(family.clone(), q(distance, 2));
                    for (start, end, contains_cusp) in [
                        (q(1, scale), q(3, scale), true),
                        (q(1, scale), cusp.clone(), true),
                        (cusp.clone(), q(3, scale), true),
                        (q(5, 2 * scale), q(3, scale), false),
                        (r(0), r(1), scale == 4),
                    ] {
                        for reversed in [false, true] {
                            let (start, end) = if reversed {
                                (end.clone(), start.clone())
                            } else {
                                (start.clone(), end.clone())
                            };
                            let Classification::Decided(range) =
                                crate::support::under_classified_result(&policy, || {
                                    CurveParameterRange2::try_new(start.into(), end.into())
                                })
                                .unwrap()
                            else {
                                panic!("represented finite range")
                            };
                            let Classification::Decided(analysis) =
                                crate::support::under_classified_result(&policy, || {
                                    parallel.singularity_analysis(&range)
                                })
                                .unwrap()
                            else {
                                panic!("finite parabola regularity")
                            };
                            assert_eq!(analysis.range(), &range);
                            assert!(analysis.source_is_regular());
                            if distance > 0 && contains_cusp {
                                let [actual] = analysis.parallel_cusps() else {
                                    panic!("one cusp on the positive normal sheet: {analysis:?}")
                                };
                                assert_eq!(
                                    crate::support::under_classified_result(&policy, || actual
                                        .cmp_by_refinement(&BezierParameter2::Exact(cusp.clone())))
                                    .unwrap(),
                                    Classification::Decided(std::cmp::Ordering::Equal),
                                );
                            } else {
                                assert!(analysis.parallel_is_cusp_free(), "{analysis:?}");
                            }
                        }
                    }
                }
            }
        }
    }
}

#[test]
fn finite_parallel_singularity_ranges_separate_source_roots_and_poles() {
    // The stationary source P(t)=((t-2)^2,0) has one undefined normal,
    // while R(t)=(t/(t-2),1/(t-2)) has a genuine pole at the same parameter.
    let stationary = QuadraticBezier2::new(p(4, 0), p(2, 0), p(1, 0));
    let rational = RationalBezier2::try_new(
        vec![Point2::new(r(0), q(-1, 2)), p(-1, -1)],
        vec![r(-2), r(-1)],
    )
    .unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for distance in [r(0), q(1, 10)] {
            let stationary = stationary.parallel_left(distance.clone()).unwrap();
            let rational = rational.parallel_left(distance).unwrap();
            for (start, end, contains_two) in [
                (0, 1, false),
                (3, 4, false),
                (4, 3, false),
                (1, 3, true),
                (1, 2, true),
                (2, 3, true),
            ] {
                let Classification::Decided(range) =
                    crate::support::under_classified_result(&policy, || {
                        CurveParameterRange2::try_new(r(start).into(), r(end).into())
                    })
                    .unwrap()
                else {
                    panic!("represented finite range")
                };
                let Classification::Decided(analysis) =
                    crate::support::under_classified_result(&policy, || {
                        stationary.singularity_analysis(&range)
                    })
                    .unwrap()
                else {
                    panic!("source singularity is retained evidence")
                };
                assert_eq!(analysis.range(), &range);
                assert!(analysis.parallel_is_cusp_free());
                assert_eq!(analysis.source_is_regular(), !contains_two);
                if contains_two {
                    let [root] = analysis.source_singularities() else {
                        panic!("one source root")
                    };
                    assert_eq!(
                        crate::support::under_classified_result(&policy, || root
                            .cmp_by_refinement(&BezierParameter2::Exact(r(2))))
                        .unwrap(),
                        Classification::Decided(std::cmp::Ordering::Equal)
                    );
                    assert!(matches!(
                        crate::support::under_classified_result(&policy, || rational
                            .singularity_analysis(&range))
                        .unwrap(),
                        Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
                    ));
                } else {
                    let Classification::Decided(analysis) =
                        crate::support::under_classified_result(&policy, || {
                            rational.singularity_analysis(&range)
                        })
                        .unwrap()
                    else {
                        panic!("a pole elsewhere cannot reject this range")
                    };
                    assert!(analysis.source_is_regular() && analysis.parallel_is_cusp_free());
                }
            }
        }
    }
}

#[test]
fn parallel_cusp_sign_excludes_shared_algebraic_source_singularities() {
    // P'(t)=(2t^2-1)(1-t^2,2t). The source singularity at sqrt(1/2)
    // also solves every squared cusp polynomial. A positive left distance
    // 1/20 has exactly one true cusp on either side; a negative one has none.
    // Reversal changes the sign of the distance that creates those cusps.
    for gauge in [r(1), -r(2).sqrt().unwrap()] {
        let source = RationalBezier2::try_new(
            vec![
                p(0, 0),
                Point2::new(q(-1, 5), r(0)),
                Point2::new(q(-2, 5), q(-1, 10)),
                Point2::new(q(-1, 2), q(-3, 10)),
                Point2::new(q(-2, 5), q(-2, 5)),
                Point2::new(q(-2, 5), r(0)),
            ],
            vec![gauge; 6],
        )
        .unwrap();
        for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
            for reversed in [false, true] {
                let source = if reversed {
                    source.reversed()
                } else {
                    source.clone()
                };
                for distance in [-1, 0, 1] {
                    let analysis = crate::support::under_classified_result(&policy, || {
                        source
                            .parallel_left(q(distance, 20))
                            .unwrap()
                            .singularity_analysis(&CurveParameterRange2::unit())
                    })
                    .unwrap();
                    let Classification::Decided(analysis) = analysis else {
                        panic!("shared algebraic roots must retain exact cusp classification")
                    };
                    assert_eq!(analysis.source_singularities().len(), 1);
                    let singularity = &analysis.source_singularities()[0];
                    let (lower, upper) = if reversed {
                        (q(1, 4), q(3, 10))
                    } else {
                        (q(7, 10), q(3, 4))
                    };
                    for (bound, order) in [
                        (lower, std::cmp::Ordering::Greater),
                        (upper, std::cmp::Ordering::Less),
                    ] {
                        assert_eq!(
                            crate::support::under_classified_result(&policy, || singularity
                                .cmp_by_refinement(&BezierParameter2::Exact(bound)))
                            .unwrap(),
                            Classification::Decided(order)
                        );
                    }
                    if (distance > 0 && !reversed) || (distance < 0 && reversed) {
                        let [left, right] = analysis.parallel_cusps() else {
                            panic!(
                                "the two regular cusp branches must survive the shared source root"
                            )
                        };
                        assert_eq!(
                            crate::support::under_classified_result(&policy, || left
                                .cmp_by_refinement(singularity))
                            .unwrap(),
                            Classification::Decided(std::cmp::Ordering::Less)
                        );
                        assert_eq!(
                            crate::support::under_classified_result(&policy, || right
                                .cmp_by_refinement(singularity))
                            .unwrap(),
                            Classification::Decided(std::cmp::Ordering::Greater)
                        );
                    } else {
                        assert!(analysis.parallel_cusps().is_empty());
                    }
                }
            }
        }
    }
}

#[test]
fn quadratic_parallel_isolates_distance_dependent_interior_cusp() {
    // P(t) = (t, t^2). At t=1/2, |P'|^3 = 2*sqrt(2) and
    // P'' x P' = -2, so a left distance sqrt(2) creates a parallel cusp.
    let source = QuadraticBezier2::new(p(0, 0), Point2::new(q(1, 2), r(0)), p(1, 1));
    let parallel = source.parallel_left(r(2).sqrt().unwrap()).unwrap();
    let analysis = match crate::support::under_classified_result(&policy(), || {
        parallel.singularity_analysis(&CurveParameterRange2::unit())
    })
    .unwrap()
    {
        Classification::Decided(analysis) => analysis,
        Classification::Uncertain(reason) => panic!("cusp isolation was uncertain: {reason:?}"),
    };
    assert!(analysis.source_is_regular());
    assert_eq!(analysis.parallel_cusps().len(), 1);
    assert_eq!(exact_parameter(&analysis.parallel_cusps()[0]), &q(1, 2));

    let derivative = match crate::support::under_classified_result(&policy(), || {
        parallel.derivative_at(&q(1, 2))
    })
    .unwrap()
    {
        Classification::Decided(derivative) => derivative,
        Classification::Uncertain(reason) => panic!("cusp derivative was uncertain: {reason:?}"),
    };
    assert_eq!(derivative.zero_status(), hyperreal::ZeroKnowledge::Zero);
}

#[test]
fn quadratic_parallel_cusp_matches_its_radical_parameter() {
    let source = QuadraticBezier2::new(p(0, 0), Point2::new(q(1, 2), r(0)), p(1, 1));
    let parallel = source.parallel_left(r(1)).unwrap();
    let target_speed_squared = r(4).root_n(3).unwrap();
    let constant = r(1) - target_speed_squared;
    let quadratic = r(4);
    let denominator = r(2) * &quadratic;
    let discriminant = r(0) - r(4) * &quadratic * constant;
    let expected = (discriminant / (&denominator * &denominator))
        .unwrap()
        .sqrt()
        .unwrap();
    let mut strict_cusp = None;
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let analysis = match crate::support::under_classified_result(&policy, || {
            parallel.singularity_analysis(&CurveParameterRange2::unit())
        })
        .unwrap()
        {
            Classification::Decided(analysis) => analysis,
            Classification::Uncertain(reason) => {
                panic!("radical cusp isolation was uncertain: {reason:?}")
            }
        };
        assert!(analysis.source_is_regular());
        let [cusp] = analysis.parallel_cusps() else {
            panic!("the polynomial-quadratic parallel has one cusp");
        };
        // The isolated cusp stays a selected root of the cusp polynomial and
        // equals the independently derived radical exactly.
        assert_eq!(
            crate::support::under_outcome_classified(&policy, || CurveParameter2::from(
                cusp.clone()
            )
            .compare(&expected.clone().into()))
            .unwrap()
            .value,
            Classification::Decided(std::cmp::Ordering::Equal)
        );
        let cusp = &expected;
        let derivative =
            match crate::support::under_classified_result(&policy, || parallel.derivative_at(cusp))
                .unwrap()
            {
                Classification::Decided(derivative) => derivative,
                Classification::Uncertain(reason) => {
                    panic!("the represented cusp derivative was uncertain: {reason:?}")
                }
            };
        assert_eq!(derivative.zero_status(), hyperreal::ZeroKnowledge::Zero);
        if let Some(strict_cusp) = &strict_cusp {
            assert_eq!(cusp, strict_cusp);
        } else {
            strict_cusp = Some(cusp.clone());
        }
    }
}

#[test]
fn cubic_parallel_isolates_a_symmetric_pair_of_offset_cusps() {
    let source = CubicBezier2::new(p(0, 0), p(1, -4), p(2, -4), p(3, 0));
    let analysis = match crate::support::under_classified_result(&policy(), || {
        source
            .parallel_left(q(1, 2))
            .unwrap()
            .singularity_analysis(&CurveParameterRange2::unit())
    })
    .unwrap()
    {
        Classification::Decided(analysis) => analysis,
        Classification::Uncertain(reason) => panic!("cusp-pair isolation failed: {reason:?}"),
    };
    assert!(analysis.source_is_regular());
    assert_eq!(analysis.parallel_cusps().len(), 2);
    assert!(
        crate::support::under_classified_result(&policy(), || analysis.parallel_cusps()[0]
            .cmp_by_interval(&analysis.parallel_cusps()[1]))
        .unwrap()
        .is_decided()
    );
}

#[test]
fn retained_parallel_accepts_every_hyperreal_representation_as_exact_translation() {
    let parameter = q(1, 3);
    for translation in real_representation_samples() {
        let source = QuadraticBezier2::new(
            Point2::new(translation.clone(), r(0)),
            Point2::new(&translation + r(1), r(1)),
            Point2::new(&translation + r(2), r(0)),
        );
        let parallel = source.parallel_left(q(1, 10)).unwrap();
        let point = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("representation-specific parallel evaluation failed: {reason:?}")
            }
        };
        assert!(point.x().to_f64_lossy().is_some());
        assert!(point.y().to_f64_lossy().is_some());
    }
}

#[test]
fn exact_parallel_commutes_with_orientation_preserving_rigid_transform() {
    let source = QuadraticBezier2::new(p(0, 0), p(2, 3), p(5, 1));
    let transformed = QuadraticBezier2::new(
        Point2::new(r(5) - source.start().y(), source.start().x() - r(3)),
        Point2::new(r(5) - source.control().y(), source.control().x() - r(3)),
        Point2::new(r(5) - source.end().y(), source.end().x() - r(3)),
    );
    let parallel = source.parallel_left(q(2, 5)).unwrap();
    let transformed_parallel = transformed.parallel_left(q(2, 5)).unwrap();
    for parameter in [r(0), q(1, 3), q(2, 3), r(1)] {
        let point = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => panic!("source parallel failed: {reason:?}"),
        };
        let expected = Point2::new(r(5) - point.y(), point.x() - r(3));
        let actual = match crate::support::under_classified_result(&policy(), || {
            transformed_parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("transformed parallel failed: {reason:?}")
            }
        };
        let error = actual.distance_squared(&expected).to_f64_lossy().unwrap();
        assert!(
            error.abs() <= 1.0e-20,
            "rigid-transform replay error was {error}"
        );
    }
}

#[test]
fn cubic_parallel_analysis_keeps_regular_inflection_cusp_free() {
    let source = CubicBezier2::new(p(0, 0), p(1, 2), p(2, -2), p(3, 0));
    let parallel = source.parallel_left(q(1, 100)).unwrap();
    let analysis = match crate::support::under_classified_result(&policy(), || {
        parallel.singularity_analysis(&CurveParameterRange2::unit())
    })
    .unwrap()
    {
        Classification::Decided(analysis) => analysis,
        Classification::Uncertain(reason) => {
            panic!("regular inflected cubic analysis was uncertain: {reason:?}")
        }
    };
    assert!(analysis.source_is_regular());
    assert!(analysis.parallel_is_cusp_free());
    assert!(analysis.parallel_cusp_polynomial_degree().unwrap() <= 12);
}

#[test]
fn cubic_pythagorean_hodograph_parallel_materializes_exact_rational_bezier() {
    // P(t) = (t - t^3/3, t^2), with
    // P'(t) = (1 - t^2, 2t) and |P'(t)|^2 = (1 + t^2)^2.
    let source = CubicBezier2::new(
        p(0, 0),
        Point2::new(q(1, 3), r(0)),
        Point2::new(q(2, 3), q(1, 3)),
        Point2::new(q(2, 3), r(1)),
    );
    let parallel = source.parallel_left(r(1)).unwrap();
    let exact = match crate::support::under_classified_result(&policy(), || {
        parallel.exact_pythagorean_hodograph_offset()
    })
    .unwrap()
    {
        Classification::Decided(Some(exact)) => exact,
        Classification::Decided(None) => panic!("PH cubic was not recognized"),
        Classification::Uncertain(reason) => panic!("PH recognition was uncertain: {reason:?}"),
    };
    assert_eq!(exact.source_degree(), 3);
    assert_eq!(exact.rational_degree(), 5);
    assert_eq!(exact.speed_polynomial(), &[r(1), r(0), r(1)]);
    assert!(
        exact
            .curve()
            .weights()
            .iter()
            .all(|weight| weight.partial_cmp(&r(0)).is_some_and(|order| order.is_gt()))
    );

    for parameter in [r(0), q(1, 2), r(1)] {
        let analytic = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("analytic PH evaluation was uncertain: {reason:?}")
            }
        };
        let rational =
            crate::support::under_value(&policy(), || exact.curve().point_at(&parameter)).unwrap();
        assert_eq!(rational, analytic);
    }
}

#[test]
fn approximate_ph_materialization_never_selects_a_structural_component() {
    let undecidable_zero = support::terminally_unresolved_zero();
    let source =
        QuadraticBezier2::new(p(0, 0), Point2::new(Real::one(), undecidable_zero), p(2, 0));
    let parallel = source.parallel_left(Real::one()).unwrap();

    assert!(matches!(
        crate::support::under_classified_result(&PredicatePolicy::STRICT, || parallel
            .exact_pythagorean_hodograph_offset()),
        Ok(Classification::Uncertain(_))
    ));
    assert!(matches!(
        crate::support::under_classified_result(&PredicatePolicy::APPROXIMATE_512, || parallel
            .exact_pythagorean_hodograph_offset()),
        Ok(Classification::Uncertain(_))
    ));
    assert!(matches!(
        crate::support::under_classified_result(&PredicatePolicy::STRICT, || parallel
            .exact_pythagorean_hodograph_offset()),
        Ok(Classification::Uncertain(_))
    ));
}

#[test]
fn nonuniform_rational_line_parallel_materializes_exactly() {
    let source =
        RationalBezier2::try_new(vec![p(0, 0), p(1, 0), p(2, 0)], vec![r(1), r(2), r(3)]).unwrap();
    let parallel = source.parallel_left(r(2)).unwrap();
    let exact = match crate::support::under_classified_result(&policy(), || {
        parallel.exact_pythagorean_hodograph_offset()
    })
    .unwrap()
    {
        Classification::Decided(Some(exact)) => exact,
        Classification::Decided(None) => panic!("rational line was not recognized as PH"),
        Classification::Uncertain(reason) => {
            panic!("rational line PH recognition was uncertain: {reason:?}")
        }
    };

    for parameter in [r(0), q(1, 2), r(1)] {
        let analytic = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("rational analytic parallel was uncertain: {reason:?}")
            }
        };
        let materialized =
            crate::support::under_value(&policy(), || exact.curve().point_at(&parameter)).unwrap();
        assert_eq!(analytic, materialized);
        assert_eq!(analytic.y(), &r(2));
    }
    assert_eq!(
        crate::support::under_classified_result(&policy(), || parallel.point_at(&q(1, 2))).unwrap(),
        Classification::Decided(Point2::new(q(5, 4), r(2)))
    );
}

#[test]
fn rational_quarter_circle_parallel_materializes_concentric_exact_curve() {
    // Homogeneous power form `(1-t^2, 2t, 1+t^2)` traces the unit-circle
    // quarter. Its Bernstein weights `[1, 1, 2]` deliberately exercise a
    // nonuniform rational parameterization without an approximate scalar.
    let source =
        RationalQuadraticBezier2::try_new(p(1, 0), p(1, 1), p(0, 1), r(1), r(1), r(2)).unwrap();
    let parallel = source.parallel_left(q(1, 2)).unwrap();
    let exact = match crate::support::under_classified_result(&policy(), || {
        parallel.exact_pythagorean_hodograph_offset()
    })
    .unwrap()
    {
        Classification::Decided(Some(exact)) => exact,
        Classification::Decided(None) => panic!("rational circle was not recognized as PH"),
        Classification::Uncertain(reason) => {
            panic!("rational circle PH recognition was uncertain: {reason:?}")
        }
    };

    for parameter in [r(0), q(1, 2), r(1)] {
        let analytic = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("rational circle parallel was uncertain: {reason:?}")
            }
        };
        assert_eq!(
            crate::support::under_value(&policy(), || exact.curve().point_at(&parameter)).unwrap(),
            analytic
        );
        assert_eq!(
            analytic.x() * analytic.x() + analytic.y() * analytic.y(),
            q(1, 4)
        );
    }
}

#[test]
fn noncircular_rational_ph_parallel_preserves_parameter_and_derivative_exactly() {
    // This is the noncircular polynomial PH curve
    // `P(t) = (t - t^3/3, t^2)` represented with the nonconstant projective
    // factor `W(t) = 1 + t`. Its homogeneous hodograph has speed
    // `(1 + t)^2 (1 + t^2)`.
    let source = RationalBezier2::try_new(
        vec![
            p(0, 0),
            Point2::new(q(1, 5), r(0)),
            Point2::new(q(4, 9), q(1, 9)),
            Point2::new(q(2, 3), q(3, 7)),
            Point2::new(q(2, 3), r(1)),
        ],
        vec![r(1), q(5, 4), q(3, 2), q(7, 4), r(2)],
    )
    .unwrap();
    let parallel = source.parallel_left(q(1, 10)).unwrap();
    let analysis = match crate::support::under_classified_result(&policy(), || {
        parallel.singularity_analysis(&CurveParameterRange2::unit())
    })
    .unwrap()
    {
        Classification::Decided(analysis) => analysis,
        Classification::Uncertain(reason) => {
            panic!("rational PH singularity analysis was uncertain: {reason:?}")
        }
    };
    assert!(analysis.source_is_regular());
    assert!(analysis.parallel_is_cusp_free());

    let exact = match crate::support::under_classified_result(&policy(), || {
        parallel.exact_pythagorean_hodograph_offset()
    })
    .unwrap()
    {
        Classification::Decided(Some(exact)) => exact,
        Classification::Decided(None) => panic!("noncircular rational PH curve was rejected"),
        Classification::Uncertain(reason) => {
            panic!("noncircular rational PH proof was uncertain: {reason:?}")
        }
    };
    let midpoint = q(1, 2);
    let analytic_point =
        match crate::support::under_classified_result(&policy(), || parallel.point_at(&midpoint))
            .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("rational PH point was uncertain: {reason:?}")
            }
        };
    assert_eq!(analytic_point, Point2::new(q(227, 600), q(31, 100)));
    assert_eq!(
        crate::support::under_value(&policy(), || exact.curve().point_at(&midpoint)).unwrap(),
        analytic_point
    );

    let analytic_derivative = match crate::support::under_classified_result(&policy(), || {
        parallel.derivative_at(&midpoint)
    })
    .unwrap()
    {
        Classification::Decided(derivative) => derivative,
        Classification::Uncertain(reason) => {
            panic!("rational PH derivative was uncertain: {reason:?}")
        }
    };
    assert_eq!(analytic_derivative.dx(), &q(327, 500));
    assert_eq!(analytic_derivative.dy(), &q(109, 125));
    assert_eq!(
        crate::support::under_value(&policy(), || exact.curve().derivative_at(&midpoint)).unwrap(),
        analytic_derivative
    );
}

#[test]
fn exact_ph_materialization_retains_natural_degree_with_mixed_weights() {
    // Let `a=t-1/2` and `b=1/16`. The cubic below has hodograph
    // `(a^2-b^2, 2ab)` and speed `(t-1/2)^2 + 1/256`. The speed is strictly
    // positive, but its Bernstein coefficients do not all become positive
    // until degree 65. Homogeneous controls retain the natural degree five.
    let source = CubicBezier2::new(
        p(0, 0),
        Point2::new(q(21, 256), q(-1, 48)),
        Point2::new(q(-1, 384), q(-1, 48)),
        Point2::new(q(61, 768), r(0)),
    );
    let parallel = source.parallel_left(q(1, 10)).unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let exact = match crate::support::under_classified_result(&policy, || {
            parallel.exact_pythagorean_hodograph_offset()
        })
        .unwrap()
        {
            Classification::Decided(Some(exact)) => exact,
            Classification::Decided(None) => panic!("strictly regular PH curve was rejected"),
            Classification::Uncertain(reason) => {
                panic!("PH degree elevation was uncertain: {reason:?}")
            }
        };
        assert_eq!(exact.rational_degree(), 5);
        for parameter in [r(0), q(1, 2), r(1)] {
            let analytic = match crate::support::under_classified_result(&policy, || {
                parallel.point_at(&parameter)
            })
            .unwrap()
            {
                Classification::Decided(point) => point,
                Classification::Uncertain(reason) => {
                    panic!("analytic PH parallel was uncertain: {reason:?}")
                }
            };
            assert_eq!(
                crate::support::under_value(&policy, || exact.curve().point_at(&parameter))
                    .unwrap(),
                analytic
            );
        }
    }
}

#[test]
fn symmetric_algebraic_quarter_circle_parallel_is_exact_under_both_policies() {
    let half_sqrt_two = (r(2).sqrt().unwrap() / r(2)).unwrap();
    let source =
        RationalQuadraticBezier2::try_unit_end_weights(p(1, 0), p(1, 1), p(0, 1), half_sqrt_two)
            .unwrap();
    let parallel = source.parallel_left(q(1, 2)).unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let exact = match crate::support::under_classified_result(&policy, || {
            parallel.exact_pythagorean_hodograph_offset()
        })
        .unwrap()
        {
            Classification::Decided(Some(exact)) => exact,
            Classification::Decided(None) => panic!("algebraic rational circle was not PH"),
            Classification::Uncertain(reason) => {
                panic!("algebraic rational circle PH proof was uncertain: {reason:?}")
            }
        };

        assert_eq!(exact.rational_degree(), 2);
        assert_eq!(
            exact.curve().affine_control_points().unwrap(),
            &[
                Point2::new(q(1, 2), r(0)),
                Point2::new(q(1, 2), q(1, 2)),
                Point2::new(r(0), q(1, 2))
            ]
        );
        assert_eq!(
            exact.curve().weights(),
            &[r(1), (r(2).sqrt().unwrap() / r(2)).unwrap(), r(1)]
        );
        assert_eq!(
            crate::support::under_value(&policy, || exact.curve().point_at(&r(0))).unwrap(),
            Point2::new(q(1, 2), r(0))
        );
        assert_eq!(
            crate::support::under_value(&policy, || exact.curve().point_at(&r(1))).unwrap(),
            Point2::new(r(0), q(1, 2))
        );
    }
}

#[test]
fn circular_parallel_materializes_radius_collapse_and_reversal_exactly() {
    let source =
        RationalQuadraticBezier2::try_new(p(1, 0), p(1, 1), p(0, 1), r(1), r(1), r(2)).unwrap();
    for (distance, expected) in [
        (r(1), vec![p(0, 0), p(0, 0), p(0, 0)]),
        (r(2), vec![p(-1, 0), p(-1, -1), p(0, -1)]),
    ] {
        let parallel = source.parallel_left(distance).unwrap();
        let exact = match crate::support::under_classified_result(&PredicatePolicy::STRICT, || {
            parallel.exact_pythagorean_hodograph_offset()
        })
        .unwrap()
        {
            Classification::Decided(Some(exact)) => exact,
            Classification::Decided(None) => panic!("circular parallel was not exact"),
            Classification::Uncertain(reason) => {
                panic!("circular parallel materialization was uncertain: {reason:?}")
            }
        };
        assert_eq!(exact.rational_degree(), 2);
        assert_eq!(exact.curve().affine_control_points().unwrap(), expected);
        assert_eq!(exact.curve().weights(), &[r(1), r(1), r(2)]);
    }
}

#[test]
fn rational_parallel_rejects_projective_denominator_boundary() {
    let source =
        RationalBezier2::try_new(vec![p(0, 0), p(1, 1), p(2, 0)], vec![r(1), r(-1), r(1)]).unwrap();
    let analysis = crate::support::under_classified_result(&policy(), || {
        source
            .parallel_left(r(1))
            .unwrap()
            .singularity_analysis(&CurveParameterRange2::unit())
    })
    .unwrap();
    assert_eq!(
        analysis,
        Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
    );
}

#[test]
fn exact_parallel_reversal_preserves_image_and_reverses_parameter_derivative() {
    let source = CubicBezier2::new(p(0, 0), p(1, 2), p(3, 2), p(4, 0));
    let parallel = source.parallel_left(q(1, 3)).unwrap();
    let reversed = parallel.reversed();

    assert_eq!(reversed.distance(), &q(-1, 3));
    assert_eq!(reversed.reversed(), parallel);
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for parameter in [r(0), q(1, 4), r(1)] {
            let complement = r(1) - &parameter;
            let expected_point =
                crate::support::under_classified_result(&policy, || parallel.point_at(&complement))
                    .unwrap();
            assert_eq!(
                crate::support::under_classified_result(&policy, || reversed.point_at(&parameter))
                    .unwrap(),
                expected_point
            );

            let Classification::Decided(expected_derivative) =
                crate::support::under_classified_result(&policy, || {
                    parallel.derivative_at(&complement)
                })
                .unwrap()
            else {
                panic!("source parallel derivative was uncertain");
            };
            let Classification::Decided(actual_derivative) =
                crate::support::under_classified_result(&policy, || {
                    reversed.derivative_at(&parameter)
                })
                .unwrap()
            else {
                panic!("reversed parallel derivative was uncertain");
            };
            assert_real_eq(actual_derivative.dx(), &(-expected_derivative.dx().clone()));
            assert_real_eq(actual_derivative.dy(), &(-expected_derivative.dy().clone()));
        }
    }
}

#[test]
fn exact_parallel_split_preserves_parameter_map_and_chain_derivative() {
    let source = CubicBezier2::new(p(0, 0), p(1, 2), p(3, 2), p(4, 0));
    let parallel = source.parallel_left(q(1, 3)).unwrap();
    let split_parameter = q(1, 3);

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let Classification::Decided((left, right)) =
            crate::support::under_classified_result(&policy, || {
                parallel.split_at_exact(&split_parameter)
            })
            .unwrap()
        else {
            panic!("interior parallel split was uncertain");
        };
        let local = q(1, 2);
        let left_global = q(1, 6);
        let right_global = q(2, 3);
        assert_eq!(
            crate::support::under_classified_result(&policy, || left.point_at(&local)).unwrap(),
            crate::support::under_classified_result(&policy, || parallel.point_at(&left_global))
                .unwrap()
        );
        assert_eq!(
            crate::support::under_classified_result(&policy, || right.point_at(&local)).unwrap(),
            crate::support::under_classified_result(&policy, || parallel.point_at(&right_global))
                .unwrap()
        );

        let Classification::Decided(left_derivative) =
            crate::support::under_classified_result(&policy, || left.derivative_at(&local))
                .unwrap()
        else {
            panic!("left split derivative was uncertain");
        };
        let Classification::Decided(source_left_derivative) =
            crate::support::under_classified_result(&policy, || {
                parallel.derivative_at(&left_global)
            })
            .unwrap()
        else {
            panic!("source left derivative was uncertain");
        };
        let expected_left_derivative = source_left_derivative.scaled(&q(1, 3));
        assert_real_eq(left_derivative.dx(), expected_left_derivative.dx());
        assert_real_eq(left_derivative.dy(), expected_left_derivative.dy());

        let Classification::Decided(right_derivative) =
            crate::support::under_classified_result(&policy, || right.derivative_at(&local))
                .unwrap()
        else {
            panic!("right split derivative was uncertain");
        };
        let Classification::Decided(source_right_derivative) =
            crate::support::under_classified_result(&policy, || {
                parallel.derivative_at(&right_global)
            })
            .unwrap()
        else {
            panic!("source right derivative was uncertain");
        };
        let expected_right_derivative = source_right_derivative.scaled(&q(2, 3));
        assert_real_eq(right_derivative.dx(), expected_right_derivative.dx());
        assert_real_eq(right_derivative.dy(), expected_right_derivative.dy());

        assert_eq!(
            crate::support::under_classified_result(&policy, || parallel.split_at_exact(&r(0)))
                .unwrap(),
            Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
        );
        assert_eq!(
            crate::support::under_classified_result(&policy, || parallel.split_at_exact(&r(1)))
                .unwrap(),
            Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
        );
    }
}

#[test]
fn rational_parallel_subcurve_preserves_parameter_map_and_chain_derivative() {
    let source =
        RationalBezier2::try_new(vec![p(0, 0), p(1, 0), p(2, 0)], vec![r(1), r(2), r(3)]).unwrap();
    let parallel = source.parallel_left(r(2)).unwrap();
    let start = q(1, 4);
    let end = q(3, 4);

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let Classification::Decided(subcurve) =
            crate::support::under_classified_result(&policy, || {
                parallel.subcurve_between_exact(&start, &end)
            })
            .unwrap()
        else {
            panic!("rational parallel subcurve was uncertain");
        };
        for (local, global) in [
            (r(0), start.clone()),
            (q(1, 2), q(1, 2)),
            (r(1), end.clone()),
        ] {
            assert_eq!(
                crate::support::under_classified_result(&policy, || subcurve.point_at(&local))
                    .unwrap(),
                crate::support::under_classified_result(&policy, || parallel.point_at(&global))
                    .unwrap()
            );
        }

        let Classification::Decided(subcurve_derivative) =
            crate::support::under_classified_result(&policy, || subcurve.derivative_at(&q(1, 2)))
                .unwrap()
        else {
            panic!("rational parallel subcurve derivative was uncertain");
        };
        let Classification::Decided(source_derivative) =
            crate::support::under_classified_result(&policy, || parallel.derivative_at(&q(1, 2)))
                .unwrap()
        else {
            panic!("rational source parallel derivative was uncertain");
        };
        let expected_derivative = source_derivative.scaled(&q(1, 2));
        assert_real_eq(subcurve_derivative.dx(), expected_derivative.dx());
        assert_real_eq(subcurve_derivative.dy(), expected_derivative.dy());

        assert_eq!(
            crate::support::under_classified_result(&policy, || parallel
                .subcurve_between_exact(&start, &start))
            .unwrap(),
            Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
        );
    }
}

#[test]
fn exact_parallel_conservative_bounds_cover_both_offset_sides() {
    let source =
        RationalBezier2::try_new(vec![p(0, 0), p(1, 0), p(2, 0)], vec![r(1), r(2), r(3)]).unwrap();
    for distance in [r(-2), r(2)] {
        let parallel = source.parallel_left(distance).unwrap();
        for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
            let Classification::Decided(bounds) = parallel.conservative_bounds().unwrap() else {
                panic!("parallel bounds were uncertain");
            };
            assert_eq!(bounds.min(), &p(-2, -2));
            assert_eq!(bounds.max(), &p(4, 2));
            for parameter in [r(0), q(1, 4), q(1, 2), q(3, 4), r(1)] {
                let Classification::Decided(point) =
                    crate::support::under_classified_result(&policy, || {
                        parallel.point_at(&parameter)
                    })
                    .unwrap()
                else {
                    panic!("parallel point was uncertain");
                };
                assert_eq!(
                    crate::support::under_classified(&policy, || bounds.contains_point(&point)),
                    Classification::Decided(true)
                );
            }
        }
    }
}

#[test]
fn generic_cubic_does_not_claim_exact_ph_parallel() {
    let source = CubicBezier2::new(p(0, 0), p(1, 2), p(2, -2), p(3, 0));
    let parallel = source.parallel_left(r(1)).unwrap();
    assert!(matches!(
        crate::support::under_classified_result(&policy(), || parallel
            .exact_pythagorean_hodograph_offset())
        .unwrap(),
        Classification::Decided(None)
    ));
}

#[test]
fn exact_parallel_promotes_ph_cubic_without_fitting() {
    let source = CubicBezier2::new(
        p(0, 0),
        Point2::new(q(1, 3), r(0)),
        Point2::new(q(2, 3), q(1, 3)),
        Point2::new(q(2, 3), r(1)),
    );
    let result = crate::support::under_classified_result(&policy(), || {
        source
            .parallel_left(q(1, 5))
            .unwrap()
            .exact_pythagorean_hodograph_offset()
    })
    .unwrap();
    let Classification::Decided(Some(offset)) = result else {
        panic!("the retained exact parallel did not select the PH lane");
    };
    assert_eq!(offset.distance(), &q(1, 5));
}

#[test]
fn blend2d_quadratic_candidate_matches_exact_parallel_endpoints() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 2), p(3, 1));
    let candidate = match crate::support::under_classified_result(&policy(), || {
        source.blend2d_offset_left_candidate(r(2))
    })
    .unwrap()
    {
        Classification::Decided(candidate) => candidate,
        Classification::Uncertain(reason) => panic!("candidate was uncertain: {reason:?}"),
    };
    let parallel = source.parallel_left(r(2)).unwrap();
    for (parameter, candidate_point) in [
        (r(0), candidate.curve().start()),
        (r(1), candidate.curve().end()),
    ] {
        let exact = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                panic!("endpoint parallel evaluation was uncertain: {reason:?}")
            }
        };
        assert_eq!(candidate_point, &exact);
    }
    assert_ne!(candidate.radial_error_bound(), &r(0));
}

#[test]
fn blend2d_straight_quadratic_candidate_has_zero_radial_error() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 0), p(2, 0));
    let candidate = match crate::support::under_classified_result(&policy(), || {
        source.blend2d_offset_left_candidate(r(3))
    })
    .unwrap()
    {
        Classification::Decided(candidate) => candidate,
        Classification::Uncertain(reason) => panic!("line candidate was uncertain: {reason:?}"),
    };
    assert_eq!(candidate.radial_error_bound(), &r(0));
    assert_eq!(candidate.curve().start(), &p(0, 3));
    assert_eq!(candidate.curve().control(), &p(1, 3));
    assert_eq!(candidate.curve().end(), &p(2, 3));
}

#[test]
fn blend2d_candidate_rejects_opposed_endpoint_tangents() {
    let source = QuadraticBezier2::new(p(-1, 0), p(0, 0), p(-1, 0));
    assert!(matches!(
        crate::support::under_classified_result(&policy(), || source
            .blend2d_offset_left_candidate(r(1)))
        .unwrap(),
        Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
    ));
}

#[test]
fn blend2d_cubic_reduction_has_exact_join_and_bound() {
    let source = CubicBezier2::new(
        p(0, 0),
        Point2::new(q(1, 3), r(0)),
        Point2::new(q(2, 3), r(0)),
        p(1, 1),
    );
    let reduction = source.blend2d_two_quadratic_reduction().unwrap();
    assert_eq!(reduction.first().end(), reduction.second().start());
    assert_eq!(reduction.first().end(), &source.point_at(q(1, 2)));
    assert_eq!(reduction.same_parameter_error_bound(), &q(1, 54));
    assert_eq!(
        reduction
            .first()
            .endpoint_tangent(hypercurve::BezierEndpoint::End),
        reduction
            .second()
            .endpoint_tangent(hypercurve::BezierEndpoint::Start)
    );
}

#[test]
fn verifier_certifies_exact_straight_parallel_without_subdivision() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 0), p(2, 0));
    let parallel = source.parallel_left(r(3)).unwrap();
    let candidate = match crate::support::under_classified_result(&policy(), || {
        source.blend2d_offset_left_candidate(r(3))
    })
    .unwrap()
    {
        Classification::Decided(candidate) => candidate,
        Classification::Uncertain(reason) => panic!("line candidate was uncertain: {reason:?}"),
    };
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 1_000_000), 4)
    })
    .unwrap();
    let certified = match crate::support::under_classified_result(&policy(), || {
        parallel.verify_polynomial_candidate(candidate.curve().clone().into(), &options)
    })
    .unwrap()
    {
        Classification::Decided(certified) => certified,
        Classification::Uncertain(reason) => panic!("line verification failed: {reason:?}"),
    };
    assert_eq!(certified.maximum_depth(), 0);
    assert_eq!(certified.leaf_count(), 1);
    assert_eq!(certified.error_bound(), options.max_error());
}

#[test]
fn verifier_certifies_curved_blend2d_candidate_by_exact_subdivision() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 1), p(2, 0));
    let parallel = source.parallel_left(q(1, 4)).unwrap();
    let candidate = match crate::support::under_classified_result(&policy(), || {
        source.blend2d_offset_left_candidate(q(1, 4))
    })
    .unwrap()
    {
        Classification::Decided(candidate) => candidate,
        Classification::Uncertain(reason) => panic!("curved candidate was uncertain: {reason:?}"),
    };
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 20), 16)
    })
    .unwrap();
    let certified = match crate::support::under_classified_result(&policy(), || {
        parallel.verify_polynomial_candidate(candidate.curve().clone().into(), &options)
    })
    .unwrap()
    {
        Classification::Decided(certified) => certified,
        Classification::Uncertain(reason) => panic!("curved verification failed: {reason:?}"),
    };
    assert!(certified.maximum_depth() > 0);
    assert!(certified.leaf_count() > 1);
    assert!(matches!(
        certified.curve(),
        BezierParallelApproximationCurve2::Quadratic(_)
    ));
}

#[test]
fn verifier_rejects_candidate_outside_requested_parallel_tube() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 1), p(2, 0));
    let parallel = source.parallel_left(r(1)).unwrap();
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 10), 8)
    })
    .unwrap();
    assert!(matches!(
        crate::support::under_classified_result(&policy(), || parallel
            .verify_polynomial_candidate(source.into(), &options))
        .unwrap(),
        Classification::Uncertain(hypercurve::UncertaintyReason::Unsupported)
    ));
}

#[test]
fn verifier_refuses_source_with_undefined_normal() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 0), p(0, 0));
    let parallel = source.parallel_left(r(1)).unwrap();
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 10), 8)
    })
    .unwrap();
    assert!(matches!(
        crate::support::under_classified_result(&policy(), || parallel
            .verify_polynomial_candidate(
                BezierParallelApproximationCurve2::Quadratic(QuadraticBezier2::new(
                    p(0, 1),
                    p(1, 1),
                    p(0, 1),
                )),
                &options
            ))
        .unwrap(),
        Classification::Uncertain(hypercurve::UncertaintyReason::Boundary)
    ));
}

#[test]
fn adaptive_quadratic_construction_subdivides_until_certified() {
    let source = QuadraticBezier2::new(p(0, 0), p(1, 1), p(2, 0));
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 100), 16)
    })
    .unwrap();
    let path = match crate::support::under_classified_result(&policy(), || {
        source.approximate_parallel_blend2d_certified(q(1, 4), &options)
    })
    .unwrap()
    {
        Classification::Decided(path) => path,
        Classification::Uncertain(reason) => {
            panic!("adaptive quadratic construction failed: {reason:?}")
        }
    };
    assert!(path.spans().len() >= 2);
    assert_eq!(path.spans().first().unwrap().source_start(), &r(0));
    assert_eq!(path.spans().last().unwrap().source_end(), &r(1));
    for pair in path.spans().windows(2) {
        assert_eq!(pair[0].source_end(), pair[1].source_start());
        let BezierParallelApproximationCurve2::Quadratic(first) = pair[0].approximation().curve()
        else {
            panic!("quadratic construction emitted non-quadratic candidate");
        };
        let BezierParallelApproximationCurve2::Quadratic(second) = pair[1].approximation().curve()
        else {
            panic!("quadratic construction emitted non-quadratic candidate");
        };
        assert_eq!(first.end(), second.start());
    }
}

#[test]
fn adaptive_cubic_construction_emits_connected_certified_curves() {
    let source = CubicBezier2::new(p(0, 0), p(1, 2), p(2, -1), p(4, 0));
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 20), 14)
    })
    .unwrap();
    let path = match crate::support::under_classified_result(&policy(), || {
        source.approximate_parallel_blend2d_certified(q(1, 10), &options)
    })
    .unwrap()
    {
        Classification::Decided(path) => path,
        Classification::Uncertain(reason) => {
            panic!("adaptive cubic construction failed: {reason:?}")
        }
    };
    assert!(path.spans().len() >= 2);
    assert!(path.construction_maximum_depth() >= 1);
    assert!(path.verification_leaf_count() >= path.spans().len());
    for pair in path.spans().windows(2) {
        assert_eq!(pair[0].source_end(), pair[1].source_start());
        let first_end = match pair[0].approximation().curve() {
            BezierParallelApproximationCurve2::Quadratic(curve) => curve.end(),
            BezierParallelApproximationCurve2::Cubic(curve) => curve.end(),
        };
        let second_start = match pair[1].approximation().curve() {
            BezierParallelApproximationCurve2::Quadratic(curve) => curve.start(),
            BezierParallelApproximationCurve2::Cubic(curve) => curve.start(),
        };
        assert_eq!(first_end, second_start);
    }
}

#[test]
fn levien_candidate_matches_parallel_endpoints_tangents_and_midpoint() {
    let source = CubicBezier2::new(p(0, 0), p(1, 2), p(3, 2), p(4, 0));
    let parallel = source.parallel_left(q(1, 10)).unwrap();
    let candidate = match crate::support::under_classified_result(&policy(), || {
        parallel.levien_cubic_candidate()
    })
    .unwrap()
    {
        Classification::Decided(candidate) => candidate,
        Classification::Uncertain(reason) => panic!("Levien candidate failed: {reason:?}"),
    };
    assert!(candidate.matched_midpoint());
    for parameter in [r(0), q(1, 2), r(1)] {
        let exact = match crate::support::under_classified_result(&policy(), || {
            parallel.point_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => panic!("parallel evaluation failed: {reason:?}"),
        };
        let fitted = candidate.curve().point_at(parameter);
        let error = fitted
            .distance_squared(&exact)
            .to_f64_lossy()
            .expect("Levien replay distance is approximable");
        assert!(error.abs() <= 1.0e-20, "midpoint replay error was {error}");
    }
    for (parameter, endpoint) in [
        (r(0), hypercurve::BezierEndpoint::Start),
        (r(1), hypercurve::BezierEndpoint::End),
    ] {
        let exact = match crate::support::under_classified_result(&policy(), || {
            parallel.derivative_at(&parameter)
        })
        .unwrap()
        {
            Classification::Decided(derivative) => derivative,
            Classification::Uncertain(reason) => panic!("parallel derivative failed: {reason:?}"),
        };
        let fitted = candidate.curve().endpoint_tangent(endpoint);
        let cross = (exact.dx() * fitted.dy() - exact.dy() * fitted.dx())
            .to_f64_lossy()
            .expect("endpoint tangent cross product is approximable");
        assert!(cross.abs() <= 1.0e-20, "endpoint tangent cross was {cross}");
    }
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 20), 14)
    })
    .unwrap();
    assert!(matches!(
        crate::support::under_classified_result(&policy(), || parallel
            .verify_polynomial_candidate(candidate.curve().clone().into(), &options))
        .unwrap(),
        Classification::Decided(_)
    ));
    let fitted = match crate::support::under_classified_result(&policy(), || {
        source.approximate_parallel_blend2d_certified(q(1, 10), &options)
    })
    .unwrap()
    {
        Classification::Decided(fitted) => fitted,
        Classification::Uncertain(reason) => panic!("adaptive Levien fit failed: {reason:?}"),
    };
    assert_eq!(fitted.spans().len(), 1);
    assert!(matches!(
        fitted.spans()[0].approximation().curve(),
        BezierParallelApproximationCurve2::Cubic(_)
    ));
    // Blend2D's deterministic cubic reduction starts with two quadratic spans;
    // the accepted Levien cubic therefore halves the construction span count.
    let reduction = source.blend2d_two_quadratic_reduction().unwrap();
    assert_eq!(reduction.first().end(), reduction.second().start());
}

#[test]
fn certified_curve_path_parallel_preserves_smooth_exact_connections() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(p(1, 0), p(1, 1), p(0, 1))),
        Curve2::from(QuadraticBezier2::new(p(0, 1), p(-1, 1), p(-1, 0))),
    ])
    .unwrap();
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 20), 16)
    })
    .unwrap();
    let parallel = match crate::support::under_classified_result(&policy(), || {
        path.approximate_parallel_blend2d_certified(q(1, 10), &options)
    })
    .unwrap()
    {
        Classification::Decided(parallel) => parallel,
        Classification::Uncertain(reason) => panic!("smooth path offset failed: {reason:?}"),
    };
    assert_eq!(parallel.source_curve_count(), 2);
    assert_eq!(parallel.approximated_source_curve_count(), 2);
    assert!(parallel.output_curve_count() >= 2);
    for pair in parallel.path().curves().windows(2) {
        assert_eq!(pair[0].end(), pair[1].start());
    }
}

#[test]
fn certified_curve_path_promotes_rational_ph_span_without_chords() {
    let source =
        RationalQuadraticBezier2::try_new(p(1, 0), p(1, 1), p(0, 1), r(1), r(1), r(2)).unwrap();
    let path = CurvePath2::try_new(vec![Curve2::from(source)]).unwrap();
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 20), 12)
    })
    .unwrap();
    let parallel = match crate::support::under_classified_result(&policy(), || {
        path.approximate_parallel_blend2d_certified(q(1, 2), &options)
    })
    .unwrap()
    {
        Classification::Decided(parallel) => parallel,
        Classification::Uncertain(reason) => panic!("rational PH path offset failed: {reason:?}"),
    };
    assert_eq!(parallel.source_curve_count(), 1);
    assert_eq!(parallel.exact_source_curve_count(), 1);
    assert_eq!(parallel.approximated_source_curve_count(), 0);
    assert_eq!(parallel.output_curve_count(), 1);
    assert!(matches!(
        parallel.path().curves()[0].geometry(),
        Some(hypercurve::CurveGeometry2::RationalBezier(_))
    ));
}

#[test]
fn certified_curve_path_parallel_leaves_corner_join_to_higher_layer() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(p(0, 0), p(1, 0), p(2, 0))),
        Curve2::from(QuadraticBezier2::new(p(2, 0), p(2, 1), p(2, 2))),
    ])
    .unwrap();
    let options = crate::support::under_value(&policy(), || {
        BezierParallelVerificationOptions::try_new(q(1, 20), 12)
    })
    .unwrap();
    assert!(matches!(
        crate::support::under_classified_result(&policy(), || path
            .approximate_parallel_blend2d_certified(q(1, 10), &options))
        .unwrap(),
        Classification::Uncertain(hypercurve::UncertaintyReason::Unsupported)
    ));
}

fn stationary_ph_boundary_path() -> CurvePath2 {
    // P'(t)=t^2(1-t^2,2t). The exact normal has a finite one-sided
    // endpoint, and repeated offsets must retain that branch and its source.
    let source = RationalBezier2::try_new(
        vec![
            p(0, 0),
            p(0, 0),
            p(0, 0),
            Point2::new(q(1, 30), r(0)),
            Point2::new(q(2, 15), q(1, 10)),
            Point2::new(q(2, 15), q(1, 2)),
        ],
        vec![r(1); 6],
    )
    .unwrap();
    CurvePath2::try_new(vec![
        Curve2::from(source.clone()),
        Curve2::from(LineSeg2::try_new(source.end().clone(), Point2::new(r(-1), q(1, 2))).unwrap()),
        Curve2::from(LineSeg2::try_new(Point2::new(r(-1), q(1, 2)), p(-1, 0)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(-1, 0), p(0, 0)).unwrap()),
    ])
    .unwrap()
}

#[test]
fn stationary_ph_region_reoffsets_through_paths_booleans_and_cancellation() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for reversed in [false, true] {
            let mut path = stationary_ph_boundary_path();
            if reversed {
                path = crate::support::under(&policy, || path.reversed())
                    .unwrap()
                    .into_value();
            }
            let original = crate::support::under(&policy, || {
                CurveRegion2::try_from_boundary_paths_with_loop_semantics(
                    &[path],
                    &[CurveRegionLoopRole::Material],
                    &[FillRule::NonZero],
                )
            })
            .unwrap();
            assert_eq!(original.certainty, hypercurve::CurveCertainty::Certified);
            let original = original.into_value();
            let first = crate::support::under(&policy, || {
                original.offset(q(1, 20), &OffsetCornerStyle2::Round)
            })
            .unwrap();
            assert_eq!(first.certainty, hypercurve::CurveCertainty::Certified);
            let second = crate::support::under(&policy, || {
                first.value.offset(q(1, 40), &OffsetCornerStyle2::Round)
            })
            .unwrap();
            assert_eq!(second.certainty, hypercurve::CurveCertainty::Certified);
            let direct = crate::support::under(&policy, || {
                original.offset(q(3, 40), &OffsetCornerStyle2::Round)
            })
            .unwrap();
            assert_eq!(direct.certainty, hypercurve::CurveCertainty::Certified);
            let difference = crate::support::under(&policy, || {
                second
                    .value
                    .boolean_region(&direct.value, hypercurve::BooleanOp::Xor)
            })
            .unwrap();
            assert_eq!(difference.certainty, hypercurve::CurveCertainty::Certified);
            assert!(difference.value.is_empty());

            let paths = crate::support::under(&policy, || second.value.boundary_paths()).unwrap();
            assert_eq!(paths.certainty, hypercurve::CurveCertainty::Certified);
            let paths = paths.value;
            assert_eq!(paths.len(), 1);
            assert!(
                paths[0]
                    .curves()
                    .iter()
                    .any(|curve| curve.family() == hypercurve::CurveFamily2::AnalyticParallel)
            );
            let restored = crate::support::under(&policy, || {
                CurveRegion2::try_from_boundary_paths_with_loop_semantics(
                    &paths,
                    &[CurveRegionLoopRole::Material],
                    &[FillRule::NonZero],
                )
            })
            .unwrap();
            assert_eq!(restored.certainty, hypercurve::CurveCertainty::Certified);
            for (point, expected) in [
                (
                    Point2::new(q(-1, 2), q(1, 4)),
                    hypercurve::RegionPointLocation::Inside,
                ),
                (p(2, 2), hypercurve::RegionPointLocation::Outside),
                (
                    Point2::new(q(-43, 40), q(1, 4)),
                    hypercurve::RegionPointLocation::Boundary,
                ),
            ] {
                let location = crate::support::under(&policy, || {
                    restored.value.classify_point(&point.clone().into())
                })
                .unwrap();
                assert_eq!(location.certainty, hypercurve::CurveCertainty::Certified);
                assert_eq!(location.value, expected);
            }
            let cancelled = crate::support::under(&policy, || {
                restored.value.offset(q(-3, 40), &OffsetCornerStyle2::Round)
            })
            .unwrap();
            assert_eq!(cancelled.certainty, hypercurve::CurveCertainty::Certified);
            let difference = crate::support::under(&policy, || {
                cancelled
                    .value
                    .boolean_region(&original, hypercurve::BooleanOp::Xor)
            })
            .unwrap();
            assert_eq!(difference.certainty, hypercurve::CurveCertainty::Certified);
            assert!(difference.value.is_empty());
        }
    }
}

#[test]
fn stationary_ph_inward_offsets_preserve_sets_through_boundary_paths() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for reversed in [false, true] {
            let mut path = stationary_ph_boundary_path();
            if reversed {
                path = crate::support::under(&policy, || path.reversed())
                    .unwrap()
                    .into_value();
            }
            let original = crate::support::under(&policy, || {
                CurveRegion2::try_from_boundary_paths_with_loop_semantics(
                    &[path],
                    &[CurveRegionLoopRole::Material],
                    &[FillRule::NonZero],
                )
            })
            .unwrap();
            assert_eq!(original.certainty, hypercurve::CurveCertainty::Certified);
            let first = crate::support::under(&policy, || {
                original.value.offset(q(-1, 20), &OffsetCornerStyle2::Round)
            })
            .unwrap();
            assert_eq!(first.certainty, hypercurve::CurveCertainty::Certified);
            let second = crate::support::under(&policy, || {
                first.value.offset(q(-1, 40), &OffsetCornerStyle2::Round)
            })
            .unwrap();
            assert_eq!(second.certainty, hypercurve::CurveCertainty::Certified);
            assert_eq!(second.value.boundary_loops().len(), 1);
            let paths = crate::support::under(&policy, || second.value.boundary_paths()).unwrap();
            assert_eq!(paths.certainty, hypercurve::CurveCertainty::Certified);
            let paths = paths.value;
            assert_eq!(paths.len(), 1);
            let restored = crate::support::under(&policy, || {
                CurveRegion2::try_from_boundary_paths_with_loop_semantics(
                    &paths,
                    &[CurveRegionLoopRole::Material],
                    &[FillRule::NonZero],
                )
            })
            .unwrap();
            assert_eq!(restored.certainty, hypercurve::CurveCertainty::Certified);

            // The source set contains [-1,0] x [0,1/2] and is contained in
            // [-1,2/15] x [0,1/2]. Inward round offsets are monotone in set
            // inclusion; the two distances sum to 3/40. These rectangles
            // independently certify the interior/exterior probes and their
            // shared left boundary, without comparing two offset solvers.
            for region in [&second.value, &restored.value] {
                for (point, expected) in [
                    (
                        Point2::new(q(-1, 2), q(1, 4)),
                        hypercurve::RegionPointLocation::Inside,
                    ),
                    (
                        Point2::new(q(-23, 25), q(1, 4)),
                        hypercurve::RegionPointLocation::Inside,
                    ),
                    (
                        Point2::new(q(-1, 2), q(21, 50)),
                        hypercurve::RegionPointLocation::Inside,
                    ),
                    (
                        Point2::new(q(-93, 100), q(1, 4)),
                        hypercurve::RegionPointLocation::Outside,
                    ),
                    (
                        Point2::new(q(-1, 2), q(43, 100)),
                        hypercurve::RegionPointLocation::Outside,
                    ),
                    (
                        Point2::new(q(-37, 40), q(1, 4)),
                        hypercurve::RegionPointLocation::Boundary,
                    ),
                ] {
                    let location = crate::support::under(&policy, || {
                        region.classify_point(&point.clone().into())
                    })
                    .unwrap();
                    assert_eq!(location.certainty, hypercurve::CurveCertainty::Certified);
                    assert_eq!(location.value, expected);
                }
            }
        }
    }
}

#[test]
fn curve_region_exact_offset_retains_analytic_parallel_arrangement() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(p(1, 0), p(1, 1), p(0, 1))),
        Curve2::from(QuadraticBezier2::new(p(0, 1), p(-1, 1), p(-1, 0))),
        Curve2::from(QuadraticBezier2::new(p(-1, 0), p(-1, -1), p(0, -1))),
        Curve2::from(QuadraticBezier2::new(p(0, -1), p(1, -1), p(1, 0))),
    ])
    .unwrap();
    let region = crate::support::under(&policy(), || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[path],
            &[CurveRegionLoopRole::Material],
            &[FillRule::EvenOdd],
        )
    })
    .unwrap()
    .into_value();
    let result = crate::support::under(&policy(), || {
        region.offset(q(1, 10), &OffsetCornerStyle2::Round)
    })
    .unwrap();
    assert!(!result.value.boundary_loops().is_empty());
    assert!(result.value.has_algebraic_fragments());
}

#[test]
fn curve_region_authored_corner_stays_on_exact_offset_path() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(p(0, 0), p(1, -1), p(2, 0))),
        Curve2::from(QuadraticBezier2::new(p(2, 0), p(2, 1), p(2, 2))),
        Curve2::from(QuadraticBezier2::new(p(2, 2), p(1, 3), p(0, 2))),
        Curve2::from(QuadraticBezier2::new(p(0, 2), p(-1, 1), p(0, 0))),
    ])
    .unwrap();
    let region = crate::support::under(&policy(), || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[path],
            &[CurveRegionLoopRole::Material],
            &[FillRule::EvenOdd],
        )
    })
    .unwrap()
    .into_value();
    let result = crate::support::under(&policy(), || {
        region.offset(q(1, 10), &OffsetCornerStyle2::Round)
    })
    .unwrap();
    assert!(result.value.has_algebraic_fragments());
}

proptest! {
    #[test]
    fn generated_blend2d_candidates_replay_exact_parallel_endpoints(
        translation_x in -100_i16..100,
        translation_y in -100_i16..100,
        run in 1_i16..20,
        rise in 1_i16..20,
        distance in -10_i16..11,
    ) {
        let tx = Real::from(translation_x);
        let ty = Real::from(translation_y);
        let run = Real::from(run);
        let rise = Real::from(rise);
        let distance = Real::from(distance);
        let source = QuadraticBezier2::new(
            Point2::new(tx.clone(), ty.clone()),
            Point2::new(&tx + &run, &ty + rise),
            Point2::new(&tx + &run * r(2), ty),
        );
        let candidate = match crate::support::under_classified_result(&policy(), || source
            .blend2d_offset_left_candidate(distance.clone()))
            .unwrap()
        {
            Classification::Decided(candidate) => candidate,
            Classification::Uncertain(reason) => {
                prop_assert!(false, "generated regular candidate was uncertain: {reason:?}");
                unreachable!()
            }
        };
        let parallel = source.parallel_left(distance).unwrap();
        for (parameter, endpoint) in [
            (r(0), candidate.curve().start()),
            (r(1), candidate.curve().end()),
        ] {
            let exact = match crate::support::under_classified_result(&policy(), || parallel.point_at(&parameter)).unwrap() {
                Classification::Decided(point) => point,
                Classification::Uncertain(reason) => {
                    prop_assert!(false, "generated endpoint evaluation was uncertain: {reason:?}");
                    unreachable!()
                }
            };
            let replay_error = endpoint.distance_squared(&exact).to_f64_lossy().unwrap();
            prop_assert!(replay_error.abs() <= 1.0e-20);
        }
    }
}
