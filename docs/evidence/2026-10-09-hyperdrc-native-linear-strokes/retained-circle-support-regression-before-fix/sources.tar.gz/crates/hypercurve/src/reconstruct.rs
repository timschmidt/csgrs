//! Polyline-to-curve reconstruction.
//!
//! The routines in this module are intentionally lossy import helpers. They
//! live at the IO boundary: sampled points are inspected through finite `f64`
//! approximations, then promoted back into native line and circular-arc
//! segments once a run has been classified.
//!
//! Arc promotion uses local finite-difference curvature witnesses. The
//! three-point circle behind that witness is the reciprocal-radius idea of
//! Menger curvature. The code chooses a deterministic streaming circumcircle
//! instead of a multi-point least-squares fit.

use std::f64::consts::PI;

use hyperreal::Real;

use crate::{
    BulgeVertex2, Contour2, CurveContext, CurveError, CurveFamily2, CurveOperation2, CurveOutcome,
    CurveRegion2, CurveResult, CurveString2, ExactCurveError, ExactCurveResult, FillRule,
    FinitePolyline2, FiniteRegionProfile2, LineSeg2, Point2, Segment2,
};

const DEFAULT_DISTANCE_TOLERANCE: f64 = 1e-6;
const DEFAULT_RELATIVE_TOLERANCE: f64 = 1e-9;
const DEFAULT_COLLINEAR_TOLERANCE: f64 = 1e-7;
const DEFAULT_DUPLICATE_POINT_TOLERANCE: f64 = 1e-12;
const DEFAULT_MIN_ARC_POINTS: usize = 4;
const MIN_ARC_POINTS: usize = 3;

/// Controls reconstruction of line and circular-arc segments from sampled
/// polyline points.
///
/// The defaults are conservative: nearly-collinear samples are merged into
/// long line segments, while arc promotion requires at least four points so a
/// single corner triplet is not interpreted as curvature.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PolylineReconstructionOptions {
    /// Maximum absolute point-to-line or radial point-to-circle error accepted
    /// while extending a candidate run.
    pub distance_tolerance: f64,
    /// Relative tolerance scaled by the candidate chord length or radius.
    pub relative_tolerance: f64,
    /// Dimensionless signed-area tolerance used to treat a three-point finite
    /// difference as collinear.
    pub collinear_tolerance: f64,
    /// Distance below which adjacent input samples are treated as duplicate
    /// polyline points.
    pub duplicate_point_tolerance: f64,
    /// Minimum number of sampled points required before a run can be promoted
    /// to a circular arc.
    pub min_arc_points: usize,
}

impl PolylineReconstructionOptions {
    /// Constructs conservative reconstruction options with a custom absolute
    /// distance tolerance.
    pub const fn new(distance_tolerance: f64) -> Self {
        Self {
            distance_tolerance,
            ..Self::DEFAULT
        }
    }

    /// Default reconstruction options.
    pub const DEFAULT: Self = Self {
        distance_tolerance: DEFAULT_DISTANCE_TOLERANCE,
        relative_tolerance: DEFAULT_RELATIVE_TOLERANCE,
        collinear_tolerance: DEFAULT_COLLINEAR_TOLERANCE,
        duplicate_point_tolerance: DEFAULT_DUPLICATE_POINT_TOLERANCE,
        min_arc_points: DEFAULT_MIN_ARC_POINTS,
    };

    fn validate(self) -> CurveResult<Self> {
        let finite_nonnegative = [
            self.distance_tolerance,
            self.relative_tolerance,
            self.collinear_tolerance,
            self.duplicate_point_tolerance,
        ]
        .into_iter()
        .all(|value| value.is_finite() && value >= 0.0);

        if !finite_nonnegative || self.min_arc_points < MIN_ARC_POINTS {
            return Err(CurveError::InvalidReconstructionOptions);
        }
        Ok(self)
    }

    fn distance_limit(self, scale: f64) -> f64 {
        self.distance_tolerance + self.relative_tolerance * scale.abs()
    }
}

impl Default for PolylineReconstructionOptions {
    fn default() -> Self {
        Self::DEFAULT
    }
}

impl BulgeVertex2 {
    /// Reconstructs exact bulge vertices from an open sampled polyline.
    ///
    /// Flat runs are collapsed to one zero-bulge line segment. Runs with
    /// consistent three-point finite curvature are represented as circular
    /// arcs with `|bulge| <= 1`, splitting naturally at semicircle boundaries.
    pub fn reconstruct_polyline(
        points: &[Point2],
        options: PolylineReconstructionOptions,
    ) -> CurveResult<Vec<Self>> {
        let options = options.validate()?;
        let samples = sample_open_points(points, options)?;
        if samples.len() < 2 {
            return Err(CurveError::InsufficientVertices);
        }

        let spans = reconstruct_spans(&samples, options)?;
        bulge_vertices_from_reconstruction_spans(&samples, &spans)
    }
}

impl CurveString2 {
    /// Constructs an open line-segment curve string from hyperreal points.
    ///
    /// This is the native counterpart to [`CurveString2::from_finite_line_string`].
    /// It keeps already-promoted coordinates in `Real` form and builds exact-aware
    /// line segments directly.
    pub fn from_real_line_string(points: &[[Real; 2]]) -> CurveResult<Self> {
        if points.len() < 2 {
            return Err(CurveError::InsufficientVertices);
        }

        let mut segments = Vec::with_capacity(points.len() - 1);
        for edge in points.windows(2) {
            let start = point_from_real_xy(&edge[0]);
            let end = point_from_real_xy(&edge[1]);
            let line = crate::LineSeg2::try_new(start, end)?;
            segments.push(crate::Segment2::Line(line));
        }
        Self::try_new(segments)
    }

    /// Constructs an open line-segment curve string from an iterator of
    /// hyperreal points.
    pub fn from_real_point_iter<I>(points: I) -> CurveResult<Self>
    where
        I: IntoIterator<Item = [Real; 2]>,
    {
        let points = points.into_iter().collect::<Vec<_>>();
        Self::from_real_line_string(&points)
    }

    /// Constructs an open line-segment curve string from finite `f64` points.
    ///
    /// This is an API-boundary import adapter: primitive floats are accepted at
    /// the boundary, immediately promoted to [`Real`], and stored as native
    /// line geometry before any topology-sensitive operation runs. That follows
    /// exact-computation discipline.
    /// Unlike [`CurveString2::reconstruct_from_polyline`], this constructor
    /// makes no attempt to infer arcs from samples.
    pub fn from_finite_line_string(points: &[[f64; 2]]) -> CurveResult<Self> {
        if points.len() < 2 {
            return Err(CurveError::InsufficientVertices);
        }

        let mut segments = Vec::with_capacity(points.len() - 1);
        for edge in points.windows(2) {
            let start = point_from_finite_xy(edge[0])?;
            let end = point_from_finite_xy(edge[1])?;
            if let Ok(line) = LineSeg2::try_new(start, end) {
                segments.push(Segment2::Line(line));
            }
        }
        Self::try_new(segments)
    }

    /// Constructs an open line-segment curve string from an iterator of finite
    /// `f64` points.
    ///
    /// This is the ownership-friendly counterpart to
    /// [`CurveString2::from_finite_line_string`] for callers that generate
    /// finite boundary samples lazily. The samples are still a boundary import:
    /// they are collected, promoted to [`Real`], and stored as native line
    /// geometry before topology-sensitive work proceeds. This follows exact-computation discipline.
    pub fn from_finite_point_iter<I>(points: I) -> CurveResult<Self>
    where
        I: IntoIterator<Item = [f64; 2]>,
    {
        let points = points.into_iter().collect::<Vec<_>>();
        Self::from_finite_line_string(&points)
    }

    /// Reconstructs an open curve string from sampled polyline points.
    ///
    /// This is a finite-precision import helper. It is useful after tracing,
    /// digitizing, tessellating, or user-editing a dense point polyline and
    /// before running exact topology on the reconstructed line/arc model.
    pub fn reconstruct_from_polyline(
        points: &[Point2],
        options: PolylineReconstructionOptions,
    ) -> CurveResult<Self> {
        let options = options.validate()?;
        let samples = sample_open_points(points, options)?;
        if samples.len() < 2 {
            return Err(CurveError::InsufficientVertices);
        }

        let spans = reconstruct_spans(&samples, options)?;
        let vertices = bulge_vertices_from_reconstruction_spans(&samples, &spans)?;
        Self::from_bulge_vertices(&vertices)
    }
}

impl Contour2 {
    /// Constructs a closed straight-segment contour from hyperreal ring points.
    ///
    /// A repeated final point equal to the first point is accepted and removed
    /// before native contour construction. Unlike [`Contour2::from_finite_ring`],
    /// this constructor does not cross a primitive-float boundary.
    pub fn from_real_ring(points: &[[Real; 2]]) -> CurveResult<Self> {
        Self::from_real_ring_with_fill_rule(points, FillRule::NonZero)
    }

    /// Constructs a closed straight-segment contour from hyperreal ring points
    /// and an explicit fill rule.
    pub fn from_real_ring_with_fill_rule(
        points: &[[Real; 2]],
        fill_rule: FillRule,
    ) -> CurveResult<Self> {
        if points.len() < 3 {
            return Err(CurveError::InsufficientVertices);
        }

        let repeated_closing_point = points.len() > 1 && points.first() == points.last();
        let end = if repeated_closing_point {
            points.len() - 1
        } else {
            points.len()
        };
        if end < 3 {
            return Err(CurveError::InsufficientVertices);
        }

        let vertices = points
            .iter()
            .take(end)
            .map(|point| BulgeVertex2::new(point_from_real_xy(point), Real::zero()))
            .collect::<Vec<_>>();
        Self::from_bulge_vertices_with_fill_rule(&vertices, fill_rule)
    }

    /// Constructs a closed straight-segment contour from finite `f64` ring points.
    ///
    /// A repeated final point equal to the first point is accepted and removed
    /// before native contour construction. This is the closed-ring counterpart
    /// to [`CurveString2::from_finite_line_string`]; it imports finite boundary
    /// coordinates as exact-aware line topology without fitting arcs.
    pub fn from_finite_ring(points: &[[f64; 2]]) -> CurveResult<Self> {
        Self::from_finite_ring_with_fill_rule(points, FillRule::NonZero)
    }

    /// Constructs a closed straight-segment contour from finite `f64` ring
    /// points and an explicit fill rule.
    pub fn from_finite_ring_with_fill_rule(
        points: &[[f64; 2]],
        fill_rule: FillRule,
    ) -> CurveResult<Self> {
        if points.len() < 3 {
            return Err(CurveError::InsufficientVertices);
        }

        let (retained_points, _) = finite_ring_points(points)?;
        let mut segments = Vec::with_capacity(retained_points.len());
        for index in 0..retained_points.len() {
            let start = retained_points[index].clone();
            let end = retained_points[(index + 1) % retained_points.len()].clone();
            // `finite_ring_points` rejects non-finite input and removes every
            // adjacent (including closing) duplicate before exact dyadic
            // promotion. Promotion preserves finite `f64` equality, while
            // shared cloned endpoints make this chain connected and closed by
            // construction. Repeating those exact distance predicates here is
            // therefore unnecessary work at this finite adapter boundary.
            segments.push(Segment2::Line(LineSeg2::new_unchecked(start, end)));
        }
        Ok(Self::new_unchecked(
            CurveString2::new_unchecked(segments),
            fill_rule,
        ))
    }

    /// Reconstructs a closed contour from sampled polyline points using the
    /// non-zero fill rule.
    ///
    /// The input may include or omit a repeated final point equal to the first
    /// point. Reconstruction is performed on the explicit closed sample chain.
    pub fn reconstruct_from_closed_polyline(
        points: &[Point2],
        options: PolylineReconstructionOptions,
    ) -> CurveResult<Self> {
        Self::reconstruct_from_closed_polyline_with_fill_rule(points, options, FillRule::NonZero)
    }

    /// Reconstructs a closed contour from sampled polyline points with an
    /// explicit fill rule.
    pub fn reconstruct_from_closed_polyline_with_fill_rule(
        points: &[Point2],
        options: PolylineReconstructionOptions,
        fill_rule: FillRule,
    ) -> CurveResult<Self> {
        let options = options.validate()?;
        let mut samples = sample_open_points(points, options)?;
        if samples.len() >= 2
            && distance(&samples[0], &samples[samples.len() - 1])
                <= options.duplicate_point_tolerance
        {
            samples.pop();
        }
        if samples.len() < 3 {
            return Err(CurveError::InsufficientVertices);
        }

        let mut closed_samples = samples.clone();
        closed_samples.push(samples[0].clone());
        let spans = reconstruct_spans(&closed_samples, options)?;
        let vertices = bulge_vertices_from_reconstruction_spans(&closed_samples, &spans)?;
        let curve = CurveString2::from_bulge_vertices(&vertices)?;
        Self::try_new_with_fill_rule(curve.into_segments(), fill_rule)
    }
}

impl CurveRegion2 {
    /// Recovers a regularized region from segmented finite profiles.
    ///
    /// Material and hole roles come from the profile structure. Reconstructed
    /// native contours enter the same exact region admission as authored
    /// contours, resolving overlaps and canceled seams before publication.
    /// The outcome records the predicates consumed by that admission.
    /// Reconstruction is lossy relative to the original source curves; the
    /// resulting exact set is defined by the reconstructed line/arc contours.
    pub fn recover_from_finite_profiles(
        profiles: &[FiniteRegionProfile2],
        options: PolylineReconstructionOptions,
    ) -> crate::ExactCurveResult<Self> {
        Self::recover_from_finite_profiles_with_policy(
            profiles,
            options,
            &crate::policy::principal_context(),
        )
        .map(crate::CurveOutcome::into_value)
    }

    /// [`Self::recover_from_finite_profiles`] under an explicit predicate policy.
    pub(crate) fn recover_from_finite_profiles_with_policy(
        profiles: &[FiniteRegionProfile2],
        options: PolylineReconstructionOptions,
        policy: &CurveContext,
    ) -> ExactCurveResult<CurveOutcome<Self>> {
        let mut material_contours = Vec::with_capacity(profiles.len());
        let hole_count = profiles.iter().map(|profile| profile.holes().len()).sum();
        let mut hole_contours = Vec::with_capacity(hole_count);

        for profile in profiles {
            material_contours.push(recover_finite_ring(profile.material(), options)?);

            for hole in profile.holes() {
                hole_contours.push(recover_finite_ring(hole, options)?);
            }
        }

        Self::try_from_native_contours_with_policy(material_contours, hole_contours, policy)
    }
}

fn recover_finite_ring(
    ring: &FinitePolyline2,
    options: PolylineReconstructionOptions,
) -> ExactCurveResult<Contour2> {
    if !ring.is_closed() {
        return Err(curve_region_recovery_error(CurveError::Topology(
            "curve-region recovery requires explicitly closed finite rings".into(),
        )));
    }
    let points = ring
        .points()
        .iter()
        .copied()
        .map(point_from_finite_xy)
        .collect::<CurveResult<Vec<_>>>()
        .map_err(curve_region_recovery_error)?;
    Contour2::reconstruct_from_closed_polyline(&points, options)
        .map_err(curve_region_recovery_error)
}

fn curve_region_recovery_error(cause: CurveError) -> ExactCurveError {
    ExactCurveError::invalid(CurveOperation2::Construction, CurveFamily2::Line, cause)
}

fn finite_ring_points(points: &[[f64; 2]]) -> CurveResult<(Vec<Point2>, usize)> {
    if points
        .iter()
        .flatten()
        .any(|coordinate| !coordinate.is_finite())
    {
        return Err(CurveError::NonFiniteReconstructionPoint);
    }

    let same_point = |left: &[f64; 2], right: &[f64; 2]| left[0] == right[0] && left[1] == right[1];
    let discarded_duplicate_count = points
        .iter()
        .zip(points.iter().cycle().skip(1))
        .take(points.len())
        .filter(|(start, end)| same_point(start, end))
        .count();

    let mut unique_points = Vec::with_capacity(points.len());
    for point in points {
        if unique_points
            .last()
            .is_some_and(|previous| same_point(previous, point))
        {
            continue;
        }
        unique_points.push(*point);
    }
    if unique_points.len() > 1
        && same_point(&unique_points[0], &unique_points[unique_points.len() - 1])
    {
        unique_points.pop();
    }
    if unique_points.len() < 3 {
        return Err(CurveError::InsufficientVertices);
    }

    let points = unique_points
        .into_iter()
        .map(point_from_finite_xy)
        .collect::<CurveResult<Vec<_>>>()?;
    Ok((points, discarded_duplicate_count))
}

fn bulge_vertices_from_reconstruction_spans(
    samples: &[SamplePoint],
    spans: &[Span],
) -> CurveResult<Vec<BulgeVertex2>> {
    let mut vertices = Vec::with_capacity(spans.len() + 1);
    for span in spans {
        vertices.push(BulgeVertex2::new(
            samples[span.start].point.clone(),
            real_from_f64(span.bulge)?,
        ));
    }
    vertices.push(BulgeVertex2::new(
        samples[samples.len() - 1].point.clone(),
        Real::zero(),
    ));
    Ok(vertices)
}

#[derive(Clone, Debug)]
struct SamplePoint {
    point: Point2,
    x: f64,
    y: f64,
}

#[derive(Clone, Copy, Debug)]
struct Span {
    start: usize,
    end: usize,
    bulge: f64,
}

#[derive(Clone, Copy, Debug)]
struct Circle {
    cx: f64,
    cy: f64,
    radius: f64,
    sign: f64,
}

#[derive(Clone, Copy, Debug)]
struct ArcCandidate {
    end: usize,
    bulge: f64,
}

fn sample_open_points(
    points: &[Point2],
    options: PolylineReconstructionOptions,
) -> CurveResult<Vec<SamplePoint>> {
    let mut samples = Vec::with_capacity(points.len());
    for point in points {
        let sample = sample_point(point)?;
        if samples.last().is_some_and(|previous| {
            distance(previous, &sample) <= options.duplicate_point_tolerance
        }) {
            continue;
        }
        samples.push(sample);
    }
    Ok(samples)
}

fn point_from_finite_xy(point: [f64; 2]) -> CurveResult<Point2> {
    if !point[0].is_finite() || !point[1].is_finite() {
        return Err(CurveError::NonFiniteReconstructionPoint);
    }
    Ok(Point2::new(
        real_from_f64(point[0])?,
        real_from_f64(point[1])?,
    ))
}

fn point_from_real_xy(point: &[Real; 2]) -> Point2 {
    Point2::new(point[0].clone(), point[1].clone())
}

fn sample_point(point: &Point2) -> CurveResult<SamplePoint> {
    let Some(x) = point.x().to_f64_lossy() else {
        return Err(CurveError::NonFiniteReconstructionPoint);
    };
    let Some(y) = point.y().to_f64_lossy() else {
        return Err(CurveError::NonFiniteReconstructionPoint);
    };
    if !x.is_finite() || !y.is_finite() {
        return Err(CurveError::NonFiniteReconstructionPoint);
    }
    Ok(SamplePoint {
        point: point.clone(),
        x,
        y,
    })
}

fn real_from_f64(value: f64) -> CurveResult<Real> {
    if !value.is_finite() {
        return Err(CurveError::NonFiniteReconstructionPoint);
    }
    Real::try_from(value).map_err(CurveError::from)
}

fn reconstruct_spans(
    samples: &[SamplePoint],
    options: PolylineReconstructionOptions,
) -> CurveResult<Vec<Span>> {
    let mut spans = Vec::new();
    let mut start = 0;

    while start + 1 < samples.len() {
        let line_end = line_run_end(samples, start, options);
        let arc = arc_run(samples, start, options);
        let span = if let Some(arc) = arc {
            if arc.end > line_end {
                Span {
                    start,
                    end: arc.end,
                    bulge: arc.bulge,
                }
            } else {
                Span {
                    start,
                    end: line_end,
                    bulge: 0.0,
                }
            }
        } else {
            Span {
                start,
                end: line_end,
                bulge: 0.0,
            }
        };

        if span.end <= start {
            return Err(CurveError::Topology(
                "polyline reconstruction made no forward progress".to_owned(),
            ));
        }
        start = span.end;
        spans.push(span);
    }

    Ok(spans)
}

fn line_run_end(
    samples: &[SamplePoint],
    start: usize,
    options: PolylineReconstructionOptions,
) -> usize {
    let mut end = start + 1;
    for candidate in (start + 2)..samples.len() {
        if line_span_ok(samples, start, candidate, options) {
            end = candidate;
        } else {
            break;
        }
    }
    end
}

fn line_span_ok(
    samples: &[SamplePoint],
    start: usize,
    end: usize,
    options: PolylineReconstructionOptions,
) -> bool {
    let scale = distance(&samples[start], &samples[end]);
    if scale <= options.duplicate_point_tolerance {
        return false;
    }
    let limit = options.distance_limit(scale);
    samples[(start + 1)..end]
        .iter()
        .all(|point| point_line_distance(point, &samples[start], &samples[end]) <= limit)
}

fn arc_run(
    samples: &[SamplePoint],
    start: usize,
    options: PolylineReconstructionOptions,
) -> Option<ArcCandidate> {
    if start + 2 >= samples.len() {
        return None;
    }

    let p0 = &samples[start];
    let p1 = &samples[start + 1];
    let p2 = &samples[start + 2];
    if point_line_distance(p1, p0, p2) <= options.distance_limit(distance(p0, p2)) {
        return None;
    }

    let circle = circumcircle(p0, p1, p2, options)?;
    let mut previous_sweep = directed_sweep(&circle, p0, p1)?;
    let mut final_sweep = directed_sweep(&circle, p0, p2)?;
    if previous_sweep <= options.collinear_tolerance
        || final_sweep <= previous_sweep + options.collinear_tolerance
        || final_sweep > PI + options.collinear_tolerance
    {
        return None;
    }

    let mut end = start + 2;
    for candidate in (start + 3)..samples.len() {
        let point = &samples[candidate];
        let radial_error = (distance_to_center(point, &circle) - circle.radius).abs();
        if radial_error > options.distance_limit(circle.radius) {
            break;
        }

        let Some(sweep) = directed_sweep(&circle, p0, point) else {
            break;
        };
        if sweep <= previous_sweep + options.collinear_tolerance {
            break;
        }
        if sweep > PI + options.collinear_tolerance {
            break;
        }

        // The local signed area is the finite-difference curvature witness.
        // Requiring a stable sign follows Menger's point-triple curvature idea:
        // Menger curvature.
        let local_turn = signed_area2(&samples[candidate - 2], &samples[candidate - 1], point);
        if local_turn.signum() != circle.sign
            && local_turn.abs()
                > options.collinear_tolerance
                    * distance(&samples[candidate - 2], &samples[candidate - 1])
                    * distance(&samples[candidate - 1], point)
        {
            break;
        }

        end = candidate;
        previous_sweep = sweep;
        final_sweep = sweep;
    }

    if end - start + 1 < options.min_arc_points {
        return None;
    }

    let sweep = final_sweep.min(PI);
    let mut bulge = circle.sign * (sweep * 0.25).tan();
    if bulge.abs() > 1.0 && bulge.abs() <= 1.0 + options.collinear_tolerance {
        bulge = circle.sign;
    }
    if bulge.abs() > 1.0 {
        return None;
    }

    Some(ArcCandidate { end, bulge })
}

fn circumcircle(
    a: &SamplePoint,
    b: &SamplePoint,
    c: &SamplePoint,
    options: PolylineReconstructionOptions,
) -> Option<Circle> {
    let abx = b.x - a.x;
    let aby = b.y - a.y;
    let acx = c.x - a.x;
    let acy = c.y - a.y;
    let cross = abx * acy - aby * acx;
    let scale = abx.hypot(aby) * acx.hypot(acy);
    if scale <= options.duplicate_point_tolerance
        || cross.abs() <= options.collinear_tolerance * scale
    {
        return None;
    }

    // This is the three-point circumcircle behind the finite curvature test.
    // Algebraic multi-point fits such as Kåsa's method are better for noisy
    // whole-run least squares, but this local formula keeps reconstruction
    // streaming and deterministic.
    let ab2 = abx * abx + aby * aby;
    let ac2 = acx * acx + acy * acy;
    let denom = 2.0 * cross;
    let cx = a.x + (acy * ab2 - aby * ac2) / denom;
    let cy = a.y + (abx * ac2 - acx * ab2) / denom;
    let radius = (a.x - cx).hypot(a.y - cy);
    if !cx.is_finite() || !cy.is_finite() || !radius.is_finite() || radius <= 0.0 {
        return None;
    }

    Some(Circle {
        cx,
        cy,
        radius,
        sign: cross.signum(),
    })
}

fn directed_sweep(circle: &Circle, start: &SamplePoint, point: &SamplePoint) -> Option<f64> {
    let start_x = start.x - circle.cx;
    let start_y = start.y - circle.cy;
    let point_x = point.x - circle.cx;
    let point_y = point.y - circle.cy;
    let cross = start_x * point_y - start_y * point_x;
    let dot = start_x * point_x + start_y * point_y;
    let raw = cross.atan2(dot);
    if !raw.is_finite() {
        return None;
    }

    let sweep = if circle.sign >= 0.0 {
        if raw < 0.0 { raw + 2.0 * PI } else { raw }
    } else if raw > 0.0 {
        -raw + 2.0 * PI
    } else {
        -raw
    };
    if sweep.is_finite() { Some(sweep) } else { None }
}

fn point_line_distance(point: &SamplePoint, start: &SamplePoint, end: &SamplePoint) -> f64 {
    let dx = end.x - start.x;
    let dy = end.y - start.y;
    let length = dx.hypot(dy);
    if length == 0.0 {
        return f64::INFINITY;
    }
    ((point.x - start.x) * dy - (point.y - start.y) * dx).abs() / length
}

fn distance(left: &SamplePoint, right: &SamplePoint) -> f64 {
    (left.x - right.x).hypot(left.y - right.y)
}

fn distance_to_center(point: &SamplePoint, circle: &Circle) -> f64 {
    (point.x - circle.cx).hypot(point.y - circle.cy)
}

fn signed_area2(a: &SamplePoint, b: &SamplePoint, c: &SamplePoint) -> f64 {
    (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
}
