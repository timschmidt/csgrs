#[path = "../tests/support/mod.rs"]
mod support;
use std::hint::black_box;
use std::time::Instant;

use hypercurve::{
    BooleanOp, BulgeVertex2, CircularArc2, Classification, Contour2, CurveCornerMode2,
    CurveCornerSolutions2, CurveRegion2, CurveRegionLoopRole, CurveResult, CurveString2,
    CurveStringEndpoint2, CurveStringTrimPoint2, FillRule, LineSeg2, OffsetCornerStyle2, Point2,
    PredicatePolicy, QuadraticBezier2, RationalBezier2, Real, Segment2,
};
use hypercurve::{Curve2, CurvePath2};

use hypercurve::{
    BezierAlgebraicParameter2, BezierParameter2, BezierParameterInterval,
    BezierParameterPolynomial, CubicBezier2, CurvePoint2,
};

/// Evaluates an authored curve at a selected algebraic parameter as a general point.
fn selected_point(
    curve: &RationalBezier2,
    parameter: &BezierAlgebraicParameter2,
    policy: &PredicatePolicy,
) -> CurvePoint2 {
    crate::support::under(policy, || {
        Curve2::from(curve.clone()).point_at(&hypercurve::CurveParameter2::from(
            hypercurve::BezierParameter2::Algebraic(parameter.clone()),
        ))
    })
    .expect("the selected benchmark endpoint must remain exact")
    .into_value()
}

fn s(value: i32) -> Real {
    value.into()
}

fn q(numerator: i32, denominator: i32) -> Real {
    (Real::from(numerator) / Real::from(denominator)).unwrap()
}

fn p(x: i32, y: i32) -> Point2 {
    Point2::new(s(x), s(y))
}

fn expect_decided<T>(classification: Classification<T>, message: &str) -> T {
    match classification {
        Classification::Decided(value) => value,
        Classification::Uncertain(_) => panic!("{message}"),
    }
}

fn corner_lane_enabled(name: &str) -> bool {
    match std::env::var("HYPERCURVE_EDIT_CORNER_LANE") {
        Ok(selected) => selected == name,
        Err(_) => true,
    }
}

fn benchmark_iterations() -> u32 {
    let iterations = match std::env::var("HYPERCURVE_EDIT_ITERATIONS") {
        Ok(iterations) => iterations
            .parse()
            .expect("HYPERCURVE_EDIT_ITERATIONS must be a positive u32"),
        Err(_) => 10_000,
    };
    assert!(iterations > 0, "benchmark iterations must be nonzero");
    iterations
}

fn vertex(x: i32, y: i32, bulge: i32) -> BulgeVertex2 {
    BulgeVertex2::new(p(x, y), s(bulge))
}

fn line_segment(start_x: i32, start_y: i32, end_x: i32, end_y: i32) -> Segment2 {
    Segment2::Line(LineSeg2::try_new(p(start_x, start_y), p(end_x, end_y)).unwrap())
}

fn line(start_x: i32, start_y: i32, end_x: i32, end_y: i32) -> LineSeg2 {
    LineSeg2::try_new(p(start_x, start_y), p(end_x, end_y)).unwrap()
}

fn rectangle(xmin: i32, ymin: i32, xmax: i32, ymax: i32) -> Contour2 {
    Contour2::from_bulge_vertices(&[
        vertex(xmin, ymin, 0),
        vertex(xmax, ymin, 0),
        vertex(xmax, ymax, 0),
        vertex(xmin, ymax, 0),
    ])
    .unwrap()
}

fn higher_order_fillet_path() -> CurvePath2 {
    CurvePath2::try_new(vec![
        Curve2::from(line(0, 0, 4, 0)),
        Curve2::from(QuadraticBezier2::new(p(4, 0), p(3, 4), p(2, 0))),
        Curve2::from(line(2, 0, 2, -2)),
        Curve2::from(line(2, -2, 0, -2)),
        Curve2::from(line(0, -2, 0, 0)),
    ])
    .expect("higher-order editing benchmark path must be connected")
}

fn subdivided_rectangle(edge_steps: i32) -> Contour2 {
    let mut vertices = Vec::with_capacity((edge_steps as usize) * 4);
    vertices.extend((0..edge_steps).map(|x| vertex(x, 0, 0)));
    vertices.extend((0..edge_steps).map(|y| vertex(edge_steps, y, 0)));
    vertices.extend((1..=edge_steps).rev().map(|x| vertex(x, edge_steps, 0)));
    vertices.extend((1..=edge_steps).rev().map(|y| vertex(0, y, 0)));
    Contour2::from_bulge_vertices(&vertices).unwrap()
}

fn bench_parameter_trim(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![
        line_segment(0, 0, 10, 0),
        line_segment(10, 0, 10, 6),
        line_segment(10, 6, 16, 6),
    ])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            curve.trim_between_parameters(
                CurveStringTrimPoint2::new(0, q(1, 5)),
                CurveStringTrimPoint2::new(2, q(1, 2)),
            )
        })
        .expect("benchmark fixture remains exact");
        let trimmed = expect_decided(result, "parameter trim benchmark should materialize");
        total_segments += black_box(trimmed.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_parameter_trim: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_point_arc_trim(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![Segment2::Arc(CircularArc2::from_bulge(
        p(0, 0),
        p(2, 0),
        s(1),
    )?)])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            curve.trim_between_points(&p(1, -1), &p(2, 0))
        })
        .expect("benchmark fixture remains exact");
        let trimmed = expect_decided(
            result,
            "point-bearing arc trim benchmark should materialize",
        );
        total_segments += black_box(trimmed.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_point_arc_trim: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_parameter_arc_trim(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![Segment2::Arc(CircularArc2::from_bulge(
        p(0, 0),
        p(2, 0),
        s(1),
    )?)])?;
    let policy = PredicatePolicy::STRICT;
    let start = CurveStringTrimPoint2::new(0, q(1, 7));
    let end = CurveStringTrimPoint2::new(0, q(5, 7));
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            curve.trim_between_parameters(start.clone(), end.clone())
        })
        .expect("benchmark fixture remains exact");
        let trimmed = expect_decided(result, "parameter arc trim benchmark should materialize");
        total_segments += black_box(trimmed.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_parameter_arc_trim: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_curve_intersection_trim(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![line_segment(0, 0, 10, 0)])?;
    let start_cutter = CurveString2::try_new(vec![line_segment(2, -1, 2, 1)])?;
    let end_cutter = CurveString2::try_new(vec![line_segment(8, -1, 8, 1)])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            curve.trim_between_curve_intersections(&start_cutter, &end_cutter)
        })
        .expect("benchmark fixture remains exact");
        let trimmed = expect_decided(
            result,
            "curve-intersection trim benchmark should materialize",
        );
        total_segments += black_box(trimmed.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_curve_intersection_trim: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_region_trim(iterations: u32) -> CurveResult<()> {
    // Repeated queries retain the common path and its exact source owners.
    let curve = CurvePath2::try_new(vec![LineSeg2::try_new(p(-2, 1), p(8, 1))?.into()])
        .expect("benchmark path must connect exactly");
    let policy = PredicatePolicy::STRICT;
    let region = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![
            rectangle(0, 0, 2, 2),
            rectangle(4, 0, 6, 2),
        ])
    })
    .expect("benchmark region must promote exactly")
    .into_value();
    let started = Instant::now();
    let mut total_outputs = 0_usize;

    for _ in 0..iterations {
        let trimmed = crate::support::under(&policy, || curve.trim_inside_region(&region))
            .expect("region trim benchmark must remain exact")
            .into_value();
        total_outputs += black_box(trimmed.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_path_region_trim: {iterations} iterations in {elapsed:?} ({:?}/iter), total outputs={total_outputs}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_line_curve_corner_solvers(iterations: u32) {
    let path = CurvePath2::try_new(vec![
        Curve2::from(line(0, 0, 4, 0)),
        Curve2::from(line(4, 0, 4, 4)),
        Curve2::from(line(4, 4, 8, 4)),
    ])
    .expect("line corner benchmark path must be connected");
    let policy = PredicatePolicy::STRICT;
    let design_value = s(1);

    if corner_lane_enabled("curve_path_design_chamfer") {
        let started = Instant::now();
        let mut curves = 0_usize;
        for _ in 0..iterations {
            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                black_box(&path).chamfer_vertex_by_setbacks(
                    1,
                    design_value.clone(),
                    design_value.clone(),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("design-parameter chamfer benchmark must remain exact")
            .into_value() else {
                panic!("line design-parameter chamfer benchmark must be unique");
            };
            curves += black_box(chamfered).curves().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_path_design_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
            elapsed / iterations
        );
    }

    if corner_lane_enabled("curve_path_design_fillet") {
        let started = Instant::now();
        let mut curves = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(&path).fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(design_value.clone()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("design-parameter fillet benchmark must remain exact")
            .into_value();
            let [filleted] = solutions.solutions() else {
                panic!("expected one isolated fillet");
            };
            curves += black_box(filleted).curves().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_path_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
            elapsed / iterations
        );
    }
}

fn bench_native_arc_chamfer_solvers(iterations: u32) -> CurveResult<()> {
    let policy = PredicatePolicy::STRICT;
    let next_arc = CircularArc2::try_from_center(p(1, 0), p(2, 1), p(1, 1), false)?;
    let line_arc_path = CurvePath2::try_new(vec![
        Curve2::from(line(-1, 0, 1, 0)),
        Curve2::from(next_arc.clone()),
    ])
    .expect("line-arc benchmark path must remain exact");

    if corner_lane_enabled("curve_path_line_arc_design_chamfer") {
        let started = Instant::now();
        let mut curves = 0_usize;
        for _ in 0..iterations {
            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                black_box(&line_arc_path).chamfer_vertex_by_setbacks(
                    1,
                    q(1, 2),
                    s(1),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("line-arc design chamfer must remain exact")
            .into_value() else {
                panic!("line-arc design chamfer must remain unique");
            };
            curves += black_box(chamfered).curves().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_path_line_arc_design_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
            elapsed / iterations
        );
    }

    let previous_arc = CircularArc2::try_from_center(p(0, -1), p(1, 0), p(1, -1), true)?;
    let arc_arc_path = CurvePath2::try_new(vec![
        Curve2::from(previous_arc),
        Curve2::from(next_arc.clone()),
    ])
    .expect("arc-arc benchmark path must remain exact");

    if corner_lane_enabled("curve_path_arc_arc_design_chamfer") {
        let started = Instant::now();
        let mut curves = 0_usize;
        for _ in 0..iterations {
            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                black_box(&arc_arc_path).chamfer_vertex_by_setbacks(
                    1,
                    s(1),
                    s(1),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("arc-arc design chamfer must remain exact")
            .into_value() else {
                panic!("arc-arc design chamfer must remain unique");
            };
            curves += black_box(chamfered).curves().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_path_arc_arc_design_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
            elapsed / iterations
        );
    }

    let rounded_contour = Contour2::try_new(vec![
        Segment2::Line(line(-1, 0, 1, 0)),
        Segment2::Arc(next_arc),
        Segment2::Line(line(2, 1, 2, 3)),
        Segment2::Line(line(2, 3, -1, 3)),
        Segment2::Line(line(-1, 3, -1, 0)),
    ])?;
    let region = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![rounded_contour])
    })
    .expect("line-arc benchmark region must promote")
    .into_value();

    if corner_lane_enabled("curve_region_line_arc_design_chamfer") {
        let started = Instant::now();
        let mut loops = 0_usize;
        for _ in 0..iterations {
            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                black_box(&region).chamfer_loop_vertex_by_setbacks(
                    0,
                    1,
                    q(1, 2),
                    s(1),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("line-arc region design chamfer must remain exact")
            .into_value() else {
                panic!("line-arc region design chamfer must remain unique");
            };
            loops += black_box(chamfered).boundary_loops().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_region_line_arc_design_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={loops}",
            elapsed / iterations
        );
    }

    Ok(())
}

fn bench_native_arc_fillet_solvers(iterations: u32) -> CurveResult<()> {
    let policy = PredicatePolicy::STRICT;
    let radius = q(1, 2);
    let next_arc = CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true)?;
    let line_arc_path = CurvePath2::try_new(vec![
        Curve2::from(line(-2, 0, 0, 0)),
        Curve2::from(next_arc.clone()),
    ])
    .expect("line-arc fillet benchmark path must remain exact");

    if corner_lane_enabled("curve_path_line_arc_design_fillet") {
        let started = Instant::now();
        let mut curves = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(&line_arc_path).fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(radius.clone()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("line-arc design fillet must remain exact")
            .into_value();
            let [filleted] = solutions.solutions() else {
                panic!("expected one isolated fillet");
            };
            curves += black_box(filleted).curves().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_path_line_arc_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
            elapsed / iterations
        );
    }

    let previous_arc = CircularArc2::try_from_center(p(-1, -1), p(0, 0), p(0, -1), true)?;
    let arc_arc_path = CurvePath2::try_new(vec![
        Curve2::from(previous_arc.clone()),
        Curve2::from(next_arc.clone()),
    ])
    .expect("arc-arc fillet benchmark path must remain exact");

    if corner_lane_enabled("curve_path_arc_arc_design_fillet") {
        let started = Instant::now();
        let mut curves = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(&arc_arc_path).fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(radius.clone()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("arc-arc design fillet must remain exact")
            .into_value();
            let [filleted] = solutions.solutions() else {
                panic!("expected one isolated fillet");
            };
            curves += black_box(filleted).curves().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_path_arc_arc_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
            elapsed / iterations
        );
    }

    let line_arc_contour = Contour2::try_new(vec![
        Segment2::Line(line(-2, 0, 0, 0)),
        Segment2::Arc(next_arc.clone()),
        Segment2::Line(line(1, 1, -2, 1)),
        Segment2::Line(line(-2, 1, -2, 0)),
    ])?;
    let line_arc_region = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![line_arc_contour])
    })
    .expect("line-arc fillet benchmark region must promote")
    .into_value();

    if corner_lane_enabled("curve_region_line_arc_design_fillet") {
        let started = Instant::now();
        let mut loops = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(&line_arc_region).fillet_loop_vertex(
                    0,
                    1,
                    &hypercurve::CurveFillet2::new(radius.clone()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("line-arc region design fillet must remain exact")
            .into_value();
            let [filleted] = solutions.solutions() else {
                panic!("expected one isolated fillet");
            };
            loops += black_box(filleted).boundary_loops().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_region_line_arc_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={loops}",
            elapsed / iterations
        );
    }

    let arc_arc_contour = Contour2::try_new(vec![
        Segment2::Arc(previous_arc),
        Segment2::Arc(next_arc),
        Segment2::Line(line(1, 1, -1, 1)),
        Segment2::Line(line(-1, 1, -1, -1)),
    ])?;
    let arc_arc_region = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![arc_arc_contour])
    })
    .expect("arc-arc fillet benchmark region must promote")
    .into_value();

    if corner_lane_enabled("curve_region_arc_arc_design_fillet") {
        let started = Instant::now();
        let mut loops = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(&arc_arc_region).fillet_loop_vertex(
                    0,
                    1,
                    &hypercurve::CurveFillet2::new(radius.clone()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("arc-arc region design fillet must remain exact")
            .into_value();
            let [filleted] = solutions.solutions() else {
                panic!("expected one isolated fillet");
            };
            loops += black_box(filleted).boundary_loops().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_region_arc_arc_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={loops}",
            elapsed / iterations
        );
    }

    Ok(())
}

fn bench_retained_circle_chamfer_lane(name: &str, path: &CurvePath2, iterations: u32) {
    let policy = PredicatePolicy::STRICT;
    let setback = q(1, 2);
    let started = Instant::now();
    let mut curves = 0_usize;
    for _ in 0..iterations {
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            black_box(path).chamfer_vertex_by_setbacks(
                1,
                setback.clone(),
                setback.clone(),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("retained circular chamfer must remain exact")
        .into_value() else {
            panic!("retained circular chamfer must remain unique");
        };
        curves += black_box(chamfered).curves().len();
    }
    let elapsed = started.elapsed();
    println!(
        "{name}: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
        elapsed / iterations
    );
}

fn bench_retained_circle_fillet_lane(name: &str, path: &CurvePath2, iterations: u32) {
    let policy = PredicatePolicy::STRICT;
    let radius = q(1, 2);
    let started = Instant::now();
    let mut curves = 0_usize;
    for _ in 0..iterations {
        let solutions = crate::support::under(&policy, || {
            black_box(path).fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(radius.clone()),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("retained circular fillet must remain exact")
        .into_value();
        let [filleted] = solutions.solutions() else {
            panic!("expected one isolated fillet");
        };
        curves += black_box(filleted).curves().len();
    }
    let elapsed = started.elapsed();
    println!(
        "{name}: {iterations} iterations in {elapsed:?} ({:?}/iter), curves={curves}",
        elapsed / iterations
    );
}

fn bench_retained_circle_corner_solvers(iterations: u32) -> CurveResult<()> {
    let policy = PredicatePolicy::STRICT;
    let native_arc = CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true)?;
    let conic = crate::support::under(&policy, || native_arc.rational_bezier_decomposition())
        .expect("retained-circle fixture decomposition must remain exact")
        .into_value()
        .spans()[0]
        .curve()
        .clone();
    let elevated = RationalBezier2::from(conic.clone())
        .elevated_to_degree(5)
        .expect("retained-circle fixture elevation must remain exact");
    let rational_quadratic_path =
        CurvePath2::try_new(vec![Curve2::from(line(-2, 0, 0, 0)), Curve2::from(conic)])
            .expect("rational-quadratic circle benchmark path must remain exact");
    let degree_five_path = CurvePath2::try_new(vec![
        Curve2::from(line(-2, 0, 0, 0)),
        Curve2::from(elevated),
    ])
    .expect("degree-five rational circle benchmark path must remain exact");

    for (name, path, chamfer) in [
        (
            "curve_path_rational_quadratic_circle_design_chamfer",
            &rational_quadratic_path,
            true,
        ),
        (
            "curve_path_rational_quadratic_circle_design_fillet",
            &rational_quadratic_path,
            false,
        ),
        (
            "curve_path_degree5_rational_circle_design_chamfer",
            &degree_five_path,
            true,
        ),
        (
            "curve_path_degree5_rational_circle_design_fillet",
            &degree_five_path,
            false,
        ),
    ] {
        if !corner_lane_enabled(name) {
            continue;
        }
        if chamfer {
            bench_retained_circle_chamfer_lane(name, path, iterations);
        } else {
            bench_retained_circle_fillet_lane(name, path, iterations);
        }
    }

    Ok(())
}

fn bench_represented_bezier_chamfer_lane(
    name: &str,
    path: &CurvePath2,
    previous_setback: &Real,
    next_setback: &Real,
    iterations: u32,
) {
    if !corner_lane_enabled(name) {
        return;
    }
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut candidates = 0_usize;
    for _ in 0..iterations {
        let solutions = crate::support::under(&policy, || {
            black_box(path).chamfer_vertex_by_setbacks(
                1,
                previous_setback.clone(),
                next_setback.clone(),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("represented Bezier chamfer must remain exact")
        .into_value();
        candidates += black_box(solutions).candidate_count();
    }
    assert_ne!(candidates, 0);
    let elapsed = started.elapsed();
    println!(
        "{name}: {iterations} iterations in {elapsed:?} ({:?}/iter), candidates={candidates}",
        elapsed / iterations
    );
}

fn bench_represented_bezier_fillet_lane(
    name: &str,
    path: &CurvePath2,
    radius: &Real,
    iterations: u32,
) {
    if !corner_lane_enabled(name) {
        return;
    }
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut candidates = 0_usize;
    for _ in 0..iterations {
        let solutions = crate::support::under(&policy, || {
            black_box(path).fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(radius.clone()),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("represented Bezier fillet must remain exact")
        .into_value();
        candidates += black_box(solutions.solutions()).len();
    }
    assert_ne!(candidates, 0);
    let elapsed = started.elapsed();
    println!(
        "{name}: {iterations} iterations in {elapsed:?} ({:?}/iter), candidates={candidates}",
        elapsed / iterations
    );
}

fn positive_sqrt_ratio_parameter(
    numerator: i32,
    denominator: i32,
    policy: &PredicatePolicy,
) -> CurveResult<BezierAlgebraicParameter2> {
    let polynomial = expect_decided(
        crate::support::under_classified_result(policy, || {
            BezierParameterPolynomial::try_new_power_basis(vec![
                Real::from(-numerator),
                Real::zero(),
                Real::from(denominator),
            ])
        })
        .expect("benchmark fixture remains exact"),
        "quadratic benchmark parameter must remain exact",
    );
    let interval = expect_decided(
        crate::support::under_classified_result(policy, || {
            BezierParameterInterval::try_new(Real::zero(), Real::one())
        })
        .expect("benchmark fixture remains exact"),
        "quadratic benchmark interval must remain exact",
    );
    Ok(expect_decided(
        crate::support::under_classified_result(policy, || {
            BezierAlgebraicParameter2::try_isolate(polynomial, interval)
        })
        .expect("benchmark fixture remains exact"),
        "positive quadratic benchmark root must remain isolated",
    ))
}

fn positive_reciprocal_sqrt_parameter(
    denominator: i32,
    policy: &PredicatePolicy,
) -> CurveResult<BezierAlgebraicParameter2> {
    positive_sqrt_ratio_parameter(1, denominator, policy)
}

fn source_related_algebraic_chord_region() -> Result<CurveRegion2, Box<dyn std::error::Error>> {
    let policy = PredicatePolicy::STRICT;
    let third = q(1, 3);
    let controls = [
        p(1, 0),
        Point2::new(Real::one() + &third, third.clone()),
        Point2::new(
            Real::one() + Real::from(2_i8) * &third,
            Real::from(2_i8) * &third,
        ),
        p(2, 0),
    ];
    let source = CubicBezier2::new(
        controls[0].clone(),
        controls[1].clone(),
        controls[2].clone(),
        controls[3].clone(),
    );
    let parameter = BezierParameter2::Algebraic(positive_reciprocal_sqrt_parameter(2, &policy)?);
    let source_curve = crate::support::under(&policy, || {
        Curve2::from(source).subcurve(Real::zero().into(), parameter.into())
    })?
    .into_value();
    let chord = crate::support::under(&policy, || {
        Curve2::try_line(source_curve.end(), p(0, 0).into())
    })?
    .into_value();
    let closure = QuadraticBezier2::from_line_segment(line(0, 0, 1, 0));
    let path = CurvePath2::try_new(vec![source_curve, chord, closure.into()])?;
    Ok(crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[path],
            &[CurveRegionLoopRole::Material],
            &[FillRule::NonZero],
        )
    })?
    .into_value())
}

fn independent_field_algebraic_chord_regions()
-> Result<[CurveRegion2; 2], Box<dyn std::error::Error>> {
    let policy = PredicatePolicy::STRICT;
    let first_parameter = positive_reciprocal_sqrt_parameter(2, &policy)?;
    let second_parameter = positive_reciprocal_sqrt_parameter(3, &policy)?;
    let first_split_parameter = BezierParameter2::Algebraic(first_parameter.clone());
    let second_split_parameter = BezierParameter2::Algebraic(second_parameter.clone());
    let x_axis = QuadraticBezier2::from_line_segment(line(0, 0, 1, 0));
    let y_axis = QuadraticBezier2::from_line_segment(line(0, 0, 0, 1));
    let x_curve = crate::support::under(&policy, || {
        Curve2::from(x_axis).subcurve(Real::zero().into(), first_split_parameter.into())
    })?
    .into_value();
    let y_curve = crate::support::under(&policy, || {
        crate::support::under(&policy, || {
            Curve2::from(y_axis).subcurve(Real::zero().into(), second_split_parameter.into())
        })?
        .into_value()
        .reversed()
    })?
    .into_value();
    let chord =
        crate::support::under(&policy, || Curve2::try_line(x_curve.end(), y_curve.start()))?
            .into_value();
    let chord_path = CurvePath2::try_new(vec![chord, y_curve, x_curve])?;
    let chord_region = crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[chord_path],
            &[CurveRegionLoopRole::Material],
            &[FillRule::NonZero],
        )
    })?
    .into_value();
    let source_path = CurvePath2::try_new(vec![
        QuadraticBezier2::from_line_segment(line(0, 0, 1, 1)).into(),
        QuadraticBezier2::from_line_segment(line(1, 1, -1, 1)).into(),
        QuadraticBezier2::from_line_segment(line(-1, 1, 0, 0)).into(),
    ])?;
    let source_region = crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[source_path],
            &[CurveRegionLoopRole::Material],
            &[FillRule::NonZero],
        )
    })?
    .into_value();
    Ok([chord_region, source_region])
}

fn noninjective_collinear_algebraic_chord_paths()
-> Result<[CurvePath2; 2], Box<dyn std::error::Error>> {
    let policy = PredicatePolicy::STRICT;
    let first_parameter = positive_reciprocal_sqrt_parameter(2, &policy)?;
    let second_parameter = positive_reciprocal_sqrt_parameter(3, &policy)?;
    let horizontal = RationalBezier2::try_new(vec![p(0, 0), p(1, 0)], vec![Real::one(); 2])?;
    let first_endpoint = selected_point(&horizontal, &first_parameter, &policy);
    let second_endpoint = selected_point(&horizontal, &second_parameter, &policy);
    let chord = crate::support::under(&policy, || {
        Curve2::try_line(first_endpoint, second_endpoint)
    })?
    .into_value();
    let chord_path = CurvePath2::try_new(vec![
        chord.clone(),
        crate::support::under(&policy, || chord.reversed())?.into_value(),
    ])?;
    let source_path = CurvePath2::try_new(vec![
        QuadraticBezier2::new(p(0, 0), p(2, 0), p(0, 0)).into(),
    ])?;
    Ok([chord_path, source_path])
}

fn strict_interior_algebraic_chord_regions() -> Result<[CurveRegion2; 2], Box<dyn std::error::Error>>
{
    let policy = PredicatePolicy::STRICT;
    let horizontal = RationalBezier2::try_new(vec![p(0, 0), p(1, 0)], vec![Real::one(); 2])?;
    let vertical = RationalBezier2::try_new(
        vec![
            Point2::new(q(5, 8), Real::from(-1_i8)),
            Point2::new(q(5, 8), Real::one()),
        ],
        vec![Real::one(); 2],
    )?;
    let endpoint = |source: &RationalBezier2, numerator, denominator| {
        let parameter = positive_sqrt_ratio_parameter(numerator, denominator, &policy)?;
        Ok::<_, Box<dyn std::error::Error>>(selected_point(source, &parameter, &policy))
    };
    let first_start = endpoint(&horizontal, 1, 2)?;
    let first_end = endpoint(&horizontal, 1, 3)?;
    let second_start = endpoint(&vertical, 2, 5)?;
    let second_end = endpoint(&vertical, 1, 5)?;
    let chord = |start, end| {
        crate::support::under(&policy, || Curve2::try_line(start, end))
            .map(crate::support::Outcome::into_value)
    };
    let first = chord(first_start.clone(), first_end.clone())?;
    let second = chord(second_start.clone(), second_end.clone())?;
    let first_apex = CurvePoint2::from(Point2::new(q(16, 25), Real::from(-1_i8)));
    let second_apex = CurvePoint2::from(Point2::new(Real::one(), q(1, 20)));
    let first_path = CurvePath2::try_new(vec![
        first,
        chord(first_end, first_apex.clone())?,
        chord(first_apex, first_start)?,
    ])?;
    let second_path = CurvePath2::try_new(vec![
        second,
        chord(second_end, second_apex.clone())?,
        chord(second_apex, second_start)?,
    ])?;
    let region = |path| {
        crate::support::under(&policy, || {
            CurveRegion2::try_from_boundary_paths_with_loop_semantics(
                &[path],
                &[CurveRegionLoopRole::Material],
                &[FillRule::NonZero],
            )
        })
        .map(|outcome| outcome.into_value())
    };
    Ok([region(first_path)?, region(second_path)?])
}

fn axis_aligned_algebraic_offset_region() -> Result<CurveRegion2, Box<dyn std::error::Error>> {
    let policy = PredicatePolicy::STRICT;
    let parameter = positive_reciprocal_sqrt_parameter(2, &policy)?;
    let horizontal = |height: Real| {
        RationalBezier2::try_new(
            vec![
                Point2::new(Real::zero(), height.clone()),
                Point2::new(Real::one(), height),
            ],
            vec![Real::one(); 2],
        )
    };
    let bottom_right = selected_point(&horizontal(Real::zero())?, &parameter, &policy);
    let top_right = selected_point(&horizontal(Real::one())?, &parameter, &policy);
    let bottom_left = CurvePoint2::from(p(0, 0));
    let top_left = CurvePoint2::from(p(0, 1));
    let chord = |start, end| {
        crate::support::under(&policy, || Curve2::try_line(start, end))
            .map(crate::support::Outcome::into_value)
    };
    let path = crate::support::under(&policy, || {
        CurvePath2::try_new(vec![
            chord(bottom_left.clone(), bottom_right.clone())?,
            chord(bottom_right, top_right.clone())?,
            chord(top_right, top_left.clone())?,
            chord(top_left, bottom_left)?,
        ])
    })?;
    Ok(crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[path.into_value()],
            &[CurveRegionLoopRole::Material],
            &[FillRule::NonZero],
        )
    })?
    .into_value())
}

fn axis_aligned_algebraic_dumbbell_offset_region()
-> Result<CurveRegion2, Box<dyn std::error::Error>> {
    let policy = PredicatePolicy::STRICT;
    let parameter = positive_reciprocal_sqrt_parameter(2, &policy)?;
    let selected = |height: Real| {
        RationalBezier2::try_new(
            vec![
                Point2::new(Real::from(12_u8), height.clone()),
                Point2::new(Real::from(13_u8), height),
            ],
            vec![Real::one(); 2],
        )
        .map(|curve| selected_point(&curve, &parameter, &policy))
    };
    let exact = |x, y| CurvePoint2::from(p(x, y));
    let points = [
        exact(0, 0),
        exact(4, 0),
        exact(4, 1),
        exact(8, 1),
        exact(8, 0),
        selected(Real::zero())?,
        selected(Real::from(4_u8))?,
        exact(8, 4),
        exact(8, 3),
        exact(4, 3),
        exact(4, 4),
        exact(0, 4),
    ];
    let mut fragments = Vec::with_capacity(points.len());
    for index in 0..points.len() {
        fragments.push(
            crate::support::under(&policy, || {
                Curve2::try_line(
                    points[index].clone(),
                    points[(index + 1) % points.len()].clone(),
                )
            })?
            .into_value(),
        );
    }
    Ok(crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            &[CurvePath2::try_new(fragments)?],
            &[CurveRegionLoopRole::Material],
            &[FillRule::NonZero],
        )
    })?
    .into_value())
}

fn orthogonal_dumbbell_offset_region() -> CurveRegion2 {
    let vertices = [
        (0, 0),
        (4, 0),
        (4, 1),
        (8, 1),
        (8, 0),
        (12, 0),
        (12, 4),
        (8, 4),
        (8, 3),
        (4, 3),
        (4, 4),
        (0, 4),
    ]
    .map(|(x, y)| vertex(x, y, 0));
    let contour = Contour2::from_bulge_vertices(&vertices)
        .expect("native dumbbell benchmark contour must remain exact");
    CurveRegion2::try_from_native_material_contours(vec![contour])
        .expect("native dumbbell benchmark region must remain exact")
}

fn bench_represented_bezier_region_corner_lanes(
    region: &CurveRegion2,
    two_bezier_region: &CurveRegion2,
    iterations: u32,
) {
    let policy = PredicatePolicy::STRICT;
    let next_setback = (s(657).sqrt().expect("positive benchmark radicand") / s(16))
        .expect("nonzero benchmark divisor");
    if corner_lane_enabled("curve_region_line_quadratic_algebraic_chamfer") {
        let started = Instant::now();
        let mut candidates = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(region).chamfer_loop_vertex_by_setbacks(
                    0,
                    1,
                    s(1),
                    s(1),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("algebraic Bezier region chamfer must retain exact carriers")
            .into_value();
            candidates += black_box(solutions).candidate_count();
        }
        assert_ne!(candidates, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_line_quadratic_algebraic_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), candidates={candidates}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_two_quadratic_algebraic_chamfer") {
        let started = Instant::now();
        let mut candidates = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(two_bezier_region).chamfer_loop_vertex_by_setbacks(
                    0,
                    1,
                    s(1),
                    s(1),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("two algebraic Bezier cuts must retain one exact chord")
            .into_value();
            candidates += black_box(solutions).candidate_count();
        }
        assert_ne!(candidates, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_two_quadratic_algebraic_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), candidates={candidates}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_line_quadratic_algebraic_regularize") {
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            region.chamfer_loop_vertex_by_setbacks(0, 1, s(1), s(1), CurveCornerMode2::TrimOnly)
        })
        .expect("algebraic Bezier region chamfer must retain exact carriers")
        .into_value() else {
            panic!("algebraic Bezier region chamfer must be unique");
        };
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let regularized =
                crate::support::under(&policy, || black_box(&chamfered).regularized_region())
                    .expect("one-field algebraic chamfer regularization must remain exact")
                    .into_value();
            fragments += black_box(&regularized).boundary_loops()[0].curves().len();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_line_quadratic_algebraic_regularize: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_source_related_algebraic_chord_regularization_reuse") {
        let retained = source_related_algebraic_chord_region()
            .expect("source-related algebraic chord benchmark fixture must remain exact");
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let regularized =
                crate::support::under(&policy, || black_box(&retained).regularized_region())
                    .expect("source-related algebraic chord regularization must remain exact")
                    .into_value();
            fragments += black_box(&regularized)
                .boundary_loops()
                .iter()
                .map(|boundary| boundary.len())
                .sum::<usize>();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_source_related_algebraic_chord_regularization_reuse: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_independent_field_algebraic_chord_boolean") {
        let [chord_region, source_region] = independent_field_algebraic_chord_regions()
            .expect("independent-field Boolean benchmark fixture must remain exact");
        let started = Instant::now();
        let mut topology_fragments = 0_usize;
        for _ in 0..iterations {
            let results = crate::support::under(&policy, || {
                black_box(&chord_region).boolean_regions(black_box(&source_region))
            })
            .expect("independent-field algebraic chord Boolean must remain exact")
            .into_value();
            topology_fragments += black_box(&results).topology_fragment_count();
        }
        assert_ne!(topology_fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_independent_field_algebraic_chord_boolean: {iterations} iterations in {elapsed:?} ({:?}/iter), topology fragments={topology_fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_path_noninjective_collinear_algebraic_chord_intersection") {
        let [chord_path, source_path] = noninjective_collinear_algebraic_chord_paths()
            .expect("noninjective collinear intersection fixture must remain exact");
        let started = Instant::now();
        let mut evidence_count = 0_usize;
        for _ in 0..iterations {
            let evidence = crate::support::under(&policy, || {
                black_box(&chord_path).intersect_path(black_box(&source_path))
            })
            .expect("noninjective collinear chord intersection must remain exact")
            .into_value();
            assert!(evidence.is_complete(), "{evidence:?}");
            evidence_count += evidence.contacts().len() + evidence.overlaps().len();
        }
        assert_ne!(evidence_count, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_path_noninjective_collinear_algebraic_chord_intersection: {iterations} iterations in {elapsed:?} ({:?}/iter), evidence={evidence_count}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_strict_interior_algebraic_chord_boolean") {
        let [first, second] = strict_interior_algebraic_chord_regions()
            .expect("strict-interior algebraic chord benchmark fixture must remain exact");
        let started = Instant::now();
        let mut topology_fragments = 0_usize;
        for _ in 0..iterations {
            let results = crate::support::under(&policy, || {
                black_box(&first).boolean_regions(black_box(&second))
            })
            .expect("strict-interior algebraic chord Boolean must remain exact")
            .into_value();
            topology_fragments += black_box(&results).topology_fragment_count();
        }
        assert_ne!(topology_fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_strict_interior_algebraic_chord_boolean: {iterations} iterations in {elapsed:?} ({:?}/iter), topology fragments={topology_fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_axis_algebraic_miter_offset") {
        let source = axis_aligned_algebraic_offset_region()
            .expect("axis-aligned offset benchmark fixture must remain exact");
        let style = OffsetCornerStyle2::Miter {
            limit: Real::from(2_u8),
        };
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let offset = crate::support::under(&policy, || {
                black_box(&source).offset(q(1, 10), black_box(&style))
            })
            .expect("axis-aligned algebraic offset must remain exact")
            .into_value();
            fragments += black_box(&offset).boundary_loops()[0].len();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_axis_algebraic_miter_offset: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_axis_algebraic_round_offset") {
        let source = axis_aligned_algebraic_offset_region()
            .expect("axis-aligned round-offset benchmark fixture must remain exact");
        let style = OffsetCornerStyle2::Round;
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let offset = crate::support::under(&policy, || {
                black_box(&source).offset(q(1, 10), black_box(&style))
            })
            .expect("axis-aligned algebraic round offset must remain exact")
            .into_value();
            fragments += black_box(&offset).boundary_loops()[0].len();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_axis_algebraic_round_offset: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_axis_algebraic_repeated_miter_offset") {
        let source = axis_aligned_algebraic_offset_region()
            .expect("axis-aligned repeated-offset benchmark fixture must remain exact");
        let style = OffsetCornerStyle2::Miter {
            limit: Real::from(2_u8),
        };
        let expanded = crate::support::under(&policy, || source.offset(q(1, 10), &style))
            .expect("first algebraic benchmark offset must remain exact")
            .into_value();
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let offset = crate::support::under(&policy, || {
                black_box(&expanded).offset(q(1, 10), black_box(&style))
            })
            .expect("repeated algebraic offset must remain exact")
            .into_value();
            fragments += black_box(&offset).boundary_loops()[0].len();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_axis_algebraic_repeated_miter_offset: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_axis_algebraic_neck_split") {
        let source = axis_aligned_algebraic_dumbbell_offset_region()
            .expect("algebraic dumbbell benchmark fixture must remain exact");
        let style = OffsetCornerStyle2::Miter {
            limit: Real::from(2_u8),
        };
        assert_eq!(
            crate::support::under(&policy, || source.offset(-q(3, 2), &style))
                .expect("algebraic dumbbell erosion must split exactly")
                .into_value()
                .boundary_loops()
                .len(),
            2,
        );
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let offset = crate::support::under(&policy, || {
                black_box(&source).offset(-q(3, 2), black_box(&style))
            })
            .expect("algebraic dumbbell erosion must split exactly")
            .into_value();
            fragments += black_box(&offset)
                .boundary_loops()
                .iter()
                .map(|boundary| boundary.len())
                .sum::<usize>();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_axis_algebraic_neck_split: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_native_orthogonal_neck_split") {
        let source = orthogonal_dumbbell_offset_region();
        let style = OffsetCornerStyle2::Miter {
            limit: Real::from(2_u8),
        };
        assert_eq!(
            crate::support::under(&policy, || source.offset(-q(3, 2), &style))
                .expect("native dumbbell erosion must split exactly")
                .into_value()
                .boundary_loops()
                .len(),
            2,
        );
        let started = Instant::now();
        let mut fragments = 0_usize;
        for _ in 0..iterations {
            let offset = crate::support::under(&policy, || {
                black_box(&source).offset(-q(3, 2), black_box(&style))
            })
            .expect("native dumbbell erosion must split exactly")
            .into_value();
            fragments += black_box(&offset)
                .boundary_loops()
                .iter()
                .map(|boundary| boundary.len())
                .sum::<usize>();
        }
        assert_ne!(fragments, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_native_orthogonal_neck_split: {iterations} iterations in {elapsed:?} ({:?}/iter), fragments={fragments}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_two_quadratic_algebraic_disjoint_boolean") {
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            two_bezier_region.chamfer_loop_vertex_by_setbacks(
                0,
                1,
                s(1),
                s(1),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("two algebraic Bezier cuts must retain one exact chord")
        .into_value() else {
            panic!("two-Bezier algebraic region chamfer must be unique");
        };
        let distant = crate::support::under(&policy, || {
            CurveRegion2::try_from_native_material_contours(vec![rectangle(10, 10, 12, 12)])
        })
        .expect("distant Boolean benchmark region must remain exact")
        .into_value();
        let started = Instant::now();
        let mut loops = 0_usize;
        for _ in 0..iterations {
            let results = crate::support::under(&policy, || {
                black_box(&chamfered).boolean_regions(black_box(&distant))
            })
            .expect("disjoint algebraic chamfer Boolean must remain exact")
            .into_value();
            loops += black_box(&results).union().boundary_loops().len();
        }
        assert_ne!(loops, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_two_quadratic_algebraic_disjoint_boolean: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={loops}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_line_quadratic_design_chamfer") {
        let started = Instant::now();
        let mut candidates = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(region).chamfer_loop_vertex_by_setbacks(
                    0,
                    1,
                    s(1),
                    next_setback.clone(),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("represented Bezier region chamfer must remain exact")
            .into_value();
            candidates += black_box(solutions).candidate_count();
        }
        assert_ne!(candidates, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_line_quadratic_design_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), candidates={candidates}",
            elapsed / iterations
        );
    }
    if corner_lane_enabled("curve_region_line_quadratic_design_fillet") {
        let started = Instant::now();
        let mut candidates = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(region).fillet_loop_vertex(
                    0,
                    1,
                    &hypercurve::CurveFillet2::new(q(15, 4)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("represented Bezier region fillet must remain exact")
            .into_value();
            candidates += black_box(solutions.solutions()).len();
        }
        assert_ne!(candidates, 0);
        let elapsed = started.elapsed();
        println!(
            "curve_region_line_quadratic_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), candidates={candidates}",
            elapsed / iterations
        );
    }
}

fn bench_represented_bezier_corner_solvers(iterations: u32) -> CurveResult<()> {
    let quadratic = QuadraticBezier2::new(p(0, 0), p(0, 1), p(1, 2));
    let quadratic_controls = quadratic
        .control_points()
        .into_iter()
        .cloned()
        .collect::<Vec<_>>();
    let quadratic_knots = vec![s(2), s(2), s(2), s(5), s(5), s(5)];
    let rational = RationalBezier2::try_new(quadratic_controls.clone(), vec![s(1), s(1), s(1)])?
        .elevated_to_degree(5)
        .expect("benchmark degree elevation must remain exact");
    let line_quadratic = CurvePath2::try_new(vec![
        Curve2::from(line(-4, 0, 0, 0)),
        Curve2::from(quadratic.clone()),
    ])
    .expect("line/quadratic benchmark path must remain exact");
    let line_rational = CurvePath2::try_new(vec![
        Curve2::from(line(-4, 0, 0, 0)),
        Curve2::from(rational),
    ])
    .expect("line/rational benchmark path must remain exact");
    let line_polynomial_spline = CurvePath2::try_new(vec![
        Curve2::from(line(-4, 0, 0, 0)),
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_polynomial_bspline(2, quadratic_controls.clone(), quadratic_knots.clone())
        })
        .expect("polynomial spline benchmark carrier must remain exact")
        .into_value(),
    ])
    .expect("line/polynomial-spline benchmark path must remain exact");
    let line_nurbs = CurvePath2::try_new(vec![
        Curve2::from(line(-4, 0, 0, 0)),
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_nurbs(
                2,
                quadratic_controls,
                vec![s(1), s(1), s(1)],
                quadratic_knots,
            )
        })
        .expect("NURBS benchmark carrier must remain exact")
        .into_value(),
    ])
    .expect("line/NURBS benchmark path must remain exact");
    let cubic_ph_pair = CurvePath2::try_new(vec![
        Curve2::from(hypercurve::CubicBezier2::new(
            p(-4, 0),
            Point2::new(-q(8, 3), s(0)),
            Point2::new(-q(4, 3), s(0)),
            p(0, 0),
        )),
        Curve2::from(hypercurve::CubicBezier2::new(
            p(0, 0),
            Point2::new(s(0), q(4, 3)),
            Point2::new(s(0), q(8, 3)),
            p(0, 4),
        )),
    ])
    .expect("exact PH cubic benchmark path must remain exact");
    let spline_ph_pair = CurvePath2::try_new(vec![
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_polynomial_bspline(
                3,
                vec![
                    p(-4, 0),
                    Point2::new(-q(8, 3), s(0)),
                    Point2::new(-q(4, 3), s(0)),
                    p(0, 0),
                ],
                vec![s(2), s(2), s(2), s(2), s(5), s(5), s(5), s(5)],
            )
        })
        .expect("polynomial PH spline benchmark carrier must remain exact")
        .into_value(),
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_nurbs(
                3,
                vec![
                    p(0, 0),
                    Point2::new(s(0), q(4, 3)),
                    Point2::new(s(0), q(8, 3)),
                    p(0, 4),
                ],
                vec![s(1), s(1), s(1), s(1)],
                vec![s(7), s(7), s(7), s(7), s(11), s(11), s(11), s(11)],
            )
        })
        .expect("NURBS PH spline benchmark carrier must remain exact")
        .into_value(),
    ])
    .expect("exact PH spline benchmark path must remain exact");
    let source_center = Point2::new(-q(7, 16), q(207, 512));
    let source_start = Point2::new(-q(7, 16), -q(49, 256));
    let arc_quadratic = CurvePath2::try_new(vec![
        Curve2::from(CircularArc2::try_from_center(
            source_start,
            p(0, 0),
            source_center,
            true,
        )?),
        Curve2::from(quadratic.clone()),
    ])
    .expect("arc/quadratic benchmark path must remain exact");
    let region_path = CurvePath2::try_new(vec![
        Curve2::from(line(-4, 0, 0, 0)),
        Curve2::from(quadratic),
        Curve2::from(line(1, 2, -4, 2)),
        Curve2::from(line(-4, 2, -4, 0)),
    ])
    .expect("region benchmark path must remain exact");
    let region =
        CurveRegion2::try_from_boundary_paths(&[region_path], hypercurve::FillRule::EvenOdd)
            .expect("represented Bezier benchmark region must remain exact");
    let two_bezier_region_path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(p(-1, 2), p(0, 1), p(0, 0))),
        Curve2::from(QuadraticBezier2::new(p(0, 0), p(0, 1), p(1, 2))),
        Curve2::from(line(1, 2, -1, 2)),
    ])
    .expect("two-Bezier region benchmark path must remain exact");
    let two_bezier_region = CurveRegion2::try_from_boundary_paths(
        &[two_bezier_region_path],
        hypercurve::FillRule::EvenOdd,
    )
    .expect("two-Bezier benchmark region must remain exact");
    let next_setback = (s(657).sqrt()? / s(16))?;

    bench_represented_bezier_chamfer_lane(
        "curve_path_line_quadratic_design_chamfer",
        &line_quadratic,
        &s(1),
        &next_setback,
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_line_quadratic_design_fillet",
        &line_quadratic,
        &q(15, 4),
        iterations,
    );
    bench_represented_bezier_chamfer_lane(
        "curve_path_line_degree5_rational_design_chamfer",
        &line_rational,
        &s(1),
        &next_setback,
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_line_degree5_rational_design_fillet",
        &line_rational,
        &q(15, 4),
        iterations,
    );
    bench_represented_bezier_chamfer_lane(
        "curve_path_line_polynomial_spline_design_chamfer",
        &line_polynomial_spline,
        &s(1),
        &next_setback,
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_line_polynomial_spline_design_fillet",
        &line_polynomial_spline,
        &q(15, 4),
        iterations,
    );
    bench_represented_bezier_chamfer_lane(
        "curve_path_line_nurbs_design_chamfer",
        &line_nurbs,
        &s(1),
        &next_setback,
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_line_nurbs_design_fillet",
        &line_nurbs,
        &q(15, 4),
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_arc_quadratic_design_fillet",
        &arc_quadratic,
        &q(5, 4),
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_cubic_ph_pair_design_fillet",
        &cubic_ph_pair,
        &s(1),
        iterations,
    );
    bench_represented_bezier_fillet_lane(
        "curve_path_polynomial_spline_nurbs_ph_pair_design_fillet",
        &spline_ph_pair,
        &s(1),
        iterations,
    );
    bench_represented_bezier_region_corner_lanes(&region, &two_bezier_region, iterations);
    Ok(())
}

fn bench_arc_extension(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![Segment2::Arc(CircularArc2::try_from_center(
        p(1, 0),
        p(0, 1),
        p(0, 0),
        false,
    )?)])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            curve.extend_endpoint_to_point(CurveStringEndpoint2::End, p(-1, 0))
        })
        .expect("benchmark fixture remains exact");
        let Classification::Decided(extended) = result else {
            panic!("arc extension benchmark became uncertain");
        };
        total_segments += black_box(extended.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_arc_extension: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_curve_string_line_merge_evidence(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![
        line_segment(0, 0, 2, 0),
        line_segment(2, 0, 5, 0),
        line_segment(5, 0, 5, 3),
        line_segment(5, 3, 5, 7),
    ])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_spans = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            curve.merge_adjacent_collinear_lines()
        })
        .expect("benchmark fixture remains exact");
        let Classification::Decided(merged) = result else {
            panic!("curve string line merge benchmark became uncertain");
        };
        total_spans += black_box(merged.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_line_merge_evidence: {iterations} iterations in {elapsed:?} ({:?}/iter), total spans={total_spans}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_curve_string_reversed_duplicate_evidence(iterations: u32) -> CurveResult<()> {
    let curve = CurveString2::try_new(vec![
        line_segment(0, 0, 2, 0),
        line_segment(2, 0, 4, 0),
        line_segment(4, 0, 2, 0),
        line_segment(2, 0, 2, 2),
    ])?;
    let started = Instant::now();
    let mut total_retained = 0_usize;

    for _ in 0..iterations {
        let result = curve.remove_adjacent_reversed_duplicates()?;
        let Classification::Decided(deduped) = result else {
            panic!("curve string reversed duplicate benchmark became uncertain");
        };
        total_retained += black_box(deduped.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_reversed_duplicate_evidence: {iterations} iterations in {elapsed:?} ({:?}/iter), total retained={total_retained}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_curve_string_pair_link_evidence(iterations: u32) -> CurveResult<()> {
    let first = CurveString2::try_new(vec![line_segment(0, 0, 1, 0)])?;
    let second = CurveString2::try_new(vec![line_segment(1, 0, 2, 0)])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let Classification::Decided(Some(linked)) =
            crate::support::under_classified_result(&policy, || {
                first.link_connected_endpoints(&second)
            })
            .expect("benchmark fixture remains exact")
        else {
            panic!("pair link benchmark should materialize");
        };
        total_segments += black_box(linked.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_pair_link_evidence: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_curve_string_ordered_link_evidence(iterations: u32) -> CurveResult<()> {
    let curves = vec![
        CurveString2::try_new(vec![line_segment(0, 0, 1, 0)])?,
        CurveString2::try_new(vec![line_segment(1, 0, 2, 0)])?,
        CurveString2::try_new(vec![line_segment(2, 0, 3, 0)])?,
    ];
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            CurveString2::link_ordered_connected_endpoints(curves.clone())
        })
        .expect("benchmark fixture remains exact");
        let linked = expect_decided(result, "ordered link benchmark should materialize");
        total_segments += black_box(linked.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_ordered_link: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_curve_string_connect_evidence(iterations: u32) -> CurveResult<()> {
    let first = CurveString2::try_new(vec![line_segment(0, 0, 1, 0)])?;
    let second = CurveString2::try_new(vec![line_segment(3, 1, 4, 1)])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_segments = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            first.connect_end_to_start_with_line(&second)
        })
        .expect("benchmark fixture remains exact");
        let connected = expect_decided(result, "connect benchmark should materialize");
        total_segments += black_box(connected.len());
    }

    let elapsed = started.elapsed();
    println!(
        "curve_string_connect_evidence: {iterations} iterations in {elapsed:?} ({:?}/iter), total segments={total_segments}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_boundary_contour_region_build(iterations: u32) -> CurveResult<()> {
    let material = rectangle(0, 0, 10, 10);
    let hole = rectangle(2, 2, 8, 8);
    let island = rectangle(4, 4, 6, 6);
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_roles = 0_usize;

    for _ in 0..iterations {
        let region = crate::support::under(&policy, || {
            CurveRegion2::try_from_native_boundary_contours(
                &[material.clone(), hole.clone(), island.clone()],
                FillRule::EvenOdd,
            )
        })
        .expect("native boundary construction must evaluate")
        .into_value();
        total_roles += black_box(region.len());
    }

    let elapsed = started.elapsed();
    println!(
        "boundary_contour_region_build: {iterations} iterations in {elapsed:?} ({:?}/iter), total roles={total_roles}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_unordered_line_segment_region_build(iterations: u32) -> CurveResult<()> {
    let segments = vec![
        Segment2::Line(line(0, 0, 10, 0)),
        Segment2::Line(line(0, 10, 10, 10)),
        Segment2::Line(line(0, 0, 0, 10)),
        Segment2::Line(line(10, 0, 10, 10)),
    ];
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_loops = 0_usize;
    let mut total_spans = 0_usize;
    for _ in 0..iterations {
        let region = crate::support::under(&policy, || {
            CurveRegion2::arrange_unordered_segments(&segments, FillRule::NonZero)
        })
        .expect("native arrangement must produce an exact region")
        .into_value();
        total_loops += black_box(region.len());
        total_spans += black_box(
            region
                .boundary_loops()
                .iter()
                .map(|loop_| loop_.len())
                .sum::<usize>(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "unordered_line_segment_region_build: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={total_loops}, spans={total_spans}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_unordered_native_segment_region_build(iterations: u32) -> CurveResult<()> {
    let segments = vec![
        Segment2::Line(line(4, 0, 0, 0)),
        Segment2::Arc(CircularArc2::from_bulge(p(0, 0), p(4, 0), s(1))?),
    ];
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_loops = 0_usize;
    let mut total_spans = 0_usize;
    for _ in 0..iterations {
        let region = crate::support::under(&policy, || {
            CurveRegion2::arrange_unordered_segments(&segments, FillRule::NonZero)
        })
        .expect("native arrangement must produce an exact region")
        .into_value();
        total_loops += black_box(region.len());
        total_spans += black_box(
            region
                .boundary_loops()
                .iter()
                .map(|loop_| loop_.len())
                .sum::<usize>(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "unordered_native_segment_region_build: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={total_loops}, spans={total_spans}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_contour_line_merge_evidence(iterations: u32) -> CurveResult<()> {
    let contour = Contour2::from_bulge_vertices(&[
        vertex(0, 0, 0),
        vertex(2, 0, 0),
        vertex(5, 0, 0),
        vertex(5, 3, 0),
        vertex(5, 7, 0),
        vertex(0, 7, 0),
    ])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_spans = 0_usize;

    for _ in 0..iterations {
        let result = crate::support::under_classified_result(&policy, || {
            contour.merge_adjacent_collinear_lines()
        })
        .expect("benchmark fixture remains exact");
        let Classification::Decided(merged) = result else {
            panic!("contour line merge benchmark became uncertain");
        };
        total_spans += black_box(merged.len());
    }

    let elapsed = started.elapsed();
    println!(
        "contour_line_merge_evidence: {iterations} iterations in {elapsed:?} ({:?}/iter), total spans={total_spans}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_region_boolean(iterations: u32) -> CurveResult<()> {
    let policy = PredicatePolicy::STRICT;
    let first = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![rectangle(0, 0, 4, 4)])
    })
    .expect("benchmark region is valid")
    .into_value();
    let second = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![rectangle(2, -1, 6, 3)])
    })
    .expect("benchmark region is valid")
    .into_value();
    let started = Instant::now();
    let mut total_boundary_contours = 0_usize;

    for _ in 0..iterations {
        let result =
            crate::support::under(&policy, || first.boolean_region(&second, BooleanOp::Union))
                .expect("region Boolean benchmark remains exact")
                .into_value();
        total_boundary_contours += black_box(result.len());
    }

    let elapsed = started.elapsed();
    println!(
        "region_boolean: {iterations} iterations in {elapsed:?} ({:?}/iter), total boundary contours={total_boundary_contours}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_contour_signed_area_cache(iterations: u32) -> CurveResult<()> {
    let contour = subdivided_rectangle(64);
    let clone = contour.clone();
    let cold_started = Instant::now();
    let cold_area = contour.signed_area()?;
    let cold_elapsed = cold_started.elapsed();
    let replay_started = Instant::now();
    let mut replay_count = 0_usize;

    for _ in 0..iterations {
        replay_count += black_box(clone.signed_area()?.is_some()) as usize;
    }

    let replay_elapsed = replay_started.elapsed();
    println!(
        "contour_signed_area_cache: cold={cold_elapsed:?}, {iterations} retained clone replays in {replay_elapsed:?} ({:?}/replay), area={}, replay count={replay_count}",
        replay_elapsed / iterations,
        cold_area.is_some(),
    );
    Ok(())
}

fn bench_curve_region_mutations(iterations: u32) -> CurveResult<()> {
    let policy = PredicatePolicy::STRICT;
    let region = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![rectangle(0, 0, 4, 4)])
    })
    .expect("benchmark rectangle must promote")
    .into_value();

    if corner_lane_enabled("curve_region_affine_transform") {
        let started = Instant::now();
        let mut transformed_loops = 0_usize;
        for _ in 0..iterations {
            let transformed = crate::support::under(&policy, || {
                black_box(&region).transform_affine(
                    &Real::zero(),
                    &-Real::one(),
                    &Real::one(),
                    &Real::zero(),
                    &Real::zero(),
                    &Real::zero(),
                )
            })
            .expect("benchmark transform must remain exact")
            .into_value();
            transformed_loops += black_box(transformed).boundary_loops().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_region_affine_transform: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={transformed_loops}",
            elapsed / iterations
        );
    }

    if corner_lane_enabled("curve_region_design_chamfer") {
        let started = Instant::now();
        let mut chamfered_loops = 0_usize;
        for _ in 0..iterations {
            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                black_box(&region).chamfer_loop_vertex_by_setbacks(
                    0,
                    1,
                    s(1),
                    s(1),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("benchmark design-parameter chamfer must remain exact")
            .into_value() else {
                panic!("CurveRegion2 design-parameter chamfer benchmark must be unique");
            };
            chamfered_loops += black_box(chamfered).boundary_loops().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_region_design_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={chamfered_loops}",
            elapsed / iterations
        );
    }

    if corner_lane_enabled("curve_region_design_fillet") {
        let started = Instant::now();
        let mut filleted_loops = 0_usize;
        for _ in 0..iterations {
            let solutions = crate::support::under(&policy, || {
                black_box(&region).fillet_loop_vertex(
                    0,
                    1,
                    &hypercurve::CurveFillet2::new(s(1)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .expect("benchmark design-parameter fillet must remain exact")
            .into_value();
            let [filleted] = solutions.solutions() else {
                panic!("expected one isolated fillet");
            };
            filleted_loops += black_box(filleted).boundary_loops().len();
        }
        let elapsed = started.elapsed();
        println!(
            "curve_region_design_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={filleted_loops}",
            elapsed / iterations
        );
    }
    Ok(())
}

fn bench_higher_order_curve_edits(iterations: u32) {
    let policy = PredicatePolicy::STRICT;
    let path = higher_order_fillet_path();
    let region = crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            std::slice::from_ref(&path),
            &[CurveRegionLoopRole::Material],
            &[FillRule::NonZero],
        )
    })
    .expect("higher-order editing benchmark region must promote")
    .into_value();

    let started = Instant::now();
    let mut region_chamfer_loops = 0_usize;
    for _ in 0..iterations {
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            region.chamfer_loop_vertex_by_setbacks(
                0,
                1,
                q(1, 2),
                q(1, 2),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("higher-order region chamfer must remain exact")
        .into_value() else {
            panic!("higher-order region chamfer benchmark must remain unique");
        };
        region_chamfer_loops += black_box(chamfered.boundary_loops().len());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_higher_order_chamfer: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={region_chamfer_loops}",
        elapsed / iterations
    );

    let started = Instant::now();
    let mut region_fillet_loops = 0_usize;
    for _ in 0..iterations {
        let filleted = crate::support::under(&policy, || {
            region.fillet_loop_vertex(
                0,
                1,
                &hypercurve::CurveFillet2::new(q(1, 2)),
                CurveCornerMode2::TrimOnly,
            )
        })
        .expect("higher-order region fillet must remain exact")
        .into_value();
        assert!(!filleted.solutions().is_empty());
        region_fillet_loops += black_box(filleted.solutions())
            .iter()
            .map(|candidate| candidate.boundary_loops().len())
            .sum::<usize>();
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_higher_order_fillet: {iterations} iterations in {elapsed:?} ({:?}/iter), loops={region_fillet_loops}",
        elapsed / iterations
    );
}

fn main() -> CurveResult<()> {
    let iterations = benchmark_iterations();
    if let Some(selection) = std::env::var_os("HYPERCURVE_EDIT_BENCH") {
        if selection == "higher-order" {
            bench_higher_order_curve_edits(iterations);
            return Ok(());
        }
        if selection == "corner-solver" {
            bench_line_curve_corner_solvers(iterations);
            bench_curve_region_mutations(iterations)?;
            return Ok(());
        }
        if selection == "native-arc-chamfer" {
            bench_native_arc_chamfer_solvers(iterations)?;
            return Ok(());
        }
        if selection == "native-arc-fillet" {
            bench_native_arc_fillet_solvers(iterations)?;
            return Ok(());
        }
        if selection == "retained-circle-corner" {
            bench_retained_circle_corner_solvers(iterations)?;
            return Ok(());
        }
        if selection == "represented-bezier-corner" {
            bench_represented_bezier_corner_solvers(iterations)?;
            return Ok(());
        }
    }
    bench_parameter_trim(iterations)?;
    bench_parameter_arc_trim(iterations)?;
    bench_point_arc_trim(iterations)?;
    bench_curve_intersection_trim(iterations)?;
    bench_region_trim(iterations)?;
    bench_line_curve_corner_solvers(iterations);
    bench_native_arc_chamfer_solvers(iterations)?;
    bench_native_arc_fillet_solvers(iterations)?;
    bench_retained_circle_corner_solvers(iterations)?;
    bench_represented_bezier_corner_solvers(iterations)?;
    bench_curve_region_mutations(iterations)?;
    bench_higher_order_curve_edits(iterations);
    bench_arc_extension(iterations)?;
    bench_curve_string_line_merge_evidence(iterations)?;
    bench_curve_string_reversed_duplicate_evidence(iterations)?;
    bench_curve_string_pair_link_evidence(iterations)?;
    bench_curve_string_ordered_link_evidence(iterations)?;
    bench_curve_string_connect_evidence(iterations)?;
    bench_boundary_contour_region_build(1_000)?;
    bench_unordered_line_segment_region_build(1_000)?;
    bench_unordered_native_segment_region_build(1_000)?;
    bench_contour_line_merge_evidence(1_000)?;
    bench_contour_signed_area_cache(100_000)?;
    bench_region_boolean(1_000)?;
    Ok(())
}
