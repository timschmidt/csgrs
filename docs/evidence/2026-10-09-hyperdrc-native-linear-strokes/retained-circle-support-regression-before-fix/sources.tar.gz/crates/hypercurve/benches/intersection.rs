#[path = "../tests/support/mod.rs"]
mod support;
use std::hint::black_box;
use std::time::Instant;

use hypercurve::{
    ArcArcIntersection, BulgeVertex2, CircleCircleRelation, CircularArc2, Classification, Contour2,
    CurveRegion2, CurveResult, CurveString2, LineCircleRelation, LineSeg2, Point2, PredicatePolicy,
    Real, Segment2,
};

fn s(value: i32) -> Real {
    value.into()
}

fn p(x: i32, y: i32) -> Point2 {
    Point2::new(s(x), s(y))
}

fn vertex(x: i32, y: i32, bulge: i32) -> BulgeVertex2 {
    BulgeVertex2::new(p(x, y), s(bulge))
}

fn rectangle(xmin: i32, ymin: i32, xmax: i32, ymax: i32) -> Contour2 {
    Contour2::from_bulge_vertices(&[
        vertex(xmin, ymin, 0),
        vertex(xmax, ymin, 0),
        vertex(xmax, ymax, 0),
        vertex(xmin, ymax, 0),
    ])
    .unwrap()
}

fn arc(start: Point2, end: Point2, center: Point2, clockwise: bool) -> CircularArc2 {
    CircularArc2::try_from_center(start, end, center, clockwise).unwrap()
}

fn line_segment(start: Point2, end: Point2) -> Segment2 {
    Segment2::Line(LineSeg2::try_new(start, end).unwrap())
}

fn bench_arc_arc_case(
    name: &str,
    first: &CircularArc2,
    second: &CircularArc2,
    iterations: u32,
) -> CurveResult<()> {
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_weight = 0_usize;

    for _ in 0..iterations {
        let weight = match crate::support::under_value(&policy, || first.intersect_arc(second))
            .expect("benchmark fixture remains exact")
        {
            ArcArcIntersection::None => 0,
            ArcArcIntersection::Point(_) => 1,
            ArcArcIntersection::TwoPoints { .. } => 2,
            ArcArcIntersection::Overlap { .. } => 3,
            ArcArcIntersection::Uncertain { reason } => {
                panic!("{name} became uncertain during benchmark: {reason:?}");
            }
        };
        total_weight += black_box(weight);
    }

    let elapsed = started.elapsed();
    println!(
        "{name}: {iterations} iterations in {elapsed:?} ({:?}/iter), total weight={total_weight}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_line_circle_relation(iterations: u32) -> CurveResult<()> {
    let line = LineSeg2::try_new(p(-100, 0), p(100, 0))?;
    let circle = arc(p(25, 0), p(-25, 0), p(0, 0), false);
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_weight = 0_usize;

    for _ in 0..iterations {
        let weight = match crate::support::under_value(&policy, || {
            line.supporting_line_circle_relation(&circle)
        })
        .expect("benchmark fixture remains exact")
        {
            LineCircleRelation::Disjoint => 0,
            LineCircleRelation::Tangent { .. } => 1,
            LineCircleRelation::Secant { .. } => 2,
            LineCircleRelation::Uncertain { reason } => {
                panic!("line_circle_relation became uncertain during benchmark: {reason:?}");
            }
        };
        total_weight += black_box(weight);
    }

    let elapsed = started.elapsed();
    println!(
        "line_circle_relation_secant: {iterations} iterations in {elapsed:?} ({:?}/iter), total weight={total_weight}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_circle_circle_relation(iterations: u32) -> CurveResult<()> {
    let first = arc(p(4, 3), p(4, -3), p(0, 0), true);
    let second = arc(p(4, -3), p(4, 3), p(8, 0), true);
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_weight = 0_usize;

    for _ in 0..iterations {
        let weight = match crate::support::under_value(&policy, || first.circle_relation(&second))
            .expect("benchmark fixture remains exact")
        {
            CircleCircleRelation::Coincident => 3,
            CircleCircleRelation::Disjoint => 0,
            CircleCircleRelation::Tangent { .. } => 1,
            CircleCircleRelation::Secant { .. } => 2,
            CircleCircleRelation::Uncertain { reason } => {
                panic!("circle_circle_relation became uncertain during benchmark: {reason:?}");
            }
        };
        total_weight += black_box(weight);
    }

    let elapsed = started.elapsed();
    println!(
        "circle_circle_relation_secant: {iterations} iterations in {elapsed:?} ({:?}/iter), total weight={total_weight}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_sparse_curve_self_contacts(segment_count: i32, iterations: u32) -> CurveResult<()> {
    let mut segments = Vec::with_capacity(segment_count as usize);
    let mut previous = p(0, 0);
    for index in 1..=segment_count {
        let next_y = if index % 2 == 0 { 0 } else { 1 };
        let next = p(index * 3, next_y);
        segments.push(line_segment(previous, next.clone()));
        previous = next;
    }

    let curve = CurveString2::try_new(segments)?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut decided_false_count = 0_usize;

    for _ in 0..iterations {
        match crate::support::under_classified_result(&policy, || curve.has_self_contacts())
            .expect("benchmark fixture remains exact")
        {
            Classification::Decided(false) => {
                decided_false_count += black_box(1);
            }
            Classification::Decided(true) => {
                panic!("sparse benchmark curve unexpectedly self-contacted");
            }
            Classification::Uncertain(reason) => {
                panic!("sparse benchmark curve became uncertain: {reason:?}");
            }
        }
    }

    let elapsed = started.elapsed();
    println!(
        "sparse_curve_self_contacts_{segment_count}: {iterations} iterations in {elapsed:?} ({:?}/iter), decided_false={decided_false_count}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_sparse_curve_string_intersections(segment_count: i32, iterations: u32) -> CurveResult<()> {
    let mut segments = Vec::with_capacity(segment_count as usize);
    let mut previous = p(0, 0);
    for index in 1..=segment_count {
        let next_y = if index % 2 == 0 { 0 } else { 1 };
        let next = p(index * 3, next_y);
        segments.push(line_segment(previous, next.clone()));
        previous = next;
    }

    let curve = CurveString2::try_new(segments)?;
    let cutter = CurveString2::try_new(vec![line_segment(p(241, -2), p(241, 3))])?;
    let policy = PredicatePolicy::STRICT;
    let started = Instant::now();
    let mut total_events = 0_usize;

    for _ in 0..iterations {
        let events = crate::support::under_value(&policy, || curve.intersect_curve_string(&cutter))
            .expect("benchmark fixture remains exact");
        if events.len() != 1 {
            panic!("sparse curve-string benchmark expected one segment-pair event");
        }
        total_events += black_box(events.len());
    }

    let elapsed = started.elapsed();
    println!(
        "sparse_curve_string_intersections_{segment_count}: {iterations} iterations in {elapsed:?} ({:?}/iter), total events={total_events}",
        elapsed / iterations
    );
    Ok(())
}

fn bench_sparse_region_events(
    contour_count: i32,
    iterations: u32,
) -> Result<(), Box<dyn std::error::Error>> {
    let mut contours = Vec::with_capacity(contour_count as usize);
    for index in 0..contour_count {
        let x = index * 10;
        contours.push(rectangle(x, 0, x + 4, 4));
    }
    let policy = PredicatePolicy::STRICT;
    let region = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(contours)
    })?
    .into_value();
    let cutter = crate::support::under(&policy, || {
        CurveRegion2::try_from_native_material_contours(vec![rectangle(12, -1, 18, 5)])
    })?
    .into_value();
    let started = Instant::now();
    let mut total_pairs = 0_usize;

    for _ in 0..iterations {
        let evidence =
            crate::support::under(&policy, || region.intersect_region(&cutter))?.into_value();
        if !evidence.is_complete() {
            panic!("sparse unified-region benchmark returned incomplete evidence");
        }
        total_pairs += black_box(evidence.contacts().len() + evidence.overlaps().len());
    }

    let elapsed = started.elapsed();
    println!(
        "sparse_curve_region_intersections_{contour_count}: {iterations} iterations in {elapsed:?} ({:?}/iter), total evidence={total_pairs}",
        elapsed / iterations
    );
    Ok(())
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    bench_line_circle_relation(100_000)?;
    bench_circle_circle_relation(100_000)?;

    let same_circle_a = arc(p(5, 0), p(-5, 0), p(0, 0), false);
    let same_circle_overlap_b = arc(p(0, 5), p(0, -5), p(0, 0), false);
    bench_arc_arc_case(
        "arc_arc_same_circle_overlap",
        &same_circle_a,
        &same_circle_overlap_b,
        100_000,
    )?;

    let same_circle_endpoint_b = arc(p(5, 0), p(-5, 0), p(0, 0), true);
    bench_arc_arc_case(
        "arc_arc_same_circle_endpoint_pair",
        &same_circle_a,
        &same_circle_endpoint_b,
        100_000,
    )?;

    let crossing_a = arc(p(4, 3), p(4, -3), p(0, 0), true);
    let crossing_b = arc(p(4, -3), p(4, 3), p(8, 0), true);
    bench_arc_arc_case(
        "arc_arc_two_point_crossing",
        &crossing_a,
        &crossing_b,
        100_000,
    )?;
    bench_sparse_curve_self_contacts(160, 1_000)?;
    bench_sparse_curve_string_intersections(160, 10_000)?;
    bench_sparse_region_events(120, 1_000)?;

    Ok(())
}
