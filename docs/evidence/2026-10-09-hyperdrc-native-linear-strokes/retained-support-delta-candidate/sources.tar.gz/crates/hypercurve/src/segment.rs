//! Line and circular-arc segment primitives.

use hyperreal::{Real, RealSign, ZeroKnowledge};
use std::{
    sync::Arc,
    sync::{Mutex, OnceLock},
};

use crate::classify::{
    LineSide, classify_oriented_line, compare_reals, in_closed_unit_interval, is_zero,
};
use crate::policy::resolve_certified_operation;
use crate::{
    Classification, CurveContext, CurveError, CurveOutcome, CurveResult, ParamRange, Point2,
};
use std::cmp::Ordering;

/// A finite line segment.
#[derive(Clone, Debug)]
pub struct LineSeg2 {
    start: Point2,
    end: Point2,
    endpoints_decided_distinct: bool,
    // An exact construction displacement can be much smaller than either
    // endpoint expression, especially for rays through selected curve points.
    retained_delta: Option<Arc<(Real, Real)>>,
    support: OnceLock<Arc<LineSupport2>>,
    has_retained_support: bool,
    // Shared supports retain source orientation; this bit recovers the
    // fragment's directed tangent without subtracting its wide endpoints.
    support_direction_reversed: bool,
    offset_provenance: Option<Arc<LineOffsetProvenance2>>,
}

impl PartialEq for LineSeg2 {
    fn eq(&self, other: &Self) -> bool {
        self.start == other.start && self.end == other.end && self.support == other.support
    }
}

#[derive(Debug)]
pub(crate) struct LineSupport2 {
    start: Point2,
    end: Point2,
    // Splitting preserves the support's original construction displacement.
    // The finite fragment keeps its own endpoint difference for parameters.
    retained_delta: Option<Arc<(Real, Real)>>,
}

impl PartialEq for LineSupport2 {
    fn eq(&self, other: &Self) -> bool {
        self.start == other.start && self.end == other.end
    }
}

#[derive(Debug, PartialEq)]
struct LineOffsetProvenance2 {
    source: Arc<LineSupport2>,
    left_distance: Real,
}

fn line_support_cell(support: Option<Arc<LineSupport2>>) -> OnceLock<Arc<LineSupport2>> {
    let cell = OnceLock::new();
    if let Some(support) = support {
        let _ = cell.set(support);
    }
    cell
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RetainedLineRelation2 {
    Coincident,
    ParallelDistinct,
    Uncertain,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ArcSweepPointLocation2 {
    Endpoint,
    Interior,
    Outside,
}

impl LineSeg2 {
    /// Constructs a line segment and rejects equal endpoints when provable.
    pub fn try_new(start: Point2, end: Point2) -> CurveResult<Self> {
        if start == end {
            return Err(CurveError::ZeroLengthLine);
        }
        let endpoints_decided_distinct = match start.distance_squared(&end).zero_status() {
            ZeroKnowledge::Zero => return Err(CurveError::ZeroLengthLine),
            ZeroKnowledge::NonZero => true,
            ZeroKnowledge::Unknown => false,
        };
        Ok(Self {
            start,
            end,
            endpoints_decided_distinct,
            retained_delta: None,
            support: OnceLock::new(),
            has_retained_support: false,
            support_direction_reversed: false,
            offset_provenance: None,
        })
    }

    /// Constructs a line segment without validating endpoint distinctness.
    pub fn new_unchecked(start: Point2, end: Point2) -> Self {
        Self {
            start,
            end,
            endpoints_decided_distinct: false,
            retained_delta: None,
            support: OnceLock::new(),
            has_retained_support: false,
            support_direction_reversed: false,
            offset_provenance: None,
        }
    }

    /// Constructs `start -> start + delta` from a certified nonzero displacement.
    /// The caller must prove that at least one displacement coordinate is
    /// nonzero, retaining any policy dependency in the enclosing operation.
    pub(crate) fn from_certified_nonzero_delta(start: Point2, dx: Real, dy: Real) -> Self {
        let end = Point2::new(start.x() + &dx, start.y() + &dy);
        let mut line = Self::new_unchecked(start, end);
        line.endpoints_decided_distinct = true;
        line.retained_delta = Some(Arc::new((dx, dy)));
        line
    }

    /// Returns the segment start point.
    pub const fn start(&self) -> &Point2 {
        &self.start
    }

    /// Returns the segment end point.
    pub const fn end(&self) -> &Point2 {
        &self.end
    }

    /// Returns `(end.x - start.x, end.y - start.y)`.
    pub fn delta(&self) -> (Real, Real) {
        self.retained_delta
            .as_deref()
            .cloned()
            .unwrap_or_else(|| self.end.delta_from(&self.start))
    }

    pub(crate) fn support_delta(&self) -> (Real, Real) {
        self.support.get().map_or_else(
            || self.delta(),
            |support| {
                support
                    .retained_delta
                    .as_deref()
                    .cloned()
                    .unwrap_or_else(|| support.end.delta_from(&support.start))
            },
        )
    }

    /// Direction of the supporting line oriented with this segment.
    ///
    /// The result is a positive multiple of [`Self::delta`]. A fragment cut
    /// at irrational points keeps its exact source direction here, so signs
    /// against it avoid subtracting the fragment's wide endpoints.
    pub(crate) fn directed_support_delta(&self) -> (Real, Real) {
        let (dx, dy) = self.support_delta();
        if self.has_retained_support && self.support_direction_reversed {
            (-dx, -dy)
        } else {
            (dx, dy)
        }
    }

    /// Rebuilds this segment between equal-valued endpoint representations.
    ///
    /// The caller certifies that `start` and `end` equal this segment's
    /// endpoints; retained support and offset provenance carry over.
    pub(crate) fn with_endpoint_representations(
        &self,
        start: Point2,
        end: Point2,
    ) -> CurveResult<Self> {
        let mut validated = Self::try_new(start, end)?;
        validated.retained_delta = self.retained_delta.clone();
        validated.offset_provenance = self.offset_provenance.clone();
        if !self.has_retained_support {
            return Ok(validated);
        }
        Ok(Self {
            support: line_support_cell(self.support.get().cloned()),
            has_retained_support: true,
            support_direction_reversed: self.support_direction_reversed,
            ..validated
        })
    }

    pub(crate) const fn has_retained_support(&self) -> bool {
        self.has_retained_support
    }

    pub(crate) const fn endpoints_decided_distinct(&self) -> bool {
        self.endpoints_decided_distinct
    }

    pub(crate) fn support_start(&self) -> &Point2 {
        self.support
            .get()
            .map_or(&self.start, |support| &support.start)
    }

    pub(crate) fn fragment_between_after_distinct_endpoints(
        &self,
        start: Point2,
        end: Point2,
        support: Arc<LineSupport2>,
    ) -> Self {
        Self {
            start,
            end,
            endpoints_decided_distinct: true,
            retained_delta: None,
            support: line_support_cell(Some(support)),
            has_retained_support: true,
            support_direction_reversed: self.support_direction_reversed,
            offset_provenance: self.offset_provenance.clone(),
        }
    }

    pub(crate) fn fragment_support(&self) -> Arc<LineSupport2> {
        self.support
            .get_or_init(|| {
                Arc::new(LineSupport2 {
                    start: self.start.clone(),
                    end: self.end.clone(),
                    retained_delta: self.retained_delta.clone(),
                })
            })
            .clone()
    }

    pub(crate) fn retained_support_intervals_decided_disjoint(
        &self,
        other: &Self,
        policy: &CurveContext,
    ) -> Option<bool> {
        if !self.has_retained_support || !other.has_retained_support {
            return None;
        }
        let first_support = self.support.get()?;
        let second_support = other.support.get()?;
        if !Arc::ptr_eq(first_support, second_support) {
            return None;
        }
        let use_x = match compare_reals(first_support.start.x(), first_support.end.x(), policy) {
            Some(Ordering::Less | Ordering::Greater) => true,
            Some(Ordering::Equal) => false,
            None => match compare_reals(first_support.start.y(), first_support.end.y(), policy) {
                Some(Ordering::Less | Ordering::Greater) => false,
                Some(Ordering::Equal) | None => return None,
            },
        };
        let (first_start, first_end) = ordered_line_endpoints(self, use_x, policy)?;
        let (second_start, second_end) = ordered_line_endpoints(other, use_x, policy)?;
        Some(
            compare_reals(first_end, second_start, policy) == Some(Ordering::Less)
                || compare_reals(second_end, first_start, policy) == Some(Ordering::Less),
        )
    }

    /// Both endpoints must be the source endpoints translated by the same
    /// left-normal offset. Translation preserves the source displacement and
    /// its distinct-endpoint certificate.
    pub(crate) fn offset_translated_endpoints(
        &self,
        start: Point2,
        end: Point2,
        distance: Real,
    ) -> CurveResult<Self> {
        let mut offset = if self.endpoints_decided_distinct {
            let mut offset = Self::new_unchecked(start, end);
            offset.endpoints_decided_distinct = true;
            offset
        } else {
            Self::try_new(start, end)?
        };
        offset.retained_delta = Some(Arc::new(self.delta()));
        let provenance = match self.offset_provenance.as_ref() {
            None => LineOffsetProvenance2 {
                source: self.fragment_support(),
                left_distance: distance,
            },
            Some(provenance) => LineOffsetProvenance2 {
                source: provenance.source.clone(),
                left_distance: &provenance.left_distance + &distance,
            },
        };
        offset.offset_provenance = Some(Arc::new(provenance));
        Ok(offset)
    }

    pub(crate) fn retained_offset_relation(
        &self,
        other: &Self,
        policy: &CurveContext,
    ) -> Option<RetainedLineRelation2> {
        let first = self.offset_provenance.as_ref()?;
        let second = other.offset_provenance.as_ref()?;
        let second_distance = if first.source == second.source {
            second.left_distance.clone()
        } else if first.source.start == second.source.end && first.source.end == second.source.start
        {
            -second.left_distance.clone()
        } else {
            return None;
        };

        Some(
            match compare_reals(&first.left_distance, &second_distance, policy) {
                Some(Ordering::Equal) => RetainedLineRelation2::Coincident,
                Some(Ordering::Less | Ordering::Greater) => RetainedLineRelation2::ParallelDistinct,
                None => RetainedLineRelation2::Uncertain,
            },
        )
    }

    pub(crate) fn map_points<F>(&self, mut map: F) -> CurveResult<Self>
    where
        F: FnMut(&Point2) -> Point2,
    {
        let start = map(&self.start);
        let end = map(&self.end);
        self.map_points_between(start, end, map)
    }

    pub(crate) fn map_points_between<F>(
        &self,
        start: Point2,
        end: Point2,
        mut map: F,
    ) -> CurveResult<Self>
    where
        F: FnMut(&Point2) -> Point2,
    {
        if start == end {
            return Err(CurveError::ZeroLengthLine);
        }
        let endpoints_decided_distinct = match start.distance_squared(&end).zero_status() {
            ZeroKnowledge::Zero => return Err(CurveError::ZeroLengthLine),
            ZeroKnowledge::NonZero => true,
            ZeroKnowledge::Unknown => false,
        };
        let support = self
            .has_retained_support
            .then(|| self.support.get())
            .flatten()
            .map(|support| {
                Arc::new(LineSupport2 {
                    start: map(&support.start),
                    end: map(&support.end),
                    retained_delta: None,
                })
            });
        Ok(Self {
            start,
            end,
            endpoints_decided_distinct,
            retained_delta: None,
            support: line_support_cell(support),
            has_retained_support: self.has_retained_support,
            support_direction_reversed: self.support_direction_reversed,
            // An arbitrary point map need not preserve signed offset distance.
            offset_provenance: None,
        })
    }

    /// Returns squared segment length.
    pub fn length_squared(&self) -> Real {
        self.start.distance_squared(&self.end)
    }

    /// Returns the point at affine parameter `t`, where `0` is start and `1` is end.
    pub fn point_at(&self, t: Real) -> Point2 {
        let interpolated = self.start.lerp(&self.end, t);
        Point2::new(
            if self.start.x() == self.end.x() {
                self.start.x().clone()
            } else {
                interpolated.x().clone()
            },
            if self.start.y() == self.end.y() {
                self.start.y().clone()
            } else {
                interpolated.y().clone()
            },
        )
    }

    /// Returns this segment with traversal direction reversed.
    pub fn reversed(&self) -> Self {
        let offset_provenance = self.offset_provenance.as_ref().map(|provenance| {
            Arc::new(LineOffsetProvenance2 {
                source: Arc::new(LineSupport2 {
                    start: provenance.source.end.clone(),
                    end: provenance.source.start.clone(),
                    retained_delta: provenance
                        .source
                        .retained_delta
                        .as_deref()
                        .map(|(dx, dy)| Arc::new((-dx, -dy))),
                }),
                left_distance: -provenance.left_distance.clone(),
            })
        });
        Self {
            start: self.end.clone(),
            end: self.start.clone(),
            endpoints_decided_distinct: self.endpoints_decided_distinct,
            retained_delta: self
                .retained_delta
                .as_deref()
                .map(|(dx, dy)| Arc::new((-dx, -dy))),
            support: line_support_cell(
                self.has_retained_support
                    .then(|| self.support.get().cloned())
                    .flatten(),
            ),
            has_retained_support: self.has_retained_support,
            support_direction_reversed: self.has_retained_support
                && !self.support_direction_reversed,
            offset_provenance,
        }
    }

    #[cfg(test)]
    pub(crate) fn into_reversed(mut self) -> Self {
        if self.offset_provenance.is_some() {
            return self.reversed();
        }
        std::mem::swap(&mut self.start, &mut self.end);
        self.retained_delta = self
            .retained_delta
            .as_deref()
            .map(|(dx, dy)| Arc::new((-dx, -dy)));
        if self.has_retained_support {
            self.support_direction_reversed = !self.support_direction_reversed;
        } else {
            self.support.take();
        }
        self
    }

    /// Classifies a point relative to this oriented line segment's supporting line.
    pub fn classify_point(&self, point: &Point2) -> crate::ExactCurveResult<LineSide> {
        crate::ExactCurveError::decided_for(
            crate::CurveOperation2::Classification,
            crate::CurveFamily2::Line,
            self.classify_point_with_policy(point, &crate::policy::principal_context()),
        )
    }

    /// [`Self::classify_point`] under an explicit predicate policy.
    pub(crate) fn classify_point_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<LineSide> {
        let support_start = self.support_start();
        let support_end = self.support.get().map_or(&self.end, |support| &support.end);
        classify_oriented_line(support_start, support_end, point, policy)
    }

    /// Classifies whether a point lies on this finite line segment.
    pub fn contains_point(&self, point: &Point2) -> crate::ExactCurveResult<bool> {
        crate::ExactCurveError::decided_for(
            crate::CurveOperation2::Classification,
            crate::CurveFamily2::Line,
            self.contains_point_with_policy(point, &crate::policy::principal_context()),
        )
    }

    /// [`Self::contains_point`] under an explicit predicate policy.
    pub(crate) fn contains_point_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<bool> {
        let side = match self.classify_point_with_policy(point, policy) {
            Classification::Decided(side) => side,
            Classification::Uncertain(reason) => return Classification::Uncertain(reason),
        };
        self.contains_point_with_classified_side(point, side, policy)
    }

    pub(crate) fn contains_point_with_classified_side(
        &self,
        point: &Point2,
        side: LineSide,
        policy: &CurveContext,
    ) -> Classification<bool> {
        if side != LineSide::On {
            return Classification::Decided(false);
        }

        match parameter_on_line(self, point, policy) {
            ParameterOnLine::Decided(t) => in_closed_unit_interval(&t, policy)
                .map(Classification::Decided)
                .unwrap_or(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                )),
            ParameterOnLine::Uncertain(reason) => Classification::Uncertain(reason),
        }
    }

    /// Returns conservative structural facts for this line segment.
    ///
    /// Axis-aligned and shared-scale facts are scheduling hints only. They help
    /// select faster exact kernels without becoming a substitute for the
    /// orientation predicates used for topology.
    pub fn structural_facts(&self) -> crate::LineSeg2Facts {
        crate::facts::compute_line_segment_facts(self)
    }
}

/// A finite circular arc segment.
#[derive(Clone, Debug)]
pub struct CircularArc2 {
    // Geometry and lazy facts share one allocation. Arc clones already share
    // the immutable geometry, while native segment vectors no longer inherit
    // the full inline arc payload for every line element.
    pub(crate) retained_facts: Arc<CircularArcRetainedFacts2>,
}

#[derive(Debug)]
pub(crate) struct CircularArcRetainedFacts2 {
    start: Point2,
    end: Point2,
    center: Point2,
    radius_squared: Real,
    endpoints_on_stored_circle: bool,
    clockwise: bool,
    source_bulge: Option<Real>,
    structural_facts: OnceLock<Box<crate::CircularArc2Facts>>,
    pub(crate) sweep_kind: crate::policy::PolicyEvaluationCache<crate::arc_bezier::ArcSweepKind>,
    pub(crate) bezier_decomposition:
        crate::policy::PolicyEvaluationCache<crate::CircularArcBezierDecomposition2>,
    representative_point: crate::policy::PolicyEvaluationCache<Point2>,
    directed_sweep_angle: crate::policy::PolicyEvaluationCache<Real>,
    parameter_lineage: OnceLock<Box<CircularArcParameterLineage2>>,
    parameter_witnesses: OnceLock<Box<Mutex<Vec<CircularArcParameterWitness2>>>>,
    fragments: OnceLock<Box<Mutex<Vec<CircularArcFragmentWitness2>>>>,
}

impl CircularArcRetainedFacts2 {
    fn new(
        start: Point2,
        end: Point2,
        center: Point2,
        radius_squared: Real,
        endpoints_on_stored_circle: bool,
        clockwise: bool,
        source_bulge: Option<Real>,
    ) -> Self {
        Self {
            start,
            end,
            center,
            radius_squared,
            endpoints_on_stored_circle,
            clockwise,
            source_bulge,
            structural_facts: OnceLock::new(),
            sweep_kind: crate::policy::PolicyEvaluationCache::new(),
            bezier_decomposition: crate::policy::PolicyEvaluationCache::new(),
            representative_point: crate::policy::PolicyEvaluationCache::new(),
            directed_sweep_angle: crate::policy::PolicyEvaluationCache::new(),
            parameter_lineage: OnceLock::new(),
            parameter_witnesses: OnceLock::new(),
            fragments: OnceLock::new(),
        }
    }
}

#[derive(Clone, Debug)]
struct CircularArcParameterLineage2 {
    root_start: Point2,
    root_sweep_angle: Real,
    root_range: ParamRange,
}

#[derive(Clone, Debug)]
struct CircularArcParameterWitness2 {
    parameter: Real,
    point: Point2,
}

#[derive(Clone, Debug)]
struct CircularArcFragmentWitness2 {
    source_range: ParamRange,
    start: Point2,
    end: Point2,
    fragment: CircularArc2,
}

const MAX_RETAINED_ARC_FRAGMENTS: usize = 8;

impl PartialEq for CircularArc2 {
    fn eq(&self, other: &Self) -> bool {
        self.start() == other.start()
            && self.end() == other.end()
            && self.center() == other.center()
            && self.radius_squared_ref() == other.radius_squared_ref()
            && self.is_clockwise() == other.is_clockwise()
            && self.bulge() == other.bulge()
    }
}

impl CircularArc2 {
    fn data(&self) -> &CircularArcRetainedFacts2 {
        &self.retained_facts
    }

    fn from_geometry(
        start: Point2,
        end: Point2,
        center: Point2,
        radius_squared: Real,
        endpoints_on_stored_circle: bool,
        clockwise: bool,
        source_bulge: Option<Real>,
    ) -> Self {
        Self {
            retained_facts: Arc::new(CircularArcRetainedFacts2::new(
                start,
                end,
                center,
                radius_squared,
                endpoints_on_stored_circle,
                clockwise,
                source_bulge,
            )),
        }
    }

    /// Constructs a circular arc from endpoints, center, and orientation.
    pub fn try_from_center(
        start: Point2,
        end: Point2,
        center: Point2,
        clockwise: bool,
    ) -> CurveResult<Self> {
        let start_radius_squared = start.distance_squared(&center);
        if start_radius_squared.zero_status() == ZeroKnowledge::Zero {
            return Err(CurveError::ZeroRadiusArc);
        }

        let end_radius_squared = end.distance_squared(&center);
        let mismatch = &start_radius_squared - &end_radius_squared;
        let endpoints_on_stored_circle = match mismatch.zero_status() {
            ZeroKnowledge::Zero => true,
            ZeroKnowledge::NonZero => return Err(CurveError::RadiusMismatch),
            ZeroKnowledge::Unknown => false,
        };

        Ok(Self::from_geometry(
            start,
            end,
            center,
            start_radius_squared,
            endpoints_on_stored_circle,
            clockwise,
            None,
        ))
    }

    pub(crate) fn new_unchecked_with_radius(
        start: Point2,
        end: Point2,
        center: Point2,
        radius_squared: Real,
        clockwise: bool,
        bulge: Option<Real>,
    ) -> Self {
        Self::from_geometry(start, end, center, radius_squared, false, clockwise, bulge)
    }

    pub(crate) fn new_with_certified_radius(
        start: Point2,
        end: Point2,
        center: Point2,
        radius_squared: Real,
        clockwise: bool,
        bulge: Option<Real>,
    ) -> Self {
        Self::from_geometry(start, end, center, radius_squared, true, clockwise, bulge)
    }

    pub(crate) fn new_with_certified_radius_and_sweep(
        start: Point2,
        end: Point2,
        center: Point2,
        radius_squared: Real,
        clockwise: bool,
        sweep_kind: crate::arc_bezier::ArcSweepKind,
    ) -> Self {
        let arc =
            Self::new_with_certified_radius(start, end, center, radius_squared, clockwise, None);
        arc.retained_facts.sweep_kind.seed_certified(sweep_kind);
        arc
    }

    pub(crate) fn try_from_center_with_bulge(
        start: Point2,
        end: Point2,
        center: Point2,
        clockwise: bool,
        bulge: Option<Real>,
    ) -> CurveResult<Self> {
        let mut arc = Self::try_from_center(start, end, center, clockwise)?;
        Arc::get_mut(&mut arc.retained_facts)
            .expect("new arc retained facts are uniquely owned")
            .source_bulge = bulge;
        Ok(arc)
    }

    /// Constructs a circular arc from CAD bulge geometry.
    ///
    /// The formula keeps the center computation in rational operations:
    /// `center = midpoint + left_perp(chord) * ((1 - b^2) / (4b))`.
    pub fn from_bulge(start: Point2, end: Point2, bulge: Real) -> CurveResult<Self> {
        if start.distance_squared(&end).zero_status() == ZeroKnowledge::Zero {
            return Err(CurveError::ZeroLengthLine);
        }

        let clockwise = clockwise_from_bulge(&bulge)?;
        let four_b = Real::from(4_i8) * &bulge;
        let b2 = &bulge * &bulge;
        let offset_factor = ((Real::one() - &b2) / four_b)?;
        let two = Real::from(2_i8);
        let mid_x = ((start.x() + end.x()) / &two)?;
        let mid_y = ((start.y() + end.y()) / &two)?;
        let (dx, dy) = end.delta_from(&start);

        let center = Point2::new(
            mid_x - (&dy * &offset_factor),
            mid_y + (&dx * &offset_factor),
        );

        let mut arc = Self::try_from_center(start, end, center, clockwise)?;
        Arc::get_mut(&mut arc.retained_facts)
            .expect("new arc retained facts are uniquely owned")
            .source_bulge = Some(bulge);
        Ok(arc)
    }

    /// Returns the arc start point.
    pub fn start(&self) -> &Point2 {
        &self.data().start
    }

    /// Returns the arc end point.
    pub fn end(&self) -> &Point2 {
        &self.data().end
    }

    /// Returns the arc center.
    pub fn center(&self) -> &Point2 {
        &self.data().center
    }

    /// Returns the squared radius.
    pub fn radius_squared(&self) -> Real {
        self.retained_facts.radius_squared.clone()
    }

    /// Returns the stored squared radius by reference.
    pub fn radius_squared_ref(&self) -> &Real {
        &self.data().radius_squared
    }

    pub(crate) fn endpoints_on_stored_circle_are_certified(&self) -> bool {
        self.data().endpoints_on_stored_circle
    }

    /// Decides endpoint membership without requiring a comparison with the
    /// other endpoint once either incidence is proved.
    pub(crate) fn contains_endpoint(&self, point: &Point2, policy: &CurveContext) -> Option<bool> {
        if point == self.start() || point == self.end() {
            return Some(true);
        }
        let at_start = points_equal(point, self.start(), policy);
        if at_start == Some(true) {
            return Some(true);
        }
        match points_equal(point, self.end(), policy) {
            Some(true) => Some(true),
            Some(false) if at_start == Some(false) => Some(false),
            Some(false) | None => None,
        }
    }

    /// Returns whether this arc travels clockwise from start to end.
    pub fn is_clockwise(&self) -> bool {
        self.data().clockwise
    }

    /// Returns the source bulge when this arc was constructed from one.
    pub fn bulge(&self) -> Option<&Real> {
        self.retained_facts.source_bulge.as_ref()
    }

    /// Classifies whether a point lies inside this arc's angular sweep.
    ///
    /// Supports minor, semicircular, major, and full-circle sweeps. The point
    /// does not have to be on the circle; callers that need point-on-arc
    /// semantics should also compare squared distance to
    /// [`CircularArc2::radius_squared`].
    /// The half-plane tests are the finite-arc containment counterpart to the
    /// circle and arc primitive tests catalogued by standard geometric constructions.
    pub fn contains_sweep_point(&self, point: &Point2) -> crate::ExactCurveResult<bool> {
        crate::ExactCurveError::decided_for(
            crate::CurveOperation2::Classification,
            crate::CurveFamily2::CircularArc,
            self.contains_sweep_point_with_policy(point, &crate::policy::principal_context()),
        )
    }

    /// [`Self::contains_sweep_point`] under an explicit predicate policy.
    pub(crate) fn contains_sweep_point_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<bool> {
        if self.contains_endpoint(point, policy) == Some(true) {
            return Classification::Decided(true);
        }

        self.contains_non_endpoint_sweep_point(point, policy)
    }

    fn contains_non_endpoint_sweep_point(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<bool> {
        let sweep_kind = match crate::arc_bezier::classify_sweep_with_policy(self, policy) {
            Ok(Classification::Decided(kind)) => kind,
            Ok(Classification::Uncertain(reason)) => {
                return Classification::Uncertain(reason);
            }
            Err(_) => return Classification::Uncertain(crate::UncertaintyReason::Predicate),
        };
        self.classify_sweep_sides(sweep_kind, policy, |at_start| {
            let endpoint = if at_start { self.start() } else { self.end() };
            classify_oriented_line(self.center(), endpoint, point, policy)
        })
    }

    pub(crate) fn strict_sweep_point_location(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<ArcSweepPointLocation2> {
        match self.contains_endpoint(point, policy) {
            Some(true) => {
                return Classification::Decided(ArcSweepPointLocation2::Endpoint);
            }
            Some(false) => {}
            None => {
                return Classification::Uncertain(crate::UncertaintyReason::RealSign);
            }
        }
        self.contains_non_endpoint_sweep_point(point, policy)
            .map(|contains| {
                if contains {
                    ArcSweepPointLocation2::Interior
                } else {
                    ArcSweepPointLocation2::Outside
                }
            })
    }

    /// Classifies a point whose incidence on this circle is already certified.
    /// The endpoint chord selects the directed sweep without reconstructing
    /// Cartesian coordinates or an inverse angular parameter.
    pub(crate) fn strict_incident_point_evidence_location(
        &self,
        point: &crate::CurvePoint2,
        policy: &CurveContext,
    ) -> CurveResult<Classification<ArcSweepPointLocation2>> {
        if let Some(point) = point.coordinates() {
            return Ok(self.strict_sweep_point_location(point, policy));
        }
        match points_equal(self.start(), self.end(), policy) {
            Some(true) => {
                return Ok(point
                    .same_point(&self.start().clone().into(), policy)
                    .map(|same| {
                        if same {
                            ArcSweepPointLocation2::Endpoint
                        } else {
                            ArcSweepPointLocation2::Interior
                        }
                    }));
            }
            Some(false) => (),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::RealSign,
                ));
            }
        }
        let chord = match crate::BezierAlgebraicChord2::try_new_from_certified_distinct_endpoints(
            self.start().clone().into(),
            self.end().clone().into(),
            policy,
        )? {
            Classification::Decided(chord) => chord,
            Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
        };
        Ok(chord.oriented_support_side(point, policy)?.map(|side| {
            if side == LineSide::On {
                ArcSweepPointLocation2::Endpoint
            } else if (side == LineSide::Left) == self.is_clockwise() {
                ArcSweepPointLocation2::Interior
            } else {
                ArcSweepPointLocation2::Outside
            }
        }))
    }

    /// Combines radial half-plane predicates without requiring an irrelevant
    /// boundary sign. A minor sweep is an intersection; a major sweep is a
    /// union. Try both bounded exact predicates before refining either one.
    pub(crate) fn classify_sweep_sides(
        &self,
        sweep_kind: crate::arc_bezier::ArcSweepKind,
        policy: &CurveContext,
        mut classify: impl FnMut(bool) -> Classification<LineSide>,
    ) -> Classification<bool> {
        if sweep_kind == crate::arc_bezier::ArcSweepKind::FullCircle {
            return Classification::Decided(true);
        }
        let decisive = sweep_kind == crate::arc_bezier::ArcSweepKind::Major;
        let mut sides = [Classification::Uncertain(crate::UncertaintyReason::Predicate); 2];
        for bounded in [true, false] {
            for (index, at_start) in [true, false].into_iter().enumerate() {
                if sides[index].is_uncertain() {
                    let side = if bounded {
                        policy.bounded_exact_predicate_pass(|| classify(at_start))
                    } else {
                        classify(at_start)
                    };
                    let inside_side = if at_start != self.is_clockwise() {
                        LineSide::Left
                    } else {
                        LineSide::Right
                    };
                    sides[index] = side.map(|side| side == LineSide::On || side == inside_side);
                }
                if sides[index] == Classification::Decided(decisive) {
                    return Classification::Decided(decisive);
                }
            }
            if sides.iter().all(Classification::is_decided) {
                return Classification::Decided(!decisive);
            }
            if policy.has_bounded_exact_predicate_budget() {
                break;
            }
        }
        sides
            .into_iter()
            .find(Classification::is_uncertain)
            .expect("the sweep still needs one unresolved half-plane")
    }

    /// Classifies whether a point lies on this finite circular arc.
    pub fn contains_point(&self, point: &Point2) -> crate::ExactCurveResult<bool> {
        crate::ExactCurveError::decided_for(
            crate::CurveOperation2::Classification,
            crate::CurveFamily2::CircularArc,
            self.contains_point_with_policy(point, &crate::policy::principal_context()),
        )
    }

    /// [`Self::contains_point`] under an explicit predicate policy.
    pub(crate) fn contains_point_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<bool> {
        if self.contains_endpoint(point, policy) == Some(true) {
            return Classification::Decided(true);
        }
        let radius_delta = point.distance_squared(self.center()) - self.radius_squared();
        match is_zero(&radius_delta, policy) {
            Some(false) => Classification::Decided(false),
            Some(true) => self.contains_sweep_point_with_policy(point, policy),
            None => Classification::Uncertain(crate::UncertaintyReason::RealSign),
        }
    }

    /// Returns conservative structural facts for this arc.
    ///
    /// These facts can schedule future circle/arc exact kernels while leaving
    /// topological decisions to certified predicates and exact sign queries.
    pub fn structural_facts(&self) -> crate::CircularArc2Facts {
        **self
            .retained_facts
            .structural_facts
            .get_or_init(|| Box::new(crate::facts::compute_circular_arc_facts(self)))
    }

    /// Returns a point in the interior of this arc's supported sweep.
    ///
    /// The point is the exact midpoint of the requested minor, semicircular,
    /// major, or full-circle traversal. Arc fragments retain their source
    /// angular parameterization, so repeated and nested trims evaluate this
    /// point without rebuilding nested trigonometric rotations.
    pub fn representative_point(&self) -> crate::ExactCurveResult<Point2> {
        self.representative_point_with_policy(&crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided_for(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    value,
                )
            })
    }

    /// [`Self::representative_point`] under an explicit predicate policy.
    pub(crate) fn representative_point_with_policy(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Point2>> {
        crate::policy::resolve_cached_evaluation(
            &self.retained_facts.representative_point,
            policy,
            |attempt| self.compute_representative_point(attempt),
        )
        .map(|classification| classification.map(Clone::clone))
    }

    fn compute_representative_point(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Point2>> {
        let half = (Real::one() / Real::from(2_i8))?;
        if self.retained_facts.parameter_lineage.get().is_some() {
            return self.point_at_sweep_fraction_with_policy(&half, policy);
        }
        match self.rational_bezier_decomposition_raw(policy) {
            Ok(Classification::Decided(decomposition)) => {
                match decomposition.point_at_raw(&half, policy) {
                    Ok(point) => Ok(Classification::Decided(point)),
                    Err(crate::ExactCurveError::Invalid { cause, .. }) => Err(cause),
                    Err(crate::ExactCurveError::Blocked(blocker)) => {
                        Ok(Classification::Uncertain(blocker.reason()))
                    }
                }
            }
            Ok(Classification::Uncertain(reason)) => Ok(Classification::Uncertain(reason)),
            Err(crate::ExactCurveError::Invalid { cause, .. }) => Err(cause),
            Err(crate::ExactCurveError::Blocked(blocker)) => {
                Ok(Classification::Uncertain(blocker.reason()))
            }
        }
    }

    /// Returns the exact directed-angular sweep fraction of a point on this arc.
    ///
    /// Zero is the arc start and one is the arc end. Interior values increase
    /// in traversal order for clockwise, counterclockwise, minor, major, and
    /// full-circle arcs. This is an angular ordering parameter; it is not the
    /// piecewise rational-Bezier evaluation parameter returned by
    /// [`CircularArc2::rational_bezier_decomposition`].
    pub fn sweep_fraction(&self, point: &Point2) -> crate::ExactCurveResult<Real> {
        self.sweep_fraction_with_policy(point, &crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided_for(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    value,
                )
            })
    }

    /// [`Self::sweep_fraction`] under an explicit predicate policy.
    pub(crate) fn sweep_fraction_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Real>> {
        match self.contains_point_with_policy(point, policy) {
            Classification::Decided(true) => self.sweep_fraction_for_incident_point(point, policy),
            Classification::Decided(false) => Ok(Classification::Uncertain(
                crate::UncertaintyReason::Boundary,
            )),
            Classification::Uncertain(reason) => Ok(Classification::Uncertain(reason)),
        }
    }

    /// Evaluates this arc at a directed-angular sweep fraction.
    ///
    /// Zero returns the stored start point and one returns the stored end point.
    /// Interior fractions follow traversal order for clockwise,
    /// counterclockwise, minor, major, and full-circle arcs. This is the
    /// inverse parameterization of [`CircularArc2::sweep_fraction`], not the
    /// piecewise rational-Bezier parameterization used by
    /// [`CircularArc2::rational_bezier_decomposition`].
    pub fn point_at_sweep_fraction(&self, fraction: &Real) -> crate::ExactCurveResult<Point2> {
        self.point_at_sweep_fraction_with_policy(fraction, &crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided_for(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    value,
                )
            })
    }

    /// [`Self::point_at_sweep_fraction`] under an explicit predicate policy.
    pub(crate) fn point_at_sweep_fraction_with_policy(
        &self,
        fraction: &Real,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Point2>> {
        match in_closed_unit_interval(fraction, policy) {
            Some(true) => {}
            Some(false) => return Err(CurveError::InvalidCurveParameter),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        match compare_reals(fraction, &Real::zero(), policy) {
            Some(Ordering::Equal) => return Ok(Classification::Decided(self.start().clone())),
            Some(_) => {}
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        match compare_reals(fraction, &Real::one(), policy) {
            Some(Ordering::Equal) => return Ok(Classification::Decided(self.end().clone())),
            Some(_) => {}
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        if let Some(point) = self.retained_parameter_witness(fraction) {
            return Ok(Classification::Decided(point));
        }

        let sweep_angle = match self.retained_directed_sweep_angle(policy)? {
            Classification::Decided(angle) => angle,
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        let (radial, traversal_angle) =
            if let Some(lineage) = self.retained_facts.parameter_lineage.get() {
                let root_width = lineage.root_range.end() - lineage.root_range.start();
                let root_fraction = lineage.root_range.start() + &(root_width * fraction);
                (
                    lineage.root_start.delta_from(self.center()),
                    &lineage.root_sweep_angle * root_fraction,
                )
            } else {
                (
                    self.start().delta_from(self.center()),
                    sweep_angle * fraction,
                )
            };
        let signed_angle = if self.is_clockwise() {
            -traversal_angle
        } else {
            traversal_angle
        };
        let cosine = signed_angle.clone().cos();
        let sine = signed_angle.sin();
        Ok(Classification::Decided(Point2::new(
            self.center().x() + (&radial.0 * &cosine) - (&radial.1 * &sine),
            self.center().y() + (&radial.0 * sine) + (&radial.1 * cosine),
        )))
    }

    /// Splits this arc at a strict interior directed-angular sweep fraction.
    ///
    /// Unlike splitting through the arc's rational-Bézier public parameter,
    /// this operation retains the original angular lineage. Nested splits
    /// therefore evaluate their endpoints from the root circle and do not
    /// accumulate algebraically equivalent rational-projection expressions.
    pub fn split_at_sweep_fraction(
        &self,
        fraction: &Real,
    ) -> crate::ExactCurveResult<(Self, Self)> {
        self.split_at_sweep_fraction_with_policy(fraction, &crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid(
                    crate::CurveOperation2::Subdivision,
                    crate::CurveFamily2::CircularArc,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided_for(
                    crate::CurveOperation2::Subdivision,
                    crate::CurveFamily2::CircularArc,
                    value,
                )
            })
    }

    /// [`Self::split_at_sweep_fraction`] under an explicit predicate policy.
    pub(crate) fn split_at_sweep_fraction_with_policy(
        &self,
        fraction: &Real,
        policy: &CurveContext,
    ) -> CurveResult<Classification<(Self, Self)>> {
        let middle = match self.point_at_sweep_fraction_with_policy(fraction, policy)? {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        self.split_at_retained_sweep_point_with_policy(fraction, middle, policy)
    }

    /// Splits this arc through an exact point with a retained sweep fraction.
    ///
    /// `point` must be retained exact contact evidence already certified on
    /// this arc at `fraction`. This method validates the strict fraction but
    /// deliberately does not re-solve point incidence: doing so would discard
    /// the caller's contact certificate and reconstruct the same image through
    /// trigonometric predicates. The retained point becomes the shared
    /// endpoint while the source arc's angular lineage is preserved.
    pub fn split_at_retained_sweep_point(
        &self,
        fraction: &Real,
        point: Point2,
    ) -> crate::ExactCurveResult<(Self, Self)> {
        self.split_at_retained_sweep_point_with_policy(
            fraction,
            point,
            &crate::policy::principal_context(),
        )
        .map_err(|cause| {
            crate::ExactCurveError::invalid(
                crate::CurveOperation2::Subdivision,
                crate::CurveFamily2::CircularArc,
                cause,
            )
        })
        .and_then(|value| {
            crate::ExactCurveError::decided_for(
                crate::CurveOperation2::Subdivision,
                crate::CurveFamily2::CircularArc,
                value,
            )
        })
    }

    /// [`Self::split_at_retained_sweep_point`] under an explicit predicate policy.
    pub(crate) fn split_at_retained_sweep_point_with_policy(
        &self,
        fraction: &Real,
        point: Point2,
        policy: &CurveContext,
    ) -> CurveResult<Classification<(Self, Self)>> {
        match compare_reals(fraction, &Real::zero(), policy) {
            Some(Ordering::Greater) => {}
            Some(_) => return Err(CurveError::InvalidCurveParameter),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        match compare_reals(fraction, &Real::one(), policy) {
            Some(Ordering::Less) => {}
            Some(_) => return Err(CurveError::InvalidCurveParameter),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        let first_range = ParamRange::new(Real::zero(), fraction.clone());
        let second_range = ParamRange::new(fraction.clone(), Real::one());
        let first = match self.fragment_between_sweep_range(
            self.start().clone(),
            point.clone(),
            &first_range,
            policy,
        )? {
            Classification::Decided(fragment) => fragment,
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        let second = match self.fragment_between_sweep_range(
            point,
            self.end().clone(),
            &second_range,
            policy,
        )? {
            Classification::Decided(fragment) => fragment,
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        Ok(Classification::Decided((first, second)))
    }

    /// Returns the exact piecewise-rational public parameter at a directed
    /// angular sweep fraction.
    ///
    /// This is the parameter-space inverse needed when an angularly
    /// parameterized owner splits a native circular arc. The angular point is
    /// constructed exactly, then replayed through the retained rational
    /// quadratic decomposition's certified point-parameter solvers.
    pub fn parameter_at_sweep_fraction(&self, fraction: &Real) -> crate::ExactCurveResult<Real> {
        self.parameter_at_sweep_fraction_with_policy(fraction, &crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided_for(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    value,
                )
            })
    }

    /// [`Self::parameter_at_sweep_fraction`] under an explicit predicate policy.
    pub(crate) fn parameter_at_sweep_fraction_with_policy(
        &self,
        fraction: &Real,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Real>> {
        match compare_reals(fraction, &Real::zero(), policy) {
            Some(Ordering::Equal) => return Ok(Classification::Decided(Real::zero())),
            Some(Ordering::Greater) => {}
            Some(Ordering::Less) => return Err(CurveError::InvalidCurveParameter),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        match compare_reals(fraction, &Real::one(), policy) {
            Some(Ordering::Equal) => return Ok(Classification::Decided(Real::one())),
            Some(Ordering::Less) => {}
            Some(Ordering::Greater) => return Err(CurveError::InvalidCurveParameter),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        let point = match self.point_at_sweep_fraction_with_policy(fraction, policy)? {
            Classification::Decided(point) => point,
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        self.parameter_at_incident_point(&point, policy)
    }

    /// Projects a point already certified on this sweep into its rational
    /// chart. Reuses Cartesian incidence without an angle/evaluation round trip.
    /// A full circle's shared endpoint belongs to the start of the traversal.
    pub(crate) fn parameter_at_incident_point(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Real>> {
        if point == self.start() {
            return Ok(Classification::Decided(Real::zero()));
        }
        if point == self.end() {
            return Ok(Classification::Decided(Real::one()));
        }
        let decomposition = match self.rational_bezier_decomposition_raw(policy) {
            Ok(Classification::Decided(decomposition)) => decomposition,
            Ok(Classification::Uncertain(reason)) => {
                return Ok(Classification::Uncertain(reason));
            }
            Err(crate::ExactCurveError::Invalid { cause, .. }) => return Err(cause),
            Err(crate::ExactCurveError::Blocked(blocker)) => {
                return Ok(Classification::Uncertain(blocker.reason()));
            }
        };
        for span in decomposition.spans() {
            let (start, end) = span.parameter_range();
            let width = end - start;
            let start_radial = span.curve().start().delta_from(self.center());
            let end_radial = span.curve().end().delta_from(self.center());
            let point_radial = point.delta_from(self.center());
            let radius_squared =
                &start_radial.0 * &start_radial.0 + &start_radial.1 * &start_radial.1;
            let start_point_dot =
                &start_radial.0 * &point_radial.0 + &start_radial.1 * &point_radial.1;
            let start_point_cross =
                &start_radial.0 * &point_radial.1 - &start_radial.1 * &point_radial.0;
            let start_end_dot = &start_radial.0 * &end_radial.0 + &start_radial.1 * &end_radial.1;
            let start_end_cross = &start_radial.0 * &end_radial.1 - &start_radial.1 * &end_radial.0;
            let denominator = (&radius_squared + start_point_dot) * start_end_cross;
            match crate::classify::is_zero(&denominator, policy) {
                Some(true) => continue, // The point is at this chart's projective pole.
                Some(false) => {}
                None => {
                    return Ok(Classification::Uncertain(
                        crate::UncertaintyReason::RealSign,
                    ));
                }
            }
            let local = (start_point_cross * (&radius_squared + start_end_dot) / denominator)?;
            // Chart parameters are rational coordinates, not angular fractions.
            // Test the projected point in each chart's own finite domain.
            match (
                compare_reals(&Real::zero(), &local, policy),
                compare_reals(&local, &Real::one(), policy),
            ) {
                (
                    Some(Ordering::Less | Ordering::Equal),
                    Some(Ordering::Less | Ordering::Equal),
                ) => {
                    return Ok(Classification::Decided(start + &(width * local)));
                }
                (Some(_), Some(_)) => {}
                _ => {
                    return Ok(Classification::Uncertain(
                        crate::UncertaintyReason::Ordering,
                    ));
                }
            }
        }
        Ok(Classification::Uncertain(
            crate::UncertaintyReason::Boundary,
        ))
    }

    /// Returns the exact positive angular sweep in traversal order.
    ///
    /// Counterclockwise and clockwise arcs both report a positive magnitude;
    /// orientation remains available through [`CircularArc2::is_clockwise`].
    /// Full circles report `tau`. The result is retained with the arc and is
    /// the angular measure used by [`CircularArc2::sweep_fraction`].
    #[inline(always)]
    pub fn directed_sweep_angle(&self) -> crate::ExactCurveResult<&Real> {
        self.directed_sweep_angle_with_policy(&crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    cause,
                )
            })
            .and_then(|outcome| {
                crate::ExactCurveError::decided_for(
                    crate::CurveOperation2::Evaluation,
                    crate::CurveFamily2::CircularArc,
                    outcome.into_value(),
                )
            })
    }

    /// [`Self::directed_sweep_angle`] under an explicit predicate policy.
    pub(crate) fn directed_sweep_angle_with_policy(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<CurveOutcome<Classification<&Real>>> {
        resolve_certified_operation(policy, |attempt| {
            self.retained_directed_sweep_angle(attempt)
        })
    }

    pub(crate) fn directed_sweep_angle_raw(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Real>> {
        self.retained_directed_sweep_angle(policy)
            .map(|classification| classification.map(Clone::clone))
    }

    #[inline]
    fn retained_directed_sweep_angle(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<Classification<&Real>> {
        crate::policy::resolve_cached_evaluation(
            &self.retained_facts.directed_sweep_angle,
            policy,
            |attempt| self.compute_directed_sweep_angle(attempt),
        )
    }

    fn retained_parameter_witness(&self, parameter: &Real) -> Option<Point2> {
        let witnesses = self.retained_facts.parameter_witnesses.get()?;
        witnesses
            .lock()
            .expect("arc parameter witness cache mutex poisoned")
            .iter()
            .find(|witness| witness.parameter == *parameter)
            .map(|witness| witness.point.clone())
    }

    fn retain_parameter_witness(&self, parameter: &Real, point: &Point2) {
        let witnesses = self
            .retained_facts
            .parameter_witnesses
            .get_or_init(|| Box::new(Mutex::new(Vec::new())));
        let mut witnesses = witnesses
            .lock()
            .expect("arc parameter witness cache mutex poisoned");
        if witnesses
            .iter()
            .any(|witness| witness.parameter == *parameter)
        {
            return;
        }
        witnesses.push(CircularArcParameterWitness2 {
            parameter: parameter.clone(),
            point: point.clone(),
        });
    }

    fn compute_directed_sweep_angle(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Real>> {
        let sweep_kind = match crate::arc_bezier::classify_sweep_with_policy(self, policy) {
            Ok(Classification::Decided(kind)) => kind,
            Ok(Classification::Uncertain(reason)) => {
                return Ok(Classification::Uncertain(reason));
            }
            Err(crate::ExactCurveError::Invalid { cause, .. }) => return Err(cause),
            Err(crate::ExactCurveError::Blocked(blocker)) => {
                return Ok(Classification::Uncertain(blocker.reason()));
            }
        };
        if sweep_kind == crate::arc_bezier::ArcSweepKind::FullCircle {
            return Ok(Classification::Decided(Real::tau()));
        }
        directed_radial_angle(self, self.end(), policy)
    }

    pub(crate) fn fragment_between_sweep_range(
        &self,
        start: Point2,
        end: Point2,
        source_range: &ParamRange,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Self>> {
        if let Some(fragment) = self.retained_fragment(source_range, &start, &end) {
            return Ok(Classification::Decided(fragment));
        }
        let source_sweep = match self.retained_directed_sweep_angle(policy)? {
            Classification::Decided(angle) => angle.clone(),
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        let source_sweep_is_certified = self
            .retained_facts
            .directed_sweep_angle
            .certified()
            .is_some();
        let (root_start, root_sweep_angle, parent_root_range) =
            if let Some(lineage) = self.retained_facts.parameter_lineage.get() {
                (
                    lineage.root_start.clone(),
                    lineage.root_sweep_angle.clone(),
                    lineage.root_range.clone(),
                )
            } else {
                (
                    self.start().clone(),
                    source_sweep,
                    ParamRange::new(Real::zero(), Real::one()),
                )
            };
        let parent_root_width = parent_root_range.end() - parent_root_range.start();
        let root_range = ParamRange::new(
            parent_root_range.start() + &(&parent_root_width * source_range.start()),
            parent_root_range.start() + &(&parent_root_width * source_range.end()),
        );
        let fragment_sweep = &root_sweep_angle * (root_range.end() - root_range.start());
        let fragment = Self::new_with_certified_radius(
            start.clone(),
            end.clone(),
            self.center().clone(),
            self.radius_squared(),
            self.is_clockwise(),
            None,
        );
        let _ =
            fragment
                .retained_facts
                .parameter_lineage
                .set(Box::new(CircularArcParameterLineage2 {
                    root_start,
                    root_sweep_angle,
                    root_range,
                }));
        if source_sweep_is_certified {
            fragment
                .retained_facts
                .directed_sweep_angle
                .seed_certified(fragment_sweep.clone());
            if let Some(kind) =
                sweep_kind_from_directed_angle(&fragment_sweep, &policy.strict_counterpart())
            {
                fragment.retained_facts.sweep_kind.seed_certified(kind);
            }
        }
        self.retain_fragment(source_range, &start, &end, &fragment);
        Ok(Classification::Decided(fragment))
    }

    fn retained_fragment(
        &self,
        source_range: &ParamRange,
        start: &Point2,
        end: &Point2,
    ) -> Option<Self> {
        let fragments = self.retained_facts.fragments.get()?;
        fragments
            .lock()
            .expect("arc fragment cache mutex poisoned")
            .iter()
            .find(|witness| {
                witness.source_range == *source_range
                    && witness.start == *start
                    && witness.end == *end
            })
            .map(|witness| witness.fragment.clone())
    }

    fn retain_fragment(
        &self,
        source_range: &ParamRange,
        start: &Point2,
        end: &Point2,
        fragment: &Self,
    ) {
        let fragments = self
            .retained_facts
            .fragments
            .get_or_init(|| Box::new(Mutex::new(Vec::new())));
        let mut fragments = fragments.lock().expect("arc fragment cache mutex poisoned");
        if fragments.len() == MAX_RETAINED_ARC_FRAGMENTS {
            fragments.remove(0);
        }
        fragments.push(CircularArcFragmentWitness2 {
            source_range: source_range.clone(),
            start: start.clone(),
            end: end.clone(),
            fragment: fragment.clone(),
        });
    }

    pub(crate) fn sweep_fraction_for_incident_point(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Real>> {
        match points_equal(point, self.start(), policy) {
            Some(true) => return Ok(Classification::Decided(Real::zero())),
            Some(false) => {}
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::RealSign,
                ));
            }
        }
        match points_equal(point, self.end(), policy) {
            Some(true) => return Ok(Classification::Decided(Real::one())),
            Some(false) => {}
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::RealSign,
                ));
            }
        }

        let point_angle = match directed_radial_angle(self, point, policy)? {
            Classification::Decided(angle) => angle,
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        let total_angle = match self.retained_directed_sweep_angle(policy)? {
            Classification::Decided(angle) => angle.clone(),
            Classification::Uncertain(reason) => {
                return Ok(Classification::Uncertain(reason));
            }
        };
        let parameter = (point_angle / total_angle).map_err(CurveError::from)?;
        self.retain_parameter_witness(&parameter, point);
        Ok(Classification::Decided(parameter))
    }

    /// Returns this arc with traversal direction reversed.
    pub fn reversed(&self) -> Self {
        Self::from_geometry(
            self.end().clone(),
            self.start().clone(),
            self.center().clone(),
            self.radius_squared(),
            self.endpoints_on_stored_circle_are_certified(),
            !self.is_clockwise(),
            self.bulge().map(|bulge| -bulge.clone()),
        )
    }
}

/// A native line or circular-arc segment.
#[derive(Clone, Debug, PartialEq)]
#[allow(clippy::large_enum_variant)]
pub enum Segment2 {
    /// Straight line segment.
    Line(LineSeg2),
    /// Circular arc segment.
    Arc(CircularArc2),
}

impl Segment2 {
    /// Returns the segment primitive family without computing structural facts.
    pub const fn kind(&self) -> crate::SegmentKind {
        match self {
            Self::Line(_) => crate::SegmentKind::Line,
            Self::Arc(_) => crate::SegmentKind::Arc,
        }
    }

    /// Constructs a native segment from a bulge value.
    ///
    /// Zero bulge maps to a line. Nonzero bulge maps to a circular arc.
    pub fn from_bulge(start: Point2, end: Point2, bulge: Real) -> CurveResult<Self> {
        match bulge.zero_status() {
            ZeroKnowledge::Zero => LineSeg2::try_new(start, end).map(Self::Line),
            ZeroKnowledge::NonZero => CircularArc2::from_bulge(start, end, bulge).map(Self::Arc),
            ZeroKnowledge::Unknown => Err(CurveError::AmbiguousBulge),
        }
    }

    /// Returns the segment start point.
    pub fn start(&self) -> &Point2 {
        match self {
            Self::Line(line) => line.start(),
            Self::Arc(arc) => arc.start(),
        }
    }

    /// Returns the segment end point.
    pub fn end(&self) -> &Point2 {
        match self {
            Self::Line(line) => line.end(),
            Self::Arc(arc) => arc.end(),
        }
    }

    /// Classifies whether a point lies on this finite segment.
    pub fn contains_point(&self, point: &Point2) -> crate::ExactCurveResult<bool> {
        crate::ExactCurveError::decided(
            crate::CurveOperation2::Classification,
            self.contains_point_with_policy(point, &crate::policy::principal_context()),
        )
    }

    /// [`Self::contains_point`] under an explicit predicate policy.
    pub(crate) fn contains_point_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<bool> {
        match self {
            Self::Line(line) => line.contains_point_with_policy(point, policy),
            Self::Arc(arc) => arc.contains_point_with_policy(point, policy),
        }
    }

    /// Returns conservative structural facts for this native segment.
    pub fn structural_facts(&self) -> crate::Segment2Facts {
        crate::facts::segment_facts(self)
    }

    /// Returns a point in the interior of this segment.
    pub fn representative_point(&self) -> crate::ExactCurveResult<Point2> {
        self.representative_point_with_policy(&crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid_unattributed(
                    crate::CurveOperation2::Evaluation,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided(crate::CurveOperation2::Evaluation, value)
            })
    }

    /// [`Self::representative_point`] under an explicit predicate policy.
    pub(crate) fn representative_point_with_policy(
        &self,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Point2>> {
        let half = (Real::one() / Real::from(2_i8))?;
        self.point_at_with_policy(&half, policy)
    }

    /// Evaluates this segment at a normalized traversal parameter in `[0, 1]`.
    pub fn point_at(&self, parameter: &Real) -> crate::ExactCurveResult<Point2> {
        self.point_at_with_policy(parameter, &crate::policy::principal_context())
            .map_err(|cause| {
                crate::ExactCurveError::invalid_unattributed(
                    crate::CurveOperation2::Evaluation,
                    cause,
                )
            })
            .and_then(|value| {
                crate::ExactCurveError::decided(crate::CurveOperation2::Evaluation, value)
            })
    }

    /// [`Self::point_at`] under an explicit predicate policy.
    pub(crate) fn point_at_with_policy(
        &self,
        parameter: &Real,
        policy: &CurveContext,
    ) -> CurveResult<Classification<Point2>> {
        match in_closed_unit_interval(parameter, policy) {
            Some(true) => {}
            Some(false) => return Err(CurveError::InvalidCurveParameter),
            None => {
                return Ok(Classification::Uncertain(
                    crate::UncertaintyReason::Ordering,
                ));
            }
        }
        match self {
            Self::Line(line) => Ok(Classification::Decided(line.point_at(parameter.clone()))),
            Self::Arc(arc) => match arc.rational_bezier_decomposition_raw(policy) {
                Ok(Classification::Uncertain(reason)) => Ok(Classification::Uncertain(reason)),
                Ok(Classification::Decided(decomposition)) => {
                    match decomposition.point_at_raw(parameter, policy) {
                        Ok(point) => Ok(Classification::Decided(point)),
                        Err(crate::ExactCurveError::Invalid { cause, .. }) => Err(cause),
                        Err(crate::ExactCurveError::Blocked(blocker)) => {
                            Ok(Classification::Uncertain(blocker.reason()))
                        }
                    }
                }
                Err(crate::ExactCurveError::Invalid { cause, .. }) => Err(cause),
                Err(crate::ExactCurveError::Blocked(blocker)) => {
                    Ok(Classification::Uncertain(blocker.reason()))
                }
            },
        }
    }

    /// Returns this segment with traversal direction reversed.
    pub fn reversed(&self) -> Self {
        match self {
            Self::Line(line) => Self::Line(line.reversed()),
            Self::Arc(arc) => Self::Arc(arc.reversed()),
        }
    }
}

#[allow(clippy::large_enum_variant)]
enum ParameterOnLine {
    Decided(Real),
    Uncertain(crate::UncertaintyReason),
}

fn parameter_on_line(line: &LineSeg2, point: &Point2, policy: &CurveContext) -> ParameterOnLine {
    let (dx, dy) = line.delta();
    let delta = point.delta_from(line.start());

    match is_zero(&dx, policy) {
        Some(false) => match delta.0 / dx {
            Ok(t) => ParameterOnLine::Decided(t),
            Err(_) => ParameterOnLine::Uncertain(crate::UncertaintyReason::RealSign),
        },
        Some(true) => match delta.1 / dy {
            Ok(t) => ParameterOnLine::Decided(t),
            Err(_) => ParameterOnLine::Uncertain(crate::UncertaintyReason::RealSign),
        },
        None => match is_zero(&dy, policy) {
            Some(false) => match delta.1 / dy {
                Ok(t) => ParameterOnLine::Decided(t),
                Err(_) => ParameterOnLine::Uncertain(crate::UncertaintyReason::RealSign),
            },
            Some(true) => ParameterOnLine::Uncertain(crate::UncertaintyReason::RealSign),
            None => ParameterOnLine::Uncertain(crate::UncertaintyReason::RealSign),
        },
    }
}

fn clockwise_from_bulge(bulge: &Real) -> CurveResult<bool> {
    if let Some(sign) = bulge.structural_facts().sign {
        return match sign {
            RealSign::Negative => Ok(true),
            RealSign::Positive => Ok(false),
            RealSign::Zero => Err(CurveError::AmbiguousBulge),
        };
    }

    // Bulge sign chooses the arc sweep orientation, so route it through the
    // shared predicate policy used by the rest of curve topology.
    match crate::classify::real_sign(bulge, &CurveContext::STRICT) {
        Some(RealSign::Negative) => Ok(true),
        Some(RealSign::Positive) => Ok(false),
        Some(RealSign::Zero) => Err(CurveError::AmbiguousBulge),
        None => Err(CurveError::AmbiguousBulge),
    }
}

fn ordered_line_endpoints<'a>(
    line: &'a LineSeg2,
    use_x: bool,
    policy: &CurveContext,
) -> Option<(&'a Real, &'a Real)> {
    let (start, end) = if use_x {
        (line.start().x(), line.end().x())
    } else {
        (line.start().y(), line.end().y())
    };
    match compare_reals(start, end, policy)? {
        Ordering::Less | Ordering::Equal => Some((start, end)),
        Ordering::Greater => Some((end, start)),
    }
}

fn points_equal(left: &Point2, right: &Point2, policy: &CurveContext) -> Option<bool> {
    if left == right {
        return Some(true);
    }
    crate::classify::is_zero(&left.distance_squared(right), policy)
}

fn directed_radial_angle(
    arc: &CircularArc2,
    point: &Point2,
    policy: &CurveContext,
) -> CurveResult<Classification<Real>> {
    let start = arc.start().delta_from(arc.center());
    let radial = point.delta_from(arc.center());
    let cross = (&start.0 * &radial.1) - (&start.1 * &radial.0);
    let directed_cross = if arc.is_clockwise() { -cross } else { cross };
    let dot = (&start.0 * &radial.0) + (&start.1 * &radial.1);
    let Some(cross_sign) = crate::classify::real_sign(&directed_cross, policy) else {
        return Ok(Classification::Uncertain(
            crate::UncertaintyReason::RealSign,
        ));
    };
    let Some(dot_sign) = crate::classify::real_sign(&dot, policy) else {
        return Ok(Classification::Uncertain(
            crate::UncertaintyReason::RealSign,
        ));
    };
    let angle = match (cross_sign, dot_sign) {
        (RealSign::Zero, RealSign::Positive) => Real::zero(),
        (RealSign::Zero, RealSign::Negative) => Real::pi(),
        (RealSign::Zero, RealSign::Zero) => {
            return Err(CurveError::InvalidCurveParameter);
        }
        (RealSign::Positive, RealSign::Zero) => (Real::pi() / Real::from(2_i8))?,
        (RealSign::Negative, RealSign::Zero) => (Real::from(3_i8) * Real::pi() / Real::from(2_i8))?,
        (cross_sign, RealSign::Positive) => {
            let base = (directed_cross / dot)?.atan()?;
            if cross_sign == RealSign::Positive {
                base
            } else {
                base + Real::tau()
            }
        }
        (_, RealSign::Negative) => (directed_cross / dot)?.atan()? + Real::pi(),
    };
    Ok(Classification::Decided(angle))
}

fn sweep_kind_from_directed_angle(
    angle: &Real,
    policy: &CurveContext,
) -> Option<crate::arc_bezier::ArcSweepKind> {
    match compare_reals(angle, &Real::tau(), policy)? {
        Ordering::Equal => return Some(crate::arc_bezier::ArcSweepKind::FullCircle),
        Ordering::Greater => return None,
        Ordering::Less => {}
    }
    Some(match compare_reals(angle, &Real::pi(), policy)? {
        Ordering::Less => crate::arc_bezier::ArcSweepKind::Minor,
        Ordering::Equal => crate::arc_bezier::ArcSweepKind::Semicircle,
        Ordering::Greater => crate::arc_bezier::ArcSweepKind::Major,
    })
}

#[cfg(test)]
mod retained_delta_tests {
    use super::*;

    #[test]
    fn certified_ray_delta_survives_reversal_and_equal_endpoint_representations() {
        let origin = Point2::new(
            Real::pi() + Real::from(2).sqrt().unwrap(),
            Real::e() + Real::from(3).sqrt().unwrap(),
        );
        let line = LineSeg2::from_certified_nonzero_delta(origin, Real::one(), Real::from(-2));
        assert!(line.endpoints_decided_distinct());
        for forward in [
            line.clone(),
            line.with_endpoint_representations(line.start().clone(), line.end().clone())
                .unwrap(),
        ] {
            assert_eq!(forward.delta(), (Real::one(), Real::from(-2)));
            for reverse in [forward.reversed(), forward.clone().into_reversed()] {
                assert_eq!(reverse.delta(), (Real::from(-1), Real::from(2)));
                assert_eq!(reverse.start(), forward.end());
                assert_eq!(reverse.end(), forward.start());
            }
        }
    }

    #[test]
    fn mapped_and_cut_lines_do_not_reuse_the_source_displacement() {
        let line = LineSeg2::from_certified_nonzero_delta(
            Point2::from_values(5, 7),
            Real::from(2),
            Real::from(4),
        );
        let mapped = line
            .map_points(|point| Point2::new(point.x() * Real::from(3), -point.y()))
            .unwrap();
        assert_eq!(mapped.delta(), (Real::from(6), Real::from(-4)));
        let cut = line.fragment_between_after_distinct_endpoints(
            Point2::from_values(6, 9),
            line.end().clone(),
            line.fragment_support(),
        );
        assert_eq!(cut.delta(), (Real::one(), Real::from(2)));
        assert_eq!(cut.support_delta(), (Real::from(2), Real::from(4)));
    }

    #[test]
    fn repeated_parallel_offsets_retain_the_exact_source_displacement() {
        let origin = Point2::new(Real::pi(), Real::e());
        let mut line = LineSeg2::from_certified_nonzero_delta(origin, Real::one(), Real::from(2));
        for distance in [Real::one(), Real::pi(), Real::from(-3)] {
            let previous = line.clone();
            line = line.offset_left(distance.clone()).unwrap();
            assert!(line.endpoints_decided_distinct());
            assert_eq!(line.delta(), (Real::one(), Real::from(2)));
            assert_eq!(line.reversed().delta(), (Real::from(-1), Real::from(-2)));
            let normal_scale = (distance / Real::from(5).sqrt().unwrap()).unwrap();
            for (before, after) in [
                (previous.start(), line.start()),
                (previous.end(), line.end()),
            ] {
                for (actual, expected) in [
                    (after.x(), before.x() - Real::from(2) * &normal_scale),
                    (after.y(), before.y() + &normal_scale),
                ] {
                    assert_eq!(
                        compare_reals(actual, &expected, &CurveContext::STRICT),
                        Some(Ordering::Equal)
                    );
                }
            }
        }
    }

    #[test]
    fn equal_endpoint_representations_keep_parallel_offset_certificates() {
        let source = LineSeg2::from_certified_nonzero_delta(
            Point2::new(Real::pi(), Real::e()),
            Real::one(),
            Real::from(2),
        );
        let left = source.offset_left(Real::one()).unwrap();
        let farther = source.offset_left(Real::from(2)).unwrap();
        let rebuilt = left
            .with_endpoint_representations(left.start().clone(), left.end().clone())
            .unwrap();
        for policy in [CurveContext::STRICT, CurveContext::APPROXIMATE_512] {
            assert_eq!(
                rebuilt.retained_offset_relation(&left, &policy),
                Some(RetainedLineRelation2::Coincident)
            );
            assert_eq!(
                rebuilt.retained_offset_relation(&farther, &policy),
                Some(RetainedLineRelation2::ParallelDistinct)
            );
            assert_eq!(
                rebuilt.reversed().retained_offset_relation(&left, &policy),
                Some(RetainedLineRelation2::Coincident)
            );
            assert!(
                rebuilt
                    .intersect_line_with_policy(&farther, &policy)
                    .unwrap()
                    .is_none()
            );
        }
    }

    #[test]
    fn split_support_preserves_direction_but_arbitrary_maps_recompute_it() {
        let source = LineSeg2::from_certified_nonzero_delta(
            Point2::new(Real::pi(), Real::e()),
            Real::one(),
            Real::from(2),
        )
        .offset_left(Real::one())
        .unwrap();
        let cut = source.fragment_between_after_distinct_endpoints(
            source.point_at((Real::one() / Real::from(2)).unwrap()),
            source.end().clone(),
            source.fragment_support(),
        );
        assert!(Arc::ptr_eq(
            cut.support.get().unwrap().retained_delta.as_ref().unwrap(),
            source.retained_delta.as_ref().unwrap(),
        ));
        assert_eq!(cut.support_delta(), (Real::one(), Real::from(2)));
        assert_eq!(
            cut.reversed().directed_support_delta(),
            (Real::from(-1), Real::from(-2))
        );
        let mapped = cut
            .map_points(|p| Point2::new(p.x() * Real::from(3), -p.y()))
            .unwrap();
        assert!(mapped.support.get().unwrap().retained_delta.is_none());
        assert!(mapped.offset_provenance.is_none());
        let (dx, dy) = mapped.support_delta();
        assert_eq!(
            compare_reals(&dx, &Real::from(3), &CurveContext::STRICT),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(&dy, &Real::from(-2), &CurveContext::STRICT),
            Some(Ordering::Equal)
        );
    }
}

#[cfg(test)]
mod policy_cache_tests {
    use super::*;

    fn point(x: i8, y: i8) -> Point2 {
        Point2::new(Real::from(x), Real::from(y))
    }

    #[test]
    fn sweep_membership_uses_a_decisive_half_plane() {
        let sine = Real::e().sin();
        let cosine = Real::e().cos();
        let unresolved_zero = &sine * &sine + &cosine * &cosine - Real::one();
        let opposite = Point2::new(Real::from(-1), unresolved_zero.clone());
        let boundary = Point2::new(Real::one(), unresolved_zero);
        assert!(
            classify_oriented_line(&point(0, 0), &point(1, 0), &opposite, &CurveContext::STRICT,)
                .is_uncertain()
        );
        for major in [false, true] {
            let arc = CircularArc2::try_from_center(point(1, 0), point(0, 1), point(0, 0), major)
                .unwrap();
            for arc in [arc.clone(), arc.reversed()] {
                let prepared = crate::prepared::PreparedCircularArc2::from_circular_arc(&arc);
                for policy in [CurveContext::STRICT, CurveContext::APPROXIMATE_512] {
                    policy.strict_predicate_pass(|| {
                        // The opposite radial ray is excluded by the minor
                        // sweep's other side and included by the major sweep.
                        // Reversal swaps which side carries the unknown sign.
                        for result in [
                            arc.contains_sweep_point_with_policy(&opposite, &policy),
                            prepared.contains_sweep_point(&opposite, &policy),
                        ] {
                            assert_eq!(result, Classification::Decided(major));
                        }
                        // At the positive ray the unresolved side is essential;
                        // the same optimization must preserve that uncertainty.
                        assert!(
                            arc.contains_sweep_point_with_policy(&boundary, &policy)
                                .is_uncertain()
                        );
                        assert!(
                            prepared
                                .contains_sweep_point(&boundary, &policy)
                                .is_uncertain()
                        );
                    });
                }
            }
        }
    }

    #[test]
    fn approximate_sweep_fragment_does_not_gain_certified_cache_facts() {
        let sine = Real::e().sin();
        let cosine = Real::e().cos();
        let undecidable_zero = &sine * &sine + &cosine * &cosine - Real::one();
        let center = Point2::new(Real::from(3_i8) + undecidable_zero, Real::one());
        let start = point(3, 0);
        let end = point(3, 2);
        let arc = CircularArc2::new_with_certified_radius(
            start.clone(),
            end,
            center.clone(),
            start.distance_squared(&center),
            false,
            None,
        );
        let half = (Real::one() / Real::from(2_i8)).unwrap();

        let Classification::Decided((first, _)) = arc
            .split_at_sweep_fraction_with_policy(&half, &CurveContext::APPROXIMATE_512)
            .unwrap()
        else {
            panic!("the authorized terminal must split the ambiguous semicircle");
        };
        assert!(
            first
                .retained_facts
                .directed_sweep_angle
                .certified()
                .is_none()
        );
        assert!(first.retained_facts.sweep_kind.certified().is_none());
    }
}
