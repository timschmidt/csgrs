//! Design-readiness checks grouped by the data model they operate on.
//!
//! `layer` checks work on already-flattened 2D geometry such as Gerber-derived
//! `Profile` layers. `drill` checks focus on holes, slots, and cross-source drill
//! tables. `board` checks use richer board context such as KiCad nets, vias,
//! component features, and panel intent.
//! `safety` checks focus on voltage, board-edge, and ESD protective-interface
//! readiness that benefits from board context but has a distinct review owner.
//! `signal` checks focus on mixed-signal partitioning and quiet-net guard or
//! return-path proximity.
//! `continuity` checks focus on same-net geometry that may be electrically
//! severed even when source net names still match.
//! `differential` checks focus on differential-pair coupling and spacing review
//! that benefits from net-name intent plus exact copper geometry.
//! `return_path` checks focus on split-plane and reference-island hazards for
//! high-speed copper.
//! `power_integrity` checks focus on high-current pad-entry and copper-spreading
//! readiness.
//! `mechanical` checks focus on chassis, mounting, and keepout intent that uses
//! board context but is primarily mechanical production readiness.

mod artifact_handoff;
mod artifact_table;
mod artifacts;
pub mod assembly;
#[cfg(test)]
mod authored_center_regressions;
pub mod board;
mod constraints;
pub mod continuity;
#[cfg(test)]
mod dense_cluster_regressions;
pub mod dense_pad;
pub mod differential;
mod distance;
pub mod drill;
#[cfg(test)]
mod drill_native_regressions;
mod excellon;
#[cfg(test)]
mod fixture_access_regressions;
mod impedance;
#[cfg(test)]
mod ipc_native_regressions;
pub mod layer;
#[cfg(test)]
mod layer_order_regressions;
pub mod manifest;
mod measurements;
pub mod mechanical;
#[cfg(test)]
mod point_consumer_regressions;
use measurements::minimum_bounding_dimension;
mod net_class;
mod net_scope;
mod outline;
pub mod power;
pub mod power_integrity;
pub mod return_path;
pub mod rf;
pub mod safety;
pub mod signal;
mod spatial;
mod spread;
pub mod stencil;
mod surface_finish;
pub mod thermal;

pub use artifacts::*;
pub use assembly::*;
pub use board::*;
pub use constraints::*;
pub use continuity::*;
pub use dense_pad::*;
pub use differential::*;
pub use drill::*;
pub use excellon::*;
pub use layer::*;
pub use manifest::*;
pub use mechanical::*;
pub use power::*;
pub use power_integrity::*;
pub use return_path::*;
pub use rf::*;
pub use safety::*;
pub use signal::*;
pub use stencil::*;
pub use thermal::*;

use crate::report::{Severity, Violation};
use crate::{PcbGeometryUncertainty, PcbRegion, Scalar};

/// Run a check whose report geometry can fail, retaining the operation and
/// source in the same explicit finding path as native metric failures.
pub(crate) fn run_geometry_check(
    requested_check: &str,
    layers: &[&str],
    check: impl FnOnce() -> Result<Vec<Violation>, PcbGeometryUncertainty>,
) -> Vec<Violation> {
    check().unwrap_or_else(|uncertainty| {
        let layers = if layers.is_empty() {
            uncertainty.source.iter().cloned().collect()
        } else {
            layers.iter().map(|name| (*name).to_owned()).collect()
        };
        vec![geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        )]
    })
}

/// Check native emptiness without turning a source or budget failure into a
/// successful early exit from a readiness check.
pub(crate) fn is_empty_for_check(
    region: &PcbRegion,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<bool, Box<Violation>> {
    region.try_is_empty().map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

/// Retain a failed geometry query in the check's findings before allowing its
/// candidate walk to continue. `None` must never silently erase uncertainty.
pub(crate) fn geometry_result_for_check<T>(
    result: Result<T, PcbGeometryUncertainty>,
    requested_check: &str,
    layers: &[&str],
    violations: &mut Vec<Violation>,
) -> Option<T> {
    match result {
        Ok(value) => Some(value),
        Err(uncertainty) => {
            violations.push(geometry_uncertainty_violation(
                requested_check,
                layers.iter().map(|layer| (*layer).to_owned()).collect(),
                uncertainty,
            ));
            None
        }
    }
}

/// Attribute a required query to its selected check before propagating failure.
pub(crate) fn required_geometry_for_check<T>(
    result: Result<T, PcbGeometryUncertainty>,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<T, Box<Violation>> {
    result.map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

/// Regularize a collection before measuring covered material. Authored pieces
/// may repeat or overlap; their individual areas and counts are not additive.
pub(crate) fn combine_regions(
    mut regions: Vec<PcbRegion>,
) -> Result<PcbRegion, PcbGeometryUncertainty> {
    crate::operations::evaluate("coverage-union", None, || {
        for region in &regions {
            region.ensure_exact_geometry("coverage-union")?;
        }
        if regions.is_empty() {
            return Ok(crate::geometry::empty_profile(None));
        }
        while regions.len() > 1 {
            let mut next = Vec::with_capacity(regions.len().div_ceil(2));
            let mut pairs = regions.into_iter();
            while let Some(left) = pairs.next() {
                next.push(match pairs.next() {
                    Some(right) => left.try_union(&right)?,
                    None => left,
                });
            }
            regions = next;
        }
        Ok(regions
            .pop()
            .expect("nonempty union reduction retains one region"))
    })
}

pub(crate) fn boundary_distance_for_check(
    left: &PcbRegion,
    right: &PcbRegion,
    requested_check: &str,
    layers: &[&str],
    violations: &mut Vec<Violation>,
) -> Option<Scalar> {
    geometry_result_for_check(
        distance::region_boundary_distance(left, right),
        requested_check,
        layers,
        violations,
    )
    .flatten()
}

pub(crate) fn metric_cmp_for_check(
    left: &Scalar,
    right: &Scalar,
    requested_check: &str,
    layers: &[&str],
    violations: &mut Vec<Violation>,
) -> Option<std::cmp::Ordering> {
    geometry_result_for_check(
        distance::compare_metrics(left, right),
        requested_check,
        layers,
        violations,
    )
}

pub(crate) fn boundaries_within_for_check(
    left: &PcbRegion,
    right: &PcbRegion,
    threshold: &Scalar,
    requested_check: &str,
    layers: &[&str],
    violations: &mut Vec<Violation>,
) -> Option<bool> {
    geometry_result_for_check(
        distance::region_boundaries_within(left, right, threshold),
        requested_check,
        layers,
        violations,
    )
}

pub(crate) fn point_boundary_within_for_check(
    point: &[Scalar; 2],
    region: &PcbRegion,
    threshold: &Scalar,
    requested_check: &str,
    layers: &[&str],
    violations: &mut Vec<Violation>,
) -> Option<bool> {
    geometry_result_for_check(
        distance::point_region_boundary_within(point, region, threshold),
        requested_check,
        layers,
        violations,
    )
}

pub(crate) fn offset_for_check(
    region: &PcbRegion,
    distance: Scalar,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<PcbRegion, Box<Violation>> {
    if crate::scalar::sign(&distance) == Some(hyperlimit::Sign::Zero) {
        return Ok(region.clone());
    }
    region.offset(distance).map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

pub(crate) fn intersection_for_check(
    left: &PcbRegion,
    right: &PcbRegion,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<PcbRegion, Box<Violation>> {
    left.try_intersection(right).map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

pub(crate) fn difference_for_check(
    left: &PcbRegion,
    right: &PcbRegion,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<PcbRegion, Box<Violation>> {
    left.try_difference(right).map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

pub(crate) fn union_for_check(
    left: &PcbRegion,
    right: &PcbRegion,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<PcbRegion, Box<Violation>> {
    left.try_union(right).map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

#[allow(dead_code)] // Kept with the complete Boolean gateway set for future XOR-based checks.
pub(crate) fn xor_for_check(
    left: &PcbRegion,
    right: &PcbRegion,
    requested_check: &str,
    layers: Vec<String>,
) -> Result<PcbRegion, Box<Violation>> {
    left.try_xor(right).map_err(|uncertainty| {
        Box::new(geometry_uncertainty_violation(
            requested_check,
            layers,
            uncertainty,
        ))
    })
}

pub(crate) fn geometry_uncertainty_violation(
    requested_check: &str,
    layers: Vec<String>,
    uncertainty: PcbGeometryUncertainty,
) -> Violation {
    Violation::new(
        "geometry-uncertainty",
        Severity::Error,
        layers,
        None,
        Vec::new(),
        Vec::new(),
        Some(format!(
            "{requested_check} could not certify required geometry: {uncertainty}"
        )),
    )
}

#[cfg(test)]
mod exact_math_audit_tests {
    use std::fs;
    use std::path::Path;

    use hypercurve::CurveRegion2;

    use super::intersection_for_check;
    use crate::PcbRegion;

    #[test]
    fn construction_failure_is_reported_instead_of_intersecting_as_empty() {
        let failed = PcbRegion::new(CurveRegion2::empty(), None)
            .with_exact_construction_error("regression sentinel");
        let valid = PcbRegion::new(CurveRegion2::empty(), None);

        let violation = intersection_for_check(
            &failed,
            &valid,
            "construction-failure-regression",
            vec!["F.Cu".to_string()],
        )
        .expect_err("failed exact construction must block Boolean evaluation");

        assert_eq!(violation.check, "geometry-uncertainty");
        assert!(
            violation
                .message
                .as_deref()
                .is_some_and(|message| message.contains("regression sentinel"))
        );
    }

    #[test]
    fn production_geometry_uses_fallible_boolean_gateways() {
        let checks_dir = Path::new(env!("CARGO_MANIFEST_DIR")).join("src/checks");
        for entry in fs::read_dir(&checks_dir).expect("read check modules") {
            let entry = entry.expect("read check module entry");
            let path = entry.path();
            if path.extension().and_then(|extension| extension.to_str()) != Some("rs") {
                continue;
            }
            let file_name = path
                .file_name()
                .and_then(|name| name.to_str())
                .unwrap_or("");
            let source = fs::read_to_string(&path).expect("read check module source");
            if file_name != "mod.rs" {
                for forbidden in [
                    ".try_union(",
                    ".try_difference(",
                    ".try_intersection(",
                    ".try_xor(",
                ] {
                    assert!(
                        !source.contains(forbidden),
                        "{} bypasses the typed geometry-uncertainty gateway with {forbidden}",
                        path.display()
                    );
                }
            }
            for forbidden in [".union(", ".difference(", ".intersection(", ".xor("] {
                if source.contains(forbidden) {
                    assert!(
                        matches!(
                            file_name,
                            "artifacts.rs" | "constraints.rs" | "differential.rs" | "mod.rs"
                        ),
                        "{} contains an infallible geometry Boolean call {forbidden}",
                        path.display()
                    );
                }
            }
        }

        let authoring = fs::read_to_string(
            Path::new(env!("CARGO_MANIFEST_DIR")).join("src/authoring_intent.rs"),
        )
        .expect("read authoring intent source");
        for forbidden in [
            ".try_union(",
            ".try_difference(",
            ".try_intersection(",
            ".try_xor(",
            ".union(",
            ".difference(",
            ".intersection(",
            ".xor(",
        ] {
            assert!(
                !authoring.contains(forbidden),
                "authoring intent bypasses the typed geometry-uncertainty gateway with {forbidden}"
            );
        }
    }
}

#[cfg(test)]
mod bounds_regressions;
