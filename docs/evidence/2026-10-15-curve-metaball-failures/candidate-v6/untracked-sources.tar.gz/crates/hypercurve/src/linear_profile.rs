//! Lossless line-contour views of already classified material/hole profiles.

use crate::{
    Contour2, CurveGeometry2, CurveOperation2, CurveRegionBoundaryLoop2, CurveRegionProfile2,
    ExactCurveError, ExactCurveResult, Segment2,
};

impl CurveRegionProfile2<'_> {
    /// Retain exact line segments and their material/hole ownership.
    ///
    /// Returns `None` if any boundary lacks a native line certificate. This is
    /// a representation query, not permission to replace a curved boundary by
    /// display chords. No coordinate passes through a finite projection.
    pub fn linear_contours(&self) -> ExactCurveResult<Option<(Contour2, Vec<Contour2>)>> {
        fn contour(boundary: &CurveRegionBoundaryLoop2) -> ExactCurveResult<Option<Contour2>> {
            let Some(segments) = boundary
                .curves()
                .iter()
                .map(|curve| match curve.geometry() {
                    Some(CurveGeometry2::Line(line)) => Some(Segment2::Line(line.clone())),
                    _ => None,
                })
                .collect::<Option<Vec<_>>>()
            else {
                return Ok(None);
            };
            Contour2::try_new(segments)
                .map(Some)
                .map_err(|cause| ExactCurveError::Invalid {
                    operation: CurveOperation2::NativeTopology,
                    family: Some(crate::CurveFamily2::Line),
                    cause,
                })
        }
        let Some(material) = contour(self.material())? else {
            return Ok(None);
        };
        let Some(holes) = self
            .holes()
            .iter()
            .map(|boundary| contour(boundary))
            .collect::<ExactCurveResult<Option<Vec<_>>>>()?
        else {
            return Ok(None);
        };
        Ok(Some((material, holes)))
    }
}
