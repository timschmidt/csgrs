//! Construction failure is distinct from a successfully represented empty set.
#![cfg(feature = "curve")]

use csgrs::{GeometryContext, Real, adapter::RawCurveRegion, curve};
use std::error::Error;

fn unresolved_zero() -> Real {
    let sine = Real::e().sin();
    let cosine = Real::e().cos();
    &sine * &sine + &cosine * &cosine - Real::one()
}

#[test]
fn negative_dimensions_fail_through_the_public_adapter() {
    assert!(RawCurveRegion::square(-Real::one()).is_err());
    assert!(RawCurveRegion::rectangle(Real::one(), -Real::one()).is_err());
    assert!(RawCurveRegion::circle(-Real::one(), 4).is_err());
}

#[test]
fn undecided_dimensions_do_not_become_empty_regions() {
    assert!(RawCurveRegion::square(unresolved_zero()).is_err());
}

#[test]
fn degenerate_dimensions_do_not_conceal_invalid_companions() {
    assert!(curve::rectangle_with_context(
        Real::zero(), -Real::one(), &GeometryContext::STRICT
    ).is_err());
    assert!(curve::rectangle_with_context(
        Real::zero(), unresolved_zero(), &GeometryContext::STRICT
    ).is_err());
}

#[test]
fn invalid_resolution_fails_even_for_a_zero_radius() {
    for radius in [Real::one(), Real::zero()] {
        assert!(RawCurveRegion::circle(radius, 2).is_err());
    }
}

#[test]
fn malformed_polygon_cannot_enter_a_downstream_pipeline() {
    let points = [[Real::zero(), Real::zero()], [Real::one(), Real::zero()]];
    assert!(RawCurveRegion::polygon(&points).is_err());
    assert!(RawCurveRegion::polygon(&[]).is_err());
}

#[test]
fn native_polygon_cause_survives_the_modeling_wrapper() {
    let error = curve::polygon_with_context(&[], &GeometryContext::STRICT).unwrap_err();
    assert!(error.source().is_some(), "native cause was flattened: {error:?}");
}

#[test]
fn compound_constructors_reject_invalid_parameters() {
    for context in [GeometryContext::STRICT, GeometryContext::APPROXIMATE_512] {
        assert!(curve::keyhole(Real::one(), -Real::one(), Real::one(), 4, &context).is_err());
        assert!(curve::ring(Real::one(), -Real::one(), 4, &context).is_err());
        assert!(curve::reuleaux(4, Real::one(), 6, &context).is_err());
        assert!(curve::crescent(Real::one(), Real::from(2), Real::zero(), 6, &context).is_err());
        assert!(curve::circle_with_keyway(Real::one(), 4, Real::from(2), Real::one(), &context).is_err());
        assert!(curve::circle_with_flat(Real::one(), 4, Real::one(), &context).is_err());
        assert!(curve::circle_with_two_flats(Real::one(), 4, Real::one(), &context).is_err());
    }
}

#[test]
fn checked_compound_capacity_failure_is_not_successful_empty_geometry() {
    assert!(curve::rounded_rectangle_with_context(
        Real::from(4), Real::from(4), Real::one(), usize::MAX, &GeometryContext::STRICT
    ).is_err());
}

#[test]
fn undecided_compound_parameter_retains_a_typed_cause() {
    let error = curve::keyhole(
        unresolved_zero(), Real::one(), Real::one(), 4, &GeometryContext::STRICT
    ).unwrap_err();
    assert!(error.source().is_some(), "predicate cause was flattened: {error:?}");
}
